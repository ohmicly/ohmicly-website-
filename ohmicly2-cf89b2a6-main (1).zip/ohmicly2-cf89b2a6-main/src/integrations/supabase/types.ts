export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      article_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      article_references: {
        Row: {
          article_id: string
          created_at: string
          id: string
          note: string | null
          section: string | null
          standard_id: string
          url: string | null
          verified: boolean
        }
        Insert: {
          article_id: string
          created_at?: string
          id?: string
          note?: string | null
          section?: string | null
          standard_id: string
          url?: string | null
          verified?: boolean
        }
        Update: {
          article_id?: string
          created_at?: string
          id?: string
          note?: string | null
          section?: string | null
          standard_id?: string
          url?: string | null
          verified?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "article_references_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "articles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "article_references_standard_id_fkey"
            columns: ["standard_id"]
            isOneToOne: false
            referencedRelation: "standards"
            referencedColumns: ["id"]
          },
        ]
      }
      articles: {
        Row: {
          author: string
          body: string | null
          canonical_url: string | null
          category_id: string | null
          cover_image_url: string | null
          created_at: string
          created_by: string | null
          excerpt: string
          id: string
          published_at: string | null
          reading_time: string | null
          search_tsv: unknown
          seo_description: string | null
          seo_title: string | null
          slug: string
          status: Database["public"]["Enums"]["publish_status"]
          tags: string[]
          title: string
          updated_at: string
        }
        Insert: {
          author?: string
          body?: string | null
          canonical_url?: string | null
          category_id?: string | null
          cover_image_url?: string | null
          created_at?: string
          created_by?: string | null
          excerpt?: string
          id?: string
          published_at?: string | null
          reading_time?: string | null
          search_tsv?: unknown
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          status?: Database["public"]["Enums"]["publish_status"]
          tags?: string[]
          title: string
          updated_at?: string
        }
        Update: {
          author?: string
          body?: string | null
          canonical_url?: string | null
          category_id?: string | null
          cover_image_url?: string | null
          created_at?: string
          created_by?: string | null
          excerpt?: string
          id?: string
          published_at?: string | null
          reading_time?: string | null
          search_tsv?: unknown
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          status?: Database["public"]["Enums"]["publish_status"]
          tags?: string[]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "articles_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "article_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      calculator_references: {
        Row: {
          calculator_id: string
          created_at: string
          id: string
          note: string | null
          section: string | null
          standard_id: string
          url: string | null
          verified: boolean
        }
        Insert: {
          calculator_id: string
          created_at?: string
          id?: string
          note?: string | null
          section?: string | null
          standard_id: string
          url?: string | null
          verified?: boolean
        }
        Update: {
          calculator_id?: string
          created_at?: string
          id?: string
          note?: string | null
          section?: string | null
          standard_id?: string
          url?: string | null
          verified?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "calculator_references_calculator_id_fkey"
            columns: ["calculator_id"]
            isOneToOne: false
            referencedRelation: "calculators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "calculator_references_standard_id_fkey"
            columns: ["standard_id"]
            isOneToOne: false
            referencedRelation: "standards"
            referencedColumns: ["id"]
          },
        ]
      }
      calculators: {
        Row: {
          category: string
          created_at: string
          description: string
          disclaimer: string | null
          faq: Json
          formula_notes: string[]
          icon: string | null
          id: string
          is_published: boolean
          keywords: string[]
          name: string
          related_calculators: string[]
          search_tsv: unknown
          seo_description: string | null
          seo_title: string | null
          slug: string
          status: string
          thumbnail_url: string | null
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          description?: string
          disclaimer?: string | null
          faq?: Json
          formula_notes?: string[]
          icon?: string | null
          id?: string
          is_published?: boolean
          keywords?: string[]
          name: string
          related_calculators?: string[]
          search_tsv?: unknown
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          status?: string
          thumbnail_url?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          disclaimer?: string | null
          faq?: Json
          formula_notes?: string[]
          icon?: string | null
          id?: string
          is_published?: boolean
          keywords?: string[]
          name?: string
          related_calculators?: string[]
          search_tsv?: unknown
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          status?: string
          thumbnail_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      downloads: {
        Row: {
          created_at: string
          id: string
          resource_id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          resource_id: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          resource_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "downloads_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "resources"
            referencedColumns: ["id"]
          },
        ]
      }
      faqs: {
        Row: {
          answer: string
          calculator_id: string | null
          created_at: string
          id: string
          is_published: boolean
          question: string
          resource_id: string | null
          scope: string
          search_tsv: unknown
          sort_order: number
          updated_at: string
        }
        Insert: {
          answer: string
          calculator_id?: string | null
          created_at?: string
          id?: string
          is_published?: boolean
          question: string
          resource_id?: string | null
          scope?: string
          search_tsv?: unknown
          sort_order?: number
          updated_at?: string
        }
        Update: {
          answer?: string
          calculator_id?: string | null
          created_at?: string
          id?: string
          is_published?: boolean
          question?: string
          resource_id?: string | null
          scope?: string
          search_tsv?: unknown
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "faqs_calculator_id_fkey"
            columns: ["calculator_id"]
            isOneToOne: false
            referencedRelation: "calculators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "faqs_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "resources"
            referencedColumns: ["id"]
          },
        ]
      }
      favorites: {
        Row: {
          created_at: string
          resource_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          resource_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          resource_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "resources"
            referencedColumns: ["id"]
          },
        ]
      }
      premium_entitlements: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          plan: string
          source: string
          starts_at: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          plan?: string
          source?: string
          starts_at?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          plan?: string
          source?: string
          starts_at?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          headline: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          headline?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          headline?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          count: number
          key: string
          window_start: string
        }
        Insert: {
          count?: number
          key: string
          window_start?: string
        }
        Update: {
          count?: number
          key?: string
          window_start?: string
        }
        Relationships: []
      }
      resource_categories: {
        Row: {
          created_at: string
          description: string | null
          group_label: string | null
          icon: string | null
          id: string
          is_active: boolean
          name: string
          parent_id: string | null
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          group_label?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name: string
          parent_id?: string | null
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          group_label?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean
          name?: string
          parent_id?: string | null
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "resource_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "resource_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      resource_references: {
        Row: {
          created_at: string
          id: string
          note: string | null
          resource_id: string
          section: string | null
          standard_id: string
          url: string | null
          verified: boolean
        }
        Insert: {
          created_at?: string
          id?: string
          note?: string | null
          resource_id: string
          section?: string | null
          standard_id: string
          url?: string | null
          verified?: boolean
        }
        Update: {
          created_at?: string
          id?: string
          note?: string | null
          resource_id?: string
          section?: string | null
          standard_id?: string
          url?: string | null
          verified?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "resource_references_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "resource_references_standard_id_fkey"
            columns: ["standard_id"]
            isOneToOne: false
            referencedRelation: "standards"
            referencedColumns: ["id"]
          },
        ]
      }
      resource_subcategories: {
        Row: {
          created_at: string
          resource_id: string
          subcategory_id: string
        }
        Insert: {
          created_at?: string
          resource_id: string
          subcategory_id: string
        }
        Update: {
          created_at?: string
          resource_id?: string
          subcategory_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "resource_subcategories_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "resource_subcategories_subcategory_id_fkey"
            columns: ["subcategory_id"]
            isOneToOne: false
            referencedRelation: "resource_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      resource_tag_map: {
        Row: {
          resource_id: string
          tag_id: string
        }
        Insert: {
          resource_id: string
          tag_id: string
        }
        Update: {
          resource_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "resource_tag_map_resource_id_fkey"
            columns: ["resource_id"]
            isOneToOne: false
            referencedRelation: "resources"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "resource_tag_map_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "resource_tags"
            referencedColumns: ["id"]
          },
        ]
      }
      resource_tags: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      resources: {
        Row: {
          author: string
          canonical_url: string | null
          category_id: string | null
          created_at: string
          created_by: string | null
          description: string
          disclaimer: string | null
          download_count: number
          featured: boolean
          file_name: string | null
          file_path: string | null
          file_size: number | null
          file_type: string | null
          file_url: string | null
          how_to_use: string[]
          id: string
          is_free: boolean
          is_premium: boolean
          noindex: boolean
          preview_images: string[]
          primary_subcategory_id: string | null
          problem_solved: string | null
          published_at: string | null
          ranking_notes: string | null
          resource_type: Database["public"]["Enums"]["resource_kind"]
          schema_type: string
          search_tsv: unknown
          seo_description: string | null
          seo_title: string | null
          slug: string
          status: Database["public"]["Enums"]["publish_status"]
          storage_bucket: string | null
          subcategory: string | null
          tags: string[]
          thumbnail_url: string | null
          title: string
          updated_at: string
          view_count: number
          whats_included: string[]
          who_for: string | null
        }
        Insert: {
          author?: string
          canonical_url?: string | null
          category_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string
          disclaimer?: string | null
          download_count?: number
          featured?: boolean
          file_name?: string | null
          file_path?: string | null
          file_size?: number | null
          file_type?: string | null
          file_url?: string | null
          how_to_use?: string[]
          id?: string
          is_free?: boolean
          is_premium?: boolean
          noindex?: boolean
          preview_images?: string[]
          primary_subcategory_id?: string | null
          problem_solved?: string | null
          published_at?: string | null
          ranking_notes?: string | null
          resource_type?: Database["public"]["Enums"]["resource_kind"]
          schema_type?: string
          search_tsv?: unknown
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          status?: Database["public"]["Enums"]["publish_status"]
          storage_bucket?: string | null
          subcategory?: string | null
          tags?: string[]
          thumbnail_url?: string | null
          title: string
          updated_at?: string
          view_count?: number
          whats_included?: string[]
          who_for?: string | null
        }
        Update: {
          author?: string
          canonical_url?: string | null
          category_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string
          disclaimer?: string | null
          download_count?: number
          featured?: boolean
          file_name?: string | null
          file_path?: string | null
          file_size?: number | null
          file_type?: string | null
          file_url?: string | null
          how_to_use?: string[]
          id?: string
          is_free?: boolean
          is_premium?: boolean
          noindex?: boolean
          preview_images?: string[]
          primary_subcategory_id?: string | null
          problem_solved?: string | null
          published_at?: string | null
          ranking_notes?: string | null
          resource_type?: Database["public"]["Enums"]["resource_kind"]
          schema_type?: string
          search_tsv?: unknown
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          status?: Database["public"]["Enums"]["publish_status"]
          storage_bucket?: string | null
          subcategory?: string | null
          tags?: string[]
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
          view_count?: number
          whats_included?: string[]
          who_for?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "resources_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "resource_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "resources_primary_subcategory_id_fkey"
            columns: ["primary_subcategory_id"]
            isOneToOne: false
            referencedRelation: "resource_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      site_settings: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      standards: {
        Row: {
          code: string
          created_at: string
          edition: string | null
          id: string
          name: string
          publisher: string | null
          slug: string
          summary: string
          updated_at: string
          url: string | null
        }
        Insert: {
          code: string
          created_at?: string
          edition?: string | null
          id?: string
          name: string
          publisher?: string | null
          slug: string
          summary: string
          updated_at?: string
          url?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          edition?: string | null
          id?: string
          name?: string
          publisher?: string | null
          slug?: string
          summary?: string
          updated_at?: string
          url?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      consume_rate_limit: {
        Args: { _key: string; _limit: number; _window_seconds: number }
        Returns: boolean
      }
      get_published_resource_file: {
        Args: { _slug: string }
        Returns: {
          bucket: string
          is_premium: boolean
          path: string
        }[]
      }
      has_premium_access: { Args: { _user_id?: string }; Returns: boolean }
      increment_resource_download: {
        Args: { _resource_id: string }
        Returns: undefined
      }
      search_content: {
        Args: { q: string; scope?: string }
        Returns: {
          access: string
          description: string
          href: string
          id: string
          label: string
          rank: number
          title: string
          type: string
        }[]
      }
      tags_text: { Args: { _tags: string[] }; Returns: string }
    }
    Enums: {
      app_role: "user" | "admin" | "super_admin"
      publish_status: "draft" | "published" | "archived"
      resource_kind:
        | "autocad"
        | "autolisp"
        | "electrical-cad"
        | "earthing"
        | "lps"
        | "pdf-books"
        | "checklist"
        | "template"
        | "electrical-safety"
        | "electricians-zone"
        | "cv-template"
        | "guide"
        | "blog"
        | "other"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["user", "admin", "super_admin"],
      publish_status: ["draft", "published", "archived"],
      resource_kind: [
        "autocad",
        "autolisp",
        "electrical-cad",
        "earthing",
        "lps",
        "pdf-books",
        "checklist",
        "template",
        "electrical-safety",
        "electricians-zone",
        "cv-template",
        "guide",
        "blog",
        "other",
      ],
    },
  },
} as const
