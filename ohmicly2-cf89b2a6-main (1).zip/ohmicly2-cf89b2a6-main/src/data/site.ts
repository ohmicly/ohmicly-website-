/** Navigation and marketing copy. Content records live in src/lib/content. */

export type NavItem = { label: string; href: string };

export const navItems: NavItem[] = [
  { label: "Calculators", href: "/calculator" },
  { label: "Resources", href: "/resources" },
  { label: "RSC & Safety", href: "/resources?category=rsc-guidelines" },
  { label: "AutoCAD", href: "/autocad" },
  { label: "Blog", href: "/blog" },
];

export type RscItem = {
  slug: string;
  title: string;
  description: string;
  icon: string;
  /** Presentation-only metadata for the homepage resource cards. */
  fileType: "XLSX" | "PDF" | "DOCX";
  fileSize: string;
  preview: "sheet" | "shield" | "doc" | "table";
};

export const rscItems: RscItem[] = [
  {
    slug: "rsc-audit-checklists",
    title: "RSC Audit Checklists",
    description: "Electrical scope checklists structured around RSC inspection points.",
    icon: "clipboard-check",
    fileType: "XLSX",
    fileSize: "75 KB",
    preview: "sheet",
  },
  {
    slug: "nirapon-checklists",
    title: "Nirapon Checklists",
    description: "Structured checklists for Nirapon electrical assessments.",
    icon: "list-checks",
    fileType: "PDF",
    fileSize: "1.2 MB",
    preview: "shield",
  },
  {
    slug: "audit-reporting-templates",
    title: "Audit Reporting Templates",
    description: "Report formats for observations, corrective actions and evidence.",
    icon: "file-text",
    fileType: "DOCX",
    fileSize: "60 KB",
    preview: "doc",
  },
  {
    slug: "electrical-safety-checklists",
    title: "Electrical Safety Checklists",
    description: "Site verification lists for panels, cabling and earthing.",
    icon: "shield-check",
    fileType: "XLSX",
    fileSize: "120 KB",
    preview: "table",
  },
];

export const valueStrip = [
  { label: "Electrical Calculators", icon: "calculator" },
  { label: "RSC & Nirapon Resources", icon: "clipboard-check" },
  { label: "AutoCAD & AutoLISP", icon: "pen-tool" },
  { label: "Engineering Templates", icon: "layers" },
  { label: "Free Resources", icon: "download" },
];

export const whyPoints = [
  {
    icon: "calculator",
    title: "Practical Engineering Tools",
    body: "Calculators built around the checks engineers repeat on real projects.",
  },
  {
    icon: "folder-open",
    title: "Professional Resources",
    body: "Drawings, templates and checklists prepared in usable working formats.",
  },
  {
    icon: "map-pin",
    title: "Bangladesh-focused References",
    body: "Standards, audit expectations and practices relevant to local projects.",
  },
  {
    icon: "smartphone",
    title: "Mobile-friendly Experience",
    body: "Designed for use on site, not only at a desktop workstation.",
  },
  {
    icon: "graduation-cap",
    title: "Reference-driven Content",
    body: "Resources link to the standards they relate to, verified before publication.",
  },
  {
    icon: "trending-up",
    title: "Continuously Growing Library",
    body: "New tools and resources added as the platform expands.",
  },
];

export const footerColumns = [
  {
    heading: "Platform",
    links: [
      { label: "Calculators", href: "/calculator" },
      { label: "Resources", href: "/resources" },
      { label: "Premium", href: "/premium" },
      { label: "Search", href: "/search" },
    ],
  },
  {
    heading: "Resources",
    links: [
      { label: "AutoCAD", href: "/autocad" },
      { label: "AutoLISP", href: "/autolisp" },
      { label: "Templates", href: "/templates" },
      { label: "Checklists", href: "/checklists" },
      { label: "RSC & Nirapon", href: "/resources" },
    ],
  },
  {
    heading: "Knowledge",
    links: [
      { label: "Blog", href: "/blog" },
      { label: "References", href: "/references" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Contact", href: "/contact" },
      { label: "Privacy", href: "/privacy" },
      { label: "Terms", href: "/terms" },
      { label: "Disclaimer", href: "/disclaimer" },
    ],
  },
];
