import { createServerFn } from "@tanstack/react-start";
import { EMPTY_PUBLIC_BRANDING, parseBrandingSetting, toPublicBranding } from "./branding";

export const getPublicBranding = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data, error } = await supabase
      .from("site_settings")
      .select("value")
      .eq("key", "branding")
      .maybeSingle();
    if (error) throw error;
    return toPublicBranding(parseBrandingSetting(data?.value));
  } catch (error) {
    console.error("[branding] Could not load public branding", error);
    return EMPTY_PUBLIC_BRANDING;
  }
});