import { brandingAssetSchema, type BrandingAsset, type BrandingKind } from "./branding";

type InspectedImage = Pick<BrandingAsset, "mimeType" | "width" | "height">;

const readUInt24LE = (bytes: Uint8Array, offset: number) =>
  (bytes[offset] ?? 0) | ((bytes[offset + 1] ?? 0) << 8) | ((bytes[offset + 2] ?? 0) << 16);

function inspectPng(bytes: Uint8Array): InspectedImage | null {
  const signature = [137, 80, 78, 71, 13, 10, 26, 10];
  if (bytes.length < 24 || !signature.every((value, index) => bytes[index] === value)) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return { mimeType: "image/png", width: view.getUint32(16), height: view.getUint32(20) };
}

function inspectWebp(bytes: Uint8Array): InspectedImage | null {
  const ascii = (start: number, length: number) =>
    String.fromCharCode(...bytes.slice(start, start + length));
  if (bytes.length < 30 || ascii(0, 4) !== "RIFF" || ascii(8, 4) !== "WEBP") return null;
  const chunk = ascii(12, 4);
  if (chunk === "VP8X") {
    return {
      mimeType: "image/webp",
      width: readUInt24LE(bytes, 24) + 1,
      height: readUInt24LE(bytes, 27) + 1,
    };
  }
  if (chunk === "VP8L" && bytes.length >= 25 && bytes[20] === 0x2f) {
    const bits =
      (bytes[21] ?? 0) |
      ((bytes[22] ?? 0) << 8) |
      ((bytes[23] ?? 0) << 16) |
      ((bytes[24] ?? 0) << 24);
    return {
      mimeType: "image/webp",
      width: (bits & 0x3fff) + 1,
      height: ((bits >>> 14) & 0x3fff) + 1,
    };
  }
  if (chunk === "VP8 " && bytes.length >= 30) {
    return {
      mimeType: "image/webp",
      width: ((bytes[26] ?? 0) | ((bytes[27] ?? 0) << 8)) & 0x3fff,
      height: ((bytes[28] ?? 0) | ((bytes[29] ?? 0) << 8)) & 0x3fff,
    };
  }
  return null;
}

function inspectIco(bytes: Uint8Array): InspectedImage | null {
  if (bytes.length < 22 || bytes[0] !== 0 || bytes[1] !== 0 || bytes[2] !== 1 || bytes[3] !== 0) {
    return null;
  }
  const count = (bytes[4] ?? 0) | ((bytes[5] ?? 0) << 8);
  if (count < 1) return null;
  return {
    mimeType: "image/x-icon",
    width: bytes[6] || 256,
    height: bytes[7] || 256,
  };
}

function inspectSvg(bytes: Uint8Array): InspectedImage | null {
  const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes).trim();
  if (!/^<\?xml[\s\S]*?\?>\s*<svg\b|^<svg\b/i.test(text)) return null;
  if (
    /<script\b|<foreignObject\b|\son\w+\s*=|javascript:|data:text\/html|<!DOCTYPE|<!ENTITY|<iframe\b/i.test(
      text,
    )
  ) {
    throw new Error("SVG contains active or unsupported content.");
  }
  const tag = text.match(/<svg\b[^>]*>/i)?.[0];
  if (!tag) return null;
  const numeric = (name: string) => {
    const match = tag.match(new RegExp(`\\b${name}\\s*=\\s*["']\\s*([0-9.]+)`, "i"));
    return match ? Number(match[1]) : 0;
  };
  let width = numeric("width");
  let height = numeric("height");
  if (!width || !height) {
    const viewBox = tag.match(/\bviewBox\s*=\s*["']\s*[-0-9.]+[ ,]+[-0-9.]+[ ,]+([0-9.]+)[ ,]+([0-9.]+)/i);
    width = Number(viewBox?.[1] ?? 0);
    height = Number(viewBox?.[2] ?? 0);
  }
  if (!width || !height) throw new Error("SVG must define width and height or a viewBox.");
  return { mimeType: "image/svg+xml", width: Math.round(width), height: Math.round(height) };
}

export function inspectBrandingImage(bytes: Uint8Array, kind: BrandingKind): InspectedImage {
  const inspected = inspectPng(bytes) ?? inspectWebp(bytes) ?? inspectIco(bytes) ?? inspectSvg(bytes);
  if (!inspected) throw new Error("The uploaded file is not a supported image.");
  const allowed =
    kind === "logo"
      ? ["image/svg+xml", "image/png", "image/webp"]
      : ["image/svg+xml", "image/png", "image/x-icon"];
  if (!allowed.includes(inspected.mimeType)) throw new Error("This image format is not allowed here.");
  if (kind === "favicon" && inspected.width !== inspected.height) {
    throw new Error("Favicon artwork must be square.");
  }
  return inspected;
}

export function parseStoredBrandingAsset(value: unknown): BrandingAsset | null {
  const parsed = brandingAssetSchema.safeParse(value);
  return parsed.success ? parsed.data : null;
}