/**
 * Admin CMS server functions for courses/modules/lessons.
 * Mirrors the auth pattern used in admin.functions.ts: every function
 * re-checks the database role table server-side before touching data.
 *
 * The `courses`, `course_modules` and `course_lessons` tables were added
 * after the last generated Supabase types snapshot, so the admin client is
 * cast to `any` only for calls against these three tables.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type {
  AdminCourseInput,
  AdminCourseModule,
  AdminCourseRow,
  AdminLessonInput,
  AdminModuleInput,
} from "./course-types";

/* ------------------------------------------------------------------ courses */

export const adminListCourses = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminCourseRow[]> => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { data: courses, error } = await db
        .from("courses")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;

      const { data: modules, error: modErr } = await db
        .from("course_modules")
        .select("id, course_id");
      if (modErr) throw modErr;

      const moduleIds: string[] = (modules ?? []).map((m: any) => m.id); // eslint-disable-line @typescript-eslint/no-explicit-any
      const lessonCounts = new Map<string, number>();
      if (moduleIds.length > 0) {
        const { data: lessons, error: lesErr } = await db
          .from("course_lessons")
          .select("id, module_id")
          .in("module_id", moduleIds);
        if (lesErr) throw lesErr;
        const moduleToCourse = new Map((modules ?? []).map((m: any) => [m.id, m.course_id])); // eslint-disable-line @typescript-eslint/no-explicit-any
        for (const lesson of lessons ?? []) {
          const courseId = moduleToCourse.get(lesson.module_id);
          if (!courseId) continue;
          lessonCounts.set(courseId, (lessonCounts.get(courseId) ?? 0) + 1);
        }
      }
      const moduleCounts = new Map<string, number>();
      for (const m of modules ?? []) {
        moduleCounts.set(m.course_id, (moduleCounts.get(m.course_id) ?? 0) + 1);
      }

      return (courses ?? []).map((c: any) => ({ // eslint-disable-line @typescript-eslint/no-explicit-any
        ...c,
        module_count: moduleCounts.get(c.id) ?? 0,
        lesson_count: lessonCounts.get(c.id) ?? 0,
      }));
    } catch (e) {
      throw friendly(e, "Could not load courses.");
    }
  });

export const adminGetCourse = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }): Promise<{ course: AdminCourseRow; modules: AdminCourseModule[] }> => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { data: course, error } = await db
        .from("courses")
        .select("*")
        .eq("id", data.id)
        .maybeSingle();
      if (error) throw error;
      if (!course) throw new Error("Course not found.");

      const { data: modules, error: modErr } = await db
        .from("course_modules")
        .select("*")
        .eq("course_id", data.id)
        .order("sort_order", { ascending: true });
      if (modErr) throw modErr;

      const moduleIds: string[] = (modules ?? []).map((m: any) => m.id); // eslint-disable-line @typescript-eslint/no-explicit-any
      let lessons: any[] = []; // eslint-disable-line @typescript-eslint/no-explicit-any
      if (moduleIds.length > 0) {
        const { data: lessonRows, error: lesErr } = await db
          .from("course_lessons")
          .select("*")
          .in("module_id", moduleIds)
          .order("sort_order", { ascending: true });
        if (lesErr) throw lesErr;
        lessons = lessonRows ?? [];
      }

      const modulesWithLessons: AdminCourseModule[] = (modules ?? []).map((m: any) => ({ // eslint-disable-line @typescript-eslint/no-explicit-any
        ...m,
        lessons: lessons.filter((l) => l.module_id === m.id),
      }));

      return { course: { ...course, module_count: modulesWithLessons.length, lesson_count: lessons.length }, modules: modulesWithLessons };
    } catch (e) {
      throw friendly(e, "Could not load this course.");
    }
  });

export const adminSaveCourse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: AdminCourseInput) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        title: z.string().min(2).max(200),
        slug: z
          .string()
          .min(2)
          .max(160)
          .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes."),
        description: z.string().max(3000).default(""),
        thumbnail_url: z.string().max(600).nullish(),
        category: z.string().max(120).nullish(),
        level: z.enum(["beginner", "intermediate", "advanced"]).default("beginner"),
        is_premium: z.boolean().default(false),
        status: z.enum(["draft", "published", "archived"]).default("draft"),
        featured: z.boolean().default(false),
        instructor: z.string().max(120).default("OHMICLY"),
        tags: z.array(z.string().max(60)).max(30).default([]),
        seo_title: z.string().max(200).nullish(),
        seo_description: z.string().max(400).nullish(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { id, ...fields } = data;
      if (id) {
        const { data: current, error: readErr } = await db
          .from("courses")
          .select("published_at")
          .eq("id", id)
          .maybeSingle();
        if (readErr) throw readErr;
        const payload = {
          ...fields,
          published_at: current?.published_at ?? (fields.status === "published" ? new Date().toISOString() : null),
        };
        const { error } = await db.from("courses").update(payload).eq("id", id);
        if (error) throw error;
        return { id };
      }
      const payload = {
        ...fields,
        published_at: fields.status === "published" ? new Date().toISOString() : null,
        created_by: context.userId,
      };
      const { data: created, error } = await db.from("courses").insert(payload).select("id").single();
      if (error) throw error;
      return { id: created.id as string };
    } catch (e) {
      throw friendly(e, "Could not save this course.");
    }
  });

export const adminDeleteCourse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId, true);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { error } = await db.from("courses").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this course.");
    }
  });

/* ------------------------------------------------------------------ modules */

export const adminSaveModule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: AdminModuleInput) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        course_id: z.string().uuid(),
        title: z.string().min(2).max(200),
        description: z.string().max(1000).default(""),
        sort_order: z.number().int().min(0).default(0),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { id, ...fields } = data;
      if (id) {
        const { error } = await db.from("course_modules").update(fields).eq("id", id);
        if (error) throw error;
        return { id };
      }
      const { data: created, error } = await db.from("course_modules").insert(fields).select("id").single();
      if (error) throw error;
      return { id: created.id as string };
    } catch (e) {
      throw friendly(e, "Could not save this module.");
    }
  });

export const adminDeleteModule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { error } = await db.from("course_modules").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this module.");
    }
  });

/* ------------------------------------------------------------------ lessons */

export const adminSaveLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: AdminLessonInput) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        module_id: z.string().uuid(),
        title: z.string().min(2).max(200),
        description: z.string().max(2000).default(""),
        video_provider: z.string().max(20).default("bunny"),
        video_id: z.string().max(200).nullish(),
        duration_seconds: z.number().int().min(0).nullish(),
        sort_order: z.number().int().min(0).default(0),
        is_free_preview: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { id, ...fields } = data;
      if (id) {
        const { error } = await db.from("course_lessons").update(fields).eq("id", id);
        if (error) throw error;
        return { id };
      }
      const { data: created, error } = await db.from("course_lessons").insert(fields).select("id").single();
      if (error) throw error;
      return { id: created.id as string };
    } catch (e) {
      throw friendly(e, "Could not save this lesson.");
    }
  });

export const adminDeleteLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = (await admin()) as any; // eslint-disable-line @typescript-eslint/no-explicit-any
      const { error } = await db.from("course_lessons").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this lesson.");
    }
  });
