/** Shared admin CMS types for courses/modules/lessons (client-safe, no server imports). */
import type { PublishStatus } from "./admin-types";

export type CourseLevel = "beginner" | "intermediate" | "advanced";

export type AdminCourseRow = {
  id: string;
  title: string;
  slug: string;
  description: string;
  thumbnail_url: string | null;
  category: string | null;
  level: CourseLevel;
  is_premium: boolean;
  status: PublishStatus;
  featured: boolean;
  instructor: string;
  tags: string[];
  module_count: number;
  lesson_count: number;
  created_at: string;
  updated_at: string;
  published_at: string | null;
};

export type AdminCourseInput = {
  id?: string | null;
  title: string;
  slug: string;
  description?: string;
  thumbnail_url?: string | null;
  category?: string | null;
  level?: CourseLevel;
  is_premium?: boolean;
  status?: PublishStatus;
  featured?: boolean;
  instructor?: string;
  tags?: string[];
  seo_title?: string | null;
  seo_description?: string | null;
};

export type AdminCourseModule = {
  id: string;
  course_id: string;
  title: string;
  description: string;
  sort_order: number;
  lessons: AdminCourseLesson[];
};

export type AdminCourseLesson = {
  id: string;
  module_id: string;
  title: string;
  description: string;
  video_provider: string;
  video_id: string | null;
  duration_seconds: number | null;
  sort_order: number;
  is_free_preview: boolean;
};

export type AdminModuleInput = {
  id?: string | null;
  course_id: string;
  title: string;
  description?: string;
  sort_order?: number;
};

export type AdminLessonInput = {
  id?: string | null;
  module_id: string;
  title: string;
  description?: string;
  video_provider?: string;
  video_id?: string | null;
  duration_seconds?: number | null;
  sort_order?: number;
  is_free_preview?: boolean;
};
