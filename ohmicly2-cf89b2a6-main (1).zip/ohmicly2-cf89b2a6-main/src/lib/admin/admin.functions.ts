/**
 * Admin CMS server functions. Every function authenticates the caller through
 * `requireSupabaseAuth` and re-checks the database role table server-side
 * before touching data with the privileged client.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ALLOWED_PREVIEW_BUCKETS, type AdminResourceInput, type AdminStats, type AdminUserRow } from "./admin-types";
import {
  BRANDING_BUCKET,
  MAX_BRANDING_FILE_BYTES,
  brandingExtension,
  brandingKindSchema,
  parseBrandingSetting,
} from "@/lib/branding";

export const adminSession = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getRoles } = await import("./admin.server");
    const roles = await getRoles(context.supabase, context.userId);
    return {
      userId: context.userId,
      email: (context.claims["email"] as string | undefined) ?? null,
      roles,
      isAdmin: roles.includes("admin") || roles.includes("super_admin"),
      isSuperAdmin: roles.includes("super_admin"),
    };
  });

export const adminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminStats> => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const count = async (
        table: "resources" | "articles" | "calculators" | "downloads" | "profiles",
        apply?: (q: any) => any, // eslint-disable-line @typescript-eslint/no-explicit-any
      ) => {
        let q = db.from(table).select("id", { count: "exact", head: true });
        if (apply) q = apply(q);
        const { count: c, error } = await q;
        if (error) throw error;
        return c ?? 0;
      };
      const [
        resources,
        published,
        premium,
        drafts,
        articles,
        calculators,
        downloads,
        users,
      ] = await Promise.all([
        count("resources"),
        count("resources", (q) => q.eq("status", "published")),
        count("resources", (q) => q.eq("is_premium", true)),
        count("resources", (q) => q.eq("status", "draft")),
        count("articles"),
        count("calculators"),
        count("downloads"),
        count("profiles"),
      ]);
      return { resources, published, premium, drafts, articles, calculators, downloads, users };
    } catch (e) {
      throw friendly(e, "Could not load dashboard statistics.");
    }
  });

/* ---------------------------------------------------------------- resources */

export const adminListResources = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { q?: string; status?: string; type?: string; access?: string } | undefined) =>
    z
      .object({
        q: z.string().max(120).optional(),
        status: z.string().max(20).optional(),
        type: z.string().max(40).optional(),
        access: z.enum(["free", "premium"]).optional(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      let query = db
        .from("resources")
        .select(
          "id, title, slug, status, resource_type, is_premium, featured, file_path, storage_bucket, download_count, updated_at, category_id",
        )
        .order("updated_at", { ascending: false })
        .limit(300);
      if (data.q) query = query.ilike("title", `%${data.q}%`);
      if (data.status) query = query.eq("status", data.status as never);
      if (data.type) query = query.eq("resource_type", data.type as never);
      if (data.access) query = query.eq("is_premium", data.access === "premium");
      const { data: rows, error } = await query;
      if (error) throw error;
      return rows ?? [];
    } catch (e) {
      throw friendly(e, "Could not load resources.");
    }
  });

export const adminGetResource = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data: row, error } = await db
        .from("resources")
        .select(
          "*, resource_references ( id, standard_id, section, note, url, verified ), resource_subcategories ( subcategory_id )",
        )
        .eq("id", data.id)
        .maybeSingle();
      if (error) throw error;
      if (!row) return null;
      const { search_tsv: _tsv, ...rest } = row;
      return rest;
    } catch (e) {
      throw friendly(e, "Could not load this resource.");
    }
  });

export const adminSaveResource = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: AdminResourceInput) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        title: z.string().min(2).max(200),
        slug: z
          .string()
          .min(2)
          .max(160)
          .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes."),
        description: z.string().max(2000).default(""),
        who_for: z.string().max(1000).nullish(),
        problem_solved: z.string().max(1000).nullish(),
        whats_included: z.array(z.string().max(300)).max(30).default([]),
        how_to_use: z.array(z.string().max(300)).max(30).default([]),
        resource_type: z.string().min(1).max(40),
        category_id: z.string().uuid().nullish(),
        primary_subcategory_id: z.string().uuid().nullish(),
        extra_subcategory_ids: z.array(z.string().uuid()).max(20).default([]),
        subcategory: z.string().max(120).nullish(),
        tags: z.array(z.string().max(60)).max(30).default([]),
        featured: z.boolean().default(false),
        status: z.enum(["draft", "published", "archived"]).default("draft"),
        is_premium: z.boolean().default(false),
        file_type: z.string().max(10).nullish(),
        file_path: z.string().max(400).nullish(),
        storage_bucket: z.string().max(40).nullish(),
        file_name: z.string().max(200).nullish(),
        file_size: z.number().int().nonnegative().nullish(),
        thumbnail_url: z.string().max(600).nullish(),
        preview_images: z.array(z.string().max(600)).max(12).default([]),
        seo_title: z.string().max(200).nullish(),
        seo_description: z.string().max(400).nullish(),
        ranking_notes: z.string().max(400).nullish(),
        disclaimer: z.string().max(1000).nullish(),
        canonical_url: z.string().max(400).nullish(),
        noindex: z.boolean().default(false),
        references: z
          .array(
            z.object({
              standard_id: z.string().uuid(),
              section: z.string().max(120).nullish(),
              note: z.string().max(500).nullish(),
              url: z.string().max(600).nullish(),
              verified: z.boolean().default(false),
            }),
          )
          .max(30)
          .default([]),
        faqs: z
          .array(
            z.object({
              question: z.string().min(4).max(300),
              answer: z.string().min(2).max(4000),
            }),
          )
          .max(20)
          .default([]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { id, references, faqs, extra_subcategory_ids, ...fields } = data;
      let resourceId = id ?? null;
      if (resourceId) {
        // Preserve the original publication date and author on edits.
        const { data: current, error: readErr } = await db
          .from("resources")
          .select("published_at")
          .eq("id", resourceId)
          .maybeSingle();
        if (readErr) throw readErr;
        const payload = {
          ...fields,
          is_free: !fields.is_premium,
          resource_type: fields.resource_type as never,
          published_at:
            current?.published_at ??
            (fields.status === "published" ? new Date().toISOString() : null),
        };
        const { error } = await db.from("resources").update(payload as never).eq("id", resourceId);
        if (error) throw error;
      } else {
        const payload = {
          ...fields,
          is_free: !fields.is_premium,
          resource_type: fields.resource_type as never,
          published_at: fields.status === "published" ? new Date().toISOString() : null,
          created_by: context.userId,
        };
        const { data: inserted, error } = await db
          .from("resources")
          .insert(payload as never)
          .select("id")
          .single();
        if (error) throw error;
        resourceId = inserted.id;
      }

      // Cross-listings: replace the set, never including the primary subcategory.
      await db.from("resource_subcategories").delete().eq("resource_id", resourceId!);
      const extras = [...new Set(extra_subcategory_ids)].filter(
        (sid) => sid !== fields.primary_subcategory_id,
      );
      if (extras.length) {
        const { error } = await db
          .from("resource_subcategories")
          .insert(extras.map((sid) => ({ resource_id: resourceId!, subcategory_id: sid })) as never);
        if (error) throw error;
      }


      await db.from("resource_references").delete().eq("resource_id", resourceId!);
      if (references.length) {
        const { error } = await db
          .from("resource_references")
          .insert(references.map((r) => ({ ...r, resource_id: resourceId! })) as never);
        if (error) throw error;
      }

      // Resource FAQs are edited inline with the resource, so replace the set.
      await db.from("faqs").delete().eq("resource_id", resourceId!).eq("scope", "resource");
      if (faqs.length) {
        const { error } = await db.from("faqs").insert(
          faqs.map((f, i) => ({
            question: f.question,
            answer: f.answer,
            scope: "resource",
            resource_id: resourceId!,
            sort_order: i,
            is_published: true,
          })) as never,
        );
        if (error) throw error;
      }
      return { id: resourceId! };
    } catch (e) {
      throw friendly(e, "Could not save this resource.");
    }
  });

export const adminUpdateResourceFlags = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; status?: string; featured?: boolean; is_premium?: boolean }) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["draft", "published", "archived"]).optional(),
        featured: z.boolean().optional(),
        is_premium: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const patch: Record<string, unknown> = {};
      if (data.status) {
        patch["status"] = data.status;
        const { data: current } = await db
          .from("resources")
          .select("published_at")
          .eq("id", data.id)
          .maybeSingle();
        // First publish stamps the date; later transitions keep the original.
        if (!current?.published_at) {
          patch["published_at"] = data.status === "published" ? new Date().toISOString() : null;
        }
      }

      if (data.featured !== undefined) patch["featured"] = data.featured;
      if (data.is_premium !== undefined) {
        patch["is_premium"] = data.is_premium;
        patch["is_free"] = !data.is_premium;
      }
      const { error } = await db.from("resources").update(patch as never).eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not update this resource.");
    }
  });

export const adminDeleteResource = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data: row } = await db
        .from("resources")
        .select("storage_bucket, file_path")
        .eq("id", data.id)
        .maybeSingle();
      await db.from("resource_references").delete().eq("resource_id", data.id);
      await db.from("faqs").delete().eq("resource_id", data.id);
      await db.from("resource_tag_map").delete().eq("resource_id", data.id);
      await db.from("downloads").delete().eq("resource_id", data.id);
      await db.from("favorites").delete().eq("resource_id", data.id);
      const { error } = await db.from("resources").delete().eq("id", data.id);
      if (error) throw error;
      if (row?.storage_bucket && row.file_path) {
        await db.storage.from(row.storage_bucket).remove([row.file_path]);
      }
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this resource.");
    }
  });

/* ------------------------------------------------------------------ uploads */

export const adminCreateUploadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      resourceType: string;
      fileName: string;
      size: number;
      kind?: "file" | "image";
      originalSize?: number;
    }) =>
      z
        .object({
          resourceType: z.string().max(40).default("other"),
          fileName: z.string().min(1).max(200),
          size: z.number().int().positive(),
          kind: z.enum(["file", "image"]).default("file"),
          /** Size of the file the admin picked, before browser-side processing. */
          originalSize: z.number().int().positive().optional(),
        })
        .parse(input),
  )
  .handler(async ({ data, context }) => {
    const mod = await import("./admin.server");
    await mod.requireAdmin(context.supabase, context.userId);
    const ext = mod.extensionOf(data.fileName);
    const isImage = data.kind === "image";
    const allowed = isImage ? mod.ALLOWED_IMAGE_EXTENSIONS : mod.ALLOWED_FILE_EXTENSIONS;
    if (!allowed.includes(ext)) {
      throw new mod.AdminError(`Unsupported file type ".${ext}". Allowed: ${allowed.join(", ")}.`);
    }
    // Hard server-side cap on the untouched original, independent of the client.
    if (isImage && data.originalSize && data.originalSize > mod.MAX_IMAGE_SOURCE_BYTES) {
      throw new mod.AdminError(
        `Original image is too large. Maximum is ${Math.round(mod.MAX_IMAGE_SOURCE_BYTES / 1048576)} MB.`,
      );
    }
    const max = isImage ? mod.MAX_IMAGE_BYTES : mod.MAX_FILE_BYTES;
    if (data.size > max) {
      throw new mod.AdminError(`File is too large. Maximum size is ${Math.round(max / 1048576)} MB.`);
    }
    try {
      const bucket = isImage ? "images" : mod.bucketForType(data.resourceType);
      const path = `${new Date().getFullYear()}/${crypto.randomUUID()}-${mod.safeFileName(data.fileName)}`;
      const db = await mod.admin();
      const { data: signed, error } = await db.storage.from(bucket).createSignedUploadUrl(path);
      if (error) throw error;
      if (!isImage) {
        return { bucket, path, token: signed.token, ext: ext.toUpperCase(), thumbPath: null, thumbToken: null };
      }
      // Images also get a signed slot for their small variant.
      const thumbPath = mod.thumbPathFor(path);
      const { data: thumbSigned, error: thumbErr } = await db.storage
        .from(bucket)
        .createSignedUploadUrl(thumbPath);
      if (thumbErr) throw thumbErr;
      return {
        bucket,
        path,
        token: signed.token,
        ext: ext.toUpperCase(),
        thumbPath,
        thumbToken: thumbSigned.token,
      };
    } catch (e) {
      throw mod.friendly(e, "Could not start the upload.");
    }
  });

/** Short-lived preview URL for an admin-owned private file. */
export const adminSignedPreviewUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { bucket: string; path: string }) =>
    z
      .object({
        bucket: z.enum(ALLOWED_PREVIEW_BUCKETS),
        path: z.string().max(400),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data: signed, error } = await db.storage.from(data.bucket).createSignedUrl(data.path, 300);
      if (error) throw error;
      return { url: signed.signedUrl };
    } catch (e) {
      throw friendly(e, "Could not open this file.");
    }
  });

/** Removes an orphaned upload from a private admin bucket. */
export const adminDeleteStorageObject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { bucket: string; path: string }) =>
    z
      .object({
        bucket: z.enum(ALLOWED_PREVIEW_BUCKETS),
        path: z.string().min(1).max(400),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { error } = await db.storage.from(data.bucket).remove([data.path]);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not remove this file from storage.");
    }
  });

/* --------------------------------------------------------------- categories */

export const adminListCategories = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db
        .from("resource_categories")
        .select(
          "id, slug, name, icon, description, parent_id, sort_order, is_active, group_label",
        )
        .order("sort_order");
      if (error) throw error;
      return data ?? [];
    } catch (e) {
      throw friendly(e, "Could not load categories.");
    }
  });

export const adminSaveCategory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      id?: string | null;
      slug: string;
      name: string;
      icon?: string | null;
      description?: string | null;
      group_label?: string | null;
      parent_id?: string | null;
      sort_order?: number;
      is_active?: boolean;
    }) =>
      z
        .object({
          id: z.string().uuid().nullish(),
          slug: z
            .string()
            .min(2)
            .max(80)
            .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes."),
          name: z.string().min(2).max(120),
          icon: z.string().max(60).nullish(),
          description: z.string().max(500).nullish(),
          group_label: z.string().max(80).nullish(),
          parent_id: z.string().uuid().nullish(),
          sort_order: z.number().int().min(0).max(999).default(0),
          is_active: z.boolean().default(true),
        })
        .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { id, ...fields } = data;
      const { error } = id
        ? await db.from("resource_categories").update(fields as never).eq("id", id)
        : await db.from("resource_categories").insert(fields as never);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save this category.");
    }
  });

/**
 * Number of resources (any status) attached to each category / subcategory,
 * counting primary assignments and cross-listings.
 */
export const adminCategoryUsage = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const [resourceRes, linkRes] = await Promise.all([
        db.from("resources").select("category_id, primary_subcategory_id").limit(5000),
        db.from("resource_subcategories").select("subcategory_id").limit(20000),
      ]);
      if (resourceRes.error) throw resourceRes.error;
      if (linkRes.error) throw linkRes.error;
      const usage: Record<string, number> = {};
      const bump = (id: string | null) => {
        if (id) usage[id] = (usage[id] ?? 0) + 1;
      };
      for (const row of resourceRes.data ?? []) {
        bump(row.category_id);
        bump(row.primary_subcategory_id);
      }
      for (const row of linkRes.data ?? []) bump(row.subcategory_id);
      return usage;
    } catch (e) {
      throw friendly(e, "Could not load category usage.");
    }
  });

/** Persists a new display order for categories / subcategories. */
export const adminReorderCategories = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { items: { id: string; sort_order: number }[] }) =>
    z
      .object({
        items: z
          .array(z.object({ id: z.string().uuid(), sort_order: z.number().int().min(0).max(999) }))
          .max(200),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      for (const item of data.items) {
        const { error } = await db
          .from("resource_categories")
          .update({ sort_order: item.sort_order } as never)
          .eq("id", item.id);
        if (error) throw error;
      }
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save the new order.");
    }
  });

/**
 * Deletes a category. Refuses to orphan resources: the caller must either
 * pass `reassign_to` (another category) or the delete is blocked.
 */
export const adminDeleteCategory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; reassign_to?: string | null }) =>
    z
      .object({ id: z.string().uuid(), reassign_to: z.string().uuid().nullish() })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly, AdminError } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    if (data.reassign_to && data.reassign_to === data.id) {
      throw new AdminError("Choose a different category to move the resources to.");
    }
    try {
      const db = await admin();
      const [primaryRes, subRes, crossRes] = await Promise.all([
        db.from("resources").select("id", { count: "exact", head: true }).eq("category_id", data.id),
        db
          .from("resources")
          .select("id", { count: "exact", head: true })
          .eq("primary_subcategory_id", data.id),
        db
          .from("resource_subcategories")
          .select("resource_id", { count: "exact", head: true })
          .eq("subcategory_id", data.id),
      ]);
      if (primaryRes.error) throw primaryRes.error;
      if (subRes.error) throw subRes.error;
      if (crossRes.error) throw crossRes.error;
      const asCategory = primaryRes.count ?? 0;
      const asSubcategory = subRes.count ?? 0;
      const crossListed = crossRes.count ?? 0;
      const used = asCategory + asSubcategory;

      const { count: childCount, error: childErr } = await db
        .from("resource_categories")
        .select("id", { count: "exact", head: true })
        .eq("parent_id", data.id);
      if (childErr) throw childErr;
      if ((childCount ?? 0) > 0) {
        throw new AdminError(
          `This category has ${childCount} sub-categor${childCount === 1 ? "y" : "ies"}. Move or delete them first.`,
        );
      }

      if (used > 0) {
        if (!data.reassign_to) {
          throw new AdminError(
            `${used} resource${used === 1 ? " uses" : "s use"} this category. Choose another category to move them to, or hide it instead.`,
          );
        }
        const { data: target, error: targetErr } = await db
          .from("resource_categories")
          .select("id")
          .eq("id", data.reassign_to)
          .maybeSingle();
        if (targetErr) throw targetErr;
        if (!target) throw new AdminError("The category you selected no longer exists.");
        if (asCategory > 0) {
          const { error: moveErr } = await db
            .from("resources")
            .update({ category_id: data.reassign_to } as never)
            .eq("category_id", data.id);
          if (moveErr) throw moveErr;
        }
        if (asSubcategory > 0) {
          const { error: moveErr } = await db
            .from("resources")
            .update({ primary_subcategory_id: data.reassign_to } as never)
            .eq("primary_subcategory_id", data.id);
          if (moveErr) throw moveErr;
        }
      }

      // Cross-listings are removed with the row (cascade); nothing is orphaned.
      const { error } = await db.from("resource_categories").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true, moved: data.reassign_to ? used : 0, crossListed };
    } catch (e) {
      throw friendly(e, "Could not delete this category.");
    }
  });


/* --------------------------------------------------------------------- tags */

export const adminListTags = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db.from("resource_tags").select("id, slug, name").order("name");
      if (error) throw error;
      return data ?? [];
    } catch (e) {
      throw friendly(e, "Could not load tags.");
    }
  });

export const adminCreateTag = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { name: string }) =>
    z.object({ name: z.string().min(2).max(60) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const slug = data.name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      const { data: existing } = await db
        .from("resource_tags")
        .select("id")
        .eq("slug", slug)
        .maybeSingle();
      if (existing) return { ok: true, duplicate: true };
      const { error } = await db.from("resource_tags").insert({ slug, name: data.name.trim() } as never);
      if (error) throw error;
      return { ok: true, duplicate: false };
    } catch (e) {
      throw friendly(e, "Could not create this tag.");
    }
  });

export const adminDeleteTag = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      await db.from("resource_tag_map").delete().eq("tag_id", data.id);
      const { error } = await db.from("resource_tags").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this tag.");
    }
  });

/* ----------------------------------------------------------------- articles */

export const adminListArticles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db
        .from("articles")
        .select("*")
        .order("updated_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      return (data ?? []).map(({ search_tsv: _tsv, ...rest }) => rest);
    } catch (e) {
      throw friendly(e, "Could not load articles.");
    }
  });

export const adminSaveArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: Record<string, unknown>) =>
      z
        .object({
          id: z.string().uuid().nullish(),
          title: z.string().min(2).max(200),
          slug: z
            .string()
            .min(2)
            .max(160)
            .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes."),
          excerpt: z.string().max(600).default(""),
          body: z.string().max(200000).nullish(),
          category_id: z.string().uuid().nullish(),
          author: z.string().max(120).default("OHMICLY"),
          reading_time: z.string().max(40).nullish(),
          status: z.enum(["draft", "published", "archived"]).default("draft"),
          tags: z.array(z.string().max(60)).max(30).default([]),
          cover_image_url: z.string().max(600).nullish(),
          seo_title: z.string().max(200).nullish(),
          seo_description: z.string().max(400).nullish(),
          canonical_url: z.string().max(400).nullish(),
        })
        .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { id, ...fields } = data;
      if (id) {
        // Keep the original publication date and author untouched on edits.
        const { data: current, error: readErr } = await db
          .from("articles")
          .select("published_at")
          .eq("id", id)
          .maybeSingle();
        if (readErr) throw readErr;
        const payload = {
          ...fields,
          published_at:
            current?.published_at ??
            (fields.status === "published" ? new Date().toISOString() : null),
        };
        const { error } = await db.from("articles").update(payload as never).eq("id", id);
        if (error) throw error;
      } else {
        const payload = {
          ...fields,
          created_by: context.userId,
          published_at: fields.status === "published" ? new Date().toISOString() : null,
        };
        const { error } = await db.from("articles").insert(payload as never);
        if (error) throw error;
      }

      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save this article.");
    }
  });

export const adminDeleteArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      await db.from("article_references").delete().eq("article_id", data.id);
      const { error } = await db.from("articles").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this article.");
    }
  });

export const adminListArticleCategories = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db.from("article_categories").select("id, name, slug").order("name");
      if (error) throw error;
      return data ?? [];
    } catch (e) {
      throw friendly(e, "Could not load article categories.");
    }
  });

/* --------------------------------------------------------------------- faqs */

export const adminListFaqs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { scope?: string; resource_id?: string | null; calculator_id?: string | null } | undefined) =>
    z
      .object({
        scope: z.string().max(40).optional(),
        resource_id: z.string().uuid().nullish(),
        calculator_id: z.string().uuid().nullish(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      let query = db
        .from("faqs")
        .select("id, question, answer, scope, resource_id, calculator_id, sort_order, is_published")
        .order("sort_order");
      if (data.scope) query = query.eq("scope", data.scope);
      if (data.resource_id) query = query.eq("resource_id", data.resource_id);
      if (data.calculator_id) query = query.eq("calculator_id", data.calculator_id);
      const { data: rows, error } = await query;
      if (error) throw error;
      return rows ?? [];
    } catch (e) {
      throw friendly(e, "Could not load FAQs.");
    }
  });

export const adminSaveFaq = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        question: z.string().min(4).max(300),
        answer: z.string().min(2).max(4000),
        scope: z.string().max(40).default("site"),
        resource_id: z.string().uuid().nullish(),
        calculator_id: z.string().uuid().nullish(),
        sort_order: z.number().int().min(0).max(999).default(0),
        is_published: z.boolean().default(true),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { id, ...rest } = data;
      const fields = {
        ...rest,
        resource_id: rest.resource_id ?? null,
        calculator_id: rest.calculator_id ?? null,
      };
      const { error } = id
        ? await db.from("faqs").update(fields as never).eq("id", id)
        : await db.from("faqs").insert(fields as never);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save this FAQ.");
    }
  });


export const adminDeleteFaq = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { error } = await db.from("faqs").delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this FAQ.");
    }
  });

/* -------------------------------------------------------------- calculators */

export const adminListCalculators = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db.from("calculators").select("*").order("name");
      if (error) throw error;
      return (data ?? []).map(({ search_tsv: _tsv, ...rest }) => rest);
    } catch (e) {
      throw friendly(e, "Could not load calculators.");
    }
  });

export const adminSaveCalculator = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        name: z.string().min(2).max(160),
        slug: z
          .string()
          .min(2)
          .max(160)
          .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes."),
        description: z.string().max(1000).default(""),
        category: z.string().max(80).default("General"),
        icon: z.string().max(60).nullish(),
        status: z.enum(["available", "coming-soon"]).default("coming-soon"),
        seo_title: z.string().max(200).nullish(),
        seo_description: z.string().max(400).nullish(),
        keywords: z.array(z.string().max(60)).max(30).default([]),
        disclaimer: z.string().max(1000).nullish(),
        thumbnail_url: z.string().max(600).nullish(),
        is_published: z.boolean().default(true),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { id, ...fields } = data;
      const { error } = id
        ? await db.from("calculators").update(fields as never).eq("id", id)
        : await db.from("calculators").insert(fields as never);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save this calculator.");
    }
  });

/* ---------------------------------------------------------------- standards */

export const adminListStandards = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db.from("standards").select("*").order("code");
      if (error) throw error;
      return data ?? [];
    } catch (e) {
      throw friendly(e, "Could not load standards.");
    }
  });

export const adminSaveStandard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z
      .object({
        id: z.string().uuid().nullish(),
        slug: z
          .string()
          .min(2)
          .max(80)
          .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes."),
        code: z.string().min(2).max(60),
        name: z.string().min(2).max(200),
        edition: z.string().max(40).nullish(),
        publisher: z.string().max(160).nullish(),
        summary: z.string().min(2).max(2000),
        url: z.string().max(600).nullish(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { id, ...fields } = data;
      const { error } = id
        ? await db.from("standards").update(fields as never).eq("id", id)
        : await db.from("standards").insert(fields as never);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save this standard.");
    }
  });

/* ---------------------------------------------------------------- downloads */

/* --------------------------------------------------------------- references */

/** Lists every reference link of one entity kind, with its parent + standard. */
export const adminListReferences = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z.object({ entity: z.enum(["calculator", "resource", "article"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    const { REF_TABLE, REF_FK, REF_PARENT_TABLE, REF_PARENT_LABEL } = await import("./admin-types");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const parentTable = REF_PARENT_TABLE[data.entity];
      const parentLabel = REF_PARENT_LABEL[data.entity];
      const { data: rows, error } = await db
        .from(REF_TABLE[data.entity])
        .select(
          `id, ${REF_FK[data.entity]}, standard_id, section, note, url, verified,
           ${parentTable} ( ${parentLabel}, slug ),
           standards ( code, edition, name )`,
        )
        .order("created_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return (rows ?? []).map((r: any) => ({
        id: r.id as string,
        parentId: r[REF_FK[data.entity]] as string,
        parentTitle: (r[parentTable]?.[parentLabel] as string | undefined) ?? "—",
        standardId: r.standard_id as string,
        standardCode: (r.standards?.code as string | undefined) ?? "—",
        standardEdition: (r.standards?.edition as string | null | undefined) ?? null,
        standardName: (r.standards?.name as string | undefined) ?? "",
        section: (r.section as string | null) ?? null,
        note: (r.note as string | null) ?? null,
        url: (r.url as string | null) ?? null,
        verified: Boolean(r.verified),
      }));
    } catch (e) {
      throw friendly(e, "Could not load references.");
    }
  });

/** Options an admin can attach a reference to. */
export const adminReferenceTargets = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z.object({ entity: z.enum(["calculator", "resource", "article"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      if (data.entity === "calculator") {
        const { data: rows, error } = await db.from("calculators").select("id, name").order("name");
        if (error) throw error;
        return (rows ?? []).map((r) => ({ id: r.id, label: r.name }));
      }
      const table = data.entity === "resource" ? "resources" : "articles";
      const { data: rows, error } = await db.from(table).select("id, title").order("title");
      if (error) throw error;
      return (rows ?? []).map((r) => ({ id: r.id, label: r.title }));
    } catch (e) {
      throw friendly(e, "Could not load reference targets.");
    }
  });

export const adminSaveReference = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z
      .object({
        entity: z.enum(["calculator", "resource", "article"]),
        id: z.string().uuid().nullish(),
        parentId: z.string().uuid(),
        standard_id: z.string().uuid(),
        section: z.string().max(200).nullish(),
        note: z.string().max(2000).nullish(),
        url: z.string().max(600).nullish(),
        verified: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    const { REF_TABLE, REF_FK } = await import("./admin-types");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const fields = {
        [REF_FK[data.entity]]: data.parentId,
        standard_id: data.standard_id,
        section: data.section || null,
        note: data.note || null,
        url: data.url || null,
        verified: data.verified,
      };
      const { error } = data.id
        ? await db.from(REF_TABLE[data.entity]).update(fields as never).eq("id", data.id)
        : await db.from(REF_TABLE[data.entity]).insert(fields as never);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save this reference.");
    }
  });

export const adminDeleteReference = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, unknown>) =>
    z
      .object({ entity: z.enum(["calculator", "resource", "article"]), id: z.string().uuid() })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    const { REF_TABLE } = await import("./admin-types");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { error } = await db.from(REF_TABLE[data.entity]).delete().eq("id", data.id);
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not delete this reference.");
    }
  });


export const adminListDownloads = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db
        .from("downloads")
        .select("id, created_at, user_id, resources ( title, slug, is_premium )")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    } catch (e) {
      throw friendly(e, "Could not load download activity.");
    }
  });

/* -------------------------------------------------------------------- users */

export const adminListUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminUserRow[]> => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data: list, error } = await db.auth.admin.listUsers({ page: 1, perPage: 200 });
      if (error) throw error;
      const { data: roles } = await db.from("user_roles").select("user_id, role");
      const { data: profiles } = await db.from("profiles").select("id, display_name");
      return list.users.map((u) => ({
        id: u.id,
        email: u.email ?? null,
        displayName: profiles?.find((p) => p.id === u.id)?.display_name ?? null,
        roles: (roles ?? []).filter((r) => r.user_id === u.id).map((r) => r.role),
        confirmed: Boolean(u.email_confirmed_at),
        createdAt: u.created_at,
        lastSignInAt: u.last_sign_in_at ?? null,
      }));
    } catch (e) {
      throw friendly(e, "Could not load users.");
    }
  });

export const adminSetUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; role: string; grant: boolean }) =>
    z
      .object({
        userId: z.string().uuid(),
        role: z.enum(["user", "admin", "super_admin"]),
        grant: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly, AdminError } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId, true);
    if (data.userId === context.userId && !data.grant) {
      throw new AdminError("You cannot remove your own administrator access.");
    }
    try {
      const db = await admin();
      if (data.grant) {
        const { error } = await db
          .from("user_roles")
          .upsert({ user_id: data.userId, role: data.role as never }, { onConflict: "user_id,role" });
        if (error) throw error;
      } else {
        const { error } = await db
          .from("user_roles")
          .delete()
          .eq("user_id", data.userId)
          .eq("role", data.role as never);
        if (error) throw error;
      }
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not update this user's role.");
    }
  });

/* ------------------------------------------------------------- site settings */

export const adminGetSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db.from("site_settings").select("key, value");
      if (error) throw error;
      return data ?? [];
    } catch (e) {
      throw friendly(e, "Could not load site settings.");
    }
  });

export const adminSaveSetting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { key: string; value: Record<string, unknown> }) =>
    z.object({ key: z.string().max(60), value: z.record(z.string(), z.unknown()) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId, true);
    try {
      const db = await admin();
      const { error } = await db
        .from("site_settings")
        .upsert({ key: data.key, value: data.value as never }, { onConflict: "key" });
      if (error) throw error;
      return { ok: true };
    } catch (e) {
      throw friendly(e, "Could not save site settings.");
    }
  });

/* --------------------------------------------------------------- branding */

const brandingUploadInput = z.object({
  kind: brandingKindSchema,
  fileName: z.string().trim().min(1).max(200),
  mimeType: z.string().trim().min(1).max(100),
  size: z.number().int().positive().max(MAX_BRANDING_FILE_BYTES),
});

const extensionByKind = {
  logo: ["svg", "png", "webp"],
  favicon: ["svg", "png", "ico"],
} as const;

export const adminGetBranding = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data, error } = await db
        .from("site_settings")
        .select("value")
        .eq("key", "branding")
        .maybeSingle();
      if (error) throw error;
      return parseBrandingSetting(data?.value);
    } catch (error) {
      throw friendly(error, "Could not load branding settings.");
    }
  });

export const adminCreateBrandingUploadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: z.input<typeof brandingUploadInput>) => brandingUploadInput.parse(input))
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, safeFileName, friendly, AdminError } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    const ext = brandingExtension(data.fileName);
    if (!(extensionByKind[data.kind] as readonly string[]).includes(ext)) {
      throw new AdminError(`Unsupported ${data.kind} file type.`);
    }
    const allowedMimeTypes =
      data.kind === "logo"
        ? ["image/svg+xml", "image/png", "image/webp"]
        : ["image/svg+xml", "image/png", "image/x-icon", "image/vnd.microsoft.icon"];
    if (!allowedMimeTypes.includes(data.mimeType)) {
      throw new AdminError(`Unsupported ${data.kind} MIME type.`);
    }
    try {
      const path = `branding/${data.kind}/${crypto.randomUUID()}-${safeFileName(data.fileName)}`;
      const db = await admin();
      const { data: signed, error } = await db.storage.from(BRANDING_BUCKET).createSignedUploadUrl(path);
      if (error) throw error;
      return { bucket: BRANDING_BUCKET, path, token: signed.token };
    } catch (error) {
      throw friendly(error, "Could not start the branding upload.");
    }
  });

export const adminFinalizeBrandingUpload = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: z.input<typeof brandingUploadInput> & { path: string }) =>
    brandingUploadInput.extend({ path: z.string().min(1).max(400) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly, AdminError } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    const expectedPrefix = `branding/${data.kind}/`;
    if (!data.path.startsWith(expectedPrefix) || data.path.includes("..")) {
      throw new AdminError("Invalid branding asset path.");
    }
    const db = await admin();
    try {
      const { data: blob, error: downloadError } = await db.storage.from(BRANDING_BUCKET).download(data.path);
      if (downloadError || !blob) throw downloadError ?? new Error("Upload could not be verified.");
      if (blob.size !== data.size || blob.size > MAX_BRANDING_FILE_BYTES) {
        throw new AdminError("Uploaded file size does not match the selected file.");
      }
      const bytes = new Uint8Array(await blob.arrayBuffer());
      const { inspectBrandingImage } = await import("@/lib/branding.server");
      const inspected = inspectBrandingImage(bytes, data.kind);
      const claimedMime = data.mimeType === "image/vnd.microsoft.icon" ? "image/x-icon" : data.mimeType;
      if (claimedMime !== inspected.mimeType) {
        throw new AdminError("Reported file type does not match its contents.");
      }
      const extension = brandingExtension(data.fileName);
      const extensionMatches =
        inspected.mimeType === "image/svg+xml"
          ? extension === "svg"
          : inspected.mimeType === "image/png"
            ? extension === "png"
            : inspected.mimeType === "image/webp"
              ? extension === "webp"
              : extension === "ico";
      if (!extensionMatches) throw new AdminError("File extension does not match its contents.");

      const { data: currentRow, error: readError } = await db
        .from("site_settings")
        .select("value")
        .eq("key", "branding")
        .maybeSingle();
      if (readError) throw readError;
      const current = parseBrandingSetting(currentRow?.value);
      const previous = current[data.kind];
      const revision = `${Date.now()}-${crypto.randomUUID()}`;
      const next = {
        ...current,
        [data.kind]: {
          path: data.path,
          filename: data.fileName,
          mimeType: inspected.mimeType,
          size: blob.size,
          width: inspected.width,
          height: inspected.height,
          revision,
        },
      };
      const { error: saveError } = await db
        .from("site_settings")
        .upsert({ key: "branding", value: next as never }, { onConflict: "key" });
      if (saveError) throw saveError;
      if (previous?.path && previous.path !== data.path) {
        const { error: removeError } = await db.storage.from(BRANDING_BUCKET).remove([previous.path]);
        if (removeError) console.error("[branding] Could not remove replaced asset", removeError);
      }
      return next;
    } catch (error) {
      await db.storage.from(BRANDING_BUCKET).remove([data.path]);
      throw friendly(error, "Could not save this branding asset.");
    }
  });

export const adminDiscardBrandingUpload = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { kind: "logo" | "favicon"; path: string }) =>
    z.object({ kind: brandingKindSchema, path: z.string().min(1).max(400) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly, AdminError } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    if (!data.path.startsWith(`branding/${data.kind}/`) || data.path.includes("..")) {
      throw new AdminError("Invalid branding asset path.");
    }
    try {
      const db = await admin();
      const { data: row, error: readError } = await db
        .from("site_settings")
        .select("value")
        .eq("key", "branding")
        .maybeSingle();
      if (readError) throw readError;
      const active = parseBrandingSetting(row?.value)[data.kind];
      if (active?.path === data.path) throw new AdminError("The active branding asset cannot be discarded.");
      const { error } = await db.storage.from(BRANDING_BUCKET).remove([data.path]);
      if (error) throw error;
      return { ok: true };
    } catch (error) {
      throw friendly(error, "Could not clean up the upload.");
    }
  });

export const adminRemoveBrandingAsset = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { kind: "logo" | "favicon" }) =>
    z.object({ kind: brandingKindSchema }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { requireAdmin, admin, friendly } = await import("./admin.server");
    await requireAdmin(context.supabase, context.userId);
    try {
      const db = await admin();
      const { data: row, error: readError } = await db
        .from("site_settings")
        .select("value")
        .eq("key", "branding")
        .maybeSingle();
      if (readError) throw readError;
      const current = parseBrandingSetting(row?.value);
      const previous = current[data.kind];
      const next = { ...current, [data.kind]: null };
      const { error: saveError } = await db
        .from("site_settings")
        .upsert({ key: "branding", value: next as never }, { onConflict: "key" });
      if (saveError) throw saveError;
      if (previous?.path) {
        const { error: removeError } = await db.storage.from(BRANDING_BUCKET).remove([previous.path]);
        if (removeError) throw removeError;
      }
      return next;
    } catch (error) {
      throw friendly(error, "Could not remove this branding asset.");
    }
  });