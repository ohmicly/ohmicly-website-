/**
 * Server-only helpers for the admin CMS.
 * Authorization is always re-checked here against the database role table —
 * never trusted from the client.
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];

export class AdminError extends Error {}

/** Reads the caller's roles through their own RLS-scoped client. */
export async function getRoles(
  supabase: SupabaseClient<Database>,
  userId: string,
): Promise<AppRole[]> {
  const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  if (error) throw error;
  return (data ?? []).map((r) => r.role);
}

export async function requireAdmin(
  supabase: SupabaseClient<Database>,
  userId: string,
  needSuper = false,
): Promise<AppRole[]> {
  const roles = await getRoles(supabase, userId);
  const isSuper = roles.includes("super_admin");
  const ok = needSuper ? isSuper : isSuper || roles.includes("admin");
  if (!ok) throw new AdminError("Forbidden: administrator access required.");
  return roles;
}

export async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Never surface raw database errors to the browser. */
export function friendly(error: unknown, fallback: string): Error {
  if (error instanceof AdminError) return error;
  const message = error instanceof Error ? error.message : "";
  if (/duplicate key|unique constraint/i.test(message)) {
    return new Error("That slug or name is already in use.");
  }
  if (/foreign key/i.test(message)) {
    return new Error("This item is still referenced by other content.");
  }
  console.error("[admin]", error);
  return new Error(fallback);
}

/** Maps a resource type to the private storage bucket it belongs in. */
export function bucketForType(resourceType: string): string {
  switch (resourceType) {
    case "autocad":
    case "electrical-cad":
      return "autocad";
    case "autolisp":
      return "autolisp";
    case "template":
    case "cv-template":
      return "templates";
    case "checklist":
      return "checklists";
    case "pdf-books":
    case "guide":
      return "pdf";
    default:
      return "resources";
  }
}

export const ALLOWED_FILE_EXTENSIONS = [
  "dwg",
  "dxf",
  "lsp",
  "pdf",
  "xlsx",
  "xls",
  "docx",
  "doc",
  "zip",
  "csv",
];
export const ALLOWED_IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "webp"];
export const MAX_FILE_BYTES = 100 * 1024 * 1024;
/** Cap for the processed image actually written to storage. */
export const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
/** Hard server-side cap on the ORIGINAL file the admin picked. */
export const MAX_IMAGE_SOURCE_BYTES = 5 * 1024 * 1024;

/**
 * Deterministic sibling path for the small variant of an image.
 * `2026/uuid-name.webp` -> `2026/thumbs/uuid-name.webp`
 */
export function thumbPathFor(path: string): string {
  const cut = path.lastIndexOf("/");
  return cut === -1 ? `thumbs/${path}` : `${path.slice(0, cut)}/thumbs/${path.slice(cut + 1)}`;
}

export function extensionOf(name: string): string {
  const parts = name.toLowerCase().split(".");
  return parts.length > 1 ? parts[parts.length - 1]! : "";
}

export function safeFileName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .slice(-120);
}