/** Shared admin CMS types (client-safe, no server imports). */
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];
export type PublishStatus = "draft" | "published" | "archived";

export type AdminStats = {
  resources: number;
  published: number;
  premium: number;
  drafts: number;
  articles: number;
  calculators: number;
  downloads: number;
  users: number;
};

export type AdminUserRow = {
  id: string;
  email: string | null;
  displayName: string | null;
  roles: AppRole[];
  confirmed: boolean;
  createdAt: string;
  lastSignInAt: string | null;
};

export type AdminReferenceInput = {
  standard_id: string;
  section?: string | null;
  note?: string | null;
  url?: string | null;
  verified?: boolean;
};

export type AdminResourceInput = {
  id?: string | null;
  title: string;
  slug: string;
  description?: string;
  who_for?: string | null;
  problem_solved?: string | null;
  whats_included?: string[];
  how_to_use?: string[];
  resource_type: string;
  category_id?: string | null;
  /** Primary subcategory — drives breadcrumb and canonical listing URL. */
  primary_subcategory_id?: string | null;
  /** Optional cross-listing subcategories (any category). */
  extra_subcategory_ids?: string[];
  subcategory?: string | null;
  tags?: string[];
  featured?: boolean;
  status?: PublishStatus;
  is_premium?: boolean;
  file_type?: string | null;
  file_path?: string | null;
  storage_bucket?: string | null;
  file_name?: string | null;
  file_size?: number | null;
  thumbnail_url?: string | null;
  preview_images?: string[];
  seo_title?: string | null;
  seo_description?: string | null;
  ranking_notes?: string | null;
  disclaimer?: string | null;
  canonical_url?: string | null;
  noindex?: boolean;
  references?: AdminReferenceInput[];
  faqs?: { question: string; answer: string }[];
};

export const RESOURCE_TYPES: { value: string; label: string }[] = [
  { value: "autocad", label: "AutoCAD" },
  { value: "autolisp", label: "AutoLISP" },
  { value: "electrical-cad", label: "Electrical CAD" },
  { value: "earthing", label: "Earthing" },
  { value: "lps", label: "LPS" },
  { value: "pdf-books", label: "PDF Books" },
  { value: "checklist", label: "Checklists" },
  { value: "template", label: "Templates" },
  { value: "cv-template", label: "CV Templates" },
  { value: "electrical-safety", label: "Electrical Safety" },
  { value: "electricians-zone", label: "Electricians Zone" },
  { value: "guide", label: "Guide" },
  { value: "blog", label: "Blog" },
  { value: "other", label: "Other" },
];

/** Private storage buckets that may be previewed through the admin signed URL. */
export const ALLOWED_PREVIEW_BUCKETS = [
  "autocad",
  "autolisp",
  "checklists",
  "images",
  "pdf",
  "resources",
  "templates",
] as const;

/** Entity kinds that can carry standard references. */
export type RefEntity = "calculator" | "resource" | "article";

export const REF_TABLE = {
  calculator: "calculator_references",
  resource: "resource_references",
  article: "article_references",
} as const;

export const REF_FK = {
  calculator: "calculator_id",
  resource: "resource_id",
  article: "article_id",
} as const;

export const REF_PARENT_TABLE = {
  calculator: "calculators",
  resource: "resources",
  article: "articles",
} as const;

export const REF_PARENT_LABEL = {
  calculator: "name",
  resource: "title",
  article: "title",
} as const;