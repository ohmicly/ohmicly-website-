/**
 * Analytics abstraction.
 * Providers (GA4, GTM, server-side) register here; nothing is loaded by
 * default, so no tracking script ships until one is configured.
 */
export type AnalyticsEvent =
  | { name: "page_view"; path: string }
  | { name: "search"; query: string; scope: string }
  | { name: "resource_view"; slug: string; access: "free" | "premium" }
  | { name: "download"; slug: string; fileType: string }
  | { name: "calculator_run"; slug: string }
  | { name: "cta_click"; label: string };

export type AnalyticsProvider = { id: string; track: (event: AnalyticsEvent) => void };

const providers: AnalyticsProvider[] = [];

export function registerAnalyticsProvider(provider: AnalyticsProvider) {
  if (!providers.some((p) => p.id === provider.id)) providers.push(provider);
}

export function track(event: AnalyticsEvent) {
  for (const p of providers) {
    try {
      p.track(event);
    } catch {
      /* analytics must never break the UI */
    }
  }
}
