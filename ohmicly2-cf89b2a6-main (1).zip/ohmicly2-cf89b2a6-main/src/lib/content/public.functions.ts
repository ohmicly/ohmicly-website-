/**
 * Public content read layer. All published website content comes from the
 * database through these server functions (SSR-safe, anon RLS).
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type {
  Article,
  CalculatorDef,
  Category,
  Faq,
  Resource,
  ResolvedReference,
  SearchResult,
  Standard,
} from "./types";

const REF_SELECT =
  "section, note, url, standards ( id, slug, code, edition, name, summary, url )";

type RefRow = {
  section: string | null;
  note: string | null;
  url: string | null;
  standards: {
    id: string;
    slug: string;
    code: string;
    edition: string | null;
    name: string;
    summary: string;
    url: string | null;
  } | null;
};

function mapRefs(rows: RefRow[] | null | undefined): ResolvedReference[] {
  return (rows ?? [])
    .filter((r) => r.standards)
    .map((r) => ({
      id: r.standards!.id,
      slug: r.standards!.slug,
      code: r.standards!.code,
      edition: r.standards!.edition,
      name: r.standards!.name,
      summary: r.standards!.summary,
      section: r.section,
      note: r.note,
      url: r.url ?? r.standards!.url,
    }));
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapResource(row: any): Resource {
  return {
    id: row.id,
    title: row.title,
    slug: row.slug,
    description: row.description ?? "",
    who_for: row.who_for ?? null,
    problem_solved: row.problem_solved ?? null,
    whats_included: row.whats_included ?? [],
    how_to_use: row.how_to_use ?? [],
    category: row.resource_categories?.slug ?? "",
    category_name: row.resource_categories?.name ?? "",
    subcategory: row.subcategory ?? undefined,
    subcategory_slug: row.primary_subcategory?.slug ?? null,
    subcategory_name: row.primary_subcategory?.name ?? null,
    subcategory_slugs: Array.from(
      new Set(
        [
          row.primary_subcategory?.slug,
          ...((row.resource_subcategories ?? []) as any[]).map(
            (l) => l.resource_categories?.slug,
          ),
        ].filter(Boolean),
      ),
    ) as string[],
    resource_type: row.resource_type,
    file_type: (row.file_type ?? "PDF") as Resource["file_type"],
    file_name: row.file_name ?? null,
    file_size: row.file_size ?? null,
    file_url: row.file_url ?? null,
    has_file: Boolean(row.file_path || row.file_url),
    thumbnail_url: row.thumbnail_url ?? null,
    preview_images:
      row.preview_images?.length ? row.preview_images : row.thumbnail_url ? [row.thumbnail_url] : [],
    is_free: row.is_free,
    is_premium: row.is_premium,
    status: row.status,
    tags: row.tags ?? [],
    keywords: row.tags ?? [],
    author: row.author ?? "OHMICLY",
    created_at: row.created_at,
    updated_at: row.updated_at,
    download_count: row.download_count ?? 0,
    view_count: row.view_count ?? 0,
    featured: row.featured ?? false,
    seo_title: row.seo_title ?? row.title,
    seo_description: row.seo_description ?? row.description ?? "",
    ranking_notes: row.ranking_notes ?? "",
    disclaimer: row.disclaimer ?? null,
    canonical_url: row.canonical_url ?? `/resources/${row.slug}`,
    noindex: row.noindex ?? false,
    schema_type: row.schema_type ?? "CreativeWork",
    references: mapRefs(row.resource_references),
  };
}

function mapCalculator(row: any): CalculatorDef {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description ?? "",
    category: row.category ?? "General",
    icon: row.icon ?? "calculator",
    thumbnail_url: row.thumbnail_url ?? null,
    status: (row.status ?? "coming-soon") as CalculatorDef["status"],
    seo_title: row.seo_title ?? row.name,
    seo_description: row.seo_description ?? row.description ?? "",
    keywords: row.keywords ?? [],
    related_calculators: row.related_calculators ?? [],
    references: mapRefs(row.calculator_references),
    faq: (row.faq ?? []) as Faq[],
    formula_notes: row.formula_notes ?? [],
    disclaimer: row.disclaimer ?? undefined,
  };
}

function mapArticle(row: any): Article {
  return {
    id: row.id,
    title: row.title,
    slug: row.slug,
    excerpt: row.excerpt ?? "",
    body: row.body ?? null,
    category: row.article_categories?.name ?? "Knowledge",
    category_slug: row.article_categories?.slug ?? "knowledge",
    author: row.author ?? "OHMICLY",
    reading_time: row.reading_time ?? "5 min read",
    status: row.status,
    tags: row.tags ?? [],
    created_at: row.created_at,
    updated_at: row.updated_at,
    published_at: row.published_at ?? null,
    cover_image_url: row.cover_image_url ?? null,
    references: mapRefs(row.article_references),
  };
}
/* eslint-enable @typescript-eslint/no-explicit-any */

const RESOURCE_SELECT =
  "*, resource_categories!resources_category_id_fkey ( slug, name ), " +
  "primary_subcategory:resource_categories!resources_primary_subcategory_id_fkey ( slug, name ), " +
  "resource_subcategories ( resource_categories ( slug, name ) ), " +
  "resource_references ( " +
  REF_SELECT +
  " )";

export type ResourceFilter = {
  categories?: string[];
  subcategories?: string[];
  resourceType?: string;
  access?: "free" | "premium";
  limit?: number;
};

export const listResources = createServerFn({ method: "GET" })
  .inputValidator((input: ResourceFilter | undefined) =>
    z
      .object({
        categories: z.array(z.string()).optional(),
        subcategories: z.array(z.string()).optional(),
        resourceType: z.string().optional(),
        access: z.enum(["free", "premium"]).optional(),
        limit: z.number().int().positive().max(200).optional(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data }): Promise<Resource[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    let query = supabase
      .from("resources")
      .select(RESOURCE_SELECT)
      .eq("status", "published")
      .order("featured", { ascending: false })
      .order("created_at", { ascending: false });

    if (data.resourceType) query = query.eq("resource_type", data.resourceType as never);
    if (data.access === "premium") query = query.eq("is_premium", true);
    if (data.access === "free") query = query.eq("is_premium", false);
    if (data.limit) query = query.limit(data.limit);

    const { data: rows, error } = await query;
    if (error) throw error;
    let mapped = (rows ?? []).map(mapResource);
    if (data.categories?.length) {
      const set = new Set(data.categories);
      mapped = mapped.filter((r) => set.has(r.category));
    }
    if (data.subcategories?.length) {
      const set = new Set(data.subcategories);
      mapped = mapped.filter(
        (r) => r.subcategory_slugs.some((s) => set.has(s)) || (r.subcategory && set.has(r.subcategory)),
      );
    }
    return mapped;
  });

export type ResourceBundle = {
  resource: Resource;
  faqs: Faq[];
  relatedResources: { slug: string; title: string; file_type: string; is_premium: boolean }[];
  premiumPicks: { slug: string; title: string; file_type: string }[];
  relatedTools: { slug: string; name: string; category: string }[];
  relatedArticles: { slug: string; title: string; reading_time: string }[];
};

export const getResource = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) => z.object({ slug: z.string() }).parse(input))
  .handler(async ({ data }): Promise<ResourceBundle | null> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const { hasCalculatorEngine } = await import("./engine-slugs");
    const supabase = createPublicServerClient();
    const { data: row, error } = await supabase
      .from("resources")
      .select(RESOURCE_SELECT)
      .eq("slug", data.slug)
      .eq("status", "published")
      .maybeSingle();
    if (error) throw error;
    if (!row) return null;
    const resource = mapResource(row);
    const tags = resource.tags.filter(Boolean);

    const [faqRes, sameCat, tagRes, calcRes, artRes] = await Promise.all([
      supabase
        .from("faqs")
        .select("question, answer")
        .eq("is_published", true)
        .eq("resource_id", resource.id)
        .order("sort_order", { ascending: true }),
      supabase
        .from("resources")
        .select("slug, title, file_type, is_premium, resource_categories!resources_category_id_fkey ( slug )")
        .eq("status", "published")
        .neq("slug", resource.slug)
        .limit(30),
      tags.length
        ? supabase
            .from("resources")
            .select("slug, title, file_type, is_premium")
            .eq("status", "published")
            .neq("slug", resource.slug)
            .overlaps("tags", tags)
            .limit(10)
        : Promise.resolve({ data: [] as never[] }),
      tags.length
        ? supabase
            .from("calculators")
            .select("slug, name, category, keywords")
            .eq("is_published", true)
            .overlaps("keywords", tags)
            .limit(6)
        : Promise.resolve({ data: [] as never[] }),
      tags.length
        ? supabase
            .from("articles")
            .select("slug, title, reading_time, body")
            .eq("status", "published")
            .overlaps("tags", tags)
            .limit(5)
        : Promise.resolve({ data: [] as never[] }),
    ]);

    /* eslint-disable @typescript-eslint/no-explicit-any */
    const catRows = ((sameCat.data ?? []) as any[]).filter(
      (r) => (r.resource_categories?.slug ?? "") === resource.category,
    );
    const pool = [...catRows, ...((tagRes.data ?? []) as any[])];
    const dedupe = new Map<string, any>();
    for (const r of pool) if (!dedupe.has(r.slug)) dedupe.set(r.slug, r);
    const all = [...dedupe.values()];

    const relatedResources = all
      .filter((r) => !r.is_premium || resource.is_premium)
      .slice(0, 5)
      .map((r) => ({
        slug: r.slug,
        title: r.title,
        file_type: r.file_type ?? "",
        is_premium: Boolean(r.is_premium),
      }));
    const premiumPicks = resource.is_premium
      ? []
      : all
          .filter((r) => r.is_premium)
          .slice(0, 3)
          .map((r) => ({ slug: r.slug, title: r.title, file_type: r.file_type ?? "" }));
    const relatedTools = ((calcRes.data ?? []) as any[])
      .filter((c) => hasCalculatorEngine(c.slug))
      .slice(0, 4)
      .map((c) => ({ slug: c.slug, name: c.name, category: c.category ?? "" }));
    const relatedArticles = ((artRes.data ?? []) as any[])
      .filter((a) => Boolean(a.body && a.body.trim()))
      .slice(0, 4)
      .map((a) => ({ slug: a.slug, title: a.title, reading_time: a.reading_time ?? "" }));
    /* eslint-enable @typescript-eslint/no-explicit-any */

    return {
      resource,
      faqs: (faqRes.data ?? []) as Faq[],
      relatedResources,
      premiumPicks,
      relatedTools,
      relatedArticles,
    };
  });

export const listCategories = createServerFn({ method: "GET" }).handler(
  async (): Promise<Category[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data, error } = await supabase
      .from("resource_categories")
      .select("id, slug, name, icon, description, parent_id")
      .eq("is_active", true)
      .order("sort_order", { ascending: true });
    if (error) throw error;
    return (data ?? []).map((c) => ({
      id: c.id,
      slug: c.slug,
      name: c.name,
      icon: c.icon ?? "folder",
      description: c.description ?? "",
      parentId: c.parent_id,
    }));
  },
);

export type SidebarSubcategory = { slug: string; name: string; icon: string; count: number };
export type SidebarCategory = {
  slug: string;
  name: string;
  icon: string;
  groupLabel: string;
  count: number;
  subcategories: SidebarSubcategory[];
};

export type PublicSidebarData = {
  totalResources: number;
  categories: SidebarCategory[];
  topics: Array<{ label: string; score: number }>;
};

const FALLBACK_TOPICS = ["Electrical Safety", "RSC Audit", "Nirapon", "AutoCAD", "Cable Sizing"];

export const getPublicSidebarData = createServerFn({ method: "GET" }).handler(
  async (): Promise<PublicSidebarData> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const [categoryResult, resourceResult] = await Promise.all([
      supabase
        .from("resource_categories")
        .select("id, slug, name, icon, parent_id, sort_order, is_active, group_label")
        .order("sort_order", { ascending: true }),
      supabase
        .from("resources")
        .select(
          "tags, download_count, view_count, resource_categories!resources_category_id_fkey ( slug ), " +
            "primary_subcategory:resource_categories!resources_primary_subcategory_id_fkey ( slug ), " +
            "resource_subcategories ( resource_categories ( slug ) )",
        )
        .eq("status", "published"),
    ]);
    if (categoryResult.error) throw categoryResult.error;
    if (resourceResult.error) throw resourceResult.error;

    /* eslint-disable @typescript-eslint/no-explicit-any */
    const resources = (resourceResult.data ?? []) as any[];
    /** slug -> set of resource indexes, so a resource is never counted twice. */
    const members = new Map<string, Set<number>>();
    const counts = { get: (slug: string) => members.get(slug)?.size ?? 0 };
    const topicScores = new Map<string, number>();
    const topicLabels = new Map<string, string>();
    for (const [index, resource] of resources.entries()) {
      const slugs = new Set<string>();
      const category = resource.resource_categories?.slug;
      if (category) slugs.add(category);
      if (resource.primary_subcategory?.slug) slugs.add(resource.primary_subcategory.slug);
      for (const link of resource.resource_subcategories ?? []) {
        if (link.resource_categories?.slug) slugs.add(link.resource_categories.slug);
      }
      for (const slug of slugs) {
        const set = members.get(slug) ?? new Set<number>();
        set.add(index);
        members.set(slug, set);
      }


      const engagement = (resource.download_count ?? 0) * 3 + (resource.view_count ?? 0) + 1;
      for (const rawTag of resource.tags ?? []) {
        const label = String(rawTag).trim();
        if (!label) continue;
        const key = label.toLowerCase();
        topicLabels.set(key, topicLabels.get(key) ?? label);
        topicScores.set(key, (topicScores.get(key) ?? 0) + engagement);
      }
    }

    const rows = (categoryResult.data ?? []) as any[];
    /* eslint-enable @typescript-eslint/no-explicit-any */
    const visible = (row: { is_active: boolean; slug: string }, own: number) =>
      row.is_active || own > 0;

    const categories: SidebarCategory[] = rows
      .filter((row) => !row.parent_id)
      .map((row) => {
        const subcategories: SidebarSubcategory[] = rows
          .filter((child) => child.parent_id === row.id)
          .map((child) => ({
            slug: child.slug,
            name: child.name,
            icon: child.icon ?? "folder",
            count: counts.get(child.slug) ?? 0,
          }))
          .filter((child) => {
            const source = rows.find((r) => r.slug === child.slug);
            return visible(source, child.count);
          });
        // Distinct resources across the category itself and all its subcategories.
        const union = new Set<number>(members.get(row.slug) ?? []);
        for (const child of subcategories) {
          for (const index of members.get(child.slug) ?? []) union.add(index);
        }
        const total = union.size;
        return {
          slug: row.slug,
          name: row.name,
          icon: row.icon ?? "folder-open",
          groupLabel: row.group_label?.trim() || "Browse",
          count: total,
          subcategories,
        };
      })
      .filter((category) => {
        const source = rows.find((r) => r.slug === category.slug);
        return visible(source, category.count);
      });

    const ranked = [...topicScores.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 6)
      .map(([key, score]) => ({ label: topicLabels.get(key) ?? key, score }));
    const topics = ranked.length >= 3
      ? ranked
      : FALLBACK_TOPICS.map((label) => ({ label, score: topicScores.get(label.toLowerCase()) ?? 0 }));

    return { totalResources: resources.length, categories, topics };
  },
);

/**
 * Popular RSC & NIRAPON resources for the homepage.
 * Ranked automatically by downloads + views (engagement), no manual curation.
 */
export const listPopularRscResources = createServerFn({ method: "GET" }).handler(
  async (): Promise<Resource[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data: rows, error } = await supabase
      .from("resources")
      .select(RESOURCE_SELECT)
      .eq("status", "published")
      .order("download_count", { ascending: false })
      .order("view_count", { ascending: false })
      .limit(60);
    if (error) throw error;
    const mapped = (rows ?? []).map(mapResource);
    const score = (r: Resource) => r.download_count * 3 + r.view_count;
    const matches = (r: Resource) => {
      const hay = [
        r.title,
        r.description,
        r.category,
        r.category_name,
        r.subcategory_name ?? "",
        ...r.subcategory_slugs,
        ...r.tags,
      ]
        .join(" ")
        .toLowerCase();
      return /\brsc\b|nirapon|audit|safety|checklist/.test(hay);
    };
    const primary = mapped.filter(matches).sort((a, b) => score(b) - score(a));
    const rest = mapped.filter((r) => !matches(r)).sort((a, b) => score(b) - score(a));
    return [...primary, ...rest].slice(0, 4);
  },
);

/**
 * Live platform counters for the homepage compliance section.
 * Everything is derived from published rows, so adding or removing
 * a resource/calculator changes these numbers automatically.
 */
export type PlatformStats = {
  resources: number;
  templates: number;
  calculators: number;
  downloads: number;
  frameworks: { key: "rsc" | "nirapon" | "higg"; count: number; percent: number }[];
};

export const getPlatformStats = createServerFn({ method: "GET" }).handler(
  async (): Promise<PlatformStats> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();

    const [resourcesRes, calcRes] = await Promise.all([
      supabase
        .from("resources")
        .select("title, description, resource_type, subcategory, tags, download_count")
        .eq("status", "published"),
      supabase.from("calculators").select("id").eq("is_published", true),
    ]);
    if (resourcesRes.error) throw resourcesRes.error;
    if (calcRes.error) throw calcRes.error;

    const rows = resourcesRes.data ?? [];
    const hay = (r: (typeof rows)[number]) =>
      [r.title, r.description, r.resource_type, r.subcategory ?? "", ...(r.tags ?? [])]
        .join(" ")
        .toLowerCase();

    const total = rows.length;
    const templates = rows.filter(
      (r) => r.resource_type === "template" || /\btemplate\b/.test(hay(r)),
    ).length;
    const downloads = rows.reduce((sum, r) => sum + (r.download_count ?? 0), 0);

    const patterns: { key: "rsc" | "nirapon" | "higg"; re: RegExp }[] = [
      { key: "rsc", re: /\brsc\b|audit|checklist/ },
      { key: "nirapon", re: /nirapon|safety|fire|structural/ },
      { key: "higg", re: /higg|\bfem\b|environment/ },
    ];
    const frameworks = patterns.map(({ key, re }) => {
      const count = rows.filter((r) => re.test(hay(r))).length;
      return { key, count, percent: total ? Math.round((count / total) * 100) : 0 };
    });

    return {
      resources: total,
      templates,
      calculators: (calcRes.data ?? []).length,
      downloads,
      frameworks,
    };
  },
);



export const listCalculators = createServerFn({ method: "GET" }).handler(
  async (): Promise<CalculatorDef[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data, error } = await supabase
      .from("calculators")
      .select("*, calculator_references ( " + REF_SELECT + " )")
      .eq("is_published", true)
      .order("name", { ascending: true });
    if (error) throw error;
    return (data ?? []).map(mapCalculator);
  },
);

export const getCalculator = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) => z.object({ slug: z.string() }).parse(input))
  .handler(async ({
    data,
  }): Promise<{
    calculator: CalculatorDef;
    related: CalculatorDef[];
    relatedResources: { title: string; slug: string; category: string }[];
    relatedArticles: { title: string; slug: string; reading_time: string }[];
  } | null> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data: row, error } = await supabase
      .from("calculators")
      .select("*, calculator_references ( " + REF_SELECT + " )")
      .eq("slug", data.slug)
      .eq("is_published", true)
      .maybeSingle();
    if (error) throw error;
    if (!row) return null;
    const calculator = mapCalculator(row);
    let related: CalculatorDef[] = [];
    if (calculator.related_calculators.length) {
      const { data: rel } = await supabase
        .from("calculators")
        .select("*")
        .eq("is_published", true)
        .in("slug", calculator.related_calculators);
      related = (rel ?? []).map(mapCalculator);
    }

    // Related content is only surfaced when the database actually links it
    // through shared tags — nothing is fabricated.
    const tags = calculator.keywords.flatMap((k) => k.split(/[\s,]+/)).filter(Boolean);
    let relatedResources: { title: string; slug: string; category: string }[] = [];
    let relatedArticles: { title: string; slug: string; reading_time: string }[] = [];
    if (tags.length) {
      const [res, arts] = await Promise.all([
        supabase
          .from("resources")
          .select("title, slug, resource_categories!resources_category_id_fkey ( name )")
          .eq("status", "published")
          .overlaps("tags", tags)
          .limit(5),
        supabase
          .from("articles")
          .select("title, slug, reading_time")
          .eq("status", "published")
          .overlaps("tags", tags)
          .limit(5),
      ]);
      relatedResources = (res.data ?? []).map((r) => ({
        title: r.title,
        slug: r.slug,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        category: (r as any).resource_categories?.name ?? "",
      }));
      relatedArticles = (arts.data ?? []).map((a) => ({
        title: a.title,
        slug: a.slug,
        reading_time: a.reading_time ?? "",
      }));
    }

    return { calculator, related, relatedResources, relatedArticles };
  });

export const listArticles = createServerFn({ method: "GET" })
  .inputValidator((input: { limit?: number } | undefined) =>
    z.object({ limit: z.number().int().positive().max(100).optional() }).parse(input ?? {}),
  )
  .handler(async ({ data }): Promise<Article[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    let query = supabase
      .from("articles")
      .select("*, article_categories ( name, slug )")
      .eq("status", "published")
      .order("published_at", { ascending: false, nullsFirst: false });
    if (data.limit) query = query.limit(data.limit);
    const { data: rows, error } = await query;
    if (error) throw error;
    return (rows ?? []).map(mapArticle);
  });

export const getArticle = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) => z.object({ slug: z.string() }).parse(input))
  .handler(async ({ data }): Promise<{ article: Article; related: Article[] } | null> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data: row, error } = await supabase
      .from("articles")
      .select("*, article_categories ( name, slug ), article_references ( " + REF_SELECT + " )")
      .eq("slug", data.slug)
      .eq("status", "published")
      .maybeSingle();
    if (error) throw error;
    if (!row) return null;
    const { data: rel } = await supabase
      .from("articles")
      .select("*, article_categories ( name, slug )")
      .eq("status", "published")
      .neq("slug", data.slug)
      .limit(4);
    return { article: mapArticle(row), related: (rel ?? []).map(mapArticle) };
  });

export const listFaqs = createServerFn({ method: "GET" }).handler(async (): Promise<Faq[]> => {
  const { createPublicServerClient } = await import("@/lib/supabase-public.server");
  const supabase = createPublicServerClient();
  const { data, error } = await supabase
    .from("faqs")
    .select("question, answer")
    .eq("is_published", true)
    .eq("scope", "site")
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return data ?? [];
});

export const listStandards = createServerFn({ method: "GET" }).handler(
  async (): Promise<Standard[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data, error } = await supabase
      .from("standards")
      .select("id, name, code, edition, publisher, summary, url")
      .order("code", { ascending: true });
    if (error) throw error;
    return (data ?? []).map((s) => ({
      id: s.id,
      name: s.name,
      code: s.code,
      edition: s.edition ?? undefined,
      publisher: s.publisher ?? undefined,
      summary: s.summary,
      url: s.url ?? undefined,
    }));
  },
);

export const searchContent = createServerFn({ method: "GET" })
  .inputValidator((input: { q: string; scope?: string }) =>
    z.object({ q: z.string().max(200), scope: z.string().max(40).optional() }).parse(input),
  )
  .handler(async ({ data }): Promise<SearchResult[]> => {
    if (!data.q.trim()) return [];
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const supabase = createPublicServerClient();
    const { data: rows, error } = await supabase.rpc("search_content", {
      q: data.q,
      scope: data.scope ?? "All",
    });
    if (error) throw error;
    return (rows ?? []).map((r) => ({
      id: r.id,
      type: r.type as SearchResult["type"],
      label: r.label,
      title: r.title,
      description: r.description ?? "",
      href: r.href,
      access: (r.access ?? undefined) as SearchResult["access"],
    }));
  });

/** Slugs + real timestamps for the XML sitemap (indexable content only). */
export type StandardUsage = Standard & {
  slug: string;
  calculators: { slug: string; name: string }[];
  resources: { slug: string; title: string }[];
  articles: { slug: string; title: string }[];
};

/**
 * Standards with the calculators, resources and articles that reference them.
 * Only existing reference rows are used; nothing is inferred.
 */
export const listStandardUsage = createServerFn({ method: "GET" }).handler(
  async (): Promise<StandardUsage[]> => {
    const { createPublicServerClient } = await import("@/lib/supabase-public.server");
    const { hasCalculatorEngine } = await import("./engine-slugs");
    const supabase = createPublicServerClient();
    const [std, calcRefs, resRefs, artRefs] = await Promise.all([
      supabase
        .from("standards")
        .select("id, slug, name, code, edition, publisher, summary, url")
        .order("code", { ascending: true }),
      supabase
        .from("calculator_references")
        .select("standard_id, calculators ( slug, name, is_published )"),
      supabase.from("resource_references").select("standard_id, resources ( slug, title, status )"),
      supabase
        .from("article_references")
        .select("standard_id, articles ( slug, title, status, body )"),
    ]);

    return (std.data ?? []).map((s) => {
      const dedupe = <T extends { slug: string }>(rows: T[]) =>
        Array.from(new Map(rows.map((r) => [r.slug, r])).values());
      return {
        id: s.id,
        slug: s.slug,
        name: s.name,
        code: s.code,
        edition: s.edition ?? undefined,
        publisher: s.publisher ?? undefined,
        summary: s.summary,
        url: s.url ?? undefined,
        calculators: dedupe(
          (calcRefs.data ?? [])
            .filter((r) => r.standard_id === s.id && r.calculators?.is_published)
            .map((r) => ({ slug: r.calculators!.slug, name: r.calculators!.name }))
            .filter((c) => hasCalculatorEngine(c.slug)),
        ),
        resources: dedupe(
          (resRefs.data ?? [])
            .filter((r) => r.standard_id === s.id && r.resources?.status === "published")
            .map((r) => ({ slug: r.resources!.slug, title: r.resources!.title })),
        ),
        articles: dedupe(
          (artRefs.data ?? [])
            .filter(
              (r) =>
                r.standard_id === s.id &&
                r.articles?.status === "published" &&
                Boolean(r.articles.body && r.articles.body.trim()),
            )
            .map((r) => ({ slug: r.articles!.slug, title: r.articles!.title })),
        ),
      };
    });
  },
);

export const listSitemapEntries = createServerFn({ method: "GET" }).handler(async () => {
  const { createPublicServerClient } = await import("@/lib/supabase-public.server");
  const { hasCalculatorEngine } = await import("./engine-slugs");
  const supabase = createPublicServerClient();
  const [tools, res, posts] = await Promise.all([
    supabase.from("calculators").select("slug, updated_at").eq("is_published", true),
    // Only indexable resources: published, not manually hidden, and with a real file attached.
    supabase
      .from("resources")
      .select("slug, updated_at")
      .eq("status", "published")
      .eq("noindex", false)
      .or("file_path.not.is.null,file_url.not.is.null"),
    supabase.from("articles").select("slug, body, published_at, updated_at").eq("status", "published"),
  ]);
  const day = (v: string | null | undefined) => (v ? v.slice(0, 10) : undefined);
  return {
    tools: (tools.data ?? [])
      .filter((r) => hasCalculatorEngine(r.slug))
      .map((r) => ({ slug: r.slug, lastmod: day(r.updated_at) })),
    resources: (res.data ?? []).map((r) => ({ slug: r.slug, lastmod: day(r.updated_at) })),
    articles: (posts.data ?? [])
      .filter((r) => Boolean(r.body && r.body.trim()))
      .map((r) => ({ slug: r.slug, lastmod: day(r.updated_at ?? r.published_at) })),
  };
});