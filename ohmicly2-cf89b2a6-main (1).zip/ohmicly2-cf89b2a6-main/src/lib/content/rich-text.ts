/** Helpers for rendering admin-authored article bodies safely. */

const HTML_HINT = /<(p|h2|h3|ul|ol|li|blockquote|strong|em|b|i|u|a|img|br|hr|div|figure)\b/i;

/** True when the stored body was written with the rich-text editor. */
export const isHtmlBody = (body: string) => HTML_HINT.test(body);

/**
 * Conservative allowlist sanitizer: removes scripts, embedded frames, inline
 * event handlers and javascript: URLs before the body is rendered.
 */
export function sanitizeArticleHtml(html: string): string {
  return html
    .replace(/<\s*(script|style|iframe|object|embed|form|input|link|meta)\b[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
    .replace(/<\s*(script|style|iframe|object|embed|form|input|link|meta)\b[^>]*\/?>/gi, "")
    .replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, "")
    .replace(/\son[a-z]+\s*=\s*'[^']*'/gi, "")
    .replace(/\son[a-z]+\s*=\s*[^\s>]+/gi, "")
    .replace(/(href|src)\s*=\s*(["'])\s*javascript:[^"']*\2/gi, '$1="#"');
}

/** Converts stored rich text into readable plain text for cards and metadata. */
export function richTextToPlainText(value: string): string {
  return value
    .replace(/<\s*br\s*\/?>/gi, " ")
    .replace(/<\s*\/\s*(p|div|h2|h3|li|blockquote)\s*>/gi, " ")
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#(?:0*39|x0*27);/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}
