/**
 * Content domain models.
 * Field names intentionally mirror the future Supabase tables so the
 * repository layer can switch from local seed data to queries without
 * touching components.
 */

export type Access = "free" | "premium";
export type PublishStatus = "draft" | "published" | "archived";

export type ResourceType =
  | "blog"
  | "autocad"
  | "autolisp"
  | "checklist"
  | "template"
  | "cv-template"
  | "pdf"
  | "guide"
  | "other";

export type FileType = "DWG" | "DXF" | "LSP" | "PDF" | "XLSX" | "DOCX" | "ZIP" | "HTML";

/** Standards registry entry (BNBC, NEC, NSC, RSC, Nirapon, ...). */
export type Standard = {
  id: string;
  name: string;
  code: string;
  edition?: string | undefined;
  publisher?: string | undefined;
  summary: string;
  url?: string | undefined;
};

/**
 * A citation attached to a resource, calculator or article.
 * `section` stays optional on purpose: exact clause numbers are only
 * displayed once verified and entered through the admin system.
 */
export type ReferenceLink = {
  standardId: string;
  section?: string | undefined;
  note?: string | undefined;
  url?: string | undefined;
};

export type Faq = { question: string; answer: string };

/** A standard reference already resolved against the standards registry. */
export type ResolvedReference = {
  id: string;
  slug: string;
  code: string;
  edition: string | null;
  name: string;
  summary: string;
  section: string | null;
  note: string | null;
  url: string | null;
};

export type Category = {
  id: string;
  slug: string;
  name: string;
  icon: string;
  description: string;
  parentId?: string | null | undefined;
};

export type Resource = {
  id: string;
  title: string;
  slug: string;
  description: string;
  who_for: string | null;
  problem_solved: string | null;
  whats_included: string[];
  how_to_use: string[];
  category: string;
  category_name: string;
  subcategory?: string | undefined;
  /** Primary subcategory (drives breadcrumb + canonical listing URL). */
  subcategory_slug: string | null;
  subcategory_name: string | null;
  /** Primary + cross-listed subcategory slugs. */
  subcategory_slugs: string[];
  resource_type: ResourceType;
  file_type: FileType;
  file_name: string | null;
  file_size: number | null;
  file_url: string | null;
  has_file: boolean;
  thumbnail_url: string | null;
  /** Uploaded preview images (gallery). First entry mirrors thumbnail_url. */
  preview_images: string[];
  is_free: boolean;
  is_premium: boolean;
  status: PublishStatus;
  tags: string[];
  keywords: string[];
  author: string;
  created_at: string;
  updated_at: string;
  download_count: number;
  view_count: number;
  featured: boolean;
  seo_title: string;
  seo_description: string;
  ranking_notes: string;
  /** Optional per-resource engineering disclaimer. Hidden when empty. */
  disclaimer: string | null;
  canonical_url: string;
  noindex: boolean;
  schema_type: string;
  references: ResolvedReference[];
};

export type CalculatorStatus = "available" | "coming-soon";

export type CalculatorDef = {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: string;
  icon: string;
  thumbnail_url: string | null;
  status: CalculatorStatus;
  seo_title: string;
  seo_description: string;
  keywords: string[];
  related_calculators: string[];
  references: ResolvedReference[];
  faq: Faq[];
  formula_notes: string[];
  disclaimer?: string | undefined;
};

export type Article = {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  category: string;
  category_slug: string;
  author: string;
  reading_time: string;
  status: PublishStatus;
  tags: string[];
  created_at: string;
  updated_at: string;
  published_at: string | null;
  body: string | null;
  cover_image_url: string | null;
  references: ResolvedReference[];
};

export type SearchResultType =
  | "CALCULATOR"
  | "RESOURCE"
  | "ARTICLE"
  | "FAQ"
  | "REFERENCE"
  | "TEMPLATE";

export type SearchResult = {
  id: string;
  type: SearchResultType;
  label: string;
  title: string;
  description: string;
  href: string;
  access?: Access | undefined;
};

export const accessOf = (r: Resource): Access => (r.is_premium ? "premium" : "free");
