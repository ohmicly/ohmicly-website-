/**
 * Calculator slugs that have a real implemented calculation engine.
 * Pages without an engine stay accessible but are noindex and excluded
 * from the XML sitemap until their engine ships.
 */
export const ENGINE_CALCULATOR_SLUGS = [
  "voltage-drop-calculator",
  "cable-size-calculator",
  "load-calculator",
  "ocpd-calculator",
] as const;

export const hasCalculatorEngine = (slug: string): boolean =>
  (ENGINE_CALCULATOR_SLUGS as readonly string[]).includes(slug);
