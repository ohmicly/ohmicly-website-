/**
 * Branded PDF report generation for the OHMICLY calculators.
 *
 * Client-side only (jsPDF is imported dynamically). This module never performs
 * a calculation: every number it prints is supplied by the caller, which reads
 * it straight from the calculator engine output already shown on screen.
 */

import { ENGINEERING_DISCLAIMER, SITE } from "@/lib/site";

export type ReportTone = "pass" | "fail" | "info";

export type ReportRow = { label: string; value: string; tone?: ReportTone };

export type ReportSpec = {
  /** e.g. "Voltage Drop Calculation" — " Report" is appended. */
  title: string;
  /** Short calculator code used in the reference number, e.g. "VD". */
  code: string;
  /** Path of the calculator page, e.g. "/calculator/voltage-drop-calculator". */
  path: string;
  preparedFor?: string;
  status?: { label: string; tone: ReportTone };
  /** Single headline result line, printed large under the status band. */
  headline: string;
  inputs: ReportRow[];
  results: ReportRow[];
  steps: { label: string; expression: string }[];
  comparison?: { title: string; head: string[]; rows: { cells: string[]; tone?: ReportTone }[] };
  references: { title: string; detail?: string; url?: string }[];
  notes?: string[];
};

/* ---------- design tokens (mirrors the app palette) ---------- */
const PRIMARY: [number, number, number] = [30, 64, 175]; // #1E40AF
const TEAL: [number, number, number] = [15, 118, 110]; // #0F766E
const ACCENT: [number, number, number] = [249, 115, 22]; // #F97316
const WARN: [number, number, number] = [180, 83, 9]; // amber warning already used in-app
const BG: [number, number, number] = [248, 250, 252]; // #F8FAFC
const TEXT: [number, number, number] = [15, 23, 42]; // #0F172A
const MUTED: [number, number, number] = [100, 116, 139]; // #64748B
const BORDER: [number, number, number] = [226, 232, 240]; // #E2E8F0

const PAGE_W = 210;
const PAGE_H = 297;
const M = 15; // page margin
const CONTENT_W = PAGE_W - M * 2;
const TOP = 34; // first content y after header
const BOTTOM = 268; // content must stop here

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

/** OHM-VD-YYYYMMDD-XXXXXX */
export function makeReferenceNo(code: string, when = new Date()): string {
  const d = when.toISOString().slice(0, 10).replace(/-/g, "");
  let rand = "";
  const bytes = new Uint8Array(6);
  if (typeof crypto !== "undefined" && "getRandomValues" in crypto) crypto.getRandomValues(bytes);
  else for (let i = 0; i < 6; i++) bytes[i] = Math.floor(Math.random() * 256);
  for (let i = 0; i < 6; i++) rand += CODE_CHARS[bytes[i]! % CODE_CHARS.length];
  return `OHM-${code}-${d}-${rand}`;
}

const utcStamp = (d: Date) =>
  `${d.toUTCString().replace("GMT", "UTC")}`;

export async function generateCalculatorReport(spec: ReportSpec): Promise<void> {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const now = new Date();
  const refNo = makeReferenceNo(spec.code, now);

  /**
   * jsPDF's built-in Helvetica only covers WinAnsi. Engineering notation uses
   * several characters outside it, which would otherwise print as garbage, so
   * every string drawn is mapped to a WinAnsi-safe equivalent first.
   */
  const GLYPHS: [RegExp, string][] = [
    [/√(\d)/g, "sqrt($1)"],
    [/√/g, "sqrt"],
    [/Ω/g, "ohm"],
    [/[φϕ]/g, "phi"],
    [/ρ/g, "rho"],
    [/µ/g, "u"],
    [/±/g, "+/-"],
    [/×/g, "x"],
    [/÷/g, "/"],
    [/[−–—]/g, "-"],
    [/·/g, "-"],
    [/≤/g, "<="],
    [/≥/g, ">="],
    [/≈/g, "~"],
    [/[’‘]/g, "'"],
    [/[“”]/g, '"'],
    [/…/g, "..."],
  ];
  const clean = (t: unknown): string => {
    let s = String(t);
    for (const [re, to] of GLYPHS) s = s.replace(re, to);
    return s;
  };
  const cleanAny = (t: unknown): string | string[] =>
    Array.isArray(t) ? t.map((line) => clean(line)) : clean(t);

  const patch = doc as unknown as Record<string, (...args: never[]) => unknown>;
  const rawText = doc.text.bind(doc) as (...args: never[]) => unknown;
  const rawSplit = doc.splitTextToSize.bind(doc) as (...args: never[]) => unknown;
  patch["text"] = ((text: unknown, ...rest: never[]) =>
    rawText(cleanAny(text) as never, ...rest)) as (...args: never[]) => unknown;
  patch["splitTextToSize"] = ((text: unknown, ...rest: never[]) =>
    rawSplit(clean(text) as never, ...rest)) as (...args: never[]) => unknown;

  let y = TOP;


  const setFill = (c: [number, number, number]) => doc.setFillColor(c[0], c[1], c[2]);
  const setText = (c: [number, number, number]) => doc.setTextColor(c[0], c[1], c[2]);
  const setDraw = (c: [number, number, number]) => doc.setDrawColor(c[0], c[1], c[2]);

  const drawWatermark = () => {
    doc.saveGraphicsState();
    // Border-gray, low opacity diagonal repeat.
    // @ts-expect-error GState is provided by jsPDF at runtime.
    doc.setGState(new doc.GState({ opacity: 0.12 }));
    setText(BORDER);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    for (let row = 0; row < 7; row++) {
      for (let col = 0; col < 3; col++) {
        doc.text("OHMICLY FREE TOOL", 5 + col * 75, 45 + row * 40, { angle: 30 });
      }
    }
    doc.restoreGraphicsState();
    setText(TEXT);
  };

  const drawHeader = () => {
    setFill(BG);
    doc.rect(0, 0, PAGE_W, 26, "F");
    setDraw(BORDER);
    doc.line(0, 26, PAGE_W, 26);

    // Logo mark
    setFill(PRIMARY);
    doc.roundedRect(M, 7, 7, 7, 1.5, 1.5, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(255, 255, 255);
    doc.text("O", M + 3.5, 12, { align: "center" });

    setText(PRIMARY);
    doc.setFontSize(13);
    doc.text("OHMICLY", M + 10, 12.5);
    setText(TEXT);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text(`${spec.title} Report`, M + 10, 18);

    doc.setFontSize(8);
    setText(ACCENT);
    doc.setFont("helvetica", "bold");
    doc.text(`Ref. ${refNo}`, PAGE_W - M, 10, { align: "right" });
    doc.setFont("helvetica", "normal");
    setText(MUTED);
    doc.text(`Generated ${utcStamp(now)}`, PAGE_W - M, 14.5, { align: "right" });
    if (spec.preparedFor?.trim()) {
      doc.text(`Prepared for: ${spec.preparedFor.trim()}`, PAGE_W - M, 19, { align: "right" });
    }
    setText(TEXT);
  };

  const drawFooter = (page: number) => {
    setDraw(BORDER);
    doc.line(M, 274, PAGE_W - M, 274);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    setText(MUTED);
    const lines = doc.splitTextToSize(ENGINEERING_DISCLAIMER, CONTENT_W);
    doc.text(lines, M, 278);
    doc.setFontSize(7.5);
    doc.text(`Generated by OHMICLY — ohmicly2.lovable.app`, M, PAGE_H - 8);
    doc.text(`Page ${page}`, PAGE_W - M, PAGE_H - 8, { align: "right" });
    setText(TEXT);
  };

  const startPage = () => {
    drawWatermark();
    drawHeader();
    y = TOP;
  };

  const ensure = (h: number) => {
    if (y + h <= BOTTOM) return;
    doc.addPage();
    startPage();
  };

  const heading = (text: string) => {
    ensure(14);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    setText(PRIMARY);
    doc.text(text, M, y);
    y += 2;
    setDraw(BORDER);
    doc.line(M, y, PAGE_W - M, y);
    y += 5;
    setText(TEXT);
  };

  const toneColor = (tone?: ReportTone) =>
    tone === "pass" ? TEAL : tone === "fail" ? WARN : MUTED;

  const twoColTable = (rows: ReportRow[]) => {
    const labelW = CONTENT_W * 0.55;
    rows.forEach((row, i) => {
      const labelLines = doc.splitTextToSize(row.label, labelW - 6);
      const valueLines = doc.splitTextToSize(row.value, CONTENT_W - labelW - 6);
      const h = Math.max(labelLines.length, valueLines.length) * 4.4 + 3.6;
      ensure(h);
      if (i % 2 === 0) {
        setFill(BG);
        doc.rect(M, y - 4, CONTENT_W, h, "F");
      }
      setDraw(BORDER);
      doc.rect(M, y - 4, CONTENT_W, h, "S");
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      setText(TEXT);
      doc.text(labelLines, M + 3, y);
      setText(row.tone ? toneColor(row.tone) : TEXT);
      doc.setFont("helvetica", "bold");
      doc.text(valueLines, M + labelW + 3, y);
      setText(TEXT);
      y += h;
    });
    y += 5;
  };

  const gridTable = (head: string[], rows: { cells: string[]; tone?: ReportTone }[]) => {
    const cols = head.length;
    const colW = CONTENT_W / cols;
    const drawHead = () => {
      ensure(9);
      setFill(PRIMARY);
      doc.rect(M, y - 4.5, CONTENT_W, 7, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.setTextColor(255, 255, 255);
      head.forEach((h, i) => doc.text(h, M + i * colW + 2.5, y));
      setText(TEXT);
      y += 7;
    };
    drawHead();
    rows.forEach((row, i) => {
      const h = 6.2;
      if (y + h > BOTTOM) {
        doc.addPage();
        startPage();
        drawHead();
      }
      if (i % 2 === 0) {
        setFill(BG);
        doc.rect(M, y - 4.2, CONTENT_W, h, "F");
      }
      setDraw(BORDER);
      doc.rect(M, y - 4.2, CONTENT_W, h, "S");
      doc.setFontSize(8);
      row.cells.forEach((cell, c) => {
        const last = c === cols - 1;
        doc.setFont("helvetica", last && row.tone ? "bold" : "normal");
        setText(last && row.tone ? toneColor(row.tone) : TEXT);
        doc.text(doc.splitTextToSize(cell, colW - 5)[0] ?? "", M + c * colW + 2.5, y);
      });
      setText(TEXT);
      y += h;
    });
    y += 5;
  };

  const paragraph = (text: string, size = 8.5, color = MUTED) => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(size);
    setText(color);
    const lines = doc.splitTextToSize(text, CONTENT_W);
    for (const line of lines) {
      ensure(5);
      doc.text(line, M, y);
      y += 4.4;
    }
    setText(TEXT);
  };

  /* ---------------- build ---------------- */
  startPage();

  // Status band
  if (spec.status) {
    ensure(20);
    const tone = spec.status.tone;
    setFill(tone === "pass" ? TEAL : tone === "fail" ? WARN : PRIMARY);
    doc.roundedRect(M, y - 4, CONTENT_W, 13, 2, 2, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(255, 255, 255);
    doc.text(spec.status.label.toUpperCase(), M + 5, y + 4.5);
    setText(TEXT);
    y += 16;
  }

  ensure(14);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  setText(PRIMARY);
  const headlineLines = doc.splitTextToSize(spec.headline, CONTENT_W);
  doc.text(headlineLines, M, y + 2);
  y += headlineLines.length * 7 + 6;
  setText(TEXT);

  heading("Input parameters");
  twoColTable(spec.inputs);

  heading("Results summary");
  twoColTable(spec.results);

  if (spec.steps.length) {
    heading("Calculation steps");
    spec.steps.forEach((s) => {
      ensure(11);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      setText(TEXT);
      doc.text(s.label, M, y);
      y += 4.4;
      doc.setFont("courier", "normal");
      doc.setFontSize(8.5);
      setText(PRIMARY);
      const lines = doc.splitTextToSize(s.expression, CONTENT_W);
      for (const line of lines) {
        ensure(5);
        doc.text(line, M + 2, y);
        y += 4.4;
      }
      y += 2;
      setText(TEXT);
      doc.setFont("helvetica", "normal");
    });
    y += 2;
  }

  if (spec.comparison && spec.comparison.rows.length) {
    heading(spec.comparison.title);
    gridTable(spec.comparison.head, spec.comparison.rows);
  }

  if (spec.notes?.length) {
    heading("Notes and limitations");
    spec.notes.forEach((n) => {
      paragraph(`• ${n}`);
      y += 1;
    });
    y += 3;
  }

  if (spec.references.length) {
    heading("Standard references");
    spec.references.forEach((r) => {
      ensure(10);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.5);
      setText(TEXT);
      const t = doc.splitTextToSize(r.title, CONTENT_W);
      doc.text(t, M, y);
      y += t.length * 4.4;
      if (r.detail) paragraph(r.detail);
      if (r.url) {
        ensure(5);
        doc.setFontSize(8);
        setText(TEAL);
        doc.textWithLink(r.url, M, y, { url: r.url });
        y += 4.4;
      }
      y += 2;
      setText(TEXT);
    });
  }

  ensure(10);
  paragraph(
    `Source page: ${SITE.url}${spec.path} — re-run this calculation online to verify the values above.`,
    8,
  );

  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    drawFooter(p);
  }

  doc.save(`${refNo}.pdf`);
}
