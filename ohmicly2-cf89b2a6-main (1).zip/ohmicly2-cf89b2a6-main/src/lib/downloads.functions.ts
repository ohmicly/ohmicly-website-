/**
 * Secure download issuing. Files live in PRIVATE storage buckets; the browser
 * never gets a permanent public URL. A short-lived signed URL is minted here
 * only after the resource's access level has been checked server-side.
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SIGNED_URL_TTL_SECONDS = 300;
const FREE_DOWNLOAD_LIMIT = 20;
const FREE_DOWNLOAD_WINDOW_SECONDS = 60;

/**
 * Client IP as seen by the edge. `cf-connecting-ip` is written by Cloudflare on
 * every inbound request and overwrites anything the client sent, so it cannot be
 * spoofed by a custom header. The `x-forwarded-for` fallback only exists for
 * local development, where there is no edge in front of the server.
 */
function clientIp(): string | null {
  const cf = getRequestHeader("cf-connecting-ip");
  if (cf) return cf;
  const xff = getRequestHeader("x-forwarded-for");
  if (xff) {
    // The right-most entry is the one appended by the closest trusted proxy.
    const parts = xff.split(",").map((p) => p.trim()).filter(Boolean);
    const last = parts[parts.length - 1];
    if (last) return last;
  }
  return null;
}

/** Returns true when the caller is still within the allowed request budget. */
async function withinFreeDownloadLimit(): Promise<boolean> {
  const ip = clientIp();
  if (!ip) return true; // No trustworthy identity available — do not block real users.
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.rpc("consume_rate_limit", {
    _key: `free_download:${ip}`,
    _limit: FREE_DOWNLOAD_LIMIT,
    _window_seconds: FREE_DOWNLOAD_WINDOW_SECONDS,
  });
  if (error) {
    console.error("[downloads] rate limit check failed", error);
    return true; // Never break downloads because the limiter itself failed.
  }
  return data !== false;
}

const slugInput = (input: { slug: string }) => z.object({ slug: z.string().max(200) }).parse(input);

type FileRow = { bucket: string | null; path: string | null; is_premium: boolean };

async function lookupFile(slug: string): Promise<FileRow | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.rpc("get_published_resource_file", { _slug: slug });
  if (error) throw error;
  const row = (data as FileRow[] | null)?.[0];
  return row ?? null;
}

async function signUrl(bucket: string, path: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.storage
    .from(bucket)
    .createSignedUrl(path, SIGNED_URL_TTL_SECONDS, { download: true });
  if (error) throw error;
  return data.signedUrl;
}

async function recordDownload(slug: string, userId: string | null) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: resource } = await supabaseAdmin
    .from("resources")
    .select("id")
    .eq("slug", slug)
    .maybeSingle();
  if (!resource) return;
  await supabaseAdmin.from("downloads").insert({ resource_id: resource.id, user_id: userId });
  // Atomic increment — safe under concurrent downloads.
  await supabaseAdmin.rpc("increment_resource_download", { _resource_id: resource.id });
}

/** Free resources only. Rejects anything marked premium. */
export const getFreeDownloadUrl = createServerFn({ method: "POST" })
  .inputValidator(slugInput)
  .handler(async ({ data }): Promise<{ url: string } | { error: string }> => {
    if (!(await withinFreeDownloadLimit())) {
      return { error: "Too many download requests. Please try again in a minute." };
    }
    const row = await lookupFile(data.slug);
    if (!row?.bucket || !row.path) return { error: "This file is not available yet." };
    if (row.is_premium) return { error: "Premium access required." };
    const url = await signUrl(row.bucket, row.path);
    await recordDownload(data.slug, null);
    return { url };
  });

/** Premium resources. Requires a signed-in user with active premium access. */
export const getPremiumDownloadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(slugInput)
  .handler(async ({ data, context }): Promise<{ url: string } | { error: string }> => {
    const { data: allowed, error } = await context.supabase.rpc("has_premium_access", {
      _user_id: context.userId,
    });
    if (error) throw error;
    if (!allowed) return { error: "Premium access required." };
    const row = await lookupFile(data.slug);
    if (!row?.bucket || !row.path) return { error: "This file is not available yet." };
    const url = await signUrl(row.bucket, row.path);
    await recordDownload(data.slug, context.userId);
    return { url };
  });
