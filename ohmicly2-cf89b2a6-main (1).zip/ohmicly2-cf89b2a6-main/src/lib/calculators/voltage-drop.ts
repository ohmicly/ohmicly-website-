/**
 * Voltage drop calculation engine.
 *
 * Pure functions only — no UI, no data access. All conductor tables, material
 * properties and unit conversions come from the shared engineering data layer
 * in `@/lib/engineering`; this module only holds the voltage-drop formulas.
 */

import {
  AWG_SIZES,
  CONDUCTOR_SIZES,
  type ConductorMaterial,
  type ConductorSize,
  conductorReactanceOhms,
  conductorResistanceOhms,
  feetToMetres,
  findSize,
  FT_TO_M,
  METRIC_SIZES,
  OPERATING_TEMP_C_VALUE,
  REACTANCE_PER_M_VALUE,
  RESISTIVITY_AT_OPERATING_TEMP,
} from "@/lib/engineering";

export type PhaseMode = "dc" | "single" | "three";
export type Material = ConductorMaterial;

export {
  AWG_SIZES,
  METRIC_SIZES,
  CONDUCTOR_SIZES,
  findSize,
  FT_TO_M,
  type ConductorSize,
};

/**
 * Resistivity (Ω·mm²/m) at the assumed conductor operating temperature.
 * Unchanged values, now sourced from the shared engineering data layer.
 */
export const RESISTIVITY_75C: Record<Material, number> = {
  copper: RESISTIVITY_AT_OPERATING_TEMP.copper.value,
  aluminum: RESISTIVITY_AT_OPERATING_TEMP.aluminum.value,
};

/** Typical per-conductor reactance for AC circuits in conduit (Ω per metre). */
export const REACTANCE_PER_M = REACTANCE_PER_M_VALUE.value;

/** Conductor operating temperature assumed by the resistivity values above. */
export const OPERATING_TEMP_C = OPERATING_TEMP_C_VALUE.value;

export type VoltageDropInput = {
  voltage: number;
  phase: PhaseMode;
  current: number;
  distanceFt: number;
  sizeId: string;
  material: Material;
  powerFactor: number;
  conductorsPerPhase: number;
  limitPercent: number;
};

export type VoltageDropResult = {
  dropVolts: number;
  dropPercent: number;
  receivingVoltage: number;
  resistanceOhms: number;
  reactanceOhms: number;
  lengthM: number;
  withinLimit: boolean;
};

export function calculateVoltageDrop(input: VoltageDropInput): VoltageDropResult {
  const size = findSize(input.sizeId);
  if (!size) throw new Error("Unknown conductor size");

  const lengthM = feetToMetres(input.distanceFt);
  const parallel = Math.max(1, input.conductorsPerPhase);

  const R = conductorResistanceOhms({
    resistivity: RESISTIVITY_75C[input.material],
    lengthM,
    areaMm2: size.areaMm2,
    conductorsPerPhase: parallel,
  });
  const X =
    input.phase === "dc"
      ? 0
      : conductorReactanceOhms({ reactancePerM: REACTANCE_PER_M, lengthM, conductorsPerPhase: parallel });

  const pf = input.phase === "dc" ? 1 : Math.min(1, Math.max(0, input.powerFactor));
  const sinPhi = input.phase === "dc" ? 0 : Math.sqrt(Math.max(0, 1 - pf * pf));

  const multiplier = input.phase === "three" ? Math.sqrt(3) : 2;
  const dropVolts = multiplier * input.current * (R * pf + X * sinPhi);
  const dropPercent = (dropVolts / input.voltage) * 100;

  return {
    dropVolts,
    dropPercent,
    receivingVoltage: input.voltage - dropVolts,
    resistanceOhms: R,
    reactanceOhms: X,
    lengthM,
    withinLimit: dropPercent <= input.limitPercent,
  };
}

export type FieldErrors = Partial<Record<keyof VoltageDropInput, string>>;

export function validateVoltageDrop(raw: {
  voltage: string;
  current: string;
  distanceFt: string;
  powerFactor: string;
  limitPercent: string;
  sizeId: string;
  phase: PhaseMode;
}): FieldErrors {
  const errors: FieldErrors = {};
  const num = (v: string) => (v.trim() === "" ? NaN : Number(v));

  const voltage = num(raw.voltage);
  if (Number.isNaN(voltage)) errors.voltage = "System voltage is required.";
  else if (voltage <= 0) errors.voltage = "Voltage must be greater than zero.";
  else if (voltage > 36000) errors.voltage = "This tool covers low and medium voltage up to 36,000 V.";

  const current = num(raw.current);
  if (Number.isNaN(current)) errors.current = "Load current is required.";
  else if (current <= 0) errors.current = "Current must be greater than zero.";
  else if (current > 10000) errors.current = "Enter a load current of 10,000 A or less.";

  const distance = num(raw.distanceFt);
  if (Number.isNaN(distance)) errors.distanceFt = "One-way distance is required.";
  else if (distance <= 0) errors.distanceFt = "Distance must be greater than zero.";
  else if (distance > 50000) errors.distanceFt = "Enter a one-way distance of 50,000 ft or less.";

  if (!findSize(raw.sizeId)) errors.sizeId = "Select a conductor size.";

  if (raw.phase !== "dc") {
    const pf = num(raw.powerFactor);
    if (Number.isNaN(pf)) errors.powerFactor = "Power factor is required for AC circuits.";
    else if (pf <= 0 || pf > 1) errors.powerFactor = "Power factor must be between 0.01 and 1.";
  }

  const limit = num(raw.limitPercent);
  if (Number.isNaN(limit)) errors.limitPercent = "Enter a voltage drop limit.";
  else if (limit <= 0 || limit > 20) errors.limitPercent = "Limit must be between 0.1% and 20%.";

  return errors;
}