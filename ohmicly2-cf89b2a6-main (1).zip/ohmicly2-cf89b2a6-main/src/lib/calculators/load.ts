/**
 * Load calculation engine (v1).
 *
 * Pure functions only — no UI, no data access.
 *
 * Scope note: this calculator computes connected load, apparent power and
 * load current from the fundamental single-phase and three-phase power
 * relationships. It does NOT apply demand factors, diversity factors or code
 * loading rules because OHMICLY does not hold verified tables for those values.
 * Any demand/diversity factor is entered explicitly by the user and is simply
 * multiplied against the connected load.
 */

export type LoadType = "resistive" | "motor" | "general";
export type Phase = "single" | "three";

export type LoadInput = {
  loadType: LoadType;
  powerKw: number;
  voltage: number;
  phase: Phase;
  powerFactor: number;
  quantity: number;
  loadFactor?: number | undefined;
};

export type LoadResult = {
  /** Real power for one load unit (kW). */
  unitLoadKw: number;
  /** Total connected real power = unitLoadKw × quantity (kW). */
  connectedLoadKw: number;
  /** Total apparent power = connectedLoadKw / powerFactor (kVA). */
  apparentPowerKva: number;
  /** Line current calculated from apparent power and system voltage (A). */
  currentA: number;
  /** Power factor used in the calculation. */
  powerFactor: number;
  /** Quantity multiplier applied. */
  quantity: number;
  /** User-supplied load factor, if any. */
  loadFactor?: number | undefined;
  /** Load after applying user-supplied load factor (connectedLoadKw × loadFactor). */
  diversifiedLoadKw?: number | undefined;
  /** Apparent power after applying user-supplied load factor (kVA). */
  diversifiedKva?: number | undefined;
  /** Phase arrangement used. */
  phase: Phase;
  /** Voltage used. */
  voltage: number;
};

/** Square root of 3, cached for readability and consistency. */
const SQRT3 = Math.sqrt(3);

export function calculateLoad(input: LoadInput): LoadResult {
  const quantity = Math.max(1, Math.floor(input.quantity || 1));
  const pf = Math.min(1, Math.max(0.01, input.powerFactor));
  const connectedLoadKw = input.powerKw * quantity;
  const apparentPowerKva = connectedLoadKw / pf;

  const currentA =
    input.phase === "three"
      ? (apparentPowerKva * 1000) / (SQRT3 * input.voltage)
      : (apparentPowerKva * 1000) / input.voltage;

  const result: LoadResult = {
    unitLoadKw: input.powerKw,
    connectedLoadKw,
    apparentPowerKva,
    currentA,
    powerFactor: pf,
    quantity,
    phase: input.phase,
    voltage: input.voltage,
  };

  if (input.loadFactor !== undefined && !Number.isNaN(input.loadFactor)) {
    const lf = Math.min(1, Math.max(0, input.loadFactor));
    result.loadFactor = lf;
    result.diversifiedLoadKw = connectedLoadKw * lf;
    result.diversifiedKva = result.diversifiedLoadKw / pf;
  }

  return result;
}

export type LoadFieldErrors = Partial<Record<keyof LoadInput, string>>;

export function validateLoad(raw: {
  powerKw: string;
  voltage: string;
  powerFactor: string;
  quantity: string;
  loadFactor: string;
  phase: Phase;
}): LoadFieldErrors {
  const errors: LoadFieldErrors = {};
  const num = (v: string) => (v.trim() === "" ? NaN : Number(v));

  const power = num(raw.powerKw);
  if (Number.isNaN(power)) errors.powerKw = "Load power is required.";
  else if (power <= 0) errors.powerKw = "Load power must be greater than zero.";
  else if (power > 100000) errors.powerKw = "Enter a load power of 100,000 kW or less.";

  const voltage = num(raw.voltage);
  if (Number.isNaN(voltage)) errors.voltage = "Voltage is required.";
  else if (voltage <= 0) errors.voltage = "Voltage must be greater than zero.";
  else if (voltage > 36000) errors.voltage = "This tool covers low and medium voltage up to 36,000 V.";

  const pf = num(raw.powerFactor);
  if (Number.isNaN(pf)) errors.powerFactor = "Power factor is required.";
  else if (pf <= 0 || pf > 1) errors.powerFactor = "Power factor must be between 0.01 and 1.";

  const quantity = num(raw.quantity);
  if (Number.isNaN(quantity) || quantity < 1) errors.quantity = "Quantity must be at least 1.";
  else if (quantity > 10000) errors.quantity = "Enter a quantity of 10,000 or less.";

  if (raw.loadFactor.trim() !== "") {
    const lf = num(raw.loadFactor);
    if (Number.isNaN(lf)) errors.loadFactor = "Load factor must be a number.";
    else if (lf < 0 || lf > 1) errors.loadFactor = "Load factor must be between 0 and 1.";
  }

  return errors;
}
