/**
 * Overcurrent protection device (OCPD) calculation engine (v1).
 *
 * Pure functions only — no UI, no data access.
 *
 * Scope note: this module computes the REQUIRED PROTECTION CURRENT from the
 * design current and any factor the user explicitly enters. It does NOT apply
 * code rules (continuous-load multipliers, motor rules, next-standard-size
 * allowances, conductor-ampacity coordination), and it does NOT ship a
 * standard OCPD rating table. OHMICLY holds no verified standard-rating series,
 * so automatic device selection is reported as UNAVAILABLE rather than guessed.
 */

export type OcpdApplication = "general" | "continuous" | "motor" | "other";

export type OcpdInput = {
  application: OcpdApplication;
  /** Calculated / design load current (A). */
  designCurrentA: number;
  /** Optional multiplier, only when the user explicitly enters one. */
  continuousFactor?: number | undefined;
  /** Optional user-entered maximum allowable protection rating (A). */
  maxRatingA?: number | undefined;
};

export type OcpdStandardRating = {
  ratingA: number;
  series: string;
  source: string;
};

export type OcpdResult = {
  designCurrentA: number;
  continuousFactor?: number | undefined;
  /** Design current × user-entered factor (or design current when no factor). */
  requiredProtectionCurrentA: number;
  maxRatingA?: number | undefined;
  /** True when the user-entered maximum is below the required protection current. */
  exceedsMaxRating: boolean;
  application: OcpdApplication;
  /** Null whenever no verified standard-rating data exists (always in v1). */
  standardRating: OcpdStandardRating | null;
  /** Machine-readable reason the standard rating could not be selected. */
  standardRatingUnavailableReason: string | null;
};

/**
 * Verified standard OCPD rating series registry.
 *
 * Deliberately empty: no published standard-rating series (for example the
 * NEC 240.6(A) list or an equivalent BNBC/IEC series) has been verified into
 * OHMICLY. Inventing ratings would be unsafe, so selection stays unavailable.
 */
export const OCPD_STANDARD_RATINGS: Record<string, readonly OcpdStandardRating[]> = {};

export const OCPD_STANDARD_RATING_UNAVAILABLE =
  "No verified standard OCPD rating series is loaded in OHMICLY, so a breaker or fuse size cannot be selected automatically.";

/** Returns the smallest verified standard rating at or above the current, or null. */
export function selectStandardRating(currentA: number, series?: string): OcpdStandardRating | null {
  const lists = series ? [OCPD_STANDARD_RATINGS[series] ?? []] : Object.values(OCPD_STANDARD_RATINGS);
  const candidates = lists
    .flat()
    .filter((r) => r.ratingA >= currentA)
    .sort((a, b) => a.ratingA - b.ratingA);
  return candidates[0] ?? null;
}

export function calculateOcpd(input: OcpdInput): OcpdResult {
  const design = input.designCurrentA;
  const factor =
    input.continuousFactor !== undefined && !Number.isNaN(input.continuousFactor)
      ? input.continuousFactor
      : undefined;
  const required = factor !== undefined ? design * factor : design;
  const standardRating = selectStandardRating(required);

  const result: OcpdResult = {
    designCurrentA: design,
    requiredProtectionCurrentA: required,
    exceedsMaxRating: input.maxRatingA !== undefined ? input.maxRatingA < required : false,
    application: input.application,
    standardRating,
    standardRatingUnavailableReason: standardRating ? null : OCPD_STANDARD_RATING_UNAVAILABLE,
  };
  if (factor !== undefined) result.continuousFactor = factor;
  if (input.maxRatingA !== undefined) result.maxRatingA = input.maxRatingA;
  return result;
}

export type OcpdFieldErrors = Partial<Record<"designCurrentA" | "continuousFactor" | "maxRatingA", string>>;

export function validateOcpd(raw: {
  designCurrentA: string;
  continuousFactor: string;
  maxRatingA: string;
}): OcpdFieldErrors {
  const errors: OcpdFieldErrors = {};
  const num = (v: string) => (v.trim() === "" ? NaN : Number(v));

  const current = num(raw.designCurrentA);
  if (Number.isNaN(current)) errors.designCurrentA = "Design current is required.";
  else if (current <= 0) errors.designCurrentA = "Design current must be greater than zero.";
  else if (current > 100000) errors.designCurrentA = "Enter a design current of 100,000 A or less.";

  if (raw.continuousFactor.trim() !== "") {
    const f = num(raw.continuousFactor);
    if (Number.isNaN(f)) errors.continuousFactor = "Factor must be a number.";
    else if (f < 1 || f > 5) errors.continuousFactor = "Factor must be between 1 and 5.";
  }

  if (raw.maxRatingA.trim() !== "") {
    const m = num(raw.maxRatingA);
    if (Number.isNaN(m)) errors.maxRatingA = "Maximum rating must be a number.";
    else if (m <= 0) errors.maxRatingA = "Maximum rating must be greater than zero.";
    else if (m > 100000) errors.maxRatingA = "Enter a maximum rating of 100,000 A or less.";
  }

  return errors;
}
