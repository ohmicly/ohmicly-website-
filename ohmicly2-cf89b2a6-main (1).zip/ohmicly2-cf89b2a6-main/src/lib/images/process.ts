/**
 * Browser-side image preparation for admin uploads.
 *
 * Every uploaded image is decoded, downscaled to the size it is actually
 * rendered at, and re-encoded as WebP (with a JPEG fallback when the browser
 * cannot encode WebP). Two variants are produced per upload so listing pages
 * can serve a small file while detail pages serve the large one.
 *
 * The matching hard limits are ALSO enforced server-side in
 * `adminCreateUploadUrl` — this module is the optimisation, not the guard.
 */

/** Largest original file we accept at all (server-enforced too). */
export const MAX_SOURCE_BYTES = 5 * 1024 * 1024;

/** Rendered sizes measured on the live site, doubled for retina screens. */
export const IMAGE_VARIANTS = {
  /** Detail-page preview: rendered ~566 CSS px wide. */
  full: { maxWidth: 1280, quality: 0.8 },
  /** Cards, listings, page thumbnails: rendered <= 400 CSS px wide. */
  thumb: { maxWidth: 400, quality: 0.78 },
} as const;

export type VariantName = keyof typeof IMAGE_VARIANTS;

export type PreparedImage = {
  blob: Blob;
  width: number;
  height: number;
  ext: "webp" | "jpg";
};

let webpSupport: boolean | null = null;

function canEncodeWebp(): boolean {
  if (webpSupport !== null) return webpSupport;
  try {
    const c = document.createElement("canvas");
    c.width = 1;
    c.height = 1;
    webpSupport = c.toDataURL("image/webp").startsWith("data:image/webp");
  } catch {
    webpSupport = false;
  }
  return webpSupport;
}

async function decode(file: File): Promise<ImageBitmap | HTMLImageElement> {
  if (typeof createImageBitmap === "function") {
    try {
      return await createImageBitmap(file);
    } catch {
      /* fall through to <img> decoding */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = "sync";
    img.src = url;
    await img.decode();
    return img;
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }
}

function encode(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}

async function render(
  source: ImageBitmap | HTMLImageElement,
  srcW: number,
  srcH: number,
  variant: VariantName,
): Promise<PreparedImage> {
  const { maxWidth, quality } = IMAGE_VARIANTS[variant];
  const scale = Math.min(1, maxWidth / srcW);
  const width = Math.max(1, Math.round(srcW * scale));
  const height = Math.max(1, Math.round(srcH * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("This browser cannot process images.");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  // Flatten onto white so transparent PNGs do not turn black in JPEG output.
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(source as CanvasImageSource, 0, 0, width, height);

  const webp = canEncodeWebp();
  let blob = await encode(canvas, webp ? "image/webp" : "image/jpeg", quality);
  let ext: "webp" | "jpg" = webp ? "webp" : "jpg";
  if (!blob) {
    blob = await encode(canvas, "image/jpeg", quality);
    ext = "jpg";
  }
  if (!blob) throw new Error("Could not compress this image.");
  return { blob, width, height, ext };
}

export type PreparedUpload = {
  full: PreparedImage;
  thumb: PreparedImage;
  /** Original dimensions, for reporting. */
  sourceWidth: number;
  sourceHeight: number;
};

/**
 * Decodes once and produces both the full and thumbnail variants.
 * Throws for files above the hard source limit.
 */
export async function prepareImageUpload(file: File): Promise<PreparedUpload> {
  if (file.size > MAX_SOURCE_BYTES) {
    throw new Error(
      `"${file.name}" is ${(file.size / 1048576).toFixed(1)} MB. Please use an image under 5 MB.`,
    );
  }
  const source = await decode(file);
  const srcW = "naturalWidth" in source ? source.naturalWidth : source.width;
  const srcH = "naturalHeight" in source ? source.naturalHeight : source.height;
  if (!srcW || !srcH) throw new Error("That file is not a readable image.");

  const full = await render(source, srcW, srcH, "full");
  const thumb = await render(source, srcW, srcH, "thumb");
  if ("close" in source && typeof source.close === "function") source.close();
  return { full, thumb, sourceWidth: srcW, sourceHeight: srcH };
}

/** Swaps a stored image reference to its small variant. */
export function thumbVariant(ref: string): string {
  if (!ref) return ref;
  if (!ref.startsWith("/api/public/")) return ref;
  if (ref.includes("s=thumb")) return ref;
  return `${ref}${ref.includes("?") ? "&" : "?"}s=thumb`;
}
