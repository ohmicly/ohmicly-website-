/**
 * OHMICLY engineering data foundation.
 *
 * Single place for conductor tables, material properties, unit conversions and
 * shared engineering helpers. Every constant carries metadata (value, unit,
 * material/type, source, notes, verified/assumption status) so calculators can
 * document exactly what they rely on.
 */
export * from "./types";
export * from "./units";
export * from "./materials";
export * from "./conductors";
export * from "./ampacity";