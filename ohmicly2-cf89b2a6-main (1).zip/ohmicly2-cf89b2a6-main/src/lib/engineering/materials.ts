/** Conductor material properties. */
import { type EngineeringValue } from "./types";

export type ConductorMaterial = "copper" | "aluminum";

export const OPERATING_TEMP_C_VALUE: EngineeringValue = {
  value: 75,
  unit: "°C",
  status: "assumption",
  notes:
    "Conductor operating temperature assumed for the resistivity values below — the usual assumption for insulated building wire at full rated load.",
};

/**
 * Resistivity at the assumed operating temperature above.
 * Generic engineering values, not taken from a specific published clause.
 */
export const RESISTIVITY_AT_OPERATING_TEMP: Record<ConductorMaterial, EngineeringValue> = {
  copper: {
    value: 0.0214,
    unit: "Ω·mm²/m",
    appliesTo: "Uncoated copper conductor",
    status: "assumption",
    notes: "Generic value at 75 °C. Not sourced from a specific standard clause.",
  },
  aluminum: {
    value: 0.0344,
    unit: "Ω·mm²/m",
    appliesTo: "Aluminium conductor",
    status: "assumption",
    notes: "Generic value at 75 °C. Not sourced from a specific standard clause.",
  },
};

/** Representative per-conductor AC reactance for conductors installed in conduit. */
export const REACTANCE_PER_M_VALUE: EngineeringValue = {
  value: 0.000164,
  unit: "Ω/m per conductor",
  status: "assumption",
  notes:
    "Single representative value (≈0.05 Ω per 300 m). Reactance varies with conductor spacing, raceway material and cable construction; use manufacturer data for critical feeders.",
};

/**
 * Resistance of a conductor run.
 * R = ρ × L ÷ (A × n)
 */
export function conductorResistanceOhms(args: {
  resistivity: number;
  lengthM: number;
  areaMm2: number;
  conductorsPerPhase?: number;
}) {
  const n = Math.max(1, args.conductorsPerPhase ?? 1);
  return (args.resistivity / (args.areaMm2 * n)) * args.lengthM;
}

/** Reactance of a conductor run: X = x × L ÷ n. */
export function conductorReactanceOhms(args: {
  reactancePerM: number;
  lengthM: number;
  conductorsPerPhase?: number;
}) {
  const n = Math.max(1, args.conductorsPerPhase ?? 1);
  return (args.reactancePerM / n) * args.lengthM;
}

/**
 * Temperature correction of resistance: R_T = R_ref × (1 + α × (T − T_ref)).
 * Provided for future calculators; the voltage drop tool uses the fixed 75 °C
 * resistivities above and does not call this.
 */
export const TEMP_COEFFICIENT_PER_C: Record<ConductorMaterial, EngineeringValue> = {
  copper: {
    value: 0.00393,
    unit: "1/°C at 20 °C",
    appliesTo: "Annealed copper",
    status: "assumption",
    notes: "Generic textbook coefficient. Not sourced from a specific standard clause.",
  },
  aluminum: {
    value: 0.00403,
    unit: "1/°C at 20 °C",
    appliesTo: "Aluminium",
    status: "assumption",
    notes: "Generic textbook coefficient. Not sourced from a specific standard clause.",
  },
};

export function temperatureCorrectedResistance(args: {
  resistanceAtRef: number;
  alphaPerC: number;
  refTempC: number;
  operatingTempC: number;
}) {
  return args.resistanceAtRef * (1 + args.alphaPerC * (args.operatingTempC - args.refTempC));
}