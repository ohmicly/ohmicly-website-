/** Conductor size tables shared by all calculators. */

export type ConductorSystem = "awg" | "metric";

export type ConductorSize = {
  id: string;
  label: string;
  /** Cross-sectional area in mm². */
  areaMm2: number;
  system: ConductorSystem;
};

/**
 * AWG / kcmil conductors with their published nominal metric area (mm²).
 * Status: verified nominal areas as commonly published in conductor tables.
 */
export const AWG_SIZES: ConductorSize[] = [
  { id: "awg-14", label: "14 AWG", areaMm2: 2.08, system: "awg" },
  { id: "awg-12", label: "12 AWG", areaMm2: 3.31, system: "awg" },
  { id: "awg-10", label: "10 AWG", areaMm2: 5.26, system: "awg" },
  { id: "awg-8", label: "8 AWG", areaMm2: 8.37, system: "awg" },
  { id: "awg-6", label: "6 AWG", areaMm2: 13.3, system: "awg" },
  { id: "awg-4", label: "4 AWG", areaMm2: 21.2, system: "awg" },
  { id: "awg-3", label: "3 AWG", areaMm2: 26.7, system: "awg" },
  { id: "awg-2", label: "2 AWG", areaMm2: 33.6, system: "awg" },
  { id: "awg-1", label: "1 AWG", areaMm2: 42.4, system: "awg" },
  { id: "awg-1-0", label: "1/0 AWG", areaMm2: 53.5, system: "awg" },
  { id: "awg-2-0", label: "2/0 AWG", areaMm2: 67.4, system: "awg" },
  { id: "awg-3-0", label: "3/0 AWG", areaMm2: 85.0, system: "awg" },
  { id: "awg-4-0", label: "4/0 AWG", areaMm2: 107.2, system: "awg" },
  { id: "kcmil-250", label: "250 kcmil", areaMm2: 127, system: "awg" },
  { id: "kcmil-300", label: "300 kcmil", areaMm2: 152, system: "awg" },
  { id: "kcmil-350", label: "350 kcmil", areaMm2: 177, system: "awg" },
  { id: "kcmil-400", label: "400 kcmil", areaMm2: 203, system: "awg" },
  { id: "kcmil-500", label: "500 kcmil", areaMm2: 253, system: "awg" },
];

/** Metric conductors commonly specified in Bangladesh and IEC markets. */
export const METRIC_SIZES: ConductorSize[] = [
  1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300,
].map((a) => ({ id: `mm2-${a}`, label: `${a} mm²`, areaMm2: a, system: "metric" as const }));

export const CONDUCTOR_SIZES: ConductorSize[] = [...AWG_SIZES, ...METRIC_SIZES];

export const findSize = (id: string) => CONDUCTOR_SIZES.find((s) => s.id === id);