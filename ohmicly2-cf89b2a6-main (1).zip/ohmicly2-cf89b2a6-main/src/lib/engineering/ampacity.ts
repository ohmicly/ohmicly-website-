/**
 * Ampacity / derating data registry.
 *
 * IMPORTANT: OHMICLY does not ship any ampacity table, ambient-temperature
 * correction table, grouping factor table or installation-method factor table.
 * Those values are published in specific code tables (for example NEC/NFPA 70
 * or BNBC) that have not been verified into this project, and inventing them
 * would be unsafe. Until a verified table is added, calculators must treat
 * ampacity as UNAVAILABLE and take correction factors from the user, who reads
 * them from the standard applicable to their project.
 */
import type { ConductorMaterial, EngineeringValue } from "./index";

export type AmpacityLookup = {
  material: ConductorMaterial;
  sizeId: string;
  /** Insulation temperature rating column, e.g. 75 (°C). */
  insulationTempC: number;
  installationMethod: string;
};

export type AmpacityRecord = EngineeringValue & {
  /** Base allowable current before any correction factor. */
  value: number;
};

/** Deliberately empty: no verified ampacity table is available yet. */
export const AMPACITY_TABLES: Record<string, AmpacityRecord> = {};

/** Returns null whenever no verified ampacity value exists for the lookup. */
export function getBaseAmpacity(lookup: AmpacityLookup): AmpacityRecord | null {
  const key = `${lookup.installationMethod}|${lookup.insulationTempC}|${lookup.material}|${lookup.sizeId}`;
  return AMPACITY_TABLES[key] ?? null;
}

/** Machine-readable list of engineering data this project knows it is missing. */
export const MISSING_ENGINEERING_DATA = [
  {
    id: "ampacity-tables",
    label: "Conductor ampacity tables",
    notes:
      "No verified allowable-current table (per material, size, insulation rating and installation method) has been loaded into OHMICLY.",
  },
  {
    id: "ambient-temperature-correction",
    label: "Ambient temperature correction factors",
    notes: "No verified temperature correction table is available; the factor must be supplied by the user.",
  },
  {
    id: "grouping-factors",
    label: "Grouping / bundling adjustment factors",
    notes:
      "No verified adjustment table for the number of current-carrying conductors is available; the factor must be supplied by the user.",
  },
  {
    id: "installation-method-factors",
    label: "Installation method factors",
    notes: "No verified installation-method (reference method) factor table is available.",
  },
] as const;