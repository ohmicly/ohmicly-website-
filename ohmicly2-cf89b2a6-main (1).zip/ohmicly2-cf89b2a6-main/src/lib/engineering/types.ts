/**
 * Shared metadata wrapper for every engineering constant in this layer.
 *
 * Values are either `verified` (traceable to a named published source) or
 * `assumption` (a generic engineering value used for estimation). Nothing in
 * this module may be marked `verified` without a real `source`.
 */

export type EngineeringStatus = "verified" | "assumption";

export type EngineeringValue<T = number> = {
  /** Numeric (or structured) value used by calculations. */
  value: T;
  /** Unit string, e.g. "Ω·mm²/m". */
  unit: string;
  /** Material or type this value applies to, when relevant. */
  appliesTo?: string;
  /** Published source or reference — only present when status is "verified". */
  source?: string;
  /** Assumptions, caveats and scope notes. */
  notes?: string;
  status: EngineeringStatus;
};

export const value = <T>(v: EngineeringValue<T>): EngineeringValue<T> => v;

/** Convenience accessor so calculation code stays readable. */
export const raw = <T>(v: EngineeringValue<T>): T => v.value;