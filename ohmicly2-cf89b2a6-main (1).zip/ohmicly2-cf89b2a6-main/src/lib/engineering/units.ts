/** Unit conversions shared by all calculators. */
import { type EngineeringValue, raw } from "./types";

export const FT_TO_M_VALUE: EngineeringValue = {
  value: 0.3048,
  unit: "m/ft",
  status: "verified",
  source: "International yard and pound agreement (1959): 1 ft = 0.3048 m exactly.",
};

export const FT_TO_M = raw(FT_TO_M_VALUE);

export const feetToMetres = (ft: number) => ft * FT_TO_M;
export const metresToFeet = (m: number) => m / FT_TO_M;

/** 1 kcmil = 1000 circular mils; 1 circular mil = π/4 × (0.001 in)². */
export const KCMIL_TO_MM2_VALUE: EngineeringValue = {
  value: 0.5067,
  unit: "mm²/kcmil",
  status: "verified",
  source: "Geometric definition of the circular mil with 1 in = 25.4 mm.",
  notes:
    "Provided for reference only. Conductor tables in this module list published nominal areas rather than converting from kcmil.",
};