/** Global site configuration. Non-secret values only. */
export const SITE = {
  name: "OHMICLY",
  tagline: "Electrical Engineering Tools, Resources & Knowledge — All in One Place.",
  url: (import.meta.env["VITE_SITE_URL"] as string | undefined) ?? "https://ohmicly2.lovable.app",
  locale: "en",
  twitter: "@ohmicly",
} as const;

export const ENGINEERING_DISCLAIMER =
  "Calculations and technical information are provided for reference and should be reviewed by a qualified electrical professional before use in design, construction or compliance decisions.";

export const canonical = (path: string) => `${SITE.url}${path === "/" ? "" : path}`;
