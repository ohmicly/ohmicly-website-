import { z } from "zod";

export const BRANDING_BUCKET = "site-assets";
export const MAX_BRANDING_FILE_BYTES = 2 * 1024 * 1024;

export const brandingKindSchema = z.enum(["logo", "favicon"]);
export type BrandingKind = z.infer<typeof brandingKindSchema>;

export const brandingAssetSchema = z.object({
  path: z.string().min(1).max(400),
  filename: z.string().min(1).max(200),
  mimeType: z.string().min(1).max(100),
  size: z.number().int().positive().max(MAX_BRANDING_FILE_BYTES),
  width: z.number().int().positive().max(10000),
  height: z.number().int().positive().max(10000),
  revision: z.string().min(1).max(80),
});

export const brandingSettingSchema = z.object({
  logo: brandingAssetSchema.nullable().default(null),
  favicon: brandingAssetSchema.nullable().default(null),
});

export type BrandingAsset = z.infer<typeof brandingAssetSchema>;
export type BrandingSetting = z.infer<typeof brandingSettingSchema>;

export type PublicBranding = {
  logoUrl: string | null;
  faviconUrl: string | null;
};

export const EMPTY_BRANDING: BrandingSetting = { logo: null, favicon: null };
export const EMPTY_PUBLIC_BRANDING: PublicBranding = { logoUrl: null, faviconUrl: null };

export const allowedBrandingTypes = {
  logo: ["image/svg+xml", "image/png", "image/webp"],
  favicon: ["image/svg+xml", "image/png", "image/x-icon", "image/vnd.microsoft.icon"],
} satisfies Record<BrandingKind, string[]>;

export const brandingAssetUrl = (kind: BrandingKind, revision: string) =>
  `/api/public/site-asset?kind=${kind}&v=${encodeURIComponent(revision)}`;

export function parseBrandingSetting(value: unknown): BrandingSetting {
  const result = brandingSettingSchema.safeParse(value);
  return result.success ? result.data : EMPTY_BRANDING;
}

export function toPublicBranding(setting: BrandingSetting): PublicBranding {
  return {
    logoUrl: setting.logo ? brandingAssetUrl("logo", setting.logo.revision) : null,
    faviconUrl: setting.favicon
      ? brandingAssetUrl("favicon", setting.favicon.revision)
      : null,
  };
}

export function brandingExtension(filename: string) {
  return filename.toLowerCase().split(".").pop() ?? "";
}

export function validateBrandingSelection(kind: BrandingKind, file: File): string | null {
  if (file.size <= 0 || file.size > MAX_BRANDING_FILE_BYTES) {
    return "File must be smaller than 2 MB.";
  }
  const extension = brandingExtension(file.name);
  const allowedExtensions = kind === "logo" ? ["svg", "png", "webp"] : ["svg", "png", "ico"];
  if (!allowedExtensions.includes(extension) || !allowedBrandingTypes[kind].includes(file.type)) {
    return kind === "logo" ? "Use an SVG, PNG, or WebP file." : "Use an SVG, PNG, or ICO file.";
  }
  return null;
}