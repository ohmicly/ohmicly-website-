import { createFileRoute, stripSearchParams } from "@tanstack/react-router";
import { fallback, zodValidator } from "@tanstack/zod-adapter";
import { z } from "zod";
import { PageLayout } from "@/components/site/PageLayout";
import { CalculatorBrowser } from "@/components/tools/CalculatorBrowser";
import { EngineeringDisclaimer } from "@/components/site/Disclaimer";
import { listCalculators } from "@/lib/content/public.functions";
import { seo, breadcrumbJsonLd } from "@/lib/seo";

const searchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  category: fallback(z.string(), "").default(""),
  page: fallback(z.number().int(), 1).default(1),
  sort: fallback(z.string(), "category").default("category"),
});

const defaultSearch = { q: "", category: "", page: 1, sort: "category" };
type CalculatorRouteSearch = typeof defaultSearch;

export const Route = createFileRoute("/calculator/")({
  validateSearch: zodValidator(searchSchema),
  search: { middlewares: [stripSearchParams(defaultSearch)] },
  loader: async () => ({ calculators: await listCalculators() }),
  head: () =>
    seo({
      title: "Electrical Calculators — OHMICLY",
      description:
        "Electrical calculators for voltage drop, cable sizing, load, transformer, fault current and earthing checks.",
      path: "/calculator",
      jsonLd: breadcrumbJsonLd([{ name: "Calculators", path: "/calculator" }]),
    }),
  component: Page,
});

function Page() {
  const { calculators } = Route.useLoaderData();
  const search = Route.useSearch() as CalculatorRouteSearch;
  return (
    <PageLayout crumbs={[{ name: "Calculators", path: "/calculator" }]}>
      <CalculatorBrowser
        calculators={calculators}
        q={search.q.slice(0, 100)}
        category={search.category.slice(0, 100)}
        page={Math.max(1, Math.min(999, search.page))}
        sort={search.sort}
      />
      <div className="container-page pb-10">
        <EngineeringDisclaimer />
      </div>
    </PageLayout>
  );
}
