import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/tools/")({
  beforeLoad: ({ search }) => {
    throw redirect({ to: "/calculator", search, replace: true, statusCode: 301 });
  },
});