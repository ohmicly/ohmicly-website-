import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { CategoryIntro } from "@/components/site/CategoryIntro";
import { ResourceCard } from "@/components/ui-kit/Cards";
import { EmptyState } from "@/components/ui-kit/States";
import { listResources } from "@/lib/content/public.functions";
import { seo, breadcrumbJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/autolisp")({
  loader: async () => { const items = await listResources({ data: { categories: ["autolisp"] } }); return { items }; },
  head: () =>
    seo({
      title: 'AutoLISP Utilities for Electrical Drafting — OHMICLY',
      description: 'AutoLISP routines and drafting utilities that speed up repetitive electrical drawing tasks.',
      path: "/autolisp",
      jsonLd: breadcrumbJsonLd([{ name: 'AutoLISP Utilities', path: "/autolisp" }]),
    }),
  component: Page,
});

function Page() {
  const { items } = Route.useLoaderData();
  return (
    <PageLayout crumbs={[{ name: 'AutoLISP Utilities', path: "/autolisp" }]}>
      <PageHero eyebrow='Automation' title='AutoLISP Utilities' description='Routines that remove repetitive steps from electrical drafting work.' />
      <CategoryIntro heading="About the AutoLISP utility library">
        <p>This section lists the AutoLISP routines published on OHMICLY. They automate repetitive steps in electrical drafting, such as placing and editing recurring drawing elements, so a task that is normally done manually can be run as a command.</p>
        <p>It is useful for CAD users and drafting teams already working in AutoCAD who want to reduce manual drawing time. Every routine shows its file type and access level, and each entry has its own page with the description and any standards referenced.</p>
      </CategoryIntro>
      <div className="container-page py-10 sm:py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <ResourceCard key={item.slug} item={item} />
          ))}
        </div>
        {items.length === 0 ? <EmptyState /> : null}
      </div>
    </PageLayout>
  );
}
