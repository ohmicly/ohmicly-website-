import { createFileRoute } from "@tanstack/react-router";

import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Hero } from "@/components/site/Hero";
import { ResourcePoster } from "@/components/site/ResourcePoster";
import { ComplianceFocus } from "@/components/site/ComplianceFocus";
import { HomeBlogSection } from "@/components/site/HomeBlogSection";
import { PremiumUpgrade } from "@/components/site/PremiumUpgrade";
import { MobilePublicSidebar } from "@/components/site/PublicSidebar";


import {
  RscSection,
} from "@/components/site/HomeSections";
import { getPlatformStats, listArticles, listPopularRscResources } from "@/lib/content/public.functions";
import { seo } from "@/lib/seo";

const title = "OHMICLY — Electrical Engineering Tools & Resources";
const description =
  "Electrical calculators, RSC & Nirapon audit checklists, AutoCAD and AutoLISP files, templates and technical guides for electrical engineers.";

export const Route = createFileRoute("/")({
  loader: async () => {
    const [popularResources, platformStats, articles] = await Promise.all([
      listPopularRscResources(),
      getPlatformStats(),
      listArticles({ data: { limit: 8 } }),
    ]);
    return { popularResources, platformStats, articles };
  },
  head: () => seo({ title, description, path: "/" }),
  component: Index,
});

function Index() {
  const { popularResources, platformStats, articles } = Route.useLoaderData();
  return (
    <div className="flex min-h-screen flex-col overflow-x-hidden bg-background">
      <Header />
      <main className="flex-1">
        <Hero />
        <ResourcePoster />

        <RscSection items={popularResources} />
        <ComplianceFocus stats={platformStats} />
        <HomeBlogSection articles={articles} />
        <PremiumUpgrade />
        

      </main>
      <Footer />
      <MobilePublicSidebar />
    </div>
  );
}
