import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { ResourceBrowser } from "@/components/resources/ResourceBrowser";
import { breadcrumbJsonLd, seo } from "@/lib/seo";
import { listCategories, listResources } from "@/lib/content/public.functions";

export const Route = createFileRoute("/premium")({
  loader: async () => {
    const [categories, resources] = await Promise.all([
      listCategories(),
      listResources({ data: { access: "premium" } }),
    ]);
    return { categories, resources };
  },
  head: () =>
    seo({
      title: "Premium Electrical Engineering Resources — OHMICLY",
      description:
        "Professional premium engineering files: SLD templates, earthing and LPS design sheets, and career templates.",
      path: "/premium",
      jsonLd: breadcrumbJsonLd([{ name: "Premium Resources", path: "/premium" }]),
    }),
  component: Page,
});

function Page() {
  const { categories, resources } = Route.useLoaderData();
  return (
    <PageLayout crumbs={[{ name: "Premium Resources", path: "/premium" }]}>
      <ResourceBrowser
        categories={categories}
        resources={resources}
        initialAccess="premium"
        variant="premium"
      />
    </PageLayout>
  );
}
