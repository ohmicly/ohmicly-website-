import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { breadcrumbJsonLd, seo } from "@/lib/seo";

export const Route = createFileRoute("/about")({
  head: () =>
    seo({
      title: "About OHMICLY — Electrical Engineering Platform",
      description: "OHMICLY brings electrical calculators, engineering resources, audit material and technical knowledge together in one platform.",
      path: "/about",
      jsonLd: breadcrumbJsonLd([{ name: "About OHMICLY", path: "/about" }]),
    }),
  component: Page,
});

function Page() {
  return (
    <PageLayout crumbs={[{ name: "About OHMICLY", path: "/about" }]}>
      <PageHero eyebrow="Company" title="About OHMICLY" description="An electrical engineering platform built for practical, day-to-day professional work." />
      <div className="container-page py-10 sm:py-14">
        <div className="max-w-3xl space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>OHMICLY is an electrical engineering platform bringing calculators, engineering resources, audit material, CAD files, templates and technical knowledge together in one place.</p>
          <p>The platform is built for engineers, consultants, technicians and students working in Bangladesh, with an architecture designed to scale globally.</p>
          <p>Every resource is prepared in a working format and linked to the standards it relates to, with references verified before publication.</p>
        </div>
      </div>
    </PageLayout>
  );
}
