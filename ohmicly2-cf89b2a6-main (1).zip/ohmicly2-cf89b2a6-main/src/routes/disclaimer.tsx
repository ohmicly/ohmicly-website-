import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { breadcrumbJsonLd, seo } from "@/lib/seo";
import { EngineeringDisclaimer } from "@/components/site/Disclaimer";

export const Route = createFileRoute("/disclaimer")({
  head: () =>
    seo({
      title: "Engineering Disclaimer — OHMICLY",
      description: "Calculations and technical information on OHMICLY are reference material and must be reviewed by a qualified electrical professional.",
      path: "/disclaimer",
      jsonLd: breadcrumbJsonLd([{ name: "Engineering Disclaimer", path: "/disclaimer" }]),
    }),
  component: Page,
});

function Page() {
  return (
    <PageLayout crumbs={[{ name: "Engineering Disclaimer", path: "/disclaimer" }]}>
      <PageHero eyebrow="Legal" title="Engineering Disclaimer" description="Read this before applying any OHMICLY output to a real installation." />
      <div className="container-page py-10 sm:py-14">
        <div className="max-w-3xl space-y-4">
          <EngineeringDisclaimer />
          <p className="text-sm leading-relaxed text-muted-foreground">
            Code references shown on OHMICLY are provided for orientation. Where a clause number is
            displayed, it has been verified against the published standard; where none is shown, the
            reference is general. Always consult the current edition of the applicable standard.
          </p>
          <p className="text-sm leading-relaxed text-muted-foreground">
            OHMICLY accepts no liability for design, construction or compliance decisions made on the
            basis of information published here.
          </p>
        </div>
      </div>
    </PageLayout>
  );
}
