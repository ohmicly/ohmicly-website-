import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, ImageIcon, Trash2, UploadCloud } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  adminCreateBrandingUploadUrl,
  adminDiscardBrandingUpload,
  adminFinalizeBrandingUpload,
  adminGetBranding,
  adminRemoveBrandingAsset,
} from "@/lib/admin/admin.functions";
import {
  brandingAssetUrl,
  type BrandingAsset,
  type BrandingKind,
  validateBrandingSelection,
} from "@/lib/branding";
import { AdminPage, Btn, Loading, Notice, Panel } from "@/components/admin/AdminUI";
import { DefaultLogoVisual } from "@/components/site/Logo";

export const Route = createFileRoute("/_authenticated/admin/branding")({
  head: () => ({
    meta: [
      { title: "Branding Settings — OHMICLY Admin" },
      { name: "description", content: "Manage the OHMICLY site logo and favicon." },
      { property: "og:title", content: "Branding Settings — OHMICLY Admin" },
      { property: "og:description", content: "Manage the OHMICLY site logo and favicon." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: BrandingPage,
});

type PendingAsset = { file: File; previewUrl: string };

function AssetPanel({
  kind,
  asset,
  onChanged,
}: {
  kind: BrandingKind;
  asset: BrandingAsset | null;
  onChanged: () => Promise<void>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<PendingAsset | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const createUpload = useServerFn(adminCreateBrandingUploadUrl);
  const finalizeUpload = useServerFn(adminFinalizeBrandingUpload);
  const discardUpload = useServerFn(adminDiscardBrandingUpload);
  const removeAsset = useServerFn(adminRemoveBrandingAsset);

  useEffect(() => () => {
    if (pending) URL.revokeObjectURL(pending.previewUrl);
  }, [pending]);

  const label = kind === "logo" ? "Logo" : "Favicon";
  const currentUrl = asset ? brandingAssetUrl(kind, asset.revision) : null;
  const displayedUrl = pending?.previewUrl ?? currentUrl;

  const selectFile = (file: File) => {
    setError(null);
    setSuccess(null);
    const validationError = validateBrandingSelection(kind, file);
    if (validationError) {
      setError(validationError);
      return;
    }
    const previewUrl = URL.createObjectURL(file);
    setPending((previous) => {
      if (previous) URL.revokeObjectURL(previous.previewUrl);
      return { file, previewUrl };
    });
  };

  const save = async () => {
    if (!pending) return;
    if (asset && !window.confirm(`Replace the current ${label.toLowerCase()}?`)) return;
    setBusy(true);
    setError(null);
    setSuccess(null);
    setProgress(10);
    let uploaded: { bucket: string; path: string } | null = null;
    try {
      const signed = await createUpload({
        data: {
          kind,
          fileName: pending.file.name,
          mimeType: pending.file.type,
          size: pending.file.size,
        },
      });
      uploaded = { bucket: signed.bucket, path: signed.path };
      setProgress(35);
      const { error: uploadError } = await supabase.storage
        .from(signed.bucket)
        .uploadToSignedUrl(signed.path, signed.token, pending.file, {
          contentType: pending.file.type,
          cacheControl: "31536000",
        });
      if (uploadError) throw new Error(uploadError.message);
      setProgress(75);
      await finalizeUpload({
        data: {
          kind,
          path: signed.path,
          fileName: pending.file.name,
          mimeType: pending.file.type,
          size: pending.file.size,
        },
      });
      setProgress(100);
      URL.revokeObjectURL(pending.previewUrl);
      setPending(null);
      await onChanged();
      setSuccess(`${label} saved.`);
    } catch (caught) {
      if (uploaded) {
        try {
          await discardUpload({ data: { kind, path: uploaded.path } });
        } catch {
          // Finalization removes invalid uploads itself. This is a best-effort
          // cleanup for interrupted requests after the browser upload completes.
        }
      }
      setError(caught instanceof Error ? caught.message : `${label} upload failed.`);
      setProgress(0);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!asset || !window.confirm(`Remove the custom ${label.toLowerCase()} and restore the OHMICLY default?`)) {
      return;
    }
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      await removeAsset({ data: { kind } });
      await onChanged();
      setSuccess(`${label} removed. The default is active.`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : `Could not remove the ${label.toLowerCase()}.`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Panel title={label}>
      <div className="grid min-w-0 gap-5 sm:grid-cols-[9rem_minmax(0,1fr)] sm:items-start">
        <div className="flex h-32 w-full items-center justify-center overflow-hidden rounded-lg border border-border bg-surface p-3 sm:w-36">
          {displayedUrl || (kind === "favicon" && !asset) ? (
            <img
              src={displayedUrl ?? "/favicon.ico"}
              alt={`${label} preview`}
              className={kind === "favicon" ? "h-20 w-20 object-contain" : "max-h-full max-w-full object-contain"}
            />
          ) : kind === "logo" ? (
            <div className="flex items-center gap-2">
              <DefaultLogoVisual />
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              <ImageIcon className="mx-auto h-7 w-7" aria-hidden="true" />
              <span className="mt-2 block text-xs">OHMICLY default</span>
            </div>
          )}
        </div>

        <div className="min-w-0 space-y-3">
          <div>
            <p className="break-all text-sm font-semibold text-foreground">
              {pending?.file.name ?? asset?.filename ?? `Default OHMICLY ${label.toLowerCase()}`}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {kind === "logo"
                ? "SVG, PNG or WebP. Maximum 2 MB."
                : "Square SVG, PNG or ICO. Maximum 2 MB."}
            </p>
          </div>

          <input
            ref={inputRef}
            type="file"
            className="sr-only"
            accept={kind === "logo" ? ".svg,.png,.webp,image/svg+xml,image/png,image/webp" : ".svg,.png,.ico,image/svg+xml,image/png,image/x-icon"}
            disabled={busy}
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) selectFile(file);
              event.target.value = "";
            }}
          />

          {busy ? (
            <div aria-label={`Uploading ${label.toLowerCase()}`}>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full bg-primary transition-[width]" style={{ width: `${progress}%` }} />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">Uploading and verifying… {progress}%</p>
            </div>
          ) : null}

          <div className="flex flex-wrap gap-2">
            <Btn type="button" variant="outline" disabled={busy} onClick={() => inputRef.current?.click()}>
              <UploadCloud className="h-4 w-4" aria-hidden="true" />
              {asset || pending ? "Choose replacement" : `Choose ${label.toLowerCase()}`}
            </Btn>
            {pending ? (
              <>
                <Btn type="button" busy={busy} onClick={() => void save()}>
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" /> Save
                </Btn>
                <Btn
                  type="button"
                  variant="ghost"
                  disabled={busy}
                  onClick={() => {
                    URL.revokeObjectURL(pending.previewUrl);
                    setPending(null);
                    setError(null);
                  }}
                >
                  Cancel
                </Btn>
              </>
            ) : null}
            {asset && !pending ? (
              <Btn type="button" variant="danger" busy={busy} onClick={() => void remove()}>
                <Trash2 className="h-4 w-4" aria-hidden="true" /> Remove custom {label.toLowerCase()}
              </Btn>
            ) : null}
          </div>
          {pending ? <p className="text-xs font-semibold text-amber-accent-foreground">Unsaved change</p> : null}
          {error ? <Notice kind="error">{error}</Notice> : null}
          {success ? <Notice kind="success">{success}</Notice> : null}
        </div>
      </div>
    </Panel>
  );
}

function BrandingPage() {
  const getBranding = useServerFn(adminGetBranding);
  const queryClient = useQueryClient();
  const query = useQuery({
    queryKey: ["admin", "branding"],
    queryFn: () => getBranding(),
    retry: false,
  });
  const refresh = useMemo(
    () => async () => {
      await queryClient.invalidateQueries({ queryKey: ["admin", "branding"] });
      await queryClient.invalidateQueries({ queryKey: ["branding", "public"] });
    },
    [queryClient],
  );

  return (
    <AdminPage title="Branding" description="Manage the logo and browser icon shown across OHMICLY.">
      {query.isLoading ? (
        <Loading label="Loading branding…" />
      ) : query.isError || !query.data ? (
        <Notice kind="error">Could not load branding settings.</Notice>
      ) : (
        <div className="space-y-5">
          <AssetPanel kind="logo" asset={query.data.logo} onChanged={refresh} />
          <AssetPanel kind="favicon" asset={query.data.favicon} onChanged={refresh} />
        </div>
      )}
    </AdminPage>
  );
}