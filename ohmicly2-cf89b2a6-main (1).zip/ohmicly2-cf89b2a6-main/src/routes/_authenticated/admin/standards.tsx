import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Plus } from "lucide-react";
import { adminListStandards, adminSaveStandard } from "@/lib/admin/admin.functions";
import { AdminPage, Btn, EmptyState, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";
import { ReferenceManager } from "@/components/admin/ReferenceManager";

export const Route = createFileRoute("/_authenticated/admin/standards")({
  component: StandardsAdmin,
});

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);

type Draft = {
  id: string | null;
  code: string;
  slug: string;
  name: string;
  edition: string;
  publisher: string;
  summary: string;
  url: string;
};

const EMPTY: Draft = {
  id: null,
  code: "",
  slug: "",
  name: "",
  edition: "",
  publisher: "",
  summary: "",
  url: "",
};

function StandardsAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListStandards);
  const save = useServerFn(adminSaveStandard);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const standards = useQuery({
    queryKey: ["admin", "standards"],
    queryFn: () => list(),
    retry: false,
  });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      await save({
        data: {
          id: draft.id,
          code: draft.code.trim(),
          slug: draft.slug.trim(),
          name: draft.name.trim(),
          edition: draft.edition || null,
          publisher: draft.publisher || null,
          summary: draft.summary.trim(),
          url: draft.url || null,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin"] });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this standard.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminPage
      title="Standards"
      description="The reference registry used for citations across resources, tools and articles."
      actions={
        <Btn onClick={() => setDraft({ ...EMPTY })}>
          <Plus className="h-4 w-4" aria-hidden="true" /> New standard
        </Btn>
      }
    >
      {draft ? (
        <Panel title={draft.id ? "Edit standard" : "New standard"}>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Code" required hint="e.g. BNBC 2020">
                <input
                  className="admin-input"
                  required
                  value={draft.code}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      code: e.target.value,
                      slug: draft.id ? draft.slug : slugify(e.target.value),
                    })
                  }
                />
              </Field>
              <Field label="Slug" required>
                <input
                  className="admin-input"
                  required
                  value={draft.slug}
                  onChange={(e) => setDraft({ ...draft, slug: slugify(e.target.value) })}
                />
              </Field>
              <Field label="Full name" required>
                <input
                  className="admin-input"
                  required
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </Field>
              <Field label="Edition">
                <input
                  className="admin-input"
                  value={draft.edition}
                  onChange={(e) => setDraft({ ...draft, edition: e.target.value })}
                />
              </Field>
              <Field label="Publisher">
                <input
                  className="admin-input"
                  value={draft.publisher}
                  onChange={(e) => setDraft({ ...draft, publisher: e.target.value })}
                />
              </Field>
              <Field label="Official URL">
                <input
                  className="admin-input"
                  value={draft.url}
                  onChange={(e) => setDraft({ ...draft, url: e.target.value })}
                />
              </Field>
            </div>
            <Field label="Summary" required>
              <textarea
                className="admin-input min-h-24"
                required
                value={draft.summary}
                onChange={(e) => setDraft({ ...draft, summary: e.target.value })}
              />
            </Field>
            {error ? <Notice kind="error">{error}</Notice> : null}
            <div className="flex flex-wrap gap-2">
              <Btn type="submit" busy={busy}>
                Save standard
              </Btn>
              <Btn type="button" variant="outline" onClick={() => setDraft(null)}>
                Cancel
              </Btn>
            </div>
          </form>
        </Panel>
      ) : null}

      {standards.isLoading ? (
        <Loading />
      ) : !standards.data?.length ? (
        <EmptyState title="No standards registered." />
      ) : (
        <ul className="space-y-3">
          {standards.data.map((s) => (
            <li
              key={s.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card p-4 shadow-sm"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-foreground">
                  {s.code} — {s.name}
                </p>
                <p className="truncate text-xs text-muted-foreground">{s.summary}</p>
              </div>
              <Btn
                variant="outline"
                onClick={() =>
                  setDraft({
                    id: s.id,
                    code: s.code,
                    slug: s.slug,
                    name: s.name,
                    edition: s.edition ?? "",
                    publisher: s.publisher ?? "",
                    summary: s.summary,
                    url: s.url ?? "",
                  })
                }
              >
                Edit
              </Btn>
            </li>
          ))}
        </ul>
      )}

      <ReferenceManager
        standards={(standards.data ?? []).map((s) => ({
          id: s.id,
          code: s.code,
          name: s.name,
          edition: s.edition ?? null,
        }))}
      />
    </AdminPage>
  );
}