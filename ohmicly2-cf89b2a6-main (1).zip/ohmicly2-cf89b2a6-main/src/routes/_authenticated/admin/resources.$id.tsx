import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ExternalLink, ImageIcon, Plus, Trash2, UploadCloud } from "lucide-react";
import {
  adminCreateUploadUrl,
  adminDeleteStorageObject,
  adminGetResource,
  adminListCategories,
  adminListFaqs,
  adminListStandards,
  adminSaveResource,
  adminSignedPreviewUrl,
} from "@/lib/admin/admin.functions";
import { RESOURCE_TYPES, type AdminReferenceInput } from "@/lib/admin/admin-types";
import { prepareImageUpload } from "@/lib/images/process";
import { ThumbnailField } from "@/components/admin/ThumbnailField";
import { supabase } from "@/integrations/supabase/client";
import { AdminPage, Btn, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";
import { RichTextEditor } from "@/components/admin/RichTextEditor";

export const Route = createFileRoute("/_authenticated/admin/resources/$id")({
  component: ResourceEditor,
});

const lines = (v: string) =>
  v
    .split("\n")
    .map((l) => l.replace(/^[-*\u2022]\s*/, "").trim())
    .filter(Boolean);

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 160);

/** Preview images live in the private `images` bucket and are proxied publicly. */
const imageRef = (path: string) => `/api/public/resource-image?path=${encodeURIComponent(path)}`;
const imagePathOf = (url: string) => {
  const m = /^\/api\/public\/resource-image\?path=(.+)$/.exec(url.trim());
  return m?.[1] ? decodeURIComponent(m[1]) : "";
};

type FormState = {
  title: string;
  slug: string;
  description: string;
  who_for: string;
  problem_solved: string;
  whats_included: string;
  how_to_use: string;
  resource_type: string;
  category_id: string;
  primary_subcategory_id: string;
  extra_subcategory_ids: string[];
  subcategory: string;
  tags: string;
  status: "draft" | "published" | "archived";
  is_premium: boolean;
  featured: boolean;
  file_type: string;
  file_path: string;
  storage_bucket: string;
  file_name: string;
  file_size: number | null;
  /** Preview images (gallery). */
  images: string[];
  /** Card thumbnail. Falls back to the first preview image when empty. */
  thumbnail_url: string;
  seo_title: string;
  seo_description: string;
  ranking_notes: string;
  disclaimer: string;
  canonical_url: string;
  noindex: boolean;
};

const EMPTY: FormState = {
  title: "",
  slug: "",
  description: "",
  who_for: "",
  problem_solved: "",
  whats_included: "",
  how_to_use: "",
  resource_type: "other",
  category_id: "",
  primary_subcategory_id: "",
  extra_subcategory_ids: [],
  subcategory: "",
  tags: "",
  status: "draft",
  is_premium: false,
  featured: false,
  file_type: "",
  file_path: "",
  storage_bucket: "",
  file_name: "",
  file_size: null,
  images: [],
  thumbnail_url: "",
  seo_title: "",
  seo_description: "",
  ranking_notes: "",
  disclaimer: "",
  canonical_url: "",
  noindex: false,
};

type Orphan = { bucket: string; path: string };

/** Optional Q/A pairs shown on the public resource page and in FAQPage schema. */
type FaqDraft = { question: string; answer: string };

function Counter({ value, max, ideal }: { value: string; max: number; ideal: number }) {
  const n = value.trim().length;
  const tone = n === 0 ? "text-muted-foreground" : n > max ? "text-danger" : n > ideal ? "text-amber-600" : "text-emerald-600";
  return (
    <span className={`text-xs font-semibold ${tone}`}>
      {n}/{ideal} characters {n > ideal ? "(may be truncated in search results)" : ""}
    </span>
  );
}

function ResourceEditor() {
  const { id } = useParams({ from: "/_authenticated/admin/resources/$id" });
  const isNew = id === "new";
  const navigate = useNavigate();
  const qc = useQueryClient();

  const getResource = useServerFn(adminGetResource);
  const listFaqs = useServerFn(adminListFaqs);
  const listCategories = useServerFn(adminListCategories);
  const listStandards = useServerFn(adminListStandards);
  const saveResource = useServerFn(adminSaveResource);
  const createUploadUrl = useServerFn(adminCreateUploadUrl);
  const previewUrl = useServerFn(adminSignedPreviewUrl);
  const deleteObject = useServerFn(adminDeleteStorageObject);

  const [form, setForm] = useState<FormState>(EMPTY);
  const [refs, setRefs] = useState<AdminReferenceInput[]>([]);
  const [faqs, setFaqs] = useState<FaqDraft[]>([]);
  const [faqBaseline, setFaqBaseline] = useState("[]");
  const [baseline, setBaseline] = useState(() => JSON.stringify({ form: EMPTY, refs: [] }));
  const [slugTouched, setSlugTouched] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [imageUploading, setImageUploading] = useState(false);
  /** Local object URLs for images uploaded but not saved yet. */
  const [localImages, setLocalImages] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  /** Objects to delete from storage once the replacement is safely saved. */
  const orphans = useRef<Orphan[]>([]);
  /** What is currently persisted in the database (used to avoid deleting live files). */
  const savedFile = useRef<Orphan | null>(null);
  const savedImagePaths = useRef<string[]>([]);

  const categories = useQuery({
    queryKey: ["admin", "categories"],
    queryFn: () => listCategories(),
    retry: false,
  });
  const allCategories = useMemo(() => categories.data ?? [], [categories.data]);
  const topCategories = useMemo(
    () => allCategories.filter((c) => !c.parent_id),
    [allCategories],
  );
  const allSubcategories = useMemo(
    () => allCategories.filter((c) => !!c.parent_id),
    [allCategories],
  );
  const parentName = useCallback(
    (parentId: string | null | undefined) =>
      allCategories.find((c) => c.id === parentId)?.name ?? "Uncategorised",
    [allCategories],
  );
  const primarySubOptions = useMemo(
    () => allSubcategories.filter((c) => c.parent_id === form.category_id),
    [allSubcategories, form.category_id],
  );
  const standards = useQuery({
    queryKey: ["admin", "standards"],
    queryFn: () => listStandards(),
    retry: false,
  });
  const existing = useQuery({
    queryKey: ["admin", "resource", id],
    queryFn: () => getResource({ data: { id } }),
    enabled: !isNew,
    retry: false,
  });
  const existingFaqs = useQuery({
    queryKey: ["admin", "faqs", "resource", id],
    queryFn: () => listFaqs({ data: { resource_id: id } }),
    enabled: !isNew,
    retry: false,
  });

  useEffect(() => {
    const rows = existingFaqs.data;
    if (!rows) return;
    const next = rows.map((f) => ({ question: f.question, answer: f.answer }));
    setFaqs(next);
    setFaqBaseline(JSON.stringify(next));
  }, [existingFaqs.data]);

  useEffect(() => {
    const row = existing.data;
    if (!row) return;
    const next: FormState = {
      title: row.title,
      slug: row.slug,
      description: row.description ?? "",
      who_for: row.who_for ?? "",
      problem_solved: row.problem_solved ?? "",
      whats_included: (row.whats_included ?? []).join("\n"),
      how_to_use: (row.how_to_use ?? []).join("\n"),
      resource_type: row.resource_type,
      category_id: row.category_id ?? "",
      primary_subcategory_id:
        (row as { primary_subcategory_id?: string | null }).primary_subcategory_id ?? "",
      extra_subcategory_ids: (
        (row as { resource_subcategories?: { subcategory_id: string }[] }).resource_subcategories ??
        []
      ).map((r) => r.subcategory_id),
      subcategory: row.subcategory ?? "",
      tags: (row.tags ?? []).join(", "),
      status: row.status,
      is_premium: row.is_premium,
      featured: row.featured,
      file_type: row.file_type ?? "",
      file_path: row.file_path ?? "",
      storage_bucket: row.storage_bucket ?? "",
      file_name: row.file_name ?? "",
      file_size: row.file_size ?? null,
      images:
        (row as { preview_images?: string[] | null }).preview_images?.length
          ? (row as { preview_images?: string[] | null }).preview_images!
          : row.thumbnail_url
            ? [row.thumbnail_url]
            : [],
      thumbnail_url: row.thumbnail_url ?? "",
      seo_title: row.seo_title ?? "",
      seo_description: row.seo_description ?? "",
      ranking_notes: (row as { ranking_notes?: string | null }).ranking_notes ?? "",
      disclaimer: (row as { disclaimer?: string | null }).disclaimer ?? "",
      canonical_url: row.canonical_url ?? "",
      noindex: (row as { noindex?: boolean }).noindex ?? false,
    };
    const nextRefs = (row.resource_references ?? []).map((r) => ({
      standard_id: r.standard_id,
      section: r.section,
      note: r.note,
      url: r.url,
      verified: r.verified,
    }));
    setForm(next);
    setRefs(nextRefs);
    setBaseline(JSON.stringify({ form: next, refs: nextRefs }));
    savedFile.current =
      row.file_path && row.storage_bucket ? { bucket: row.storage_bucket, path: row.file_path } : null;
    savedImagePaths.current = next.images.map(imagePathOf).filter(Boolean);
  }, [existing.data]);

  const dirty = useMemo(
    () =>
      JSON.stringify({ form, refs }) !== baseline || JSON.stringify(faqs) !== faqBaseline,
    [form, refs, baseline, faqs, faqBaseline],
  );

  useEffect(() => {
    if (!dirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const dropObject = useCallback(
    async (bucket: string, path: string) => {
      try {
        await deleteObject({ data: { bucket, path } });
      } catch {
        /* Cleanup is best-effort; the record is what matters. */
      }
    },
    [deleteObject],
  );

  /** Retires the file currently held in the form before a replace/remove. */
  const retireCurrentFile = async () => {
    if (!form.file_path || !form.storage_bucket) return;
    const isPersisted =
      savedFile.current?.path === form.file_path && savedFile.current?.bucket === form.storage_bucket;
    if (isPersisted) orphans.current.push({ bucket: form.storage_bucket, path: form.file_path });
    else await dropObject(form.storage_bucket, form.file_path);
  };

  /** Retires one gallery image: persisted ones wait for a successful save. */
  const retireImage = async (ref: string) => {
    const path = imagePathOf(ref);
    if (!path) return;
    if (savedImagePaths.current.includes(path)) orphans.current.push({ bucket: "images", path });
    else await dropObject("images", path);
  };

  const upload = async (file: File) => {
    setUploading(true);
    setError(null);
    setMessage(null);
    try {
      const signed = await createUploadUrl({
        data: { resourceType: form.resource_type, fileName: file.name, size: file.size, kind: "file" },
      });
      const { error: upErr } = await supabase.storage
        .from(signed.bucket)
        .uploadToSignedUrl(signed.path, signed.token, file);
      if (upErr) throw new Error(upErr.message);
      await retireCurrentFile();
      setForm((f) => ({
        ...f,
        storage_bucket: signed.bucket,
        file_path: signed.path,
        file_name: file.name,
        file_size: file.size,
        file_type: signed.ext,
      }));
      setMessage(`Uploaded "${file.name}". Save to attach it to this resource.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  };

  /** Uploads one or more preview images and appends them to the gallery. */
  const uploadImages = async (files: File[]) => {
    setImageUploading(true);
    setError(null);
    setMessage(null);
    try {
      for (const file of files) {
        // Resize + compress in the browser, then upload the large and small variants.
        const prepared = await prepareImageUpload(file);
        const baseName = file.name.replace(/\.[^.]+$/, "");
        const signed = await createUploadUrl({
          data: {
            resourceType: form.resource_type,
            fileName: `${baseName}.${prepared.full.ext}`,
            size: prepared.full.blob.size,
            originalSize: file.size,
            kind: "image",
          },
        });
        const { error: upErr } = await supabase.storage
          .from(signed.bucket)
          .uploadToSignedUrl(signed.path, signed.token, prepared.full.blob);
        if (upErr) throw new Error(upErr.message);
        if (signed.thumbPath && signed.thumbToken) {
          await supabase.storage
            .from(signed.bucket)
            .uploadToSignedUrl(signed.thumbPath, signed.thumbToken, prepared.thumb.blob);
        }
        const ref = imageRef(signed.path);
        const objectUrl = URL.createObjectURL(prepared.full.blob);
        setLocalImages((m) => ({ ...m, [ref]: objectUrl }));
        setForm((f) => ({ ...f, images: [...f.images, ref] }));
      }
      setMessage(
        files.length > 1
          ? `${files.length} preview images uploaded. Save to publish them.`
          : "Preview image uploaded. Save to publish it.",
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Image upload failed.");
    } finally {
      setImageUploading(false);
    }
  };

  const removeFile = async () => {
    await retireCurrentFile();
    setForm((f) => ({
      ...f,
      file_path: "",
      storage_bucket: "",
      file_name: "",
      file_size: null,
      file_type: "",
    }));
    setMessage("File detached. Save to apply.");
  };

  const removeImage = async (ref: string) => {
    await retireImage(ref);
    setForm((f) => ({ ...f, images: f.images.filter((i) => i !== ref) }));
    setLocalImages((m) => {
      const { [ref]: _gone, ...rest } = m;
      return rest;
    });
    setMessage("Preview image removed. Save to apply.");
  };

  const moveImage = (ref: string, dir: -1 | 1) =>
    setForm((f) => {
      const i = f.images.indexOf(ref);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= f.images.length) return f;
      const images = [...f.images];
      const a = images[i]!;
      images[i] = images[j]!;
      images[j] = a;
      return { ...f, images };
    });

  const openFile = async () => {
    try {
      const { url } = await previewUrl({
        data: { bucket: form.storage_bucket, path: form.file_path },
      });
      window.open(url, "_blank", "noopener,noreferrer");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not open this file.");
    }
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      const slug = form.slug.trim();
      const result = await saveResource({
        data: {
          id: isNew ? null : id,
          title: form.title.trim(),
          slug,
          description: form.description.trim(),
          who_for: form.who_for.trim() || null,
          problem_solved: form.problem_solved.trim() || null,
          whats_included: lines(form.whats_included),
          how_to_use: lines(form.how_to_use),
          resource_type: form.resource_type,
          category_id: form.category_id || null,
          primary_subcategory_id: form.primary_subcategory_id || null,
          extra_subcategory_ids: form.extra_subcategory_ids,
          subcategory: form.subcategory.trim() || null,
          tags: form.tags
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean),
          status: form.status,
          is_premium: form.is_premium,
          featured: form.featured,
          file_type: form.file_type || null,
          file_path: form.file_path || null,
          storage_bucket: form.storage_bucket || null,
          file_name: form.file_name || null,
          file_size: form.file_size,
          thumbnail_url: form.thumbnail_url.trim() || form.images[0] || null,
          preview_images: form.images,
          seo_title: form.seo_title.trim() || null,
          seo_description: form.seo_description.trim() || null,
          ranking_notes: form.ranking_notes.trim() || null,
          disclaimer: form.disclaimer.trim() || null,
          canonical_url: form.canonical_url.trim() || `/resources/${slug}`,
          noindex: form.noindex,
          references: refs.filter((r) => r.standard_id),
          faqs: faqs
            .map((f) => ({ question: f.question.trim(), answer: f.answer.trim() }))
            .filter((f) => f.question.length >= 4 && f.answer.length >= 2),
        },
      });

      // Replaced/removed files are only purged once the new state is persisted.
      const toDelete = orphans.current;
      orphans.current = [];
      await Promise.all(toDelete.map((o) => dropObject(o.bucket, o.path)));

      savedFile.current =
        form.file_path && form.storage_bucket
          ? { bucket: form.storage_bucket, path: form.file_path }
          : null;
      savedImagePaths.current = form.images.map(imagePathOf).filter(Boolean);
      setBaseline(JSON.stringify({ form, refs }));
      setFaqBaseline(JSON.stringify(faqs));

      await qc.invalidateQueries({ queryKey: ["admin"] });
      if (isNew) void navigate({ to: "/admin/resources/$id", params: { id: result.id } });
      else setMessage("Resource saved.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this resource.");
    } finally {
      setSaving(false);
    }
  };

  const leave = () => {
    if (dirty && !window.confirm("You have unsaved changes. Leave without saving?")) return;
    void navigate({ to: "/admin/resources" });
  };

  if (!isNew && existing.isLoading) return <Loading label="Loading resource…" />;

  const srcFor = (ref: string) => localImages[ref] ?? ref;


  return (
    <AdminPage
      title={isNew ? "New resource" : "Edit resource"}
      description="Upload a file, classify it, add standard references and publish."
    >
      <form onSubmit={submit} className="grid gap-5 pb-24 lg:grid-cols-[minmax(0,1fr)_340px] lg:pb-5">
        <div className="space-y-5">
          <Panel title="Content">
            <div className="space-y-4">
              <Field label="Title" required>
                <input
                  className="admin-input"
                  required
                  value={form.title}
                  onChange={(e) => {
                    set("title", e.target.value);
                    if (!slugTouched) set("slug", slugify(e.target.value));
                  }}
                />
              </Field>
              <Field label="Slug" required hint="Lowercase letters, numbers and dashes only.">
                <input
                  className="admin-input"
                  required
                  value={form.slug}
                  onChange={(e) => {
                    setSlugTouched(true);
                    set("slug", slugify(e.target.value));
                  }}
                />
              </Field>
              <Field label="Description" hint="Format text with headings, emphasis, quotes, lists, links and dividers.">
                <RichTextEditor
                  value={form.description}
                  busy={saving}
                  onChange={(html) => set("description", html)}
                />
              </Field>
              <Field label="What problem does it solve?" hint="Shown on the public resource page.">
                <textarea
                  className="admin-input min-h-24"
                  value={form.problem_solved}
                  onChange={(e) => set("problem_solved", e.target.value)}
                />
              </Field>
              <Field label="Who is it for?" hint="Shown on the public resource page.">
                <textarea
                  className="admin-input min-h-24"
                  value={form.who_for}
                  onChange={(e) => set("who_for", e.target.value)}
                />
              </Field>
              <Field label="What's included" hint="One item per line.">
                <textarea
                  className="admin-input min-h-24"
                  value={form.whats_included}
                  onChange={(e) => set("whats_included", e.target.value)}
                />
              </Field>
              <Field label="How to use it" hint="One step per line.">
                <textarea
                  className="admin-input min-h-24"
                  value={form.how_to_use}
                  onChange={(e) => set("how_to_use", e.target.value)}
                />
              </Field>
              <Field
                label="Engineering disclaimer"
                hint="Optional. Shown at the bottom of the Description tab on the public page. Leave empty to hide it completely."
              >
                <textarea
                  className="admin-input min-h-20"
                  value={form.disclaimer}
                  onChange={(e) => set("disclaimer", e.target.value)}
                  maxLength={1000}
                />
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Resource type" required>
                  <select
                    className="admin-input"
                    value={form.resource_type}
                    onChange={(e) => set("resource_type", e.target.value)}
                  >
                    {RESOURCE_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Category" required>
                  <select
                    className="admin-input"
                    value={form.category_id}
                    onChange={(e) => {
                      set("category_id", e.target.value);
                      set("primary_subcategory_id", "");
                    }}
                  >
                    <option value="">Select a category…</option>
                    {topCategories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field
                  label="Subcategory"
                  required
                  hint="Primary subcategory — used for the breadcrumb and canonical link"
                >
                  <select
                    className="admin-input"
                    value={form.primary_subcategory_id}
                    onChange={(e) => set("primary_subcategory_id", e.target.value)}
                    disabled={!form.category_id}
                  >
                    <option value="">
                      {form.category_id
                        ? primarySubOptions.length
                          ? "Select a subcategory…"
                          : "This category has no subcategories yet"
                        : "Select a category first"}
                    </option>
                    {primarySubOptions.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field
                  label="Also show under"
                  hint="Optional cross-listing — does not change the URL or breadcrumb"
                >
                  <div className="max-h-44 space-y-1 overflow-y-auto rounded-lg border border-border p-2">
                    {allSubcategories.filter((c) => c.id !== form.primary_subcategory_id).length ? (
                      allSubcategories
                        .filter((c) => c.id !== form.primary_subcategory_id)
                        .map((c) => (
                          <label key={c.id} className="flex items-center gap-2 text-sm">
                            <input
                              type="checkbox"
                              className="h-4 w-4 rounded border-border"
                              checked={form.extra_subcategory_ids.includes(c.id)}
                              onChange={(e) =>
                                set(
                                  "extra_subcategory_ids",
                                  e.target.checked
                                    ? [...form.extra_subcategory_ids, c.id]
                                    : form.extra_subcategory_ids.filter((x) => x !== c.id),
                                )
                              }
                            />
                            <span className="truncate">
                              {parentName(c.parent_id)} › {c.name}
                            </span>
                          </label>
                        ))
                    ) : (
                      <p className="text-xs text-muted-foreground">No other subcategories yet.</p>
                    )}
                  </div>
                </Field>
                <Field label="Tags" hint="Comma separated">
                  <input
                    className="admin-input"
                    value={form.tags}
                    onChange={(e) => set("tags", e.target.value)}
                    placeholder="earthing, bnbc, checklist"
                  />
                </Field>
              </div>
            </div>
          </Panel>

          <Panel title="Downloadable file">
            <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border px-4 py-8 text-center hover:border-electric/50">
              <UploadCloud className="h-6 w-6 text-electric" aria-hidden="true" />
              <span className="text-sm font-semibold text-foreground">
                {uploading ? "Uploading…" : form.file_path ? "Replace file" : "Choose a file to upload"}
              </span>
              <span className="text-xs text-muted-foreground">
                Stored in a private bucket; downloads use short-lived signed links.
              </span>
              <input
                type="file"
                className="sr-only"
                disabled={uploading}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void upload(file);
                  e.target.value = "";
                }}
              />
            </label>
            {form.file_path ? (
              <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-surface px-3 py-2">
                <div className="min-w-0 text-sm">
                  <p className="truncate font-semibold text-foreground">
                    {form.file_name || form.file_path}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {form.storage_bucket} · {form.file_type}
                    {form.file_size ? ` · ${(form.file_size / 1048576).toFixed(2)} MB` : ""}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Btn type="button" variant="outline" onClick={openFile}>
                    <ExternalLink className="h-4 w-4" aria-hidden="true" /> Preview
                  </Btn>
                  <Btn type="button" variant="danger" onClick={() => void removeFile()}>
                    Remove
                  </Btn>
                </div>
              </div>
            ) : null}
          </Panel>

          <Panel title="Thumbnail">
            <ThumbnailField
              value={form.thumbnail_url}
              onChange={(next) => set("thumbnail_url", next)}
              resourceType={form.resource_type}
              hint="Card image for this resource. Leave empty to use the first preview image."
            />
          </Panel>

          <Panel title="Preview images">
            <div className="space-y-4">
              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-border px-4 py-5 text-center text-sm font-semibold hover:border-electric/50">
                <UploadCloud className="h-5 w-5 text-electric" aria-hidden="true" />
                {imageUploading ? "Uploading…" : "Upload preview images"}
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  multiple
                  className="sr-only"
                  disabled={imageUploading}
                  onChange={(e) => {
                    const files = Array.from(e.target.files ?? []);
                    if (files.length) void uploadImages(files);
                    e.target.value = "";
                  }}
                />
              </label>
              <p className="text-xs text-muted-foreground">
                JPG, PNG or WebP, up to 5 MB each — resized and compressed automatically. You can add several — the first image is used as the
                card thumbnail and social preview.
              </p>

              {form.images.length ? (
                <ul className="grid gap-3 sm:grid-cols-3">
                  {form.images.map((ref, i) => (
                    <li key={ref} className="overflow-hidden rounded-xl border border-border bg-surface">
                      <div className="flex h-28 items-center justify-center overflow-hidden bg-card">
                        <img
                          src={srcFor(ref)}
                          alt={`Preview ${i + 1}`}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="flex items-center justify-between gap-1 p-2">
                        <span className="text-[11px] font-semibold uppercase text-muted-foreground">
                          {i === 0 ? "Thumbnail" : `Image ${i + 1}`}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            aria-label="Move image earlier"
                            className="h-8 w-8 rounded-md text-muted-foreground hover:bg-surface disabled:opacity-40"
                            disabled={i === 0}
                            onClick={() => moveImage(ref, -1)}
                          >
                            ↑
                          </button>
                          <button
                            type="button"
                            aria-label="Move image later"
                            className="h-8 w-8 rounded-md text-muted-foreground hover:bg-surface disabled:opacity-40"
                            disabled={i === form.images.length - 1}
                            onClick={() => moveImage(ref, 1)}
                          >
                            ↓
                          </button>
                          <button
                            type="button"
                            aria-label="Remove image"
                            className="h-8 w-8 rounded-md text-danger hover:bg-surface"
                            onClick={() => void removeImage(ref)}
                          >
                            <Trash2 className="mx-auto h-4 w-4" aria-hidden="true" />
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="flex h-24 items-center justify-center rounded-xl border border-border bg-surface">
                  <ImageIcon className="h-7 w-7 text-muted-foreground" aria-hidden="true" />
                </div>
              )}
            </div>
          </Panel>

          <Panel title="Standard references">
            <div className="space-y-3">
              {refs.map((r, i) => (
                <div key={i} className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-[1fr_1fr_auto]">
                  <select
                    className="admin-input"
                    value={r.standard_id}
                    aria-label="Standard"
                    onChange={(e) =>
                      setRefs((list) =>
                        list.map((x, j) => (j === i ? { ...x, standard_id: e.target.value } : x)),
                      )
                    }
                  >
                    <option value="">Select standard</option>
                    {(standards.data ?? []).map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} — {s.name}
                      </option>
                    ))}
                  </select>
                  <input
                    className="admin-input"
                    placeholder="Section / clause"
                    value={r.section ?? ""}
                    onChange={(e) =>
                      setRefs((list) => list.map((x, j) => (j === i ? { ...x, section: e.target.value } : x)))
                    }
                  />
                  <Btn
                    type="button"
                    variant="danger"
                    onClick={() => setRefs((list) => list.filter((_, j) => j !== i))}
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                  </Btn>
                </div>
              ))}
              <Btn
                type="button"
                variant="outline"
                onClick={() => setRefs((list) => [...list, { standard_id: "", section: "", verified: false }])}
              >
                <Plus className="h-4 w-4" aria-hidden="true" /> Add reference
              </Btn>
            </div>
          </Panel>

          <Panel title="SEO">
            <div className="space-y-4">
              <Field label="SEO title" hint="Defaults to the resource title.">
                <input
                  className="admin-input"
                  value={form.seo_title}
                  onChange={(e) => set("seo_title", e.target.value)}
                  maxLength={200}
                />
                <Counter value={form.seo_title || form.title} max={200} ideal={60} />
              </Field>
              <Field label="Meta description" hint="Aim for under 160 characters.">
                <textarea
                  className="admin-input min-h-24"
                  value={form.seo_description}
                  onChange={(e) => set("seo_description", e.target.value)}
                  maxLength={400}
                />
                <Counter value={form.seo_description || form.description} max={400} ideal={160} />
               </Field>
              <Field
                label="Ranking notes"
                hint="Optional. A short, unique note shown in the 'Why this resource ranks' box. Leave empty to hide that box — do not repeat the meta description."
              >
                <textarea
                  className="admin-input min-h-20"
                  value={form.ranking_notes}
                  onChange={(e) => set("ranking_notes", e.target.value)}
                  maxLength={400}
                />
              </Field>
              <Field
                label="Canonical URL"
                hint={`Leave empty to use /resources/${form.slug || "slug"}.`}
              >
                <input
                  className="admin-input"
                  value={form.canonical_url}
                  placeholder={`/resources/${form.slug || "slug"}`}
                  onChange={(e) => set("canonical_url", e.target.value)}
                  maxLength={400}
                />
              </Field>
              <label className="flex items-start gap-3 text-sm font-semibold text-foreground">
                <input
                  type="checkbox"
                  className="mt-0.5 h-5 w-5 rounded border-border"
                  checked={form.noindex}
                  onChange={(e) => set("noindex", e.target.checked)}
                />
                <span>
                  Hide from search engines (noindex)
                  <span className="block text-xs font-normal text-muted-foreground">
                    Also removes this resource from the sitemap.
                  </span>
                </span>
              </label>
            </div>
          </Panel>

          <Panel title="FAQs">
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">
                Optional. Shown on the public resource page and published as FAQ structured data
                only when real questions exist.
              </p>
              {faqs.map((f, i) => (
                <div key={i} className="space-y-2 rounded-lg border border-border p-3">
                  <input
                    className="admin-input"
                    placeholder="Question"
                    aria-label={`FAQ question ${i + 1}`}
                    maxLength={300}
                    value={f.question}
                    onChange={(e) =>
                      setFaqs((list) => list.map((x, j) => (j === i ? { ...x, question: e.target.value } : x)))
                    }
                  />
                  <textarea
                    className="admin-input min-h-20"
                    placeholder="Answer"
                    aria-label={`FAQ answer ${i + 1}`}
                    maxLength={4000}
                    value={f.answer}
                    onChange={(e) =>
                      setFaqs((list) => list.map((x, j) => (j === i ? { ...x, answer: e.target.value } : x)))
                    }
                  />
                  <Btn
                    type="button"
                    variant="danger"
                    onClick={() => setFaqs((list) => list.filter((_, j) => j !== i))}
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" /> Remove
                  </Btn>
                </div>
              ))}
              <Btn
                type="button"
                variant="outline"
                onClick={() => setFaqs((list) => [...list, { question: "", answer: "" }])}
              >
                <Plus className="h-4 w-4" aria-hidden="true" /> Add FAQ
              </Btn>
            </div>
          </Panel>
        </div>

        <aside className="space-y-5 lg:sticky lg:top-24 lg:self-start">
          <Panel title="Publishing">
            <div className="space-y-4">
              <Field label="Status">
                <select
                  className="admin-input"
                  value={form.status}
                  onChange={(e) => set("status", e.target.value as FormState["status"])}
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </Field>
              <label className="flex items-center gap-3 text-sm font-semibold text-foreground">
                <input
                  type="checkbox"
                  className="h-5 w-5 rounded border-border"
                  checked={form.is_premium}
                  onChange={(e) => set("is_premium", e.target.checked)}
                />
                Premium resource
              </label>
              <label className="flex items-center gap-3 text-sm font-semibold text-foreground">
                <input
                  type="checkbox"
                  className="h-5 w-5 rounded border-border"
                  checked={form.featured}
                  onChange={(e) => set("featured", e.target.checked)}
                />
                Featured on homepage
              </label>
              {error ? <Notice kind="error">{error}</Notice> : null}
              {message ? <Notice kind="success">{message}</Notice> : null}
              <Btn type="submit" busy={saving} className="w-full">
                {isNew ? "Create resource" : "Save changes"}
              </Btn>
              <Btn type="button" variant="outline" className="w-full" onClick={leave}>
                Back to list
              </Btn>
            </div>
          </Panel>
        </aside>

        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-white/95 px-4 py-3 backdrop-blur lg:hidden">
          <div className="flex items-center gap-3">
            <p className="min-w-0 flex-1 truncate text-xs font-semibold text-muted-foreground">
              {saving ? "Saving…" : dirty ? "Unsaved changes" : "All changes saved"}
            </p>
            <Btn type="button" variant="outline" onClick={leave} className="min-h-11">
              Back
            </Btn>
            <Btn type="submit" busy={saving} className="min-h-11">
              Save
            </Btn>
          </div>
        </div>
      </form>
    </AdminPage>
  );
}
