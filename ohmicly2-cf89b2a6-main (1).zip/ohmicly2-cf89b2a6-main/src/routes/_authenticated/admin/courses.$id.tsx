import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { ChevronDown, ChevronUp, Plus, Trash2, Video } from "lucide-react";
import {
  adminDeleteLesson,
  adminDeleteModule,
  adminGetCourse,
  adminSaveCourse,
  adminSaveLesson,
  adminSaveModule,
} from "@/lib/admin/course.functions";
import type { AdminCourseLesson, AdminCourseModule, CourseLevel } from "@/lib/admin/course-types";
import type { PublishStatus } from "@/lib/admin/admin-types";
import { AdminPage, Btn, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/courses/$id")({
  component: CourseEdit,
});

type CourseDraft = {
  title: string;
  slug: string;
  description: string;
  category: string;
  level: CourseLevel;
  is_premium: boolean;
  status: PublishStatus;
  featured: boolean;
  instructor: string;
  seo_title: string;
  seo_description: string;
};

const EMPTY_COURSE: CourseDraft = {
  title: "",
  slug: "",
  description: "",
  category: "",
  level: "beginner",
  is_premium: false,
  status: "draft",
  featured: false,
  instructor: "OHMICLY",
  seo_title: "",
  seo_description: "",
};

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function CourseEdit() {
  const { id } = useParams({ from: "/_authenticated/admin/courses/$id" });
  const isNew = id === "new";
  const navigate = useNavigate();
  const qc = useQueryClient();

  const getCourse = useServerFn(adminGetCourse);
  const saveCourse = useServerFn(adminSaveCourse);
  const saveModule = useServerFn(adminSaveModule);
  const deleteModule = useServerFn(adminDeleteModule);
  const saveLesson = useServerFn(adminSaveLesson);
  const deleteLesson = useServerFn(adminDeleteLesson);

  const query = useQuery({
    queryKey: ["admin", "course", id],
    queryFn: () => getCourse({ data: { id } }),
    enabled: !isNew,
    retry: false,
  });

  const [draft, setDraft] = useState<CourseDraft>(EMPTY_COURSE);
  const [slugTouched, setSlugTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modules, setModules] = useState<AdminCourseModule[]>([]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (query.data) {
      const c = query.data.course;
      setDraft({
        title: c.title,
        slug: c.slug,
        description: c.description,
        category: c.category ?? "",
        level: c.level,
        is_premium: c.is_premium,
        status: c.status,
        featured: c.featured,
        instructor: c.instructor,
        seo_title: c.seo_title ?? "",
        seo_description: c.seo_description ?? "",
      });
      setModules(query.data.modules);
      setSlugTouched(true);
    }
  }, [query.data]);

  const submitCourse = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await saveCourse({
        data: {
          id: isNew ? null : id,
          title: draft.title.trim(),
          slug: draft.slug.trim(),
          description: draft.description.trim(),
          category: draft.category.trim() || null,
          level: draft.level,
          is_premium: draft.is_premium,
          status: draft.status,
          featured: draft.featured,
          instructor: draft.instructor.trim() || "OHMICLY",
          seo_title: draft.seo_title.trim() || null,
          seo_description: draft.seo_description.trim() || null,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin", "courses"] });
      if (isNew) {
        void navigate({ to: "/admin/courses/$id", params: { id: result.id } });
      } else {
        await qc.invalidateQueries({ queryKey: ["admin", "course", id] });
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this course.");
    } finally {
      setBusy(false);
    }
  };

  const addModule = async () => {
    if (isNew) return;
    const title = window.prompt("Module title (e.g. \"Module 1: BNBC Basics\")");
    if (!title?.trim()) return;
    const result = await saveModule({
      data: { course_id: id, title: title.trim(), sort_order: modules.length },
    });
    setModules([...modules, { id: result.id, course_id: id, title: title.trim(), description: "", sort_order: modules.length, lessons: [] }]);
    setExpanded((prev) => ({ ...prev, [result.id]: true }));
  };

  const removeModule = async (moduleId: string) => {
    if (!window.confirm("Delete this module and all its lessons?")) return;
    await deleteModule({ data: { id: moduleId } });
    setModules(modules.filter((m) => m.id !== moduleId));
  };

  const addLesson = async (moduleId: string) => {
    const title = window.prompt("Lesson title");
    if (!title?.trim()) return;
    const mod = modules.find((m) => m.id === moduleId);
    const order = mod?.lessons.length ?? 0;
    const result = await saveLesson({ data: { module_id: moduleId, title: title.trim(), sort_order: order } });
    const newLesson: AdminCourseLesson = {
      id: result.id,
      module_id: moduleId,
      title: title.trim(),
      description: "",
      video_provider: "bunny",
      video_id: null,
      duration_seconds: null,
      sort_order: order,
      is_free_preview: false,
    };
    setModules(modules.map((m) => (m.id === moduleId ? { ...m, lessons: [...m.lessons, newLesson] } : m)));
  };

  const updateLesson = async (lesson: AdminCourseLesson) => {
    await saveLesson({
      data: {
        id: lesson.id,
        module_id: lesson.module_id,
        title: lesson.title,
        description: lesson.description,
        video_provider: lesson.video_provider,
        video_id: lesson.video_id,
        duration_seconds: lesson.duration_seconds,
        sort_order: lesson.sort_order,
        is_free_preview: lesson.is_free_preview,
      },
    });
  };

  const removeLesson = async (moduleId: string, lessonId: string) => {
    if (!window.confirm("Delete this lesson?")) return;
    await deleteLesson({ data: { id: lessonId } });
    setModules(
      modules.map((m) => (m.id === moduleId ? { ...m, lessons: m.lessons.filter((l) => l.id !== lessonId) } : m)),
    );
  };

  if (!isNew && query.isLoading) return <Loading />;

  return (
    <AdminPage
      title={isNew ? "New course" : draft.title || "Edit course"}
      description="Course details, then modules and video lessons below."
    >
      <Panel title="Course details">
        <form onSubmit={submitCourse} className="space-y-4">
          <Field label="Title" required>
            <input
              className="admin-input"
              required
              value={draft.title}
              onChange={(e) => {
                const title = e.target.value;
                setDraft((d) => ({ ...d, title, slug: slugTouched ? d.slug : slugify(title) }));
              }}
            />
          </Field>
          <Field label="Slug" required hint="Used in the course URL, e.g. /courses/autocad-sld-design">
            <input
              className="admin-input"
              required
              value={draft.slug}
              onChange={(e) => {
                setSlugTouched(true);
                setDraft((d) => ({ ...d, slug: slugify(e.target.value) }));
              }}
            />
          </Field>
          <Field label="Description">
            <textarea
              className="admin-input min-h-28"
              value={draft.description}
              onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Category">
              <input
                className="admin-input"
                placeholder="e.g. AutoCAD"
                value={draft.category}
                onChange={(e) => setDraft((d) => ({ ...d, category: e.target.value }))}
              />
            </Field>
            <Field label="Level">
              <select
                className="admin-input"
                value={draft.level}
                onChange={(e) => setDraft((d) => ({ ...d, level: e.target.value as CourseLevel }))}
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </Field>
            <Field label="Status">
              <select
                className="admin-input"
                value={draft.status}
                onChange={(e) => setDraft((d) => ({ ...d, status: e.target.value as PublishStatus }))}
              >
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="archived">Archived</option>
              </select>
            </Field>
          </div>
          <Field label="Instructor">
            <input
              className="admin-input"
              value={draft.instructor}
              onChange={(e) => setDraft((d) => ({ ...d, instructor: e.target.value }))}
            />
          </Field>
          <div className="flex flex-wrap gap-6">
            <label className="flex items-center gap-3 text-sm font-semibold text-foreground">
              <input
                type="checkbox"
                className="h-5 w-5 rounded border-border"
                checked={draft.is_premium}
                onChange={(e) => setDraft((d) => ({ ...d, is_premium: e.target.checked }))}
              />
              Premium course
            </label>
            <label className="flex items-center gap-3 text-sm font-semibold text-foreground">
              <input
                type="checkbox"
                className="h-5 w-5 rounded border-border"
                checked={draft.featured}
                onChange={(e) => setDraft((d) => ({ ...d, featured: e.target.checked }))}
              />
              Featured
            </label>
          </div>
          {error ? <Notice kind="error">{error}</Notice> : null}
          <Btn type="submit" busy={busy}>
            {isNew ? "Create course" : "Save course details"}
          </Btn>
        </form>
      </Panel>

      {isNew ? (
        <Notice kind="success">Save the course first, then come back here to add modules and lessons.</Notice>
      ) : (
        <Panel title="Modules & lessons">
          <div className="space-y-3">
            {modules.map((mod) => (
              <div key={mod.id} className="rounded-xl border border-border bg-surface">
                <div className="flex items-center justify-between gap-2 p-3">
                  <button
                    type="button"
                    onClick={() => setExpanded((prev) => ({ ...prev, [mod.id]: !prev[mod.id] }))}
                    className="flex min-w-0 flex-1 items-center gap-2 text-left text-sm font-bold text-foreground"
                  >
                    {expanded[mod.id] ? (
                      <ChevronUp className="h-4 w-4 shrink-0" aria-hidden="true" />
                    ) : (
                      <ChevronDown className="h-4 w-4 shrink-0" aria-hidden="true" />
                    )}
                    <span className="truncate">{mod.title}</span>
                    <span className="shrink-0 text-xs font-normal text-muted-foreground">
                      ({mod.lessons.length} lessons)
                    </span>
                  </button>
                  <Btn variant="danger" onClick={() => removeModule(mod.id)}>
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                  </Btn>
                </div>

                {expanded[mod.id] ? (
                  <div className="space-y-3 border-t border-border p-3">
                    {mod.lessons.map((lesson) => (
                      <LessonRow
                        key={lesson.id}
                        lesson={lesson}
                        onChange={(updated) =>
                          setModules(
                            modules.map((m) =>
                              m.id === mod.id
                                ? { ...m, lessons: m.lessons.map((l) => (l.id === updated.id ? updated : l)) }
                                : m,
                            ),
                          )
                        }
                        onSave={updateLesson}
                        onDelete={() => removeLesson(mod.id, lesson.id)}
                      />
                    ))}
                    <Btn variant="outline" onClick={() => addLesson(mod.id)}>
                      <Plus className="h-4 w-4" aria-hidden="true" /> Add lesson
                    </Btn>
                  </div>
                ) : null}
              </div>
            ))}
            <Btn variant="outline" onClick={addModule}>
              <Plus className="h-4 w-4" aria-hidden="true" /> Add module
            </Btn>
          </div>
        </Panel>
      )}
    </AdminPage>
  );
}

function LessonRow({
  lesson,
  onChange,
  onSave,
  onDelete,
}: {
  lesson: AdminCourseLesson;
  onChange: (lesson: AdminCourseLesson) => void;
  onSave: (lesson: AdminCourseLesson) => Promise<void>;
  onDelete: () => void;
}) {
  const [savedRecently, setSavedRecently] = useState(false);

  const commit = async (updated: AdminCourseLesson) => {
    onChange(updated);
    await onSave(updated);
    setSavedRecently(true);
    setTimeout(() => setSavedRecently(false), 1200);
  };

  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Lesson title">
          <input
            className="admin-input"
            value={lesson.title}
            onChange={(e) => onChange({ ...lesson, title: e.target.value })}
            onBlur={() => commit(lesson)}
          />
        </Field>
        <Field label="Bunny/Mux video ID" hint="Paste the video ID from your hosting dashboard">
          <div className="relative">
            <Video className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              className="admin-input pl-9"
              value={lesson.video_id ?? ""}
              onChange={(e) => onChange({ ...lesson, video_id: e.target.value })}
              onBlur={() => commit(lesson)}
            />
          </div>
        </Field>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-xs font-semibold text-foreground">
          <input
            type="checkbox"
            className="h-4 w-4 rounded border-border"
            checked={lesson.is_free_preview}
            onChange={(e) => commit({ ...lesson, is_free_preview: e.target.checked })}
          />
          Free preview (visible without premium)
        </label>
        <span className="text-xs text-muted-foreground">{savedRecently ? "Saved ✓" : ""}</span>
        <button
          type="button"
          onClick={onDelete}
          className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-destructive hover:underline"
        >
          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" /> Delete lesson
        </button>
      </div>
    </div>
  );
      }
