import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { adminDeleteFaq, adminListFaqs, adminSaveFaq } from "@/lib/admin/admin.functions";
import { AdminPage, Btn, EmptyState, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/faqs")({
  component: FaqsAdmin,
});

type Draft = {
  id: string | null;
  question: string;
  answer: string;
  sort_order: number;
  is_published: boolean;
};

const EMPTY: Draft = { id: null, question: "", answer: "", sort_order: 0, is_published: true };

function FaqsAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListFaqs);
  const save = useServerFn(adminSaveFaq);
  const remove = useServerFn(adminDeleteFaq);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const faqs = useQuery({ queryKey: ["admin", "faqs"], queryFn: () => list({ data: { scope: "site" } }), retry: false });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      await save({
        data: {
          id: draft.id,
          question: draft.question.trim(),
          answer: draft.answer.trim(),
          scope: "site",
          sort_order: draft.sort_order,
          is_published: draft.is_published,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin"] });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this FAQ.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminPage
      title="FAQs"
      description="Frequently asked questions used on resource pages and by AI answer engines."
      actions={
        <Btn onClick={() => setDraft({ ...EMPTY })}>
          <Plus className="h-4 w-4" aria-hidden="true" /> New FAQ
        </Btn>
      }
    >
      {draft ? (
        <Panel title={draft.id ? "Edit FAQ" : "New FAQ"}>
          <form onSubmit={submit} className="space-y-4">
            <Field label="Question" required>
              <input
                className="admin-input"
                required
                value={draft.question}
                onChange={(e) => setDraft({ ...draft, question: e.target.value })}
              />
            </Field>
            <Field label="Answer" required>
              <textarea
                className="admin-input min-h-32"
                required
                value={draft.answer}
                onChange={(e) => setDraft({ ...draft, answer: e.target.value })}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Sort order">
                <input
                  className="admin-input"
                  type="number"
                  min={0}
                  max={999}
                  value={draft.sort_order}
                  onChange={(e) => setDraft({ ...draft, sort_order: Number(e.target.value) || 0 })}
                />
              </Field>
              <label className="mt-7 flex items-center gap-3 text-sm font-semibold text-foreground">
                <input
                  type="checkbox"
                  className="h-5 w-5 rounded border-border"
                  checked={draft.is_published}
                  onChange={(e) => setDraft({ ...draft, is_published: e.target.checked })}
                />
                Published
              </label>
            </div>
            {error ? <Notice kind="error">{error}</Notice> : null}
            <div className="flex flex-wrap gap-2">
              <Btn type="submit" busy={busy}>
                Save FAQ
              </Btn>
              <Btn type="button" variant="outline" onClick={() => setDraft(null)}>
                Cancel
              </Btn>
            </div>
          </form>
        </Panel>
      ) : null}

      {faqs.isLoading ? (
        <Loading />
      ) : !faqs.data?.length ? (
        <EmptyState title="No FAQs yet." />
      ) : (
        <ul className="space-y-3">
          {faqs.data.map((f) => (
            <li key={f.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <p className="text-sm font-semibold text-foreground">{f.question}</p>
              <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{f.answer}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Btn
                  variant="outline"
                  onClick={() =>
                    setDraft({
                      id: f.id,
                      question: f.question,
                      answer: f.answer,
                      sort_order: f.sort_order,
                      is_published: f.is_published,
                    })
                  }
                >
                  Edit
                </Btn>
                <Btn
                  variant="danger"
                  onClick={async () => {
                    if (!window.confirm("Delete this FAQ?")) return;
                    await remove({ data: { id: f.id } });
                    await qc.invalidateQueries({ queryKey: ["admin"] });
                  }}
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" /> Delete
                </Btn>
              </div>
            </li>
          ))}
        </ul>
      )}
    </AdminPage>
  );
}