import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { ExternalLink, ImagePlus, Plus, Trash2 } from "lucide-react";
import {
  adminCreateUploadUrl,
  adminDeleteArticle,
  adminListArticleCategories,
  adminListArticles,
  adminSaveArticle,
} from "@/lib/admin/admin.functions";
import { AdminPage, Btn, EmptyState, Field, Loading, Notice, Panel, StatusPill } from "@/components/admin/AdminUI";
import { RichTextEditor } from "@/components/admin/RichTextEditor";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/articles")({
  component: ArticlesAdmin,
});

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 160);

type Draft = {
  id: string | null;
  title: string;
  slug: string;
  excerpt: string;
  body: string;
  category_id: string;
  author: string;
  reading_time: string;
  status: "draft" | "published" | "archived";
  tags: string;
  seo_title: string;
  seo_description: string;
  cover_image_url: string;
  canonical_url: string;
};

const EMPTY: Draft = {
  id: null,
  title: "",
  slug: "",
  excerpt: "",
  body: "",
  category_id: "",
  author: "OHMICLY",
  reading_time: "",
  status: "draft",
  tags: "",
  seo_title: "",
  seo_description: "",
  cover_image_url: "",
  canonical_url: "",
};

function ArticlesAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListArticles);
  const cats = useServerFn(adminListArticleCategories);
  const save = useServerFn(adminSaveArticle);
  const remove = useServerFn(adminDeleteArticle);
  const createUploadUrl = useServerFn(adminCreateUploadUrl);

  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [coverPreview, setCoverPreview] = useState("");
  const [error, setError] = useState<string | null>(null);

  /** Opens a file picker, uploads the image and returns its public reference. */
  const pickAndUploadImage = () =>
    new Promise<string | null>((resolve) => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/png,image/jpeg,image/webp";
      input.onchange = async () => {
        const file = input.files?.[0];
        if (!file) return resolve(null);
        setUploading(true);
        setError(null);
        try {
          const signed = await createUploadUrl({
            data: { resourceType: "blog", fileName: file.name, size: file.size, kind: "image" },
          });
          const { error: upErr } = await supabase.storage
            .from(signed.bucket)
            .uploadToSignedUrl(signed.path, signed.token, file);
          if (upErr) throw new Error(upErr.message);
          setCoverPreview(URL.createObjectURL(file));
          resolve(`/api/public/article-image?path=${encodeURIComponent(signed.path)}`);
        } catch (e) {
          setError(e instanceof Error ? e.message : "Image upload failed.");
          resolve(null);
        } finally {
          setUploading(false);
        }
      };
      input.click();
    });

  const articles = useQuery({ queryKey: ["admin", "articles"], queryFn: () => list(), retry: false });
  const categories = useQuery({
    queryKey: ["admin", "article-categories"],
    queryFn: () => cats(),
    retry: false,
  });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      await save({
        data: {
          id: draft.id,
          title: draft.title.trim(),
          slug: draft.slug.trim(),
          excerpt: draft.excerpt.trim(),
          body: draft.body,
          category_id: draft.category_id || null,
          author: draft.author.trim() || "OHMICLY",
          reading_time: draft.reading_time || null,
          status: draft.status,
          tags: draft.tags.split(",").map((t) => t.trim()).filter(Boolean),
          seo_title: draft.seo_title || null,
          seo_description: draft.seo_description || null,
          cover_image_url: draft.cover_image_url || null,
          canonical_url: draft.canonical_url || `/blog/${draft.slug.trim()}`,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin"] });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this article.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminPage
      title="Articles"
      description="Write and publish technical knowledge posts."
      actions={
        <Btn onClick={() => setDraft({ ...EMPTY })}>
          <Plus className="h-4 w-4" aria-hidden="true" /> New article
        </Btn>
      }
    >
      {draft ? (
        <Panel title={draft.id ? "Edit article" : "New article"}>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Title" required>
                <input
                  className="admin-input"
                  required
                  value={draft.title}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      title: e.target.value,
                      slug: draft.id ? draft.slug : slugify(e.target.value),
                    })
                  }
                />
              </Field>
              <Field label="Slug" required>
                <input
                  className="admin-input"
                  required
                  value={draft.slug}
                  onChange={(e) => setDraft({ ...draft, slug: slugify(e.target.value) })}
                />
              </Field>
            </div>
            <Field label="Excerpt">
              <textarea
                className="admin-input min-h-20"
                value={draft.excerpt}
                onChange={(e) => setDraft({ ...draft, excerpt: e.target.value })}
              />
            </Field>
            <Field label="Body" hint="Format text with the toolbar: bold, italic, headings, quotes, lists, links, dividers and images.">
              <RichTextEditor
                value={draft.body}
                busy={busy || uploading}
                onChange={(html) => setDraft((d) => (d ? { ...d, body: html } : d))}
                onRequestImage={pickAndUploadImage}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Category">
                <select
                  className="admin-input"
                  value={draft.category_id}
                  onChange={(e) => setDraft({ ...draft, category_id: e.target.value })}
                >
                  <option value="">No category</option>
                  {(categories.data ?? []).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Reading time">
                <input
                  className="admin-input"
                  placeholder="6 min read"
                  value={draft.reading_time}
                  onChange={(e) => setDraft({ ...draft, reading_time: e.target.value })}
                />
              </Field>
              <Field label="Author">
                <input
                  className="admin-input"
                  value={draft.author}
                  onChange={(e) => setDraft({ ...draft, author: e.target.value })}
                />
              </Field>
              <Field label="Status">
                <select
                  className="admin-input"
                  value={draft.status}
                  onChange={(e) => setDraft({ ...draft, status: e.target.value as Draft["status"] })}
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                  <option value="archived">Archived</option>
                </select>
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Tags" hint="Comma separated">
                <input
                  className="admin-input"
                  value={draft.tags}
                  onChange={(e) => setDraft({ ...draft, tags: e.target.value })}
                />
              </Field>
              <Field label="SEO title">
                <input
                  className="admin-input"
                  value={draft.seo_title}
                  onChange={(e) => setDraft({ ...draft, seo_title: e.target.value })}
                />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Meta description" hint={`${draft.seo_description.length}/160 characters`}>
                <textarea
                  className="admin-input min-h-24"
                  value={draft.seo_description}
                  onChange={(e) => setDraft({ ...draft, seo_description: e.target.value })}
                />
              </Field>
              <div className="space-y-4">
                <Field label="Cover image" hint="Upload a PNG, JPG or WEBP (max 2 MB), or paste an image link.">
                  <div className="space-y-2">
                    {draft.cover_image_url ? (
                      <div className="overflow-hidden rounded-lg border border-border bg-surface">
                        <img
                          src={coverPreview || draft.cover_image_url}
                          alt="Cover preview"
                          className="h-40 w-full object-cover"
                        />
                      </div>
                    ) : null}
                    <div className="flex flex-wrap gap-2">
                      <Btn
                        type="button"
                        variant="outline"
                        busy={uploading}
                        onClick={() => {
                          void pickAndUploadImage().then((url) => {
                            if (url) setDraft((d) => (d ? { ...d, cover_image_url: url } : d));
                          });
                        }}
                      >
                        <ImagePlus className="h-4 w-4" aria-hidden="true" />
                        {draft.cover_image_url ? "Replace image" : "Upload image"}
                      </Btn>
                      {draft.cover_image_url ? (
                        <Btn
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setCoverPreview("");
                            setDraft((d) => (d ? { ...d, cover_image_url: "" } : d));
                          }}
                        >
                          Remove
                        </Btn>
                      ) : null}
                    </div>
                    <input
                      className="admin-input"
                      placeholder="…or paste an image URL"
                      value={draft.cover_image_url}
                      onChange={(e) => {
                        setCoverPreview("");
                        setDraft({ ...draft, cover_image_url: e.target.value });
                      }}
                    />
                  </div>
                </Field>
                <Field label="Canonical URL">
                  <input
                    className="admin-input"
                    placeholder={`/blog/${draft.slug || "article-slug"}`}
                    value={draft.canonical_url}
                    onChange={(e) => setDraft({ ...draft, canonical_url: e.target.value })}
                  />
                </Field>
              </div>
            </div>
            {error ? <Notice kind="error">{error}</Notice> : null}
            <div className="flex flex-wrap gap-2">
              <Btn type="submit" busy={busy}>
                Save article
              </Btn>
              <Btn type="button" variant="outline" onClick={() => setDraft(null)}>
                Cancel
              </Btn>
            </div>
          </form>
        </Panel>
      ) : null}

      {articles.isLoading ? (
        <Loading />
      ) : !articles.data?.length ? (
        <EmptyState title="No articles yet." />
      ) : (
        <ul className="space-y-3">
          {articles.data.map((a) => (
            <li key={a.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">{a.title}</p>
                  <p className="truncate text-xs text-muted-foreground">/blog/{a.slug}</p>
                </div>
                <StatusPill status={a.status} />
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Btn
                  variant="outline"
                  onClick={() =>
                    setDraft({
                      id: a.id,
                      title: a.title,
                      slug: a.slug,
                      excerpt: a.excerpt ?? "",
                      body: a.body ?? "",
                      category_id: a.category_id ?? "",
                      author: a.author ?? "OHMICLY",
                      reading_time: a.reading_time ?? "",
                      status: a.status,
                      tags: (a.tags ?? []).join(", "),
                      seo_title: a.seo_title ?? "",
                      seo_description: a.seo_description ?? "",
                      cover_image_url: a.cover_image_url ?? "",
                      canonical_url: a.canonical_url ?? "",
                    })
                  }
                >
                  Edit
                </Btn>
                <Btn
                  variant="danger"
                  onClick={async () => {
                    if (!window.confirm(`Delete "${a.title}"?`)) return;
                    await remove({ data: { id: a.id } });
                    await qc.invalidateQueries({ queryKey: ["admin"] });
                  }}
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" /> Delete
                </Btn>
                {a.status === "published" ? (
                  <Link
                    to="/blog/$slug"
                    params={{ slug: a.slug }}
                    target="_blank"
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-lg border border-border px-4 text-sm font-semibold text-foreground hover:border-electric/50 hover:text-electric"
                  >
                    <ExternalLink className="h-4 w-4" aria-hidden="true" /> View
                  </Link>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      )}
    </AdminPage>
  );
}