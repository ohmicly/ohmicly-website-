import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { adminListResources, adminStats } from "@/lib/admin/admin.functions";
import { AdminPage, EmptyState, LinkBtn, Loading, Panel, StatusPill } from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: Dashboard,
});

function Dashboard() {
  const stats = useServerFn(adminStats);
  const list = useServerFn(adminListResources);
  const statsQuery = useQuery({ queryKey: ["admin", "stats"], queryFn: () => stats(), retry: false });
  const recent = useQuery({
    queryKey: ["admin", "resources", "recent"],
    queryFn: () => list({ data: {} }),
    retry: false,
  });

  const cards = [
    { label: "Resources", value: statsQuery.data?.resources },
    { label: "Published", value: statsQuery.data?.published },
    { label: "Drafts", value: statsQuery.data?.drafts },
    { label: "Premium", value: statsQuery.data?.premium },
    { label: "Articles", value: statsQuery.data?.articles },
    { label: "Calculators", value: statsQuery.data?.calculators },
    { label: "Downloads", value: statsQuery.data?.downloads },
    { label: "Members", value: statsQuery.data?.users },
  ];

  return (
    <AdminPage
      title="Dashboard"
      description="Content overview for the OHMICLY platform."
      actions={<LinkBtn to="/admin/resources/$id" params={{ id: "new" }}>New resource</LinkBtn>}
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {c.label}
            </p>
            <p className="mt-2 text-2xl font-bold tabular-nums text-foreground">
              {statsQuery.isLoading ? "—" : (c.value ?? 0)}
            </p>
          </div>
        ))}
      </div>

      <Panel title="Recently updated resources">
        {recent.isLoading ? (
          <Loading />
        ) : !recent.data?.length ? (
          <EmptyState
            title="No resources yet."
            action={<LinkBtn to="/admin/resources/$id" params={{ id: "new" }}>Create the first one</LinkBtn>}
          />
        ) : (
          <ul className="divide-y divide-border">
            {recent.data.slice(0, 8).map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">{r.title}</p>
                  <p className="truncate text-xs text-muted-foreground">/resources/{r.slug}</p>
                </div>
                <div className="flex items-center gap-2">
                  {r.is_premium ? (
                    <span className="rounded-md border border-gold/35 bg-gold-soft px-2 py-0.5 text-[11px] font-semibold uppercase text-amber-accent-foreground">
                      Premium
                    </span>
                  ) : null}
                  <StatusPill status={r.status} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </AdminPage>
  );
}