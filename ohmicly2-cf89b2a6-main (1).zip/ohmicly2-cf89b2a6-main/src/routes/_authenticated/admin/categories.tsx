import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Eye, EyeOff, Plus, Trash2 } from "lucide-react";
import {
  adminCategoryUsage,
  adminDeleteCategory,
  adminListCategories,
  adminReorderCategories,
  adminSaveCategory,
} from "@/lib/admin/admin.functions";
import { AdminPage, Btn, EmptyState, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/categories")({
  component: CategoriesAdmin,
});

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);

type Row = {
  id: string;
  slug: string;
  name: string;
  icon: string | null;
  description: string | null;
  parent_id: string | null;
  group_label: string | null;
  sort_order: number;
  is_active: boolean;
};

type Draft = {
  id: string | null;
  name: string;
  slug: string;
  icon: string;
  description: string;
  group_label: string;
  parent_id: string;
  sort_order: number;
  is_active: boolean;
};

const EMPTY: Draft = {
  id: null,
  name: "",
  slug: "",
  icon: "folder",
  description: "",
  group_label: "",
  parent_id: "",
  sort_order: 0,
  is_active: true,
};

function CategoriesAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListCategories);
  const save = useServerFn(adminSaveCategory);
  const usageFn = useServerFn(adminCategoryUsage);
  const removeFn = useServerFn(adminDeleteCategory);
  const reorderFn = useServerFn(adminReorderCategories);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [reassignTo, setReassignTo] = useState("");
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const categories = useQuery({
    queryKey: ["admin", "categories"],
    queryFn: () => list(),
    retry: false,
  });

  const usage = useQuery({
    queryKey: ["admin", "category-usage"],
    queryFn: () => usageFn(),
    retry: false,
  });

  const rows = useMemo(() => (categories.data ?? []) as Row[], [categories.data]);
  const parents = useMemo(
    () => rows.filter((r) => !r.parent_id).sort((a, b) => a.sort_order - b.sort_order),
    [rows],
  );
  const childrenOf = (parentId: string) =>
    rows.filter((r) => r.parent_id === parentId).sort((a, b) => a.sort_order - b.sort_order);
  const groups = useMemo(() => {
    const map = new Map<string, Row[]>();
    for (const p of parents) {
      const key = p.group_label?.trim() || "Other";
      map.set(key, [...(map.get(key) ?? []), p]);
    }
    return [...map.entries()];
  }, [parents]);

  const count = (id: string) => usage.data?.[id] ?? 0;

  const move = async (siblings: Row[], index: number, dir: -1 | 1) => {
    const target = index + dir;
    if (target < 0 || target >= siblings.length) return;
    const next = [...siblings];
    const a = next[index]!;
    next[index] = next[target]!;
    next[target] = a;
    await reorderFn({ data: { items: next.map((r, i) => ({ id: r.id, sort_order: i })) } });
    await qc.invalidateQueries({ queryKey: ["admin", "categories"] });
  };

  const toggleVisible = async (row: Row) => {
    await save({
      data: {
        id: row.id,
        name: row.name,
        slug: row.slug,
        icon: row.icon,
        description: row.description,
        group_label: row.group_label,
        parent_id: row.parent_id,
        sort_order: row.sort_order,
        is_active: !row.is_active,
      },
    });
    await qc.invalidateQueries({ queryKey: ["admin", "categories"] });
  };

  const startEdit = (row: Row) =>
    setDraft({
      id: row.id,
      name: row.name,
      slug: row.slug,
      icon: row.icon ?? "folder",
      description: row.description ?? "",
      group_label: row.group_label ?? "",
      parent_id: row.parent_id ?? "",
      sort_order: row.sort_order,
      is_active: row.is_active,
    });

  const confirmDelete = async (id: string) => {
    setDeleteBusy(true);
    setDeleteError(null);
    try {
      await removeFn({ data: { id, reassign_to: reassignTo || null } });
      await qc.invalidateQueries({ queryKey: ["admin"] });
      setDeleteId(null);
      setReassignTo("");
    } catch (e) {
      setDeleteError(e instanceof Error ? e.message : "Could not delete this category.");
    } finally {
      setDeleteBusy(false);
    }
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      await save({
        data: {
          id: draft.id,
          name: draft.name.trim(),
          slug: draft.slug.trim(),
          icon: draft.icon || null,
          description: draft.description || null,
          group_label: draft.parent_id ? null : draft.group_label.trim() || null,
          parent_id: draft.parent_id || null,
          sort_order: draft.sort_order,
          is_active: draft.is_active,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin"] });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this category.");
    } finally {
      setBusy(false);
    }
  };

  const deletePanel = (row: Row) =>
    deleteId === row.id ? (
      <div className="mt-3 space-y-3 rounded-lg border border-border bg-muted/40 p-4">
        {count(row.id) > 0 ? (
          <>
            <p className="text-sm text-foreground">
              {count(row.id)} resource(s) use “{row.name}”. Choose where to move them, or cancel and
              hide it instead.
            </p>
            <Field label="Move resources to">
              <select
                className="admin-input"
                value={reassignTo}
                onChange={(e) => setReassignTo(e.target.value)}
              >
                <option value="">Select a destination…</option>
                {rows
                  .filter((o) => o.id !== row.id && !!o.parent_id === !!row.parent_id)
                  .map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.name}
                    </option>
                  ))}
              </select>
            </Field>
          </>
        ) : (
          <p className="text-sm text-foreground">Delete “{row.name}”? This cannot be undone.</p>
        )}
        {deleteError ? <Notice kind="error">{deleteError}</Notice> : null}
        <div className="flex flex-wrap gap-2">
          <Btn
            variant="danger"
            busy={deleteBusy}
            disabled={count(row.id) > 0 && !reassignTo}
            onClick={() => void confirmDelete(row.id)}
          >
            Delete
          </Btn>
          <Btn variant="outline" onClick={() => setDeleteId(null)}>
            Cancel
          </Btn>
        </div>
      </div>
    ) : null;

  const rowActions = (row: Row, siblings: Row[], index: number) => (
    <div className="flex shrink-0 flex-wrap items-center gap-1.5">
      <Btn variant="outline" onClick={() => void move(siblings, index, -1)} aria-label="Move up">
        <ArrowUp className="h-4 w-4" aria-hidden="true" />
      </Btn>
      <Btn variant="outline" onClick={() => void move(siblings, index, 1)} aria-label="Move down">
        <ArrowDown className="h-4 w-4" aria-hidden="true" />
      </Btn>
      <Btn
        variant="outline"
        onClick={() => void toggleVisible(row)}
        aria-label={row.is_active ? "Hide from website" : "Show on website"}
      >
        {row.is_active ? (
          <Eye className="h-4 w-4" aria-hidden="true" />
        ) : (
          <EyeOff className="h-4 w-4" aria-hidden="true" />
        )}
      </Btn>
      <Btn variant="outline" onClick={() => startEdit(row)}>
        Edit
      </Btn>
      <Btn
        variant="danger"
        onClick={() => {
          setDeleteId(deleteId === row.id ? null : row.id);
          setReassignTo("");
          setDeleteError(null);
        }}
        aria-label={`Delete ${row.name}`}
      >
        <Trash2 className="h-4 w-4" aria-hidden="true" />
      </Btn>
    </div>
  );

  return (
    <AdminPage
      title="Categories"
      description="Group resources into the sections shown in the public sidebar."
      actions={
        <Btn onClick={() => setDraft({ ...EMPTY })}>
          <Plus className="h-4 w-4" aria-hidden="true" /> New category
        </Btn>
      }
    >
      {draft ? (
        <Panel title={draft.id ? "Edit category" : "New category"}>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name" required>
                <input
                  className="admin-input"
                  required
                  value={draft.name}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      name: e.target.value,
                      slug: draft.id ? draft.slug : slugify(e.target.value),
                    })
                  }
                />
              </Field>
              <Field label="Slug" required>
                <input
                  className="admin-input"
                  required
                  value={draft.slug}
                  onChange={(e) => setDraft({ ...draft, slug: slugify(e.target.value) })}
                />
              </Field>
              <Field label="Parent category" hint="Leave empty for a top-level category">
                <select
                  className="admin-input"
                  value={draft.parent_id}
                  onChange={(e) => setDraft({ ...draft, parent_id: e.target.value })}
                >
                  <option value="">None (top level)</option>
                  {parents
                    .filter((p) => p.id !== draft.id)
                    .map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                </select>
              </Field>
              <Field
                label="Group heading"
                hint="Bold sidebar header, e.g. “Audit & Compliance” (top-level only)"
              >
                <input
                  className="admin-input"
                  value={draft.group_label}
                  disabled={!!draft.parent_id}
                  onChange={(e) => setDraft({ ...draft, group_label: e.target.value })}
                />
              </Field>
              <Field label="Icon" hint="Lucide icon name">
                <input
                  className="admin-input"
                  value={draft.icon}
                  onChange={(e) => setDraft({ ...draft, icon: e.target.value })}
                />
              </Field>
              <Field label="Sort order">
                <input
                  className="admin-input"
                  type="number"
                  min={0}
                  max={999}
                  value={draft.sort_order}
                  onChange={(e) => setDraft({ ...draft, sort_order: Number(e.target.value) || 0 })}
                />
              </Field>
            </div>
            <Field label="Description">
              <textarea
                className="admin-input min-h-20"
                value={draft.description}
                onChange={(e) => setDraft({ ...draft, description: e.target.value })}
              />
            </Field>
            <label className="flex items-center gap-3 text-sm font-semibold text-foreground">
              <input
                type="checkbox"
                className="h-5 w-5 rounded border-border"
                checked={draft.is_active}
                onChange={(e) => setDraft({ ...draft, is_active: e.target.checked })}
              />
              Visible on the website
            </label>
            {error ? <Notice kind="error">{error}</Notice> : null}
            <div className="flex flex-wrap gap-2">
              <Btn type="submit" busy={busy}>
                Save category
              </Btn>
              <Btn type="button" variant="outline" onClick={() => setDraft(null)}>
                Cancel
              </Btn>
            </div>
          </form>
        </Panel>
      ) : null}

      {categories.isLoading ? (
        <Loading />
      ) : !rows.length ? (
        <EmptyState title="No categories yet." />
      ) : (
        <div className="space-y-8">
          {groups.map(([groupLabel, groupParents]) => (
            <section key={groupLabel}>
              <h2 className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                {groupLabel}
              </h2>
              <ul className="mt-2 space-y-3">
                {groupParents.map((parent, index) => {
                  const kids = childrenOf(parent.id);
                  return (
                    <li key={parent.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-foreground">
                            {parent.name}
                            {parent.is_active ? "" : " · hidden"}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">
                            /{parent.slug} · order {parent.sort_order} · {count(parent.id)} resource
                            {count(parent.id) === 1 ? "" : "s"}
                          </p>
                        </div>
                        {rowActions(parent, groupParents, index)}
                      </div>
                      {deletePanel(parent)}

                      <ul className="mt-3 space-y-2 border-l border-border pl-4">
                        {kids.map((kid, kidIndex) => (
                          <li key={kid.id}>
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <div className="min-w-0">
                                <p className="truncate text-sm text-foreground">
                                  {kid.name}
                                  {kid.is_active ? "" : " · hidden"}
                                </p>
                                <p className="truncate text-xs text-muted-foreground">
                                  /{kid.slug} · order {kid.sort_order} · {count(kid.id)} resource
                                  {count(kid.id) === 1 ? "" : "s"}
                                </p>
                              </div>
                              {rowActions(kid, kids, kidIndex)}
                            </div>
                            {deletePanel(kid)}
                          </li>
                        ))}
                        <li>
                          <Btn
                            variant="outline"
                            onClick={() =>
                              setDraft({
                                ...EMPTY,
                                parent_id: parent.id,
                                sort_order: kids.length,
                              })
                            }
                          >
                            <Plus className="h-4 w-4" aria-hidden="true" /> Add subcategory
                          </Btn>
                        </li>
                      </ul>
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>
      )}
    </AdminPage>
  );
}
