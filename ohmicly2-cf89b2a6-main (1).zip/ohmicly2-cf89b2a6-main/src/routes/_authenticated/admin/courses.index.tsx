import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Layers, Trash2 } from "lucide-react";
import { adminDeleteCourse, adminListCourses } from "@/lib/admin/course.functions";
import {
  AdminPage,
  Btn,
  EmptyState,
  Loading,
  LinkBtn,
  StatusPill,
} from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/courses/")({
  component: CoursesAdmin,
});

function CoursesAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListCourses);
  const remove = useServerFn(adminDeleteCourse);

  const courses = useQuery({ queryKey: ["admin", "courses"], queryFn: () => list(), retry: false });

  return (
    <AdminPage
      title="Courses"
      description="Structured, multi-module video courses (AutoCAD, LPS design, BOQ, and more)."
      actions={
        <LinkBtn to="/admin/courses/$id" params={{ id: "new" }}>
          New course
        </LinkBtn>
      }
    >
      {courses.isLoading ? (
        <Loading />
      ) : !courses.data?.length ? (
        <EmptyState title="No courses yet. Create your first course to get started." />
      ) : (
        <ul className="space-y-3">
          {courses.data.map((c) => (
            <li
              key={c.id}
              className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate text-sm font-bold text-foreground">{c.title}</p>
                  <StatusPill status={c.status} />
                  {c.is_premium ? (
                    <span className="inline-flex items-center rounded-md border border-gold/35 bg-gold-soft px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-amber-accent-foreground">
                      Premium
                    </span>
                  ) : null}
                </div>
                <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Layers className="h-3.5 w-3.5" aria-hidden="true" />
                  {c.module_count} modules · {c.lesson_count} lessons · {c.level}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <LinkBtn variant="outline" to="/admin/courses/$id" params={{ id: c.id }}>
                  Edit
                </LinkBtn>
                <Btn
                  variant="danger"
                  onClick={async () => {
                    if (!window.confirm(`Delete "${c.title}" and all its modules/lessons?`)) return;
                    await remove({ data: { id: c.id } });
                    await qc.invalidateQueries({ queryKey: ["admin", "courses"] });
                  }}
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" /> Delete
                </Btn>
              </div>
            </li>
          ))}
        </ul>
      )}
    </AdminPage>
  );
}
