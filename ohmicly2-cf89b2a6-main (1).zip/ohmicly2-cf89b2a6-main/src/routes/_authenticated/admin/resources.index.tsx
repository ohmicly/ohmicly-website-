import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Paperclip, Search, Trash2 } from "lucide-react";
import {
  adminDeleteResource,
  adminListResources,
  adminUpdateResourceFlags,
} from "@/lib/admin/admin.functions";
import { RESOURCE_TYPES } from "@/lib/admin/admin-types";
import {
  AdminPage,
  Btn,
  EmptyState,
  LinkBtn,
  Loading,
  Notice,
  Panel,
  StatusPill,
} from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/resources/")({
  component: ResourceList,
});

function ResourceList() {
  const qc = useQueryClient();
  const list = useServerFn(adminListResources);
  const setFlags = useServerFn(adminUpdateResourceFlags);
  const remove = useServerFn(adminDeleteResource);

  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [type, setType] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  const query = useQuery({
    queryKey: ["admin", "resources", q, status, type],
    queryFn: () => {
      const filter: { q?: string; status?: string; type?: string } = {};
      if (q) filter.q = q;
      if (status) filter.status = status;
      if (type) filter.type = type;
      return list({ data: filter });
    },
    retry: false,
  });

  const run = async (id: string, fn: () => Promise<unknown>) => {
    setPending(id);
    setError(null);
    try {
      await fn();
      await qc.invalidateQueries({ queryKey: ["admin"] });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Action failed.");
    } finally {
      setPending(null);
    }
  };

  return (
    <AdminPage
      title="Resources"
      description="Upload files, set access level and publish to the public library."
      actions={<LinkBtn to="/admin/resources/$id" params={{ id: "new" }}>New resource</LinkBtn>}
    >
      <Panel>
        <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto_auto]">
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <input
              className="admin-input pl-9"
              placeholder="Search by title"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="Search resources"
            />
          </div>
          <select
            className="admin-input sm:w-40"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            aria-label="Filter by status"
          >
            <option value="">All statuses</option>
            <option value="published">Published</option>
            <option value="draft">Draft</option>
            <option value="archived">Archived</option>
          </select>
          <select
            className="admin-input sm:w-48"
            value={type}
            onChange={(e) => setType(e.target.value)}
            aria-label="Filter by type"
          >
            <option value="">All types</option>
            {RESOURCE_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
      </Panel>

      {error ? <Notice kind="error">{error}</Notice> : null}

      {query.isLoading ? (
        <Loading label="Loading resources…" />
      ) : query.isError ? (
        <Notice kind="error">Could not load resources.</Notice>
      ) : !query.data?.length ? (
        <EmptyState title="No resources match these filters." />
      ) : (
        <ul className="space-y-3">
          {query.data.map((r) => (
            <li key={r.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
                    <span className="truncate">{r.title}</span>
                    {r.file_path ? (
                      <Paperclip className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-label="Has file" />
                    ) : null}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">
                    /resources/{r.slug} · {r.resource_type} · {r.download_count} downloads
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {r.is_premium ? (
                    <span className="rounded-md border border-gold/35 bg-gold-soft px-2 py-0.5 text-[11px] font-semibold uppercase text-amber-accent-foreground">
                      Premium
                    </span>
                  ) : (
                    <span className="rounded-md border border-free/25 bg-free/8 px-2 py-0.5 text-[11px] font-semibold uppercase text-free">
                      Free
                    </span>
                  )}
                  <StatusPill status={r.status} />
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <LinkBtn to="/admin/resources/$id" params={{ id: r.id }} variant="outline">
                  Edit
                </LinkBtn>
                <Btn
                  variant="outline"
                  busy={pending === r.id}
                  onClick={() =>
                    run(r.id, () =>
                      setFlags({
                        data: { id: r.id, status: r.status === "published" ? "draft" : "published" },
                      }),
                    )
                  }
                >
                  {r.status === "published" ? "Unpublish" : "Publish"}
                </Btn>
                <Btn
                  variant="outline"
                  busy={pending === r.id}
                  onClick={() => run(r.id, () => setFlags({ data: { id: r.id, featured: !r.featured } }))}
                >
                  {r.featured ? "Unfeature" : "Feature"}
                </Btn>
                <Btn
                  variant="outline"
                  busy={pending === r.id}
                  onClick={() => {
                    const next = r.status === "archived" ? "draft" : "archived";
                    if (
                      next === "archived" &&
                      !window.confirm(
                        `Archive "${r.title}"? It will be removed from public listings and search, but the file and its records are kept.`,
                      )
                    )
                      return;
                    void run(r.id, () => setFlags({ data: { id: r.id, status: next } }));
                  }}
                >
                  {r.status === "archived" ? "Restore" : "Archive"}
                </Btn>
                <Btn
                  variant="danger"
                  busy={pending === r.id}
                  onClick={() => {
                    if (!window.confirm(`Delete "${r.title}"? This also removes its stored file.`)) return;
                    void run(r.id, () => remove({ data: { id: r.id } }));
                  }}
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" /> Delete
                </Btn>
              </div>
            </li>
          ))}
        </ul>
      )}
    </AdminPage>
  );
}