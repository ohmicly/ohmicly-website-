import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { adminListUsers, adminSession, adminSetUserRole } from "@/lib/admin/admin.functions";
import { AdminPage, Btn, EmptyState, Loading, Notice, Panel } from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/users")({
  component: UsersAdmin,
});

function UsersAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListUsers);
  const session = useServerFn(adminSession);
  const setRole = useServerFn(adminSetUserRole);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);

  const me = useQuery({ queryKey: ["admin", "session"], queryFn: () => session(), retry: false });
  const users = useQuery({ queryKey: ["admin", "users"], queryFn: () => list(), retry: false });
  const canManage = Boolean(me.data?.isSuperAdmin);

  const toggle = async (userId: string, role: "admin" | "super_admin", grant: boolean) => {
    setPending(userId + role);
    setError(null);
    try {
      await setRole({ data: { userId, role, grant } });
      await qc.invalidateQueries({ queryKey: ["admin", "users"] });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not update this role.");
    } finally {
      setPending(null);
    }
  };

  return (
    <AdminPage
      title="Users"
      description="Platform members and their roles. Only super administrators can change roles."
    >
      {error ? <Notice kind="error">{error}</Notice> : null}
      {!canManage ? (
        <Notice kind="success">
          You have administrator access. Role changes require a super administrator.
        </Notice>
      ) : null}
      <Panel>
        {users.isLoading ? (
          <Loading />
        ) : !users.data?.length ? (
          <EmptyState title="No members yet." />
        ) : (
          <ul className="divide-y divide-border">
            {users.data.map((u) => (
              <li key={u.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">
                    {u.displayName || u.email || u.id}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {u.email} · {u.roles.length ? u.roles.join(", ") : "user"}
                    {u.confirmed ? "" : " · unconfirmed"}
                  </p>
                </div>
                {canManage ? (
                  <div className="flex flex-wrap gap-2">
                    <Btn
                      variant="outline"
                      busy={pending === u.id + "admin"}
                      onClick={() => toggle(u.id, "admin", !u.roles.includes("admin"))}
                    >
                      {u.roles.includes("admin") ? "Revoke admin" : "Make admin"}
                    </Btn>
                    <Btn
                      variant="outline"
                      busy={pending === u.id + "super_admin"}
                      onClick={() => toggle(u.id, "super_admin", !u.roles.includes("super_admin"))}
                    >
                      {u.roles.includes("super_admin") ? "Revoke super admin" : "Make super admin"}
                    </Btn>
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </AdminPage>
  );
}