import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { adminListDownloads } from "@/lib/admin/admin.functions";
import { AdminPage, EmptyState, Loading, Panel } from "@/components/admin/AdminUI";

export const Route = createFileRoute("/_authenticated/admin/downloads")({
  component: DownloadsAdmin,
});

function DownloadsAdmin() {
  const list = useServerFn(adminListDownloads);
  const downloads = useQuery({
    queryKey: ["admin", "downloads"],
    queryFn: () => list(),
    retry: false,
  });

  return (
    <AdminPage title="Download activity" description="The 200 most recent secure download events.">
      <Panel>
        {downloads.isLoading ? (
          <Loading />
        ) : !downloads.data?.length ? (
          <EmptyState title="No downloads recorded yet." />
        ) : (
          <ul className="divide-y divide-border">
            {downloads.data.map((d) => (
              <li key={d.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">
                    {d.resources?.title ?? "Removed resource"}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {d.user_id ? "Signed-in member" : "Guest"} ·{" "}
                    {new Date(d.created_at).toLocaleString()}
                  </p>
                </div>
                {d.resources?.is_premium ? (
                  <span className="rounded-md border border-gold/35 bg-gold-soft px-2 py-0.5 text-[11px] font-semibold uppercase text-amber-accent-foreground">
                    Premium
                  </span>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </AdminPage>
  );
}