import { createFileRoute, Link, Outlet, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import {
  BarChart3,
  BookOpen,
  Calculator,
  FileText,
  FolderTree,
  GraduationCap,
  HelpCircle,
  Home,
  Library,
  Loader2,
  LogOut,
  Menu,
  ScrollText,
  Settings,
  ShieldAlert,
  Users,
  X,
} from "lucide-react";
import { adminSession } from "@/lib/admin/admin.functions";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/site/Logo";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminLayout,
});

const NAV = [
  { to: "/admin", label: "Dashboard", icon: BarChart3, exact: true },
  { to: "/admin/resources", label: "Resources", icon: Library },
  { to: "/admin/courses", label: "Courses", icon: GraduationCap },
  { to: "/admin/articles", label: "Articles", icon: FileText },
  { to: "/admin/calculators", label: "Calculators", icon: Calculator },
  { to: "/admin/categories", label: "Categories", icon: FolderTree },
  { to: "/admin/standards", label: "Standards", icon: BookOpen },
  { to: "/admin/faqs", label: "FAQs", icon: HelpCircle },
  { to: "/admin/downloads", label: "Downloads", icon: ScrollText },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/branding", label: "Branding", icon: Settings, section: "System" },
] as const;

function AdminLayout() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const session = useServerFn(adminSession);
  const { data, isLoading, isError } = useQuery({
    queryKey: ["admin", "session"],
    queryFn: () => session(),
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Checking your access…
      </div>
    );
  }

  if (isError || !data?.isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center px-5">
        <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 text-center shadow-sm">
          <ShieldAlert className="mx-auto h-8 w-8 text-destructive" aria-hidden="true" />
          <h1 className="mt-3 text-lg font-bold text-foreground">Administrator access required</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            This area is restricted to OHMICLY administrators. If you believe this is a mistake, contact
            the platform owner.
          </p>
          <Link
            to="/"
            className="mt-5 inline-flex h-11 items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
          >
            Back to website
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface">
      <header className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur">
        <div className="flex h-16 items-center justify-between gap-3 px-4 lg:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-label={open ? "Close admin menu" : "Open admin menu"}
              className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border lg:hidden"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <Link to="/" className="flex items-center gap-2">
              <Logo />
            </Link>
            <span className="hidden rounded-md border border-electric/30 bg-electric/8 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-electric sm:inline-flex">
              Admin
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden max-w-[220px] truncate text-sm text-muted-foreground md:inline">
              {data.email}
            </span>
            <Link
              to="/"
              className="inline-flex h-11 items-center gap-2 rounded-lg border border-border px-3 text-sm font-semibold text-foreground hover:border-electric/50 hover:text-electric"
            >
              <Home className="h-4 w-4" aria-hidden="true" />
              <span className="hidden sm:inline">Website</span>
            </Link>
            <button
              type="button"
              onClick={async () => {
                await supabase.auth.signOut();
                void navigate({ to: "/auth" });
              }}
              className="inline-flex h-11 items-center gap-2 rounded-lg border border-border px-3 text-sm font-semibold text-foreground hover:border-destructive/40 hover:text-destructive"
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-[100rem] gap-6 px-4 py-5 lg:px-6">
        <nav
          className={`${open ? "block" : "hidden"} fixed inset-x-0 top-16 z-30 border-b border-border bg-card p-3 shadow-lg lg:static lg:z-auto lg:block lg:w-60 lg:shrink-0 lg:border-0 lg:bg-transparent lg:p-0 lg:shadow-none`}
          aria-label="Admin sections"
        >
          <ul className="space-y-1">
            {NAV.map((item) => (
              <li key={item.to}>
                {"section" in item ? (
                  <p className="mb-1 mt-5 px-3 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {item.section}
                  </p>
                ) : null}
                <Link
                  to={item.to}
                  onClick={() => setOpen(false)}
                  activeOptions={{ exact: Boolean("exact" in item && item.exact) }}
                  activeProps={{ className: "bg-primary/8 text-primary" }}
                  className="flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold text-muted-foreground hover:bg-muted hover:text-foreground"
                >
                  <item.icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <main className="min-w-0 flex-1 pb-16">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
