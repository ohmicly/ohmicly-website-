import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Plus } from "lucide-react";
import { adminListCalculators, adminSaveCalculator } from "@/lib/admin/admin.functions";
import { AdminPage, Btn, EmptyState, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";
import { ThumbnailField } from "@/components/admin/ThumbnailField";

export const Route = createFileRoute("/_authenticated/admin/calculators")({
  component: CalculatorsAdmin,
});

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 160);

type Draft = {
  id: string | null;
  name: string;
  slug: string;
  description: string;
  category: string;
  status: "available" | "coming-soon";
  is_published: boolean;
  seo_description: string;
  disclaimer: string;
  thumbnail_url: string;
};

const EMPTY: Draft = {
  id: null,
  name: "",
  slug: "",
  description: "",
  category: "General",
  status: "coming-soon",
  is_published: true,
  seo_description: "",
  disclaimer: "",
  thumbnail_url: "",
};

function CalculatorsAdmin() {
  const qc = useQueryClient();
  const list = useServerFn(adminListCalculators);
  const save = useServerFn(adminSaveCalculator);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const calculators = useQuery({
    queryKey: ["admin", "calculators"],
    queryFn: () => list(),
    retry: false,
  });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      await save({
        data: {
          id: draft.id,
          name: draft.name.trim(),
          slug: draft.slug.trim(),
          description: draft.description.trim(),
          category: draft.category.trim() || "General",
          status: draft.status,
          is_published: draft.is_published,
          seo_description: draft.seo_description || null,
          disclaimer: draft.disclaimer || null,
          thumbnail_url: draft.thumbnail_url.trim() || null,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin"] });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this calculator.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminPage
      title="Calculators"
      description="Register calculators and control their public availability."
      actions={
        <Btn onClick={() => setDraft({ ...EMPTY })}>
          <Plus className="h-4 w-4" aria-hidden="true" /> New calculator
        </Btn>
      }
    >
      {draft ? (
        <Panel title={draft.id ? "Edit calculator" : "New calculator"}>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name" required>
                <input
                  className="admin-input"
                  required
                  value={draft.name}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      name: e.target.value,
                      slug: draft.id ? draft.slug : slugify(e.target.value),
                    })
                  }
                />
              </Field>
              <Field label="Slug" required>
                <input
                  className="admin-input"
                  required
                  value={draft.slug}
                  onChange={(e) => setDraft({ ...draft, slug: slugify(e.target.value) })}
                />
              </Field>
            </div>
            <Field label="Description">
              <textarea
                className="admin-input min-h-24"
                value={draft.description}
                onChange={(e) => setDraft({ ...draft, description: e.target.value })}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Category">
                <input
                  className="admin-input"
                  value={draft.category}
                  onChange={(e) => setDraft({ ...draft, category: e.target.value })}
                />
              </Field>
              <Field label="Status">
                <select
                  className="admin-input"
                  value={draft.status}
                  onChange={(e) => setDraft({ ...draft, status: e.target.value as Draft["status"] })}
                >
                  <option value="available">Available</option>
                  <option value="coming-soon">Coming soon</option>
                </select>
              </Field>
              <Field label="Visible on site">
                <select
                  className="admin-input"
                  value={draft.is_published ? "yes" : "no"}
                  onChange={(e) => setDraft({ ...draft, is_published: e.target.value === "yes" })}
                >
                  <option value="yes">Published</option>
                  <option value="no">Hidden</option>
                </select>
              </Field>
            </div>
            <Field label="Thumbnail" hint="Shown on the calculators listing cards.">
              <ThumbnailField
                value={draft.thumbnail_url}
                onChange={(next) => setDraft({ ...draft, thumbnail_url: next })}
                resourceType="other"
              />
            </Field>
            {error ? <Notice kind="error">{error}</Notice> : null}
            <div className="flex flex-wrap gap-2">
              <Btn type="submit" busy={busy}>
                Save calculator
              </Btn>
              <Btn type="button" variant="outline" onClick={() => setDraft(null)}>
                Cancel
              </Btn>
            </div>
          </form>
        </Panel>
      ) : null}

      {calculators.isLoading ? (
        <Loading />
      ) : !calculators.data?.length ? (
        <EmptyState title="No calculators registered." />
      ) : (
        <ul className="space-y-3">
          {calculators.data.map((c) => (
            <li key={c.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">{c.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    /calculator/{c.slug} · {c.category} · {c.status}
                    {c.is_published ? "" : " · hidden"}
                  </p>
                </div>
                <Btn
                  variant="outline"
                  onClick={() =>
                    setDraft({
                      id: c.id,
                      name: c.name,
                      slug: c.slug,
                      description: c.description ?? "",
                      category: c.category ?? "General",
                      status: (c.status === "available" ? "available" : "coming-soon") as Draft["status"],
                      is_published: c.is_published,
                      seo_description: c.seo_description ?? "",
                      disclaimer: c.disclaimer ?? "",
                      thumbnail_url:
                        (c as { thumbnail_url?: string | null }).thumbnail_url ?? "",
                    })
                  }
                >
                  Edit
                </Btn>
              </div>
            </li>
          ))}
        </ul>
      )}
    </AdminPage>
  );
}