import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Crown, Loader2, LogOut, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageLayout } from "@/components/site/PageLayout";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({
    meta: [
      { title: "Your account — OHMICLY" },
      { name: "description", content: "Manage your OHMICLY profile, downloads and premium access." },
      { property: "og:title", content: "Your account — OHMICLY" },
      { property: "og:description", content: "Manage your OHMICLY profile and downloads." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [roles, setRoles] = useState<string[]>([]);
  const [premium, setPremium] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user) return;
      setEmail(user.email ?? null);
      const [{ data: profile }, { data: roleRows }, { data: hasPremium }] = await Promise.all([
        supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", user.id),
        supabase.rpc("has_premium_access", { _user_id: user.id }),
      ]);
      setDisplayName(profile?.display_name ?? "");
      setRoles((roleRows ?? []).map((r) => r.role));
      setPremium(Boolean(hasPremium));
      setLoading(false);
    };
    void load();
  }, []);

  const save = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setMessage(null);
    setError(null);
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    if (!user) return;
    const { error: err } = await supabase
      .from("profiles")
      .upsert({ id: user.id, display_name: displayName || null }, { onConflict: "id" });
    setSaving(false);
    if (err) setError("Could not save your profile. Please try again.");
    else setMessage("Profile saved.");
  };

  const isAdmin = roles.includes("admin") || roles.includes("super_admin");

  return (
    <PageLayout crumbs={[{ name: "Account", path: "/account" }]} showSidebar={false}>
      <section className="container-page py-10">
        <h1 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">Your account</h1>
        {loading ? (
          <p className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Loading your account…
          </p>
        ) : (
          <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
            <form
              onSubmit={save}
              className="rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-6"
            >
              <h2 className="text-lg font-semibold text-foreground">Profile</h2>
              <label className="mt-4 block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Email</span>
                <input className="auth-input" value={email ?? ""} disabled readOnly />
              </label>
              <label className="mt-4 block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Display name</span>
                <input
                  className="auth-input"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={80}
                />
              </label>
              {message ? (
                <p role="status" className="mt-3 rounded-lg bg-free/10 px-3 py-2 text-sm text-free">
                  {message}
                </p>
              ) : null}
              {error ? (
                <p role="alert" className="mt-3 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  {error}
                </p>
              ) : null}
              <button
                type="submit"
                disabled={saving}
                className="mt-5 inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : null}
                Save profile
              </button>
            </form>

            <aside className="space-y-4">
              <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
                <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Access
                </h2>
                <p className="mt-3 flex items-center gap-2 text-sm text-foreground">
                  <Crown className="h-4 w-4 text-gold" aria-hidden="true" />
                  {premium ? "Premium access active" : "Free account"}
                </p>
                {roles.length ? (
                  <p className="mt-2 flex items-center gap-2 text-sm text-foreground">
                    <ShieldCheck className="h-4 w-4 text-electric" aria-hidden="true" />
                    {roles.join(", ")}
                  </p>
                ) : null}
                {isAdmin ? (
                  <Link
                    to="/admin"
                    className="mt-4 inline-flex h-11 w-full items-center justify-center rounded-lg border border-border text-sm font-semibold text-foreground hover:border-electric/50 hover:text-electric"
                  >
                    Open admin panel
                  </Link>
                ) : null}
              </div>
              <button
                type="button"
                onClick={async () => {
                  await supabase.auth.signOut();
                  void navigate({ to: "/auth" });
                }}
                className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-border text-sm font-semibold text-foreground hover:border-destructive/40 hover:text-destructive"
              >
                <LogOut className="h-4 w-4" aria-hidden="true" /> Sign out
              </button>
            </aside>
          </div>
        )}
      </section>
    </PageLayout>
  );
}