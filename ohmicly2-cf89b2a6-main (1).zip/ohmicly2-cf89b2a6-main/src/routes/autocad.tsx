import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { CategoryIntro } from "@/components/site/CategoryIntro";
import { ResourceCard } from "@/components/ui-kit/Cards";
import { EmptyState } from "@/components/ui-kit/States";
import { listResources } from "@/lib/content/public.functions";
import { seo, breadcrumbJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/autocad")({
  loader: async () => ({
    items: await listResources({ data: { categories: ["autocad", "electrical-cad"] } }),
  }),
  head: () =>
    seo({
      title: "AutoCAD Electrical Resources — OHMICLY",
      description:
        "DWG drawings, electrical symbol libraries and single line diagram templates for electrical CAD work.",
      path: "/autocad",
      jsonLd: breadcrumbJsonLd([{ name: "AutoCAD Resources", path: "/autocad" }]),
    }),
  component: Page,
});

function Page() {
  const { items } = Route.useLoaderData();
  return (
    <PageLayout crumbs={[{ name: "AutoCAD Resources", path: "/autocad" }]}>
      <PageHero
        eyebrow="Drafting"
        title="AutoCAD Resources"
        description="DWG files, electrical symbols and SLD templates prepared for professional drawing sets."
      />
      <CategoryIntro heading="About the AutoCAD resource library">
        <p>This section collects the AutoCAD files published on OHMICLY for electrical work: DWG drawings, electrical symbol libraries and single line diagram templates that can be opened directly in a drawing set.</p>
        <p>It is aimed at electrical draftspersons, design engineers and consultants who prepare installation drawings and want a starting file rather than a blank sheet. Each item lists its file type and whether it is free or premium before you download it.</p>
      </CategoryIntro>
      <div className="container-page py-10 sm:py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <ResourceCard key={item.slug} item={item} />
          ))}
        </div>
        {items.length === 0 ? <EmptyState /> : null}
      </div>
    </PageLayout>
  );
}
