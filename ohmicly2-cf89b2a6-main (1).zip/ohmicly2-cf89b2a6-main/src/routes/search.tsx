import { createFileRoute } from "@tanstack/react-router";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { SearchBar, type SearchScope } from "@/components/ui-kit/SearchBar";
import { SearchResults } from "@/components/ui-kit/SearchResults";
import { searchContent } from "@/lib/content/public.functions";
import { seo } from "@/lib/seo";

const schema = z.object({
  q: fallback(z.string(), "").default(""),
  scope: fallback(z.string(), "All").default("All"),
});

export const Route = createFileRoute("/search")({
  validateSearch: zodValidator(schema),
  loaderDeps: ({ search }) => ({ q: search["q"], scope: search["scope"] }),
  loader: async ({ deps }) => {
    if (!deps.q.trim()) return { results: [], fallback: false };
    const results = await searchContent({ data: { q: deps.q, scope: deps.scope } });
    // Nothing in this category? Show related matches from everywhere instead of a dead end.
    if (results.length === 0 && deps.scope !== "All") {
      const all = await searchContent({ data: { q: deps.q, scope: "All" } });
      if (all.length > 0) return { results: all, fallback: true };
    }
    return { results, fallback: false };
  },
  head: () =>
    seo({
      title: "Search — OHMICLY",
      description:
        "Search OHMICLY calculators, engineering resources, CAD files, checklists, templates, articles and FAQs.",
      path: "/search",
      noindex: true,
    }),
  component: Page,
});

function Page() {
  const { q, scope } = Route.useSearch();
  const { results, fallback } = Route.useLoaderData();

  return (
    <PageLayout crumbs={[{ name: "Search", path: "/search" }]}>
      <PageHero eyebrow="Search" title="Search OHMICLY" />
      <div className="container-page py-8 sm:py-12">
        <SearchBar
          id="search-page"
          size="lg"
          showFilters
          defaultQuery={q}
          defaultScope={scope as SearchScope}
        />
        <p className="mt-6 text-sm text-muted-foreground" aria-live="polite">
          {q
            ? fallback
              ? `No ${scope.toLowerCase()} matched “${q}” — showing ${results.length} related result${results.length === 1 ? "" : "s"} from everywhere.`
              : `${results.length} result${results.length === 1 ? "" : "s"} for “${q}”`
            : null}
        </p>
        <div className="mt-3">
          <SearchResults results={results} query={q} />
        </div>
      </div>
    </PageLayout>
  );
}
