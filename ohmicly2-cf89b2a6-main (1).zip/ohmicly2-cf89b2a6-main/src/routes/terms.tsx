import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { breadcrumbJsonLd, seo } from "@/lib/seo";

export const Route = createFileRoute("/terms")({
  head: () =>
    seo({
      title: "Terms of Use — OHMICLY",
      description: "Terms governing the use of OHMICLY tools, resources and downloads.",
      path: "/terms",
      jsonLd: breadcrumbJsonLd([{ name: "Terms of Use", path: "/terms" }]),
    }),
  component: Page,
});

function Page() {
  return (
    <PageLayout crumbs={[{ name: "Terms of Use", path: "/terms" }]}>
      <PageHero eyebrow="Legal" title="Terms of Use" description="Terms governing use of OHMICLY tools, resources and downloads." />
      <div className="container-page py-10 sm:py-14">
        <div className="max-w-3xl space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>Resources are provided for professional and educational use. Redistribution or resale of downloaded files is not permitted without written permission.</p>
          <p>Premium resources are licensed to the account holder and may be used on that person's projects.</p>
          <p>OHMICLY may update tools, resources and these terms as the platform develops.</p>
        </div>
      </div>
    </PageLayout>
  );
}
