import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { breadcrumbJsonLd, seo } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  head: () =>
    seo({
      title: "Contact OHMICLY",
      description: "Get in touch with the OHMICLY team about resources, corrections, contributions or partnership enquiries.",
      path: "/contact",
      jsonLd: breadcrumbJsonLd([{ name: "Contact", path: "/contact" }]),
    }),
  component: Page,
});

function Page() {
  return (
    <PageLayout crumbs={[{ name: "Contact", path: "/contact" }]}>
      <PageHero eyebrow="Company" title="Contact" description="Questions, corrections and contributions are welcome." />
      <div className="container-page py-10 sm:py-14">
        <div className="max-w-3xl space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>For resource requests, corrections or partnership enquiries, email contact@ohmicly.com.</p>
          <p>Corrections to technical content are prioritised — please include the resource name and the specific point being raised.</p>
        </div>
      </div>
    </PageLayout>
  );
}
