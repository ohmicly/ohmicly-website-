import { createFileRoute, notFound } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { ResourceDetail } from "@/components/resources/ResourceDetail";
import { getResource } from "@/lib/content/public.functions";
import { usePremiumAccess } from "@/hooks/use-premium";
import { breadcrumbJsonLd, faqJsonLd, seo } from "@/lib/seo";
import { SITE } from "@/lib/site";
import { richTextToPlainText } from "@/lib/content/rich-text";

export const Route = createFileRoute("/resources/$slug")({
  loader: async ({ params }) => {
    const bundle = await getResource({ data: { slug: params.slug } });
    if (!bundle) throw notFound();
    return bundle;
  },

  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Resource unavailable — OHMICLY" }, { name: "robots", content: "noindex" }] };
    }
    const r = loaderData.resource;
    // Hidden from search ONLY when the resource is a draft or has no uploaded file.
    // Premium resources stay fully indexable — only the file download is gated behind sign-in.
    const notReady = r.status !== "published" || !r.has_file;
    const image = r.thumbnail_url
      ? r.thumbnail_url.startsWith("http")
        ? r.thumbnail_url
        : `${SITE.url}${r.thumbnail_url}`
      : undefined;
    return seo({
      title: r.seo_title,
      description: r.seo_description,
      path: `/resources/${params.slug}`,
      type: "article",
      canonicalUrl: r.canonical_url,
      noindex: r.noindex || notReady,
      ...(image ? { image } : {}),
      jsonLd: [
        breadcrumbJsonLd([
          { name: "Resources", path: "/resources" },
          { name: r.title, path: `/resources/${r.slug}` },
        ]),
        {
          "@context": "https://schema.org",
          "@type": r.schema_type,
          name: r.title,
          description: richTextToPlainText(r.description),
          author: { "@type": "Organization", name: r.author },
          dateModified: r.updated_at,
          encodingFormat: r.file_type,
          ...(image ? { image } : {}),
          isAccessibleForFree: !r.is_premium,
          ...(r.references.length
            ? { citation: r.references.map((ref) => `${ref.code}${ref.edition ? ` ${ref.edition}` : ""} — ${ref.name}`) }
            : {}),
        },
        ...(loaderData.faqs.length ? [faqJsonLd(loaderData.faqs)] : []),
      ],
    });
  },
  component: Page,
});

function Page() {
  const { resource, faqs, relatedResources, relatedTools, relatedArticles } = Route.useLoaderData();
  const { hasPremium } = usePremiumAccess();
  return (
    <PageLayout
      crumbs={[
        { name: "Resources", path: "/resources" },
        { name: resource.category_name || resource.category, path: `/resources?category=${resource.category}` },
        // Breadcrumbs always use the PRIMARY subcategory, never a cross-listing.
        ...(resource.subcategory_slug && resource.subcategory_name
          ? [
              {
                name: resource.subcategory_name,
                path: `/resources?category=${resource.category}&subcategory=${resource.subcategory_slug}`,
              },
            ]
          : []),
        { name: resource.title, path: `/resources/${resource.slug}` },
      ]}
    >
      <ResourceDetail
        resource={resource}
        faqs={faqs}
        relatedResources={relatedResources}
        relatedTools={relatedTools}
        relatedArticles={relatedArticles}
        canDownloadPremium={hasPremium}
      />
    </PageLayout>
  );
}

