import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/tools/$slug")({
  beforeLoad: ({ params }) => {
    throw redirect({
      to: "/calculator/$slug",
      params: { slug: params.slug },
      replace: true,
      statusCode: 301,
    });
  },
});