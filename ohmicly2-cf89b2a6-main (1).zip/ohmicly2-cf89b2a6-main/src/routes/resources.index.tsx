import { createFileRoute } from "@tanstack/react-router";
import { PageLayout } from "@/components/site/PageLayout";
import { ResourceBrowser } from "@/components/resources/ResourceBrowser";
import { listCategories, listResources } from "@/lib/content/public.functions";
import { breadcrumbJsonLd, seo } from "@/lib/seo";

type Search = {
  category?: string;
  subcategory?: string;
  access?: "free" | "premium";
  q?: string;
};

export const Route = createFileRoute("/resources/")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    ...(typeof search["category"] === "string" ? { category: search["category"] } : {}),
    ...(typeof search["subcategory"] === "string"
      ? { subcategory: search["subcategory"] }
      : {}),
    ...(search["access"] === "free" || search["access"] === "premium"
      ? { access: search["access"] }
      : {}),
    ...(typeof search["q"] === "string" ? { q: search["q"].slice(0, 100) } : {}),
  }),
  loader: async () => {
    const [categories, resources] = await Promise.all([
      listCategories(),
      listResources({ data: {} }),
    ]);
    return { categories, resources };
  },
  head: () =>
    seo({
      title: "Electrical Engineering Resources & Downloads — OHMICLY",
      description:
        "Browse electrical engineering resources: CAD drawings, checklists, templates, guides and reference material.",
      path: "/resources",
      jsonLd: breadcrumbJsonLd([{ name: "Resources", path: "/resources" }]),
    }),
  component: Page,
});

function Page() {
  const { categories, resources } = Route.useLoaderData();
  const { category, subcategory, access, q } = Route.useSearch();

  return (
    <PageLayout crumbs={[{ name: "Resources", path: "/resources" }]}>
      <ResourceBrowser
        categories={categories}
        resources={resources}
        initialCategory={category}
        initialSubcategory={subcategory}
        initialAccess={access}
        initialQuery={q}
      />
    </PageLayout>
  );
}

