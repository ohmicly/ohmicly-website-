import { createFileRoute, notFound } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { FAQBlock } from "@/components/ui-kit/FAQBlock";
import { ReferenceBlock } from "@/components/ui-kit/ReferenceBlock";
import { RelatedItems } from "@/components/ui-kit/RelatedItems";
import { EmptyState } from "@/components/ui-kit/States";
import { EngineeringDisclaimer } from "@/components/site/Disclaimer";
import { VoltageDropCalculator } from "@/components/tools/VoltageDropCalculator";
import { VoltageDropMethod } from "@/components/tools/VoltageDropMethod";
import { CableSizeCalculator } from "@/components/tools/CableSizeCalculator";
import { CableSizeMethod } from "@/components/tools/CableSizeMethod";
import { LoadCalculator } from "@/components/tools/LoadCalculator";
import { LoadMethod } from "@/components/tools/LoadMethod";
import { OcpdCalculator } from "@/components/tools/OcpdCalculator";
import { OcpdMethod } from "@/components/tools/OcpdMethod";
import { CalculatorByline, CalculatorExtras, type CalculatorSlug } from "@/components/tools/CalculatorPageExtras";
import { getCalculator } from "@/lib/content/public.functions";
import { hasCalculatorEngine } from "@/lib/content/engine-slugs";
import { breadcrumbJsonLd, faqJsonLd, seo } from "@/lib/seo";
import { SITE, canonical } from "@/lib/site";

export const Route = createFileRoute("/calculator/$slug")({
  loader: async ({ params }) => {
    const result = await getCalculator({ data: { slug: params.slug } });
    if (!result) throw notFound();
    return result;
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Calculator unavailable — OHMICLY" }, { name: "robots", content: "noindex" }] };
    }
    const c = loaderData.calculator;
    const hasEngine = hasCalculatorEngine(c.slug);
    return seo({
      title: c.seo_title,
      description: c.seo_description,
      path: `/calculator/${params.slug}`,
      noindex: !hasEngine,
      jsonLd: [
        breadcrumbJsonLd([
          { name: "Calculators", path: "/calculator" },
          { name: c.name, path: `/calculator/${c.slug}` },
        ]),
        ...(c.faq.length ? [faqJsonLd(c.faq)] : []),
        ...(hasEngine
          ? [
              {
                "@context": "https://schema.org",
                "@type": "SoftwareApplication",
                name: c.name,
                description: c.seo_description,
                url: canonical(`/calculator/${c.slug}`),
                applicationCategory: "EngineeringApplication",
                operatingSystem: "Web",
                offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
                publisher: { "@id": `${SITE.url}/#organization` },
              },
            ]
          : []),
      ],
    });
  },
  component: Page,
});

function Page() {
  const { calculator: c, related: relatedCalcs, relatedResources, relatedArticles } = Route.useLoaderData();
  const related = relatedCalcs.map((x) => ({
    title: x.name,
    href: `/calculator/${x.slug}`,
    meta: x.category,
  }));
  const isVoltageDrop = c.slug === "voltage-drop-calculator";
  const isCableSize = c.slug === "cable-size-calculator";
  const isLoad = c.slug === "load-calculator";
  const isOcpd = c.slug === "ocpd-calculator";
  const hasEngine = isVoltageDrop || isCableSize || isLoad || isOcpd;

  /** Verified references already attached to this calculator, for the PDF report. */
  const reportReferences = c.references.map((r) => ({
    title: [r.code, r.edition, r.section ? `— ${r.section}` : ""].filter(Boolean).join(" "),
    ...(r.name || r.note || r.summary ? { detail: [r.name, r.note ?? r.summary].filter(Boolean).join(" — ") } : {}),
    ...(r.url ? { url: r.url } : {}),
  }));
  const referenceBlock = <ReferenceBlock references={c.references} />;

  return (
    <PageLayout
      crumbs={[
        { name: "Calculators", path: "/calculator" },
        { name: c.name, path: `/calculator/${c.slug}` },
      ]}
    >
      <PageHero eyebrow={c.category} title={c.name} description={c.description} />
      <div className="container-page grid min-w-0 gap-8 py-10 sm:py-14 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="min-w-0 space-y-8">
          {hasEngine ? <CalculatorByline /> : null}
          {isVoltageDrop ? (
            <>
              <VoltageDropCalculator references={reportReferences} referenceContent={referenceBlock} />
              <VoltageDropMethod />
              <section aria-labelledby="about-heading">
                <h2 id="about-heading" className="text-xl font-bold text-primary sm:text-2xl">
                  About this voltage drop calculation
                </h2>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  Voltage drop is the loss of voltage along a conductor run caused by conductor resistance and,
                  in AC circuits, reactance. Enter the system voltage, load current, one-way run length,
                  conductor size and material, and the tool returns the voltage drop in volts, the drop as a
                  percentage of system voltage, and the estimated receiving-end voltage. DC, single-phase and
                  three-phase circuits are each handled with their own formula.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  Excessive voltage drop is rarely a safety failure on its own, but it degrades everything
                  connected downstream: motors draw more current and run hotter as terminal voltage falls,
                  contactor coils chatter or fail to pull in, lighting output and driver life decline, and
                  electronic loads reset during starting transients. Because the drop is proportional to both
                  current and run length, the circuits worth checking first are the long ones, the heavily
                  loaded ones, and any feeder serving motor loads at the far end of a site.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  When a result exceeds your design limit, the usual remedies in order of cost are: increase the
                  conductor size, add conductors in parallel per phase, shorten the run or relocate the
                  distribution board closer to the load, raise the distribution voltage, or improve the load
                  power factor so less current flows for the same real power. This tool lets you test each of
                  those changes directly by re-running the calculation with the revised input.
                </p>
              </section>
            </>
          ) : null}
          {isCableSize ? (
            <>
              <CableSizeCalculator references={reportReferences} referenceContent={referenceBlock} />
              <CableSizeMethod />
              <section aria-labelledby="about-heading">
                <h2 id="about-heading" className="text-xl font-bold text-primary sm:text-2xl">
                  About this cable size calculation
                </h2>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  Sizing a cable is a sequence of independent checks, and the conductor you install has to pass
                  all of them: it must carry the load current continuously without exceeding its insulation
                  temperature, keep voltage drop within the limit your design or specification sets, withstand
                  the prospective short-circuit energy for as long as the protective device takes to clear, and
                  coordinate with that device so a fault at the far end is detected. Version 1 of this tool
                  performs the voltage drop check across every listed conductor size and returns the smallest
                  one that passes.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  Enter the load current, system voltage, phase arrangement, conductor material, run length and
                  the design drop limit, and the calculator compares the whole size table for you rather than
                  making you re-run a voltage drop check by hand for each candidate. The number of
                  current-carrying conductors and ambient temperature are recorded with the correction factors
                  you supply, so the design current used for your own ampacity comparison is shown explicitly
                  alongside the result.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  On long runs the voltage drop check usually governs the final size, while short runs at high
                  current are almost always governed by ampacity. If the recommended size looks larger than
                  expected, the practical levers are the same as for voltage drop: add conductors per phase,
                  shorten the route, move the distribution board closer to the load, or raise the distribution
                  voltage.
                </p>
              </section>
            </>
          ) : null}
          {isLoad ? (
            <>
              <LoadCalculator references={reportReferences} referenceContent={referenceBlock} />
              <LoadMethod />
              <section aria-labelledby="about-heading">
                <h2 id="about-heading" className="text-xl font-bold text-primary sm:text-2xl">
                  About this load calculation
                </h2>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  This calculator turns a load&apos;s real power (kW), system voltage and power factor into the
                  apparent power (kVA) and line current needed to size cables, breakers and distribution
                  equipment. It handles single-phase and three-phase circuits using the standard power
                  relationships, and it can multiply a single load by a quantity to give a total connected load.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  The result is the running current under the conditions you enter. It is not a demand load
                  unless you supply a verified load or diversity factor from your applicable standard. The
                  calculator deliberately does not apply automatic demand factors, diversity factors or code
                  loading values — those vary by country, occupancy and installation type, and must come from
                  the engineer or the standard being used.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  For motor loads the running current is calculated from the kW and power factor you provide.
                  Motor starting (locked-rotor) current, efficiency, service factor and power-factor correction
                  are not modelled. If you are selecting a motor feeder, perform the starting-current and
                  protection-coordination checks separately.
                </p>
              </section>
            </>
          ) : null}
          {isOcpd ? (
            <>
              <OcpdCalculator references={reportReferences} referenceContent={referenceBlock} />
              <OcpdMethod />
              <section aria-labelledby="about-heading">
                <h2 id="about-heading" className="text-xl font-bold text-primary sm:text-2xl">
                  About this overcurrent protection calculation
                </h2>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  An overcurrent protection device protects the conductor and the equipment downstream of it
                  against overload and fault current. Sizing it starts with a single number: the current the
                  circuit is designed to carry. This tool takes that design current, applies any continuous-load
                  factor you explicitly supply from your own standard, and reports the minimum protection
                  current the device must be able to carry without nuisance tripping.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  Everything after that number is code and product territory. The permitted rating depends on
                  the conductor ampacity after correction and adjustment factors, on whether the load is
                  continuous, on motor and transformer rules that differ between BNBC and NEC practice, on the
                  interrupting rating required at the point of installation, and on the trip characteristic the
                  manufacturer publishes. OHMICLY does not hold a verified standard-rating series, so this
                  version deliberately does not propose a breaker or fuse size.
                </p>
                <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                  Use the calculated protection current as the minimum requirement, then select the device from
                  the code applicable to your project and the manufacturer&apos;s catalogue. If you enter a
                  maximum allowable rating — for example the limit set by the conductor you have already sized —
                  the tool tells you whether your requirement fits below it, so an undersized conductor or an
                  optimistic load assumption shows up before procurement.
                </p>
              </section>
            </>
          ) : null}
          {!hasEngine ? (
            <>
              <EmptyState
                title="Calculation engine in preparation"
                description="This calculator page is live and its inputs, results and export actions are being finalised. Formula notes and references below already apply."
              />
              {referenceBlock}
            </>
          ) : null}
          <section aria-labelledby="notes-heading">
            <h2 id="notes-heading" className="text-xl font-bold text-primary sm:text-2xl">
              Formula notes
            </h2>
            <ul className="mt-3 space-y-2 rounded-xl border border-border bg-card p-5 text-sm leading-relaxed text-muted-foreground">
              {c.formula_notes.map((n) => (
                <li key={n} className="list-inside list-disc">
                  {n}
                </li>
              ))}
            </ul>
          </section>
          {hasEngine ? <CalculatorExtras slug={c.slug as CalculatorSlug} /> : null}
          <FAQBlock faqs={c.faq} />
          {c.disclaimer?.trim() ? <EngineeringDisclaimer text={c.disclaimer} /> : null}
        </div>
        <aside className="min-w-0 space-y-4">
          <RelatedItems title="Related calculators" items={related} />
          <RelatedItems
            title="Related resources"
            items={relatedResources.map((r) => ({
              title: r.title,
              href: `/resources/${r.slug}`,
              ...(r.category ? { meta: r.category } : {}),
            }))}
          />
          <RelatedItems
            title="Related articles"
            items={relatedArticles.map((a) => ({
              title: a.title,
              href: `/blog/${a.slug}`,
              ...(a.reading_time ? { meta: a.reading_time } : {}),
            }))}
          />
        </aside>
      </div>
    </PageLayout>
  );
}
