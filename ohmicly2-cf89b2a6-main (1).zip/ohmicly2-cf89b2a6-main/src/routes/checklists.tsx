import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { CategoryIntro } from "@/components/site/CategoryIntro";
import { ResourceCard } from "@/components/ui-kit/Cards";
import { EmptyState } from "@/components/ui-kit/States";
import { listResources } from "@/lib/content/public.functions";
import { seo, breadcrumbJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/checklists")({
  loader: async () => { const items = await listResources({ data: { resourceType: "checklist" } }); return { items }; },
  head: () =>
    seo({
      title: 'Electrical Checklists & Inspection Lists — OHMICLY',
      description: 'Inspection, audit and commissioning checklists for electrical installations.',
      path: "/checklists",
      jsonLd: breadcrumbJsonLd([{ name: 'Electrical Checklists', path: "/checklists" }]),
    }),
  component: Page,
});

function Page() {
  const { items } = Route.useLoaderData();
  return (
    <PageLayout crumbs={[{ name: 'Electrical Checklists', path: "/checklists" }]}>
      <PageHero eyebrow='Checklists' title='Electrical Checklists' description='Verification lists for inspection, audit and commissioning activities.' />
      <CategoryIntro heading="About the electrical checklist library">
        <p>This section lists the checklist documents published on OHMICLY, covering inspection, audit and commissioning activities on electrical installations.</p>
        <p>It is aimed at site engineers, inspectors and auditors who need a written verification list to work through on site. Each checklist page shows its file format, description and any standards referenced for that document.</p>
      </CategoryIntro>
      <div className="container-page py-10 sm:py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <ResourceCard key={item.slug} item={item} />
          ))}
        </div>
        {items.length === 0 ? <EmptyState /> : null}
      </div>
    </PageLayout>
  );
}
