import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { breadcrumbJsonLd, seo } from "@/lib/seo";

export const Route = createFileRoute("/privacy")({
  head: () =>
    seo({
      title: "Privacy Policy — OHMICLY",
      description: "How OHMICLY handles personal data, account information and analytics.",
      path: "/privacy",
      jsonLd: breadcrumbJsonLd([{ name: "Privacy Policy", path: "/privacy" }]),
    }),
  component: Page,
});

function Page() {
  return (
    <PageLayout crumbs={[{ name: "Privacy Policy", path: "/privacy" }]}>
      <PageHero eyebrow="Legal" title="Privacy Policy" description="How OHMICLY handles personal data and analytics." />
      <div className="container-page py-10 sm:py-14">
        <div className="max-w-3xl space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>OHMICLY collects only the information needed to operate the platform, such as account details when accounts are enabled.</p>
          <p>Analytics, when configured, is used in aggregate to understand which tools and resources are useful. No tracking scripts load unless a provider is configured.</p>
          <p>Personal data is never sold. Contact us to request access to or deletion of your data.</p>
        </div>
      </div>
    </PageLayout>
  );
}
