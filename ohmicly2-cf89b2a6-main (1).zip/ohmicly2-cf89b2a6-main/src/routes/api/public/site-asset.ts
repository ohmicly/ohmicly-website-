import { createFileRoute } from "@tanstack/react-router";
import { BRANDING_BUCKET, brandingKindSchema, parseBrandingSetting } from "@/lib/branding";

export const Route = createFileRoute("/api/public/site-asset")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const parsedKind = brandingKindSchema.safeParse(url.searchParams.get("kind"));
        if (!parsedKind.success) return new Response("Bad request", { status: 400 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: settingRow, error: settingError } = await supabaseAdmin
          .from("site_settings")
          .select("value")
          .eq("key", "branding")
          .maybeSingle();
        if (settingError) return new Response("Unavailable", { status: 503 });

        const asset = parseBrandingSetting(settingRow?.value)[parsedKind.data];
        if (!asset) return new Response("Not found", { status: 404 });
        const expectedPrefix = `branding/${parsedKind.data}/`;
        if (!asset.path.startsWith(expectedPrefix) || asset.path.includes("..")) {
          return new Response("Not found", { status: 404 });
        }

        const etag = `"${asset.revision}"`;
        if (request.headers.get("if-none-match") === etag) {
          return new Response(null, { status: 304, headers: { ETag: etag } });
        }
        const { data: blob, error } = await supabaseAdmin.storage
          .from(BRANDING_BUCKET)
          .download(asset.path);
        if (error || !blob) return new Response("Not found", { status: 404 });

        return new Response(blob, {
          headers: {
            "Content-Type": asset.mimeType,
            "Content-Length": String(blob.size),
            "Cache-Control": "public, max-age=31536000, immutable",
            ETag: etag,
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox",
          },
        });
      },
    },
  },
});