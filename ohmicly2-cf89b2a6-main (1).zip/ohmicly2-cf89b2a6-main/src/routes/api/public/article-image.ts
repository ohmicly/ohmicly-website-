import { createFileRoute } from "@tanstack/react-router";

/**
 * Serves an article image stored in the private `images` bucket. Only paths
 * referenced by an article (cover or body) are allowed, so private storage
 * cannot be enumerated through this route.
 */
export const Route = createFileRoute("/api/public/article-image")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const path = new URL(request.url).searchParams.get("path");
        if (!path || path.length > 400 || path.includes("..")) {
          return new Response("Bad request", { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const reference = `/api/public/article-image?path=${encodeURIComponent(path)}`;

        const { data: byCover } = await supabaseAdmin
          .from("articles")
          .select("id")
          .eq("cover_image_url", reference)
          .limit(1)
          .maybeSingle();
        let allowed = Boolean(byCover);
        if (!allowed) {
          const { data: byBody } = await supabaseAdmin
            .from("articles")
            .select("id")
            .ilike("body", `%${path}%`)
            .limit(1)
            .maybeSingle();
          allowed = Boolean(byBody);
        }
        if (!allowed) return new Response("Not found", { status: 404 });

        const wantThumb = new URL(request.url).searchParams.get("s") === "thumb";
        const cut = path.lastIndexOf("/");
        const thumbPath =
          cut === -1 ? `thumbs/${path}` : `${path.slice(0, cut)}/thumbs/${path.slice(cut + 1)}`;

        const serve = (p: string) => supabaseAdmin.storage.from("images").download(p);
        let result = wantThumb ? await serve(thumbPath) : await serve(path);
        if (wantThumb && (result.error || !result.data)) result = await serve(path);
        if (result.error || !result.data) return new Response("Not found", { status: 404 });

        // Paths are UUID-stamped per upload, so the bytes at a URL never change.
        return new Response(result.data, {
          status: 200,
          headers: {
            "Content-Type": result.data.type || "image/jpeg",
            "Cache-Control": "public, max-age=31536000, immutable",
            "X-Content-Type-Options": "nosniff",
          },
        });
      },
    },
  },
});
