import { createFileRoute } from "@tanstack/react-router";

/**
 * Serves a resource preview image that lives in the private `images` bucket.
 * Only paths referenced by a published resource are allowed, so this cannot be
 * used to enumerate private storage. Downloadable resource files are NOT served
 * here — they keep the signed-download flow.
 *
 * `?s=thumb` serves the small variant written next to the original at upload
 * time. Every stored path carries a fresh UUID, so a re-upload always produces
 * a new URL — which makes the response safe to cache immutably forever.
 */
export const Route = createFileRoute("/api/public/resource-image")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const path = url.searchParams.get("path");
        const wantThumb = url.searchParams.get("s") === "thumb";
        if (!path || path.length > 400 || path.includes("..")) {
          return new Response("Bad request", { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const reference = `/api/public/resource-image?path=${encodeURIComponent(path)}`;

        // The image must be referenced by a resource record (thumbnail or gallery),
        // which keeps this from being used to enumerate private storage.
        const { data: byThumb } = await supabaseAdmin
          .from("resources")
          .select("id")
          .eq("thumbnail_url", reference)
          .limit(1)
          .maybeSingle();
        let allowed = Boolean(byThumb);
        if (!allowed) {
          const { data: byGallery } = await supabaseAdmin
            .from("resources")
            .select("id")
            .contains("preview_images", [reference])
            .limit(1)
            .maybeSingle();
          allowed = Boolean(byGallery);
        }
        if (!allowed) return new Response("Not found", { status: 404 });

        const cut = path.lastIndexOf("/");
        const thumbPath =
          cut === -1 ? `thumbs/${path}` : `${path.slice(0, cut)}/thumbs/${path.slice(cut + 1)}`;

        // Stream the bytes back directly instead of redirecting, so our own
        // long-lived cache headers apply and each view costs one request.
        const serve = async (objectPath: string) =>
          supabaseAdmin.storage.from("images").download(objectPath);

        let result = wantThumb ? await serve(thumbPath) : await serve(path);
        if (wantThumb && (result.error || !result.data)) {
          // Older uploads have no small variant — fall back to the original.
          result = await serve(path);
        }
        if (result.error || !result.data) return new Response("Not found", { status: 404 });

        return new Response(result.data, {
          status: 200,
          headers: {
            "Content-Type": result.data.type || "image/jpeg",
            "Cache-Control": "public, max-age=31536000, immutable",
            "X-Content-Type-Options": "nosniff",
          },
        });
      },
    },
  },
});
