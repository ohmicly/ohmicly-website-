import { createFileRoute, stripSearchParams } from "@tanstack/react-router";
import { fallback, zodValidator } from "@tanstack/zod-adapter";
import { z } from "zod";
import { PageLayout } from "@/components/site/PageLayout";
import { BlogDashboard } from "@/components/blog/BlogDashboard";
import { listArticles } from "@/lib/content/public.functions";
import { breadcrumbJsonLd, seo } from "@/lib/seo";

const searchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  category: fallback(z.string(), "").default(""),
  page: fallback(z.number().int(), 1).default(1),
  sort: fallback(z.string(), "newest").default("newest"),
});

const searchDefaults = { q: "", category: "", page: 1, sort: "newest" };

export const Route = createFileRoute("/blog/")({
  validateSearch: zodValidator(searchSchema),
  search: {
    middlewares: [stripSearchParams(searchDefaults)],
  },
  loader: async () => ({ articles: await listArticles({ data: {} }) }),
  head: () =>
    seo({
      title: "Electrical Engineering Blog & Articles — OHMICLY",
      description:
        "Technical articles on electrical design, cable sizing, earthing, substations and audit practice.",
      path: "/blog",
      jsonLd: breadcrumbJsonLd([{ name: "Blog", path: "/blog" }]),
    }),
  component: Page,
});

type BlogSearch = { q: string; category: string; page: number; sort: string };

function Page() {
  const { articles } = Route.useLoaderData();
  const search = Route.useSearch() as BlogSearch;
  return (
    <PageLayout crumbs={[{ name: "Blog", path: "/blog" }]}>
      <BlogDashboard
        articles={articles}
        q={search.q.slice(0, 100)}
        category={search.category.slice(0, 100)}
        page={Math.max(1, Math.min(999, search.page))}
        sort={search.sort}
      />
    </PageLayout>
  );
}
