import { createFileRoute, notFound } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, CalendarDays, Clock3, UserRound } from "lucide-react";
import { PageLayout } from "@/components/site/PageLayout";
import { ReferenceBlock } from "@/components/ui-kit/ReferenceBlock";
import { RelatedItems } from "@/components/ui-kit/RelatedItems";
import { EmptyState } from "@/components/ui-kit/States";
import { getArticle } from "@/lib/content/public.functions";
import { isHtmlBody, sanitizeArticleHtml } from "@/lib/content/rich-text";
import { breadcrumbJsonLd, seo } from "@/lib/seo";
import { SITE, canonical } from "@/lib/site";

export const Route = createFileRoute("/blog/$slug")({
  loader: async ({ params }) => {
    const result = await getArticle({ data: { slug: params.slug } });
    if (!result) throw notFound();
    return result;
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Article unavailable — OHMICLY" }, { name: "robots", content: "noindex" }] };
    }
    const a = loaderData.article;
    const image = a.cover_image_url?.startsWith("https://") ? a.cover_image_url : undefined;
    return seo({
      title: `${a.title} — OHMICLY`,
      description: a.excerpt,
      path: `/blog/${params.slug}`,
      type: "article",
      ...(image ? { image } : {}),
      noindex: !a.body?.trim(),
      jsonLd: [
        breadcrumbJsonLd([
          { name: "Blog", path: "/blog" },
          { name: a.title, path: `/blog/${a.slug}` },
        ]),
        {
          "@context": "https://schema.org",
          "@type": "Article",
          headline: a.title,
          description: a.excerpt,
          author: { "@type": "Organization", name: a.author },
          datePublished: a.published_at ?? a.created_at,
          dateModified: a.updated_at,
          ...(image ? { image } : {}),
          publisher: { "@id": `${SITE.url}/#organization` },
          mainEntityOfPage: {
            "@type": "WebPage",
            "@id": canonical(`/blog/${a.slug}`),
          },
        },
      ],
    });
  },
  component: Page,
});

function Page() {
  const { article: a, related: relatedArticles } = Route.useLoaderData();
  const related = relatedArticles.map((x) => ({
    title: x.title,
    href: `/blog/${x.slug}`,
    meta: x.category,
  }));

  return (
    <PageLayout
      crumbs={[
        { name: "Blog", path: "/blog" },
        { name: a.title, path: `/blog/${a.slug}` },
      ]}
      showSidebar={false}
    >
      <article className="min-w-0 overflow-x-clip">
        <header className="border-b border-border bg-card">
          <div className="container-page py-9 sm:py-14">
            <Link to="/blog" className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-primary">
              <ArrowLeft className="h-4 w-4" aria-hidden="true" /> All articles
            </Link>
            <div className="mt-4 min-w-0 max-w-4xl">
              <p className="text-xs font-bold uppercase text-electric">{a.category}</p>
              <h1 className="mt-2 [overflow-wrap:anywhere] text-3xl font-extrabold leading-tight text-primary sm:text-5xl">{a.title}</h1>
              <p className="mt-4 max-w-3xl [overflow-wrap:anywhere] text-base leading-relaxed text-muted-foreground sm:text-lg">{a.excerpt}</p>
              <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-2"><UserRound className="h-4 w-4 text-electric" />{a.author}</span>
                <span className="inline-flex items-center gap-2"><CalendarDays className="h-4 w-4 text-electric" />{new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "long", year: "numeric" }).format(new Date(a.published_at ?? a.created_at))}</span>
                <span className="inline-flex items-center gap-2"><Clock3 className="h-4 w-4 text-electric" />{a.reading_time}</span>
              </div>
            </div>
          </div>
        </header>
        {a.cover_image_url ? <div className="container-page pt-8"><div className="aspect-[16/7] max-h-[34rem] overflow-hidden rounded-lg border border-border bg-surface"><img src={a.cover_image_url} alt={`${a.title} cover`} width={1200} height={525} fetchPriority="high" decoding="async" className="h-full w-full object-cover" /></div></div> : null}
        <div className="container-page grid min-w-0 gap-8 py-10 sm:py-14 min-[1200px]:grid-cols-[minmax(0,1fr)_20rem]">
          <div className="min-w-0">
          {a.body && isHtmlBody(a.body) ? (
            <div
              className="min-w-0 [overflow-wrap:anywhere] text-[15px] leading-7 text-foreground/80 sm:text-base [&_a]:break-words [&_a]:text-electric [&_a]:underline [&_blockquote]:my-4 [&_blockquote]:max-w-full [&_blockquote]:border-l-4 [&_blockquote]:border-electric/40 [&_blockquote]:pl-4 [&_blockquote]:italic [&_code]:break-words [&_h2]:mt-7 [&_h2]:[overflow-wrap:anywhere] [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:text-foreground [&_h3]:mt-5 [&_h3]:[overflow-wrap:anywhere] [&_h3]:text-xl [&_h3]:font-bold [&_h3]:text-foreground [&_hr]:my-6 [&_hr]:border-border [&_img]:my-5 [&_img]:h-auto [&_img]:max-w-full [&_img]:rounded-lg [&_li]:ml-5 [&_li]:my-1 [&_ol]:my-3 [&_ol]:list-decimal [&_p]:my-4 [&_pre]:max-w-full [&_pre]:overflow-x-auto [&_strong]:text-foreground [&_table]:block [&_table]:max-w-full [&_table]:overflow-x-auto [&_ul]:my-3 [&_ul]:list-disc"
              dangerouslySetInnerHTML={{ __html: sanitizeArticleHtml(a.body) }}
            />
          ) : a.body ? (
            <div className="min-w-0 space-y-5 [overflow-wrap:anywhere] text-[15px] leading-7 text-foreground/80 sm:text-base">
              {a.body.split(/\n{2,}/).map((p, i) => (
                p.startsWith("## ") ? <h2 key={i} className="pt-3 text-2xl font-bold text-foreground">{p.slice(3)}</h2> : p.startsWith("### ") ? <h3 key={i} className="pt-2 text-xl font-bold text-foreground">{p.slice(4)}</h3> : <p key={i}>{p}</p>
              ))}
            </div>
          ) : (
            <EmptyState
              title="Full article publishing soon"
              description="This article is scheduled for publication. The summary above reflects its scope."
            />
          )}
          </div>
          <aside className="min-w-0 space-y-4 min-[1200px]:sticky min-[1200px]:top-24 min-[1200px]:self-start">
          <ReferenceBlock references={a.references} />
          <RelatedItems title="Related articles" items={related} />
          </aside>
        </div>
      </article>
    </PageLayout>
  );
}
