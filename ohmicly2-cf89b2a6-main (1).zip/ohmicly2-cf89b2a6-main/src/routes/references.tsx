import { createFileRoute, Link } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { breadcrumbJsonLd, seo } from "@/lib/seo";
import { listStandardUsage } from "@/lib/content/public.functions";
import { EngineeringDisclaimer } from "@/components/site/Disclaimer";

export const Route = createFileRoute("/references")({
  loader: async () => ({ standards: await listStandardUsage() }),
  head: () =>
    seo({
      title: "Electrical Engineering Codes & References — OHMICLY",
      description:
        "Standards referenced across OHMICLY resources, including BNBC 2020, NFPA 70 (NEC), NSC, RSC and Nirapon.",
      path: "/references",
      jsonLd: breadcrumbJsonLd([{ name: "Engineering References", path: "/references" }]),
    }),
  component: Page,
});

function Page() {
  const { standards } = Route.useLoaderData();
  return (
    <PageLayout crumbs={[{ name: "Engineering References", path: "/references" }]}>
      <PageHero
        eyebrow="Standards"
        title="Engineering References"
        description="Standards referenced across OHMICLY resources. Clause-level citations appear only where verified."
      />
      <div className="container-page py-10 sm:py-14">
        <ul className="grid gap-4 sm:grid-cols-2">
          {standards.map((s) => (
            <li key={s.id} id={s.slug} className="scroll-mt-24 rounded-xl border border-border bg-card p-5">
              <p className="text-sm font-semibold text-foreground">
                {s.code}
                {s.edition ? ` ${s.edition}` : ""}
              </p>
              <p className="text-[13px] text-muted-foreground">{s.name}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.summary}</p>
              <UsageList
                label="Calculators referencing this standard"
                items={s.calculators.map((c) => ({ to: `/calculator/${c.slug}`, label: c.name }))}
              />
              <UsageList
                label="Resources referencing this standard"
                items={s.resources.map((r) => ({ to: `/resources/${r.slug}`, label: r.title }))}
              />
              <UsageList
                label="Articles referencing this standard"
                items={s.articles.map((a) => ({ to: `/blog/${a.slug}`, label: a.title }))}
              />
            </li>
          ))}
        </ul>
        <EngineeringDisclaimer className="mt-8" />
      </div>
    </PageLayout>
  );
}

function UsageList({ label, items }: { label: string; items: { to: string; label: string }[] }) {
  if (!items.length) return null;
  return (
    <div className="mt-4">
      <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">{label}</p>
      <ul className="mt-1.5 space-y-1">
        {items.map((i) => (
          <li key={i.to}>
            <Link to={i.to} className="text-sm font-medium text-accent hover:underline">
              {i.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
