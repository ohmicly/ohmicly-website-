import { createFileRoute } from "@tanstack/react-router";
import { PageLayout, PageHero } from "@/components/site/PageLayout";
import { CategoryIntro } from "@/components/site/CategoryIntro";
import { ResourceCard } from "@/components/ui-kit/Cards";
import { EmptyState } from "@/components/ui-kit/States";
import { listResources } from "@/lib/content/public.functions";
import { seo, breadcrumbJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/templates")({
  loader: async () => { const [a, b] = await Promise.all([listResources({ data: { resourceType: "template" } }), listResources({ data: { resourceType: "cv-template" } })]); return { items: [...a, ...b] }; },
  head: () =>
    seo({
      title: 'Engineering Templates & Schedules — OHMICLY',
      description: 'Panel schedules, load schedules, earthing sheets, inspection formats and reporting templates.',
      path: "/templates",
      jsonLd: breadcrumbJsonLd([{ name: 'Engineering Templates', path: "/templates" }]),
    }),
  component: Page,
});

function Page() {
  const { items } = Route.useLoaderData();
  return (
    <PageLayout crumbs={[{ name: 'Engineering Templates', path: "/templates" }]}>
      <PageHero eyebrow='Templates' title='Engineering Templates' description='Schedules, calculation sheets and reporting formats ready for project use.' />
      <CategoryIntro heading="About the engineering template library">
        <p>This section brings together the template files published on OHMICLY, including panel and load schedules, calculation sheets, inspection formats, reporting templates and career documents.</p>
        <p>It is intended for engineers and consultants who need a prepared document structure for project deliverables instead of building one from scratch. Each template page states the file format, its description and any standards cited for it.</p>
      </CategoryIntro>
      <div className="container-page py-10 sm:py-14">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <ResourceCard key={item.slug} item={item} />
          ))}
        </div>
        {items.length === 0 ? <EmptyState /> : null}
      </div>
    </PageLayout>
  );
}
