import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/rsc")({
  beforeLoad: () => {
    throw redirect({ to: "/resources", statusCode: 301 });
  },
});
