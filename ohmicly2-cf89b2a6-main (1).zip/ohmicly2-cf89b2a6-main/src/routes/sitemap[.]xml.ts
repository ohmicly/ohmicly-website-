import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { listSitemapEntries } from "@/lib/content/public.functions";
import { SITE } from "@/lib/site";

const BASE_URL = SITE.url;

type Entry = { path: string; priority: string; changefreq: string; lastmod?: string | undefined };

const staticPaths: Entry[] = [
  { path: "/", priority: "1.0", changefreq: "weekly" },
  { path: "/calculator", priority: "0.9", changefreq: "weekly" },
  { path: "/resources", priority: "0.9", changefreq: "weekly" },
  { path: "/autocad", priority: "0.8", changefreq: "weekly" },
  { path: "/autolisp", priority: "0.8", changefreq: "weekly" },
  { path: "/templates", priority: "0.8", changefreq: "weekly" },
  { path: "/checklists", priority: "0.8", changefreq: "weekly" },
  { path: "/premium", priority: "0.7", changefreq: "weekly" },
  { path: "/blog", priority: "0.8", changefreq: "weekly" },
  
  { path: "/references", priority: "0.7", changefreq: "monthly" },
  { path: "/about", priority: "0.5", changefreq: "yearly" },
  { path: "/contact", priority: "0.5", changefreq: "yearly" },
  { path: "/privacy", priority: "0.3", changefreq: "yearly" },
  { path: "/terms", priority: "0.3", changefreq: "yearly" },
  { path: "/disclaimer", priority: "0.3", changefreq: "yearly" },
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const dynamic = await listSitemapEntries();
        const entries: Entry[] = [
          ...staticPaths,
          ...dynamic.tools.map((t) => ({
            path: `/calculator/${t.slug}`, priority: "0.7", changefreq: "monthly", lastmod: t.lastmod,
          })),
          ...dynamic.resources.map((r) => ({
            path: `/resources/${r.slug}`, priority: "0.7", changefreq: "monthly", lastmod: r.lastmod,
          })),
          ...dynamic.articles.map((a) => ({
            path: `/blog/${a.slug}`, priority: "0.6", changefreq: "monthly", lastmod: a.lastmod,
          })),
        ];

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...entries.map((e) =>
            [
              `  <url>`,
              `    <loc>${BASE_URL}${e.path === "/" ? "" : e.path}</loc>`,
              e.lastmod ? `    <lastmod>${e.lastmod}</lastmod>` : null,
              `    <changefreq>${e.changefreq}</changefreq>`,
              `    <priority>${e.priority}</priority>`,
              `  </url>`,
            ]
              .filter(Boolean)
              .join("\n"),
          ),
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});
