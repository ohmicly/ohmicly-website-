import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageLayout } from "@/components/site/PageLayout";

export const Route = createFileRoute("/auth/reset")({
  head: () => ({
    meta: [
      { title: "Set a new password — OHMICLY" },
      { name: "description", content: "Choose a new password for your OHMICLY account." },
      { property: "og:title", content: "Set a new password — OHMICLY" },
      { property: "og:description", content: "Choose a new password for your OHMICLY account." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPage,
});

function ResetPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    if (password.length < 8) return setError("Password must be at least 8 characters.");
    if (password !== confirm) return setError("Both passwords must match.");
    setBusy(true);
    try {
      const { error: err } = await supabase.auth.updateUser({ password });
      if (err) throw err;
      setDone(true);
      setTimeout(() => void navigate({ to: "/account" }), 1200);
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "This reset link may have expired. Request a new one and try again.",
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <PageLayout showSidebar={false}>
      <section className="container-page py-10 sm:py-14">
        <div className="mx-auto w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Set a new password</h1>
          {done ? (
            <p role="status" className="mt-4 rounded-lg bg-free/10 px-3 py-2 text-sm text-free">
              Password updated. Redirecting to your account…
            </p>
          ) : (
            <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">New password</span>
                <input
                  type="password"
                  className="auth-input"
                  value={password}
                  minLength={8}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="new-password"
                  required
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">
                  Confirm password
                </span>
                <input
                  type="password"
                  className="auth-input"
                  value={confirm}
                  minLength={8}
                  onChange={(e) => setConfirm(e.target.value)}
                  autoComplete="new-password"
                  required
                />
              </label>
              {error ? (
                <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  {error}
                </p>
              ) : null}
              <button
                type="submit"
                disabled={busy}
                className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : null}
                Update password
              </button>
            </form>
          )}
        </div>
      </section>
    </PageLayout>
  );
}