import { Crown, Check } from "lucide-react";
import { cn } from "@/lib/utils";

export function PremiumBadge({ className }: { className?: string | undefined }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border border-gold/35 bg-gold-soft px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-amber-accent-foreground",
        className,
      )}
    >
      <Crown className="h-3 w-3 text-gold" strokeWidth={2.2} aria-hidden="true" />
      Premium
    </span>
  );
}

export function FreeBadge({ className }: { className?: string | undefined }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border border-free/25 bg-free/8 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-free",
        className,
      )}
    >
      <Check className="h-3 w-3" strokeWidth={2.6} aria-hidden="true" />
      Free
    </span>
  );
}

export function AccessBadge({
  access,
  className,
}: {
  access: "free" | "premium";
  className?: string | undefined;
}) {
  return access === "premium" ? <PremiumBadge className={className} /> : <FreeBadge className={className} />;
}
export function ProBadge({ className }: { className?: string | undefined }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md bg-premium-gradient px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-white",
        className,
      )}
    >
      <Crown className="h-3 w-3" strokeWidth={2.4} aria-hidden="true" />
      Pro
    </span>
  );
}

export function CategoryBadge({ name, className }: { name: string; className?: string | undefined }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md border border-border bg-surface px-2 py-0.5 text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground",
        className,
      )}
    >
      {name}
    </span>
  );
}
