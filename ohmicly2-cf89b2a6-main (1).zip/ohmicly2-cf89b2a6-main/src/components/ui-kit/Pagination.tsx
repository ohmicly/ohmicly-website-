import { ChevronLeft, ChevronRight } from "lucide-react";

export function Pagination({
  page,
  pageCount,
  buildHref,
}: {
  page: number;
  pageCount: number;
  buildHref: (page: number) => string;
}) {
  if (pageCount <= 1) return null;
  const pages = Array.from({ length: pageCount }, (_, i) => i + 1);
  return (
    <nav aria-label="Pagination" className="mt-8 flex flex-wrap items-center justify-center gap-1.5">
      <a
        href={buildHref(Math.max(1, page - 1))}
        aria-label="Previous page"
        aria-disabled={page === 1}
        className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground aria-disabled:pointer-events-none aria-disabled:opacity-40"
      >
        <ChevronLeft className="h-4 w-4" aria-hidden="true" />
      </a>
      {pages.map((p) => (
        <a
          key={p}
          href={buildHref(p)}
          aria-current={p === page ? "page" : undefined}
          className={
            "inline-flex h-11 min-w-11 items-center justify-center rounded-lg border px-3 text-sm font-semibold " +
            (p === page
              ? "border-primary/30 bg-primary/8 text-primary"
              : "border-border bg-card text-muted-foreground hover:text-foreground")
          }
        >
          {p}
        </a>
      ))}
      <a
        href={buildHref(Math.min(pageCount, page + 1))}
        aria-label="Next page"
        aria-disabled={page === pageCount}
        className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground aria-disabled:pointer-events-none aria-disabled:opacity-40"
      >
        <ChevronRight className="h-4 w-4" aria-hidden="true" />
      </a>
    </nav>
  );
}
