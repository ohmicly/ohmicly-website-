import { ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Icon } from "./Icon";
import { AccessBadge, FreeBadge, PremiumBadge, ProBadge } from "./Badge";
import type { Article, CalculatorDef, Category, Resource } from "@/lib/content/types";
import { richTextToPlainText } from "@/lib/content/rich-text";
import { thumbVariant } from "@/lib/images/process";

const cardBase =
  "group flex h-full flex-col rounded-xl border border-border bg-card p-5 shadow-card transition-all hover:border-electric/35 hover:shadow-card-hover";

const Arrow = () => (
  <ArrowRight
    className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
    strokeWidth={2.2}
    aria-hidden="true"
  />
);

export function CalculatorCard({ item }: { item: CalculatorDef }) {
  return (
    <article className={cardBase}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-electric/15 bg-accent text-electric">
          <Icon name={item.icon} className="h-5.5 w-5.5" />
        </span>
        {item.status === "coming-soon" ? (
          <span className="rounded-md border border-border bg-surface px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
            Soon
          </span>
        ) : null}
      </div>
      <h3 className="text-[15px] font-semibold leading-snug text-foreground">{item.name}</h3>
      <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
      <Link
        to="/calculator/$slug"
        params={{ slug: item.slug }}
        className="mt-4 inline-flex items-center gap-1.5 border-t border-border pt-3.5 text-sm font-semibold text-electric"
      >
        Open Calculator
        <Arrow />
      </Link>
    </article>
  );
}

export function RscCard({
  item,
}: {
  item: { slug: string; title: string; description: string; icon: string };
}) {
  return (
    <article className="group flex h-full flex-col rounded-xl border border-primary/15 bg-card p-5 shadow-card transition-colors hover:border-primary/35">
      <div className="mb-4 flex items-start justify-between gap-3">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Icon name={item.icon} className="h-5.5 w-5.5" />
        </span>
        <FreeBadge />
      </div>
      <h3 className="text-[15px] font-semibold leading-snug text-foreground">{item.title}</h3>
      <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
      <a
        href="/resources"
        className="mt-4 inline-flex items-center gap-1.5 border-t border-border pt-3.5 text-sm font-semibold text-primary"
      >
        View resources
        <Arrow />
      </a>
    </article>
  );
}

export function CategoryCard({ item, access }: { item: Category; access?: "free" | "premium" | "mixed" }) {
  const tag = access ?? "mixed";
  return (
    <a
      href={`/resources?category=${item.slug}`}
      className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 shadow-card transition-colors hover:border-electric/40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
    >
      <span
        className={
          "inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border " +
          (tag === "premium"
            ? "border-gold/30 bg-gold-soft text-amber-accent-foreground"
            : tag === "mixed"
              ? "border-electric/20 bg-accent text-electric"
              : "border-free/20 bg-free/8 text-free")
        }
      >
        <Icon name={item.icon} className="h-5 w-5" />
      </span>
      <span className="min-w-0">
        <span className="block truncate text-sm font-semibold text-foreground">{item.name}</span>
        <span className="mt-1 flex gap-1.5">
          {tag === "premium" ? (
            <PremiumBadge />
          ) : tag === "mixed" ? (
            <>
              <FreeBadge />
              <PremiumBadge />
            </>
          ) : (
            <FreeBadge />
          )}
        </span>
      </span>
    </a>
  );
}

export function ResourceCard({ item }: { item: Resource }) {
  const premium = item.is_premium;
  return (
    <article
      className={
        premium
          ? "group relative flex h-full flex-col overflow-hidden rounded-xl border border-gold/30 bg-card p-5 shadow-card transition-all hover:shadow-card-hover"
          : cardBase
      }
    >
      {premium ? (
        <span aria-hidden="true" className="absolute inset-x-0 top-0 h-0.5 bg-premium-gradient" />
      ) : null}
      {item.thumbnail_url ? (
        <div className="-mx-5 -mt-5 mb-4 h-36 overflow-hidden border-b border-border bg-surface">
          <img
            src={thumbVariant(item.thumbnail_url)}
            alt={`${item.title} preview`}
            loading="lazy"
            decoding="async"
            width={400}
            height={300}
            className="h-full w-full object-cover"
          />
        </div>
      ) : null}
      <div className="mb-3 flex items-center justify-between gap-3">
        <span className="rounded-md border border-border bg-surface px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          {item.file_type}
        </span>
        <AccessBadge access={premium ? "premium" : "free"} />
      </div>
      <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-electric">{item.category}</p>
      <h3 className="mt-1.5 text-[15px] font-semibold leading-snug text-foreground">{item.title}</h3>
      <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">{richTextToPlainText(item.description)}</p>
      <Link
        to="/resources/$slug"
        params={{ slug: item.slug }}
        className="mt-4 inline-flex items-center gap-1.5 border-t border-border pt-3.5 text-sm font-semibold text-primary"
      >
        View resource
        <Arrow />
      </Link>
    </article>
  );
}

/** Premium-only card treatment: gradient accent plus PRO badge. */
export function PremiumCard({ item }: { item: Resource }) {
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-xl border border-gold/35 bg-card p-5 shadow-card transition-all hover:shadow-card-hover">
      <span aria-hidden="true" className="absolute inset-0 bg-premium-tint" />
      <span aria-hidden="true" className="absolute inset-x-0 top-0 h-1 bg-premium-gradient" />
      <div className="relative flex flex-1 flex-col">
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className="rounded-md border border-gold/30 bg-card px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-amber-accent-foreground">
            {item.file_type}
          </span>
          <ProBadge />
        </div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-amber-accent-foreground">
          {item.category}
        </p>
        <h3 className="mt-1.5 text-[15px] font-semibold leading-snug text-foreground">{item.title}</h3>
        <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">{richTextToPlainText(item.description)}</p>
        <Link
          to="/resources/$slug"
          params={{ slug: item.slug }}
          className="mt-4 inline-flex items-center gap-1.5 border-t border-gold/25 pt-3.5 text-sm font-semibold text-amber-accent-foreground"
        >
          Get access
          <Arrow />
        </Link>
      </div>
    </article>
  );
}

export function BlogCard({ item }: { item: Article }) {
  return (
    <article className={cardBase}>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className="font-semibold uppercase tracking-[0.1em] text-electric">{item.category}</span>
        <span aria-hidden="true">•</span>
        <span>{item.reading_time}</span>
      </div>
      <h3 className="mt-2 text-[15px] font-semibold leading-snug text-foreground">{item.title}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{item.excerpt}</p>
      <Link
        to="/blog/$slug"
        params={{ slug: item.slug }}
        className="mt-4 inline-flex items-center gap-1.5 border-t border-border pt-3.5 text-sm font-semibold text-primary"
      >
        Read Article
        <Arrow />
      </Link>
    </article>
  );
}
