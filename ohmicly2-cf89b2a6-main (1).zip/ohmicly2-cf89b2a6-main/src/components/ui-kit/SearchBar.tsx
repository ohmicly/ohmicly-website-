import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

export const searchFilters = ["All", "Tools", "Resources", "Articles", "Files", "FAQs"] as const;
export type SearchScope = (typeof searchFilters)[number];

/**
 * Global search entry point. Submits as a plain GET form to /search so it
 * works without JavaScript; the scope chips set a hidden field.
 */
export function SearchBar({
  placeholder = "Search calculators, CAD files, checklists, templates, guides...",
  size = "md",
  className,
  id = "site-search",
  showFilters = false,
  defaultQuery = "",
  defaultScope = "All",
}: {
  placeholder?: string;
  size?: "md" | "lg";
  className?: string;
  id?: string;
  showFilters?: boolean;
  defaultQuery?: string;
  defaultScope?: SearchScope;
}) {
  const [scope, setScope] = useState<SearchScope>(defaultScope);
  const [query, setQuery] = useState(defaultQuery);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const navigate = useNavigate();

  // Keep the chips in sync when the URL scope changes (back/forward, external links).
  useEffect(() => {
    setScope(defaultScope);
  }, [defaultScope]);

  // Switching a filter keeps the current query and immediately re-runs the search.
  const applyScope = (next: SearchScope) => {
    setScope(next);
    if (query.trim()) {
      void navigate({ to: "/search", search: { q: query, scope: next } });
    }
  };

  return (
    <div
      className={cn("w-full", className)}
      onFocus={() => setFiltersOpen(true)}
    >
      <form
        role="search"
        action="/search"
        method="get"
        className={cn(
          "flex w-full items-center gap-2 rounded-xl border border-border bg-card shadow-card transition-shadow hover:shadow-md focus-within:border-electric/60 focus-within:ring-2 focus-within:ring-ring/25",
          size === "lg" ? "p-2 pl-3.5" : "p-1.5 pl-3",
        )}
      >
        <Search className="h-5 w-5 shrink-0 text-muted-foreground" strokeWidth={1.9} aria-hidden="true" />
        <label htmlFor={id} className="sr-only">
          Search OHMICLY
        </label>
        <input
          id={id}
          name="q"
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setFiltersOpen(true)}
          placeholder={placeholder}
          className={cn(
            "min-w-0 flex-1 bg-transparent text-[15px] text-foreground outline-none placeholder:text-muted-foreground",
            size === "lg" ? "py-2.5" : "py-2",
          )}
        />
        <input type="hidden" name="scope" value={scope} />
        <button
          type="submit"
          className={cn(
            "shrink-0 cursor-pointer rounded-lg bg-primary font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
            size === "lg" ? "px-4 py-2.5 text-sm sm:px-5" : "px-3 py-2 text-sm",
          )}
        >
          Search
        </button>
      </form>

      {showFilters && (filtersOpen || query.trim().length > 0) ? (
        <div
          role="group"
          aria-label="Search category"
          className="-mx-1 mt-3 flex gap-2 overflow-x-auto px-1 pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          {searchFilters.map((filter) => (
            <button
              key={filter}
              type="button"
              aria-pressed={scope === filter}
              onClick={() => applyScope(filter)}
              className={cn(
                "shrink-0 cursor-pointer rounded-full border px-3.5 py-2 text-[13px] font-medium shadow-xs transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
                scope === filter
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:border-electric/40 hover:text-foreground",
              )}
            >
              {filter}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
