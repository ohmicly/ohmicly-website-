import { BookMarked, ExternalLink } from "lucide-react";
import type { ResolvedReference } from "@/lib/content/types";

/**
 * Renders verified standard references only. Clause numbers appear when a
 * `section` value has been entered; nothing is inferred or generated.
 */
export function ReferenceBlock({
  references,
  title = "Applicable references",
}: {
  references: ResolvedReference[];
  title?: string;
}) {
  const rows = references ?? [];
  if (rows.length === 0) return null;

  return (
    <section
      aria-labelledby="references-heading"
      className="overflow-hidden rounded-xl border border-electric/40 bg-accent/35 shadow-card"
    >
      <h2
        id="references-heading"
        className="flex items-center gap-2 border-b border-electric/25 bg-primary px-5 py-3 text-sm font-bold text-primary-foreground"
      >
        <BookMarked className="h-4 w-4 text-primary-foreground" aria-hidden="true" />
        {title}
      </h2>
      <ul className="space-y-3 p-5">
        {rows.map((ref, i) => (
          <li key={`${ref.id}-${ref.section ?? "general"}-${i}`} className="border-t border-border pt-3 first:border-0 first:pt-0">
            <p className="text-sm font-semibold text-foreground">
              {ref.slug ? (
                <a href={`/references#${ref.slug}`} className="break-words hover:text-primary hover:underline">
                  {ref.code}
                  {ref.edition ? ` ${ref.edition}` : ""}
                </a>
              ) : (
                <>
                  {ref.code}
                  {ref.edition ? ` ${ref.edition}` : ""}
                </>
              )}
              {ref.section ? ` — ${ref.section}` : ""}
            </p>
            <p className="break-words text-[13px] text-muted-foreground">{ref.name}</p>
            <p className="mt-1 break-words text-sm leading-relaxed text-muted-foreground">{ref.note ?? ref.summary}</p>
            {ref.url ? (
              <a
                href={ref.url}
                rel="noopener noreferrer nofollow"
                target="_blank"
                className="mt-1 inline-flex items-center gap-1 text-[13px] font-semibold text-electric"
              >
                Source
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            ) : null}
          </li>
        ))}
      </ul>
    </section>
  );
}
