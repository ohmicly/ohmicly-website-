import { ArrowRight } from "lucide-react";

export type RelatedItem = { title: string; href: string; meta?: string };

export function RelatedItems({
  title,
  items,
}: {
  title: string;
  items: RelatedItem[];
}) {
  if (items.length === 0) return null;
  return (
    <section aria-label={title} className="rounded-xl border border-border bg-card p-5">
      <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      <ul className="mt-3 divide-y divide-border">
        {items.map((item) => (
          <li key={item.href}>
            <a
              href={item.href}
              className="group flex min-h-11 items-center justify-between gap-3 py-2.5 text-sm text-foreground hover:text-primary"
            >
              <span className="min-w-0">
                <span className="block truncate font-medium">{item.title}</span>
                {item.meta ? <span className="text-[12px] text-muted-foreground">{item.meta}</span> : null}
              </span>
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
