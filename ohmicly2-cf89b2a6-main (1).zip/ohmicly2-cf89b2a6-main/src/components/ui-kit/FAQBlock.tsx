import type { Faq } from "@/lib/content/types";

/** Semantic, crawlable FAQ markup — no JS needed to read the answers. */
export function FAQBlock({
  faqs,
  title = "Frequently asked questions",
  id = "faqs",
}: {
  faqs: Faq[];
  title?: string;
  id?: string;
}) {
  if (faqs.length === 0) return null;
  return (
    <section id={id} aria-labelledby={`${id}-heading`} className="scroll-mt-24">
      <h2 id={`${id}-heading`} className="text-xl font-bold text-primary sm:text-2xl">
        {title}
      </h2>
      <dl className="mt-4 divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
        {faqs.map((f) => (
          <div key={f.question} className="p-5">
            <dt className="text-[15px] font-semibold text-foreground">{f.question}</dt>
            <dd className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{f.answer}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
