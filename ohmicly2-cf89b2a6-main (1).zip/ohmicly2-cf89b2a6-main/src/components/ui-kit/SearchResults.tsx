import { ArrowRight } from "lucide-react";
import type { SearchResult } from "@/lib/content/types";
import { AccessBadge } from "./Badge";
import { EmptyState } from "./States";
import { richTextToPlainText } from "@/lib/content/rich-text";

export function SearchResults({ results, query }: { results: SearchResult[]; query: string }) {
  if (!query.trim()) {
    return (
      <EmptyState
        title="Search OHMICLY"
        description="Search calculators, CAD files, checklists, templates, articles and FAQs."
      />
    );
  }
  if (results.length === 0) {
    return (
      <EmptyState
        title={`No results for “${query}”`}
        description="Try a broader term, or browse the tools and resources sections."
      />
    );
  }
  return (
    <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
      {results.map((r) => (
        <li key={`${r.type}-${r.id}`}>
          <a href={r.href} className="group flex items-start gap-3 p-4 hover:bg-surface sm:p-5">
            <span className="mt-0.5 shrink-0 rounded-md border border-electric/20 bg-accent px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.08em] text-electric">
              {r.label}
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex flex-wrap items-center gap-2">
                <span className="text-[15px] font-semibold text-foreground">{r.title}</span>
                {r.access ? <AccessBadge access={r.access} /> : null}
              </span>
              <span className="mt-1 block text-sm leading-relaxed text-muted-foreground">{richTextToPlainText(r.description)}</span>
            </span>
            <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
          </a>
        </li>
      ))}
    </ul>
  );
}
