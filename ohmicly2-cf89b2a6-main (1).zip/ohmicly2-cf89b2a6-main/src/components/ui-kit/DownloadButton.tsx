import { useState } from "react";
import { Download, Loader2, Lock } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { track } from "@/lib/analytics";
import { cn } from "@/lib/utils";
import { getFreeDownloadUrl, getPremiumDownloadUrl } from "@/lib/downloads.functions";
import { useAuth } from "@/hooks/useAuth";

const base =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring";

export function DownloadButton({
  slug,
  fileType,
  hasFile,
  premium = false,
  canDownloadPremium = false,
  className,
}: {
  slug: string;
  fileType: string;
  hasFile: boolean;
  premium?: boolean;
  canDownloadPremium?: boolean;
  className?: string;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showInfo, setShowInfo] = useState(false);
  const { user } = useAuth();
  const freeUrl = useServerFn(getFreeDownloadUrl);
  const premiumUrl = useServerFn(getPremiumDownloadUrl);

  if (premium && !canDownloadPremium) {
    if (!user) {
      return (
        <Link
          to="/auth"
          className={cn(base, "bg-premium-gradient text-white shadow-card", className)}
        >
          <Lock className="h-4 w-4" aria-hidden="true" />
          Sign in for premium access
        </Link>
      );
    }
    return (
      <div className={className}>
        <button
          type="button"
          onClick={() => setShowInfo((v) => !v)}
          aria-expanded={showInfo}
          className={cn(base, "bg-premium-gradient text-white shadow-card")}
        >
          <Lock className="h-4 w-4" aria-hidden="true" />
          Get premium access
        </button>
        {showInfo ? (
          <div
            role="status"
            className="mt-3 rounded-xl border border-gold/30 bg-gold-soft p-4 text-sm leading-relaxed text-foreground"
          >
            <p className="font-semibold text-amber-accent-foreground">
              Premium access is not enabled yet
            </p>
            <p className="mt-1 text-muted-foreground">
              Your account does not currently have a premium entitlement. Premium purchasing is not
              open yet — once it launches, this file will unlock automatically for entitled
              accounts. Premium files stay protected until then.
            </p>
          </div>
        ) : null}
      </div>
    );
  }

  if (!hasFile) {
    return (
      <button
        type="button"
        disabled
        className={cn(
          base,
          "cursor-not-allowed border border-border bg-surface text-muted-foreground",
          className,
        )}
      >
        <Download className="h-4 w-4" aria-hidden="true" />
        File coming soon
      </button>
    );
  }

  async function handleDownload() {
    setBusy(true);
    setError(null);
    try {
      const result = premium
        ? await premiumUrl({ data: { slug } })
        : await freeUrl({ data: { slug } });
      if ("error" in result) {
        setError(result.error);
        return;
      }
      track({ name: "download", slug, fileType });
      window.location.href = result.url;
    } catch {
      setError("Download could not be prepared. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={className}>
      <button
        type="button"
        onClick={handleDownload}
        disabled={busy}
        className={cn(base, "bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-70")}
      >
        {busy ? (
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
        ) : (
          <Download className="h-4 w-4" aria-hidden="true" />
        )}
        {busy ? "Preparing…" : `Download ${fileType}`}
      </button>
      {error ? (
        <p role="alert" className="mt-2 text-sm text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}
