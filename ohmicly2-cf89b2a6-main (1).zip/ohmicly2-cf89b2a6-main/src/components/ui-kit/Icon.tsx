import {
  Activity,
  BookOpen,
  Boxes,
  Cable,
  Calculator,
  ClipboardCheck,
  Download,
  FileText,
  FolderOpen,
  GraduationCap,
  Gauge,
  HardHat,
  Layers,
  LayoutGrid,
  ListChecks,
  MapPin,
  PenTool,
  Plug,
  Shield,
  ShieldCheck,
  Smartphone,
  Terminal,
  TrendingUp,
  Zap,
  type LucideIcon,
} from "lucide-react";

const icons: Record<string, LucideIcon> = {
  activity: Activity,
  "book-open": BookOpen,
  boxes: Boxes,
  cable: Cable,
  calculator: Calculator,
  "clipboard-check": ClipboardCheck,
  download: Download,
  "file-text": FileText,
  "folder-open": FolderOpen,
  "graduation-cap": GraduationCap,
  gauge: Gauge,
  "hard-hat": HardHat,
  layers: Layers,
  "layout-grid": LayoutGrid,
  "list-checks": ListChecks,
  "map-pin": MapPin,
  "pen-tool": PenTool,
  plug: Plug,
  shield: Shield,
  "shield-check": ShieldCheck,
  smartphone: Smartphone,
  terminal: Terminal,
  "trending-up": TrendingUp,
  zap: Zap,
};

export function Icon({
  name,
  className,
  strokeWidth = 1.75,
}: {
  name: string;
  className?: string;
  strokeWidth?: number;
}) {
  const Cmp = icons[name] ?? Zap;
  return <Cmp className={className} strokeWidth={strokeWidth} aria-hidden="true" />;
}