import type { ReactNode } from "react";
import { ChevronDown } from "lucide-react";

/**
 * Collapsible wrapper for the long "method, formulas and assumptions" blocks so
 * they never stand between a mobile user and the calculator itself.
 */
export function MethodDisclosure({
  id,
  headingId,
  title,
  children,
}: {
  id: string;
  headingId: string;
  title: string;
  children: ReactNode;
}) {
  return (
    <section aria-labelledby={headingId} className="scroll-mt-24" id={id}>
      <details className="group rounded-xl border border-border bg-surface/60">
        <summary className="flex min-h-[44px] cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 sm:px-5">
          <h2 id={headingId} className="text-base font-bold text-primary sm:text-xl">
            {title}
          </h2>
          <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center text-muted-foreground">
            <ChevronDown className="h-5 w-5 transition-transform group-open:rotate-180" aria-hidden="true" />
          </span>
        </summary>
        <div className="border-t border-border px-4 pb-5 pt-4 sm:px-5">{children}</div>
      </details>
    </section>
  );
}
