import { useState } from "react";
import { FileDown, Loader2 } from "lucide-react";
import { generateCalculatorReport, type ReportSpec } from "@/lib/pdf/calculator-report";

/**
 * Renders the optional "Prepared for" field and the PDF download action.
 * The spec is built lazily so the report always reflects the current result.
 */
export function PdfReportButton({
  buildSpec,
  idPrefix,
}: {
  buildSpec: (preparedFor: string) => ReportSpec;
  idPrefix: string;
}) {
  const [preparedFor, setPreparedFor] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onClick = async () => {
    setBusy(true);
    setError(null);
    try {
      // Yield once so the loading state paints before jsPDF work begins.
      await new Promise((r) => setTimeout(r, 0));
      await generateCalculatorReport(buildSpec(preparedFor));
    } catch {
      setError("The PDF could not be generated. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="border-t border-border bg-surface px-5 py-4">
      <label
        className="block text-[13px] font-semibold text-foreground"
        htmlFor={`${idPrefix}-prepared-for`}
      >
        Prepared for (optional)
      </label>
      <input
        id={`${idPrefix}-prepared-for`}
        type="text"
        value={preparedFor}
        maxLength={80}
        placeholder="Project, client or reviewer name"
        onChange={(e) => setPreparedFor(e.target.value)}
        className="mt-1.5 block w-full rounded-lg border border-border bg-card px-3 py-2.5 text-[15px] text-foreground shadow-sm outline-none transition-colors focus:border-electric focus:ring-2 focus:ring-electric/25 min-h-11 sm:max-w-sm"
      />
      <button
        type="button"
        onClick={() => void onClick()}
        disabled={busy}
        className="mt-3 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-70 sm:w-auto"
      >
        {busy ? (
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
        ) : (
          <FileDown className="h-4 w-4" aria-hidden="true" />
        )}
        {busy ? "Preparing PDF…" : "Download PDF Report"}
      </button>
      <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
        The report contains only the inputs and results shown above. The name you enter is used for this
        download only and is not stored.
      </p>
      {error ? (
        <p role="alert" className="mt-2 text-[13px] font-medium text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}
