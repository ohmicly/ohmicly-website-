import { useState, type ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Info, RotateCcw } from "lucide-react";
import {
  calculateCableSize,
  validateCableSize,
  type CableFieldErrors,
  type CableSizeResult,
  type Material,
  type SizeSystem,
} from "@/lib/calculators/cable-size";
import type { PhaseMode } from "@/lib/calculators/voltage-drop";
import type { ReportSpec } from "@/lib/pdf/calculator-report";

import { PdfReportButton } from "./PdfReportButton";
import { StickyCalculateBar } from "./StickyCalculateBar";

type ReportReference = ReportSpec["references"][number];


const field =
  "mt-1.5 block w-full rounded-lg border border-border bg-card px-3 py-2.5 text-[15px] text-foreground shadow-sm outline-none transition-colors focus:border-electric focus:ring-2 focus:ring-electric/25 min-h-11";
const labelCls = "block text-sm font-semibold text-foreground";
const hintCls = "mt-1 text-[13px] leading-relaxed text-muted-foreground";
const errorCls = "mt-1 text-[13px] font-medium text-destructive";

const DEFAULTS = {
  current: "100",
  voltage: "400",
  distanceFt: "150",
  powerFactor: "0.9",
  limitPercent: "3",
  ambientTempC: "30",
  tempCorrectionFactor: "1.00",
  groupingFactor: "1.00",
  ccc: "3",
  conductorsPerPhase: "1",
  baseAmpacity: "",
};

export function CableSizeCalculator({
  references = [],
  referenceContent,
}: {
  references?: ReportReference[];
  referenceContent?: ReactNode;
}) {
  const [phase, setPhase] = useState<PhaseMode>("three");
  const [material, setMaterial] = useState<Material>("copper");
  const [sizeSystem, setSizeSystem] = useState<SizeSystem>("metric");
  const [form, setForm] = useState({ ...DEFAULTS });
  const [errors, setErrors] = useState<CableFieldErrors>({});
  const [result, setResult] = useState<CableSizeResult | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const isAc = phase !== "dc";
  const set = (key: keyof typeof DEFAULTS, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setResult(null);
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    const found = validateCableSize({ ...form, phase });
    setErrors(found);
    if (Object.keys(found).length > 0) {
      setResult(null);
      return;
    }
    setResult(
      calculateCableSize({
        current: Number(form.current),
        voltage: Number(form.voltage),
        phase,
        material,
        sizeSystem,
        ccc: Number(form.ccc),
        ambientTempC: Number(form.ambientTempC),
        tempCorrectionFactor: Number(form.tempCorrectionFactor),
        groupingFactor: Number(form.groupingFactor),
        distanceFt: Number(form.distanceFt),
        powerFactor: isAc ? Number(form.powerFactor) : 1,
        conductorsPerPhase: Number(form.conductorsPerPhase) || 1,
        limitPercent: Number(form.limitPercent),
        ...(form.baseAmpacity.trim() !== "" ? { baseAmpacity: Number(form.baseAmpacity) } : {}),
      }),
    );
  };

  const reset = () => {
    setForm({ ...DEFAULTS });
    setPhase("three");
    setMaterial("copper");
    setSizeSystem("metric");
    setErrors({});
    setResult(null);
    setSubmitted(false);
  };

  return (
    <section aria-labelledby="calc-heading" className="min-w-0 scroll-mt-24" id="calculator">
      <h2 id="calc-heading" className="text-xl font-bold text-primary sm:text-2xl">
        Cable size selection
      </h2>

      <div className="mt-3 flex items-start gap-2 rounded-xl border border-electric/25 bg-accent px-4 py-3 text-[13px] leading-relaxed text-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-electric" aria-hidden="true" />
        <p>
          OHMICLY does not hold a verified ampacity or derating table, so this version selects the smallest
          listed conductor that satisfies your <strong>voltage drop limit</strong>. Correction factors and any
          allowable current are values you enter from the standard applicable to your project — nothing is
          assumed on your behalf.
        </p>
      </div>

      <form id="cs-form" onSubmit={onSubmit} noValidate className="mt-4 min-w-0 rounded-xl border border-border bg-card p-4 shadow-card sm:p-5">
        <fieldset className="border-0 p-0">
          <legend className={labelCls}>Current type &amp; phase</legend>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
            {(
              [
                { id: "dc", label: "DC" },
                { id: "single", label: "AC — Single phase" },
                { id: "three", label: "AC — Three phase" },
              ] as { id: PhaseMode; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                aria-pressed={phase === opt.id}
                onClick={() => {
                  setPhase(opt.id);
                  setResult(null);
                }}
                className={
                  "min-h-11 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors " +
                  (phase === opt.id
                    ? "border-electric bg-accent text-electric"
                    : "border-border bg-surface text-muted-foreground hover:border-electric/40")
                }
              >
                {opt.label}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div>
            <label className={labelCls} htmlFor="cs-current">
              Load current (A)
            </label>
            <input
              id="cs-current"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.current}
              aria-invalid={Boolean(errors.current)}
              onChange={(e) => set("current", e.target.value)}
            />
            {submitted && errors.current ? <p className={errorCls}>{errors.current}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-voltage">
              System voltage (V)
            </label>
            <input
              id="cs-voltage"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.voltage}
              aria-invalid={Boolean(errors.voltage)}
              onChange={(e) => set("voltage", e.target.value)}
            />
            {submitted && errors.voltage ? <p className={errorCls}>{errors.voltage}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-distance">
              One-way distance (ft)
            </label>
            <input
              id="cs-distance"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.distanceFt}
              aria-invalid={Boolean(errors.distanceFt)}
              onChange={(e) => set("distanceFt", e.target.value)}
            />
            {submitted && errors.distanceFt ? <p className={errorCls}>{errors.distanceFt}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-material">
              Conductor material
            </label>
            <select
              id="cs-material"
              className={field}
              value={material}
              onChange={(e) => {
                setMaterial(e.target.value as Material);
                setResult(null);
              }}
            >
              <option value="copper">Copper</option>
              <option value="aluminum">Aluminum</option>
            </select>
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-system">
              Size system
            </label>
            <select
              id="cs-system"
              className={field}
              value={sizeSystem}
              onChange={(e) => {
                setSizeSystem(e.target.value as SizeSystem);
                setResult(null);
              }}
            >
              <option value="metric">Metric (mm²)</option>
              <option value="awg">AWG / kcmil</option>
            </select>
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-parallel">
              Conductors per phase
            </label>
            <select
              id="cs-parallel"
              className={field}
              value={form.conductorsPerPhase}
              onChange={(e) => set("conductorsPerPhase", e.target.value)}
            >
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={String(n)}>
                  {n}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-ccc">
              Current-carrying conductors (CCC)
            </label>
            <input
              id="cs-ccc"
              className={field}
              inputMode="numeric"
              type="number"
              step="1"
              value={form.ccc}
              aria-invalid={Boolean(errors.ccc)}
              onChange={(e) => set("ccc", e.target.value)}
            />
            {submitted && errors.ccc ? <p className={errorCls}>{errors.ccc}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-ambient">
              Ambient temperature (°C)
            </label>
            <input
              id="cs-ambient"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.ambientTempC}
              aria-invalid={Boolean(errors.ambientTempC)}
              onChange={(e) => set("ambientTempC", e.target.value)}
            />
            {submitted && errors.ambientTempC ? <p className={errorCls}>{errors.ambientTempC}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-ktemp">
              Temperature correction factor
            </label>
            <input
              id="cs-ktemp"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.01"
              value={form.tempCorrectionFactor}
              aria-invalid={Boolean(errors.tempCorrectionFactor)}
              onChange={(e) => set("tempCorrectionFactor", e.target.value)}
            />
            <p className={hintCls}>From your applicable standard for the ambient temperature above. Use 1.00 if none applies.</p>
            {submitted && errors.tempCorrectionFactor ? (
              <p className={errorCls}>{errors.tempCorrectionFactor}</p>
            ) : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-kgroup">
              Grouping adjustment factor
            </label>
            <input
              id="cs-kgroup"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.01"
              value={form.groupingFactor}
              aria-invalid={Boolean(errors.groupingFactor)}
              onChange={(e) => set("groupingFactor", e.target.value)}
            />
            <p className={hintCls}>From your applicable standard for the CCC count above. Use 1.00 if none applies.</p>
            {submitted && errors.groupingFactor ? <p className={errorCls}>{errors.groupingFactor}</p> : null}
          </div>

          {isAc ? (
            <div>
              <label className={labelCls} htmlFor="cs-pf">
                Power factor
              </label>
              <input
                id="cs-pf"
                className={field}
                inputMode="decimal"
                type="number"
                step="0.01"
                min="0.01"
                max="1"
                value={form.powerFactor}
                aria-invalid={Boolean(errors.powerFactor)}
                onChange={(e) => set("powerFactor", e.target.value)}
              />
              {submitted && errors.powerFactor ? <p className={errorCls}>{errors.powerFactor}</p> : null}
            </div>
          ) : null}

          <div>
            <label className={labelCls} htmlFor="cs-limit">
              Design voltage drop limit (%)
            </label>
            <input
              id="cs-limit"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.1"
              value={form.limitPercent}
              aria-invalid={Boolean(errors.limitPercent)}
              onChange={(e) => set("limitPercent", e.target.value)}
            />
            {submitted && errors.limitPercent ? <p className={errorCls}>{errors.limitPercent}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="cs-ampacity">
              Base allowable current (A) — optional
            </label>
            <input
              id="cs-ampacity"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              placeholder="From your ampacity table"
              value={form.baseAmpacity}
              aria-invalid={Boolean(errors.baseAmpacity)}
              onChange={(e) => set("baseAmpacity", e.target.value)}
            />
            <p className={hintCls}>Leave blank to skip the thermal check — OHMICLY has no verified ampacity table.</p>
            {submitted && errors.baseAmpacity ? <p className={errorCls}>{errors.baseAmpacity}</p> : null}
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button
            id="cs-submit"
            type="submit"
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 sm:flex-none sm:px-6"
          >
            Select cable size
          </button>
          <button
            type="button"
            onClick={reset}
            className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-lg border border-border bg-surface px-5 text-sm font-semibold text-muted-foreground transition-colors hover:border-electric/40"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            Reset
          </button>
        </div>
        <StickyCalculateBar formId="cs-form" anchorId="cs-submit" label="Calculate cable size" />
      </form>

      <div aria-live="polite" className="mt-5 min-w-0 space-y-5">
        {result ? (
          <CableResultCard
            result={result}
            current={Number(form.current)}
            limit={Number(form.limitPercent)}
            inputs={{ ...form, phase, material, sizeSystem }}
            references={references}
          />
        ) : null}
        {referenceContent}
      </div>
    </section>
  );
}

const PHASE_LABEL: Record<PhaseMode, string> = {
  dc: "DC",
  single: "AC — Single phase",
  three: "AC — Three phase",
};

function CableResultCard({
  result,
  current,
  limit,
  inputs,
  references,
}: {
  result: CableSizeResult;
  current: number;
  limit: number;
  inputs: typeof DEFAULTS & { phase: PhaseMode; material: Material; sizeSystem: SizeSystem };
  references: ReportReference[];
}) {
  const ok = Boolean(result.recommended);
  const fmt = (n: number, d = 2) =>
    n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
  const shortlist = result.candidates.slice(0, 12);
  const isAc = inputs.phase !== "dc";

  const buildSpec = (preparedFor: string): ReportSpec => ({
    title: "Cable Size Selection",
    code: "CS",
    path: "/calculator/cable-size-calculator",
    ...(preparedFor.trim() ? { preparedFor: preparedFor.trim() } : {}),
    status: ok
      ? { label: `Size found — within ${fmt(limit, 1)}% drop limit`, tone: "pass" as const }
      : { label: "No listed size meets the drop limit", tone: "fail" as const },
    headline: ok
      ? `${result.recommended!.size.label} — ${fmt(result.recommended!.dropPercent)} % drop (within limit)`
      : "No listed conductor size satisfies the entered voltage drop limit",
    inputs: [
      { label: "Current type & phase", value: PHASE_LABEL[inputs.phase] },
      { label: "Load current", value: `${inputs.current} A` },
      { label: "System voltage", value: `${inputs.voltage} V` },
      { label: "One-way distance", value: `${inputs.distanceFt} ft (${fmt(result.lengthM, 1)} m)` },
      { label: "Conductor material", value: inputs.material === "copper" ? "Copper" : "Aluminum" },
      { label: "Size system", value: inputs.sizeSystem === "metric" ? "Metric (mm²)" : "AWG / kcmil" },
      { label: "Conductors per phase", value: inputs.conductorsPerPhase },
      { label: "Current-carrying conductors (CCC)", value: inputs.ccc },
      { label: "Ambient temperature", value: `${inputs.ambientTempC} °C` },
      { label: "Temperature correction factor (user-entered)", value: inputs.tempCorrectionFactor },
      { label: "Grouping adjustment factor (user-entered)", value: inputs.groupingFactor },
      ...(isAc ? [{ label: "Power factor (cos φ)", value: inputs.powerFactor }] : []),
      { label: "Design voltage drop limit", value: `${inputs.limitPercent} %` },
      ...(inputs.baseAmpacity.trim()
        ? [{ label: "Base allowable current (user-entered)", value: `${inputs.baseAmpacity} A` }]
        : []),
    ],
    results: [
      {
        label: "Recommended size (voltage drop criterion)",
        value: result.recommended ? result.recommended.size.label : "—",
        tone: ok ? ("pass" as const) : ("fail" as const),
      },
      {
        label: "Voltage drop at that size",
        value: result.recommended ? `${fmt(result.recommended.dropPercent)} % (${fmt(result.recommended.dropVolts)} V)` : "—",
        tone: ok ? ("pass" as const) : ("fail" as const),
      },
      {
        label: "Receiving-end voltage at that size",
        value: result.recommended ? `${fmt(result.recommended.receivingVoltage)} V` : "—",
      },
      { label: "Design current after factors", value: `${fmt(result.designCurrent, 1)} A` },
      { label: "Circuit length (one-way)", value: `${fmt(result.lengthM, 1)} m` },
      result.thermal.status === "checked"
        ? {
            label: "Ampacity check (on your entered allowable current)",
            value: `${fmt(result.thermal.deratedAmpacity, 1)} A derated — ${result.thermal.adequate ? "adequate" : "not adequate"}`,
            tone: result.thermal.adequate ? ("pass" as const) : ("fail" as const),
          }
        : { label: "Ampacity check", value: "Not performed", tone: "info" as const },
    ],
    steps: [
      {
        label: "Design current after user-entered factors: Idesign = I ÷ (k_temp × k_group)",
        expression: `Idesign = ${fmt(current, 1)} ÷ (${fmt(result.appliedFactors[0]!.value, 2)} × ${fmt(result.appliedFactors[1]!.value, 2)}) = ${fmt(result.designCurrent, 1)} A`,
      },
      {
        label: "Voltage drop check per candidate size (same model as the Voltage Drop Calculator)",
        expression:
          inputs.phase === "three"
            ? "Vdrop = √3 × I × (R·cos φ + X·sin φ); R = ρ × L ÷ (A × n)"
            : inputs.phase === "single"
              ? "Vdrop = 2 × I × (R·cos φ + X·sin φ); R = ρ × L ÷ (A × n)"
              : "Vdrop = 2 × I × R; R = ρ × L ÷ (A × n)",
      },
      ...(result.recommended
        ? [
            {
              label: "Smallest listed size passing the limit",
              expression: `${result.recommended.size.label}: ${fmt(result.recommended.dropPercent)} % ≤ ${fmt(limit, 1)} % limit`,
            },
          ]
        : []),
    ],
    comparison: {
      title: "Size comparison (voltage drop criterion)",
      head: ["Size", "Drop (V)", "Drop (%)", "Meets limit"],
      rows: shortlist.map((c) => ({
        cells: [c.size.label, fmt(c.dropVolts), fmt(c.dropPercent), c.meetsVoltageDrop ? "PASS" : "FAIL"],
        tone: c.meetsVoltageDrop ? ("pass" as const) : ("fail" as const),
      })),
    },
    notes: [
      "This v1 recommendation is based on voltage drop only. Final conductor selection must also consider ampacity, installation conditions, correction/adjustment factors, short-circuit withstand and overcurrent protection.",
      "Correction and adjustment factors, and any allowable current, are values you entered from the standard applicable to your project — nothing is assumed by OHMICLY.",
      ...(result.thermal.status === "unavailable" ? [result.thermal.reason] : []),
    ],
    references,
  });


  return (
    <div className="min-w-0 overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div
        className={
          "flex items-start gap-2 border-b px-5 py-3 text-sm font-semibold " +
          (ok
            ? "border-free/25 bg-free/8 text-free"
            : "border-amber-accent/30 bg-gold-soft/60 text-amber-accent-foreground")
        }
      >
        {ok ? (
          <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0" aria-hidden="true" />
        ) : (
          <AlertTriangle className="mt-0.5 h-4.5 w-4.5 shrink-0" aria-hidden="true" />
        )}
        <div className="leading-snug">
          <span className="block">Voltage-drop-based conductor recommendation</span>
          <span className="block font-normal opacity-90">
            {ok ? `Smallest listed size meeting a ${fmt(limit, 1)}% drop limit` : result.warning}
          </span>
        </div>
      </div>

      <div className="flex items-start gap-2 border-b border-gold/25 bg-gold-soft/40 px-5 py-3 text-[13px] leading-relaxed text-amber-accent-foreground">
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
        <p>
          <strong>This v1 recommendation is based on voltage drop only.</strong> Final conductor selection must
          also consider ampacity, installation conditions, correction/adjustment factors, short-circuit
          withstand, and overcurrent protection.
        </p>
      </div>

      <dl className="grid grid-cols-1 divide-y divide-border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Recommended size
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-electric">
            {result.recommended ? result.recommended.size.label : "—"}
          </dd>
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Voltage drop at that size
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">
            {result.recommended ? `${fmt(result.recommended.dropPercent)} %` : "—"}
          </dd>
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Design current after factors
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">
            {fmt(result.designCurrent, 1)} A
          </dd>
        </div>
      </dl>

      <div className="border-t border-border px-5 py-4">
        <h3 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          Applied derating factors
        </h3>
        <ul className="mt-2 space-y-1.5 text-[13px] leading-relaxed text-muted-foreground">
          {result.appliedFactors.map((f) => (
            <li key={f.label}>
              <span className="font-semibold text-foreground">{f.label}:</span> {fmt(f.value, 2)} —{" "}
              {f.source}
            </li>
          ))}
          <li>
            <span className="font-semibold text-foreground">Design current:</span> {fmt(current, 1)} A ÷ (
            {fmt(result.appliedFactors[0]!.value, 2)} × {fmt(result.appliedFactors[1]!.value, 2)}) ={" "}
            {fmt(result.designCurrent, 1)} A
          </li>
        </ul>
      </div>

      <div className="border-t border-border px-5 py-4">
        <h3 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          Ampacity / allowable current
        </h3>
        {result.thermal.status === "checked" ? (
          <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
            Derated allowable current{" "}
            <span className="font-semibold text-foreground">{fmt(result.thermal.deratedAmpacity, 1)} A</span>{" "}
            against a load of {fmt(current, 1)} A —{" "}
            {result.thermal.adequate ? "adequate on the value you entered." : "not adequate; select a larger size or more conductors per phase."}
          </p>
        ) : (
          <div className="mt-2 flex items-start gap-2 rounded-lg border border-gold/35 bg-gold-soft px-3 py-2.5 text-[13px] leading-relaxed text-amber-accent-foreground">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
            <p>{result.thermal.reason}</p>
          </div>
        )}
      </div>

      <div className="border-t border-border">
        <h3 className="px-5 pt-4 text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          Calculation summary
        </h3>
        <div className="max-w-full overflow-x-auto px-4 pb-4 sm:px-5">
          <table className="mt-2 w-full min-w-[32rem] text-left text-[13px]">
            <thead>
              <tr className="text-muted-foreground">
                <th scope="col" className="py-2 pr-3 font-semibold">Size</th>
                <th scope="col" className="py-2 pr-3 font-semibold">Drop (V)</th>
                <th scope="col" className="py-2 pr-3 font-semibold">Drop (%)</th>
                <th scope="col" className="py-2 font-semibold">Meets limit</th>
              </tr>
            </thead>
            <tbody className="text-muted-foreground">
              {shortlist.map((c) => (
                <tr
                  key={c.size.id}
                  className={
                    "border-t border-border " +
                    (result.recommended?.size.id === c.size.id ? "font-semibold text-foreground" : "")
                  }
                >
                  <td className="py-2 pr-3 whitespace-nowrap">{c.size.label}</td>
                  <td className="py-2 pr-3">{fmt(c.dropVolts)}</td>
                  <td className="py-2 pr-3">{fmt(c.dropPercent)}</td>
                  <td className="py-2">{c.meetsVoltageDrop ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="border-t border-border bg-surface px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        Circuit length {fmt(result.lengthM, 1)} m one-way. Sizes are compared on the voltage drop criterion
        only; the thermal, short-circuit withstand and protective-device coordination checks remain the
        designer&apos;s responsibility.
      </div>
      <PdfReportButton idPrefix="cs" buildSpec={buildSpec} />
    </div>
  );
}