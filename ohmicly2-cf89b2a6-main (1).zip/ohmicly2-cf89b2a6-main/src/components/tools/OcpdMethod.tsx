import { MethodDisclosure } from "./MethodDisclosure";
const rowCls = "border-t border-border py-3 first:border-0 first:pt-0";

/**
 * Documents how the OCPD Calculator computes its result and what it
 * deliberately does not do. No code rule or rating table is implied.
 */
export function OcpdMethod() {
  return (
    <MethodDisclosure id="method" headingId="ocpd-method-heading" title="Method, formulas and limitations">

      <div className="rounded-xl border border-border bg-card p-5 shadow-card">
        <h3 className="text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">Formulas used</h3>
        <dl className="mt-2 text-sm leading-relaxed text-muted-foreground">
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Required protection current</dt>
            <dd className="mt-1">
              I<sub>protection</sub> = I<sub>design</sub> × factor, where the factor is applied only when you
              explicitly enter one. With no factor entered, the required protection current equals the design
              current you supplied.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Maximum allowable rating comparison</dt>
            <dd className="mt-1">
              When you enter a maximum allowable protection rating, the tool reports whether the required
              protection current is at or below that value. It is a numeric comparison against your own input,
              not a compliance determination.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Standard rating selection</dt>
            <dd className="mt-1">
              A standard device rating is returned only when a verified standard-rating series exists in
              OHMICLY&apos;s engineering data. No such series is loaded in this version, so the tool reports
              standard selection as unavailable rather than proposing a breaker or fuse size.
            </dd>
          </div>
        </dl>

        <h3 className="mt-5 text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          What this version does not model
        </h3>
        <ul className="mt-2 space-y-2 text-sm leading-relaxed text-muted-foreground">
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Code multipliers:</span> continuous-load
            multipliers, motor-circuit protection limits and next-standard-size allowances are not applied.
          </li>
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Conductor coordination:</span> the tool does not
            check the device against conductor ampacity, because no verified ampacity table is loaded.
          </li>
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Short-circuit performance:</span> interrupting
            rating, let-through energy and selectivity with upstream devices are outside the scope of v1.
          </li>
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Device characteristics:</span> trip curves,
            adjustable settings, thermal-magnetic versus electronic behaviour and manufacturer derating are not
            modelled.
          </li>
        </ul>
      </div>
    </MethodDisclosure>
  );
}
