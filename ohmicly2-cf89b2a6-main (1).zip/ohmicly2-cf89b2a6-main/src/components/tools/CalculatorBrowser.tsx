import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Calculator,
  Gauge,
  Search,
  SlidersHorizontal,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui-kit/Icon";
import { cn } from "@/lib/utils";
import type { CalculatorDef } from "@/lib/content/types";
import { thumbVariant } from "@/lib/images/process";

const PAGE_SIZE = 8;

export type CalculatorSearch = { q: string; category: string; page: number; sort: string };

const titleCase = (value: string) =>
  value
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");

const highlights = [
  { title: "7+ Calculators", detail: "Essential electrical design tools", icon: Calculator, tone: "bg-primary/10 text-primary" },
  { title: "Accurate Result", detail: "Transparent, documented methods", icon: BadgeCheck, tone: "bg-free/10 text-free" },
  { title: "Engineering Focus", detail: "Built for practical project work", icon: Gauge, tone: "bg-electric/10 text-electric" },
  { title: "Free to Use", detail: "No registration required", icon: Zap, tone: "bg-gold/10 text-gold" },
] as const;

function CalculatorCardItem({ item }: { item: CalculatorDef }) {
  const tags = item.keywords.slice(0, 3);
  return (
    <article className="group flex h-full flex-col rounded-xl border border-border bg-card p-5 shadow-card transition-all hover:-translate-y-0.5 hover:border-electric/40 hover:shadow-card-hover">
      <div className="flex items-start justify-between gap-3">
        {item.thumbnail_url ? (
          <span className="inline-flex h-12 w-12 items-center justify-center overflow-hidden rounded-lg border border-electric/15 bg-accent">
            <img src={thumbVariant(item.thumbnail_url)} alt="" loading="lazy" decoding="async" width={96} height={96} className="h-full w-full object-cover" />
          </span>
        ) : (
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-lg border border-electric/15 bg-accent text-electric">
            <Icon name={item.icon} className="h-6 w-6" />
          </span>
        )}
        <span className={cn(
          "rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em]",
          item.status === "available"
            ? "bg-primary text-primary-foreground"
            : "border border-border bg-surface text-muted-foreground",
        )}>
          {item.status === "available" ? "Live" : "Soon"}
        </span>
      </div>
      <h2 className="mt-4 text-[15px] font-bold leading-snug text-foreground">{item.name}</h2>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
      {tags.length ? (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {tags.map((tag) => (
            <span key={tag} className="rounded-md bg-surface px-2 py-1 text-[11px] font-medium text-muted-foreground">
              {tag}
            </span>
          ))}
        </div>
      ) : null}
      <Link
        to="/calculator/$slug"
        params={{ slug: item.slug }}
        className="mt-4 inline-flex items-center gap-1.5 border-t border-border pt-3.5 text-sm font-semibold text-electric"
      >
        Open Calculator
        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
      </Link>
    </article>
  );
}

export function CalculatorBrowser({
  calculators,
  q,
  category,
  page,
  sort,
}: {
  calculators: CalculatorDef[];
} & CalculatorSearch) {
  const navigate = useNavigate({ from: "/calculator/" });
  const [query, setQuery] = useState(q);
  const [panelOpen, setPanelOpen] = useState(false);

  useEffect(() => setQuery(q), [q]);

  const categories = useMemo(() => {
    const counts = new Map<string, number>();
    calculators.forEach((item) => counts.set(item.category, (counts.get(item.category) ?? 0) + 1));
    return [...counts.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [calculators]);

  const filtered = calculators.filter((item) => {
    const matchesCategory = !category || item.category === category;
    const haystack = `${item.name} ${item.description} ${item.keywords.join(" ")}`.toLowerCase();
    return matchesCategory && (!q || haystack.includes(q.toLowerCase()));
  });

  if (sort === "name") filtered.sort((a, b) => a.name.localeCompare(b.name));
  else if (sort === "available") filtered.sort((a, b) => Number(b.status === "available") - Number(a.status === "available"));
  else filtered.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(page, 1), totalPages);
  const visible = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const activeFilterCount = Number(Boolean(category)) + Number(sort !== "category");

  const search = (next: Partial<CalculatorSearch>): CalculatorSearch => ({
    q,
    category,
    page: safePage,
    sort,
    ...next,
  });

  const update = (next: Partial<CalculatorSearch>) => {
    void navigate({ search: search({ ...next, page: 1 }), resetScroll: false });
  };

  return (
    <div className="bg-surface">
      <div className="container-page py-8 sm:py-10">
        <div className="min-w-0">
          <h1 className="text-[1.85rem] font-extrabold leading-[1.1] text-primary sm:text-4xl">
            Electrical Calculators
          </h1>
          <p className="mt-2 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            Accurate, practical tools for electrical design, analysis and everyday engineering checks.
          </p>

          <div className="mt-6 flex snap-x snap-mandatory gap-2.5 overflow-x-auto overscroll-x-contain pb-2" aria-label="Calculator benefits">
            {highlights.map(({ title, detail, icon: HighlightIcon, tone }) => (
              <article key={title} className="flex h-[5.25rem] min-w-[10rem] flex-1 shrink-0 snap-start items-center gap-3 rounded-xl border border-border bg-card px-3.5 shadow-card sm:min-w-[11rem]">
                <span className={cn("inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg", tone)}>
                  <HighlightIcon className="h-[1.125rem] w-[1.125rem]" aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <strong className="block text-xs font-bold leading-tight text-foreground">{title}</strong>
                  <span className="mt-1 block text-[11px] leading-tight text-muted-foreground">{detail}</span>
                </span>
              </article>
            ))}
          </div>

          <div className="relative mt-5 rounded-xl border border-border bg-card p-2.5 shadow-card">
            <div className="flex min-w-0 items-center gap-2">
              <form
                role="search"
                className="flex h-11 min-w-0 flex-1 items-center rounded-lg border border-border bg-surface focus-within:border-ring focus-within:ring-2 focus-within:ring-ring/15"
                onSubmit={(event) => {
                  event.preventDefault();
                  update({ q: query.trim() });
                }}
              >
                <Search className="ml-3 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search calculators..."
                  aria-label="Search calculators"
                  className="min-w-0 flex-1 bg-transparent px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground"
                />
                <Button type="submit" size="sm" className="mr-1 h-9 px-3">Search</Button>
              </form>
              <Button
                type="button"
                variant="outline"
                size="icon"
                aria-label="Filter and sort calculators"
                aria-expanded={panelOpen}
                onClick={() => setPanelOpen((open) => !open)}
                className={cn(
                  "relative h-11 w-11 shrink-0 rounded-lg shadow-none",
                  panelOpen || activeFilterCount ? "border-electric bg-accent text-electric" : "border-border bg-card text-foreground",
                )}
              >
                <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
                {activeFilterCount ? (
                  <span className="absolute -right-1 -top-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                    {activeFilterCount}
                  </span>
                ) : null}
              </Button>
            </div>

            {panelOpen ? (
              <div className="absolute left-2.5 right-2.5 top-[calc(100%+0.5rem)] z-30 rounded-lg border border-border bg-card p-4 shadow-card-hover sm:left-auto sm:w-[30rem]">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-sm font-bold text-foreground">Filter & sort</p>
                  <Button type="button" variant="ghost" size="icon" aria-label="Close filter and sort" onClick={() => setPanelOpen(false)} className="h-8 w-8">
                    <X className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </div>
                <div className="mt-3">
                  <p className="text-xs font-bold uppercase text-muted-foreground">Category</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button type="button" size="sm" variant={!category ? "default" : "outline"} onClick={() => update({ category: "" })}>All</Button>
                    {categories.map(([slug, count]) => (
                      <Button key={slug} type="button" size="sm" variant={category === slug ? "default" : "outline"} onClick={() => update({ category: slug })}>
                        {titleCase(slug)} <span className="opacity-65">{count}</span>
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="mt-4 border-t border-border pt-4">
                  <p className="text-xs font-bold uppercase text-muted-foreground">Sort by</p>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {[
                      { value: "category", label: "Category" },
                      { value: "name", label: "Name A–Z" },
                      { value: "available", label: "Live first" },
                    ].map((option) => (
                      <Button key={option.value} type="button" size="sm" variant={sort === option.value ? "default" : "outline"} onClick={() => update({ sort: option.value })}>
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {visible.map((item) => <CalculatorCardItem key={item.slug} item={item} />)}
          </div>

          {filtered.length === 0 ? (
            <p className="mt-10 rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
              No calculators match your search. Try another keyword or category.
            </p>
          ) : null}

          {totalPages > 1 ? (
            <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
              <nav aria-label="Pagination" className="flex flex-wrap items-center gap-1.5">
                <Link to="/calculator" search={search({ page: Math.max(1, safePage - 1) })} aria-label="Previous page" className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground">
                  <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                </Link>
                {Array.from({ length: totalPages }, (_, index) => index + 1).map((number) => (
                  <Link key={number} to="/calculator" search={search({ page: number })} aria-current={number === safePage ? "page" : undefined} className={cn(
                    "inline-flex h-11 min-w-11 items-center justify-center rounded-lg border px-3 text-sm font-semibold",
                    number === safePage ? "border-electric bg-electric text-electric-foreground" : "border-border bg-card text-muted-foreground",
                  )}>
                    {number}
                  </Link>
                ))}
                <Link to="/calculator" search={search({ page: Math.min(totalPages, safePage + 1) })} aria-label="Next page" className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground">
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </nav>
              <p className="text-sm text-muted-foreground">
                Showing {(safePage - 1) * PAGE_SIZE + 1} to {Math.min(safePage * PAGE_SIZE, filtered.length)} of {filtered.length} calculators
              </p>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}