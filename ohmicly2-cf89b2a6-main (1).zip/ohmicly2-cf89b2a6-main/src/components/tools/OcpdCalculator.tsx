import { useState, type ReactNode } from "react";
import { AlertTriangle, Info, RotateCcw } from "lucide-react";
import {
  calculateOcpd,
  validateOcpd,
  type OcpdApplication,
  type OcpdResult,
} from "@/lib/calculators/ocpd";
import type { ReportSpec } from "@/lib/pdf/calculator-report";

import { PdfReportButton } from "./PdfReportButton";

type ReportReference = ReportSpec["references"][number];

import { StickyCalculateBar } from "./StickyCalculateBar";

const field =
  "mt-1.5 block w-full rounded-lg border border-border bg-card px-3 py-2.5 text-[15px] text-foreground shadow-sm outline-none transition-colors focus:border-electric focus:ring-2 focus:ring-electric/25 min-h-11";
const labelCls = "block text-sm font-semibold text-foreground";
const hintCls = "mt-1 text-[13px] leading-relaxed text-muted-foreground";
const errorCls = "mt-1 text-[13px] font-medium text-destructive";

const DEFAULTS = { designCurrentA: "48", continuousFactor: "", maxRatingA: "" };

const applications: { id: OcpdApplication; label: string; hint: string }[] = [
  { id: "general", label: "General circuit", hint: "Non-continuous load" },
  { id: "continuous", label: "Continuous load", hint: "Factor entered by you" },
  { id: "motor", label: "Motor circuit", hint: "Code rules not applied" },
  { id: "other", label: "Other / unspecified", hint: "Manual review" },
];

export function OcpdCalculator({
  references = [],
  referenceContent,
}: {
  references?: ReportReference[];
  referenceContent?: ReactNode;
}) {
  const [application, setApplication] = useState<OcpdApplication>("general");
  const [form, setForm] = useState({ ...DEFAULTS });
  const [errors, setErrors] = useState<ReturnType<typeof validateOcpd>>({});
  const [result, setResult] = useState<OcpdResult | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const set = (key: keyof typeof DEFAULTS, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setResult(null);
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    const found = validateOcpd(form);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      setResult(null);
      return;
    }
    setResult(
      calculateOcpd({
        application,
        designCurrentA: Number(form.designCurrentA),
        ...(form.continuousFactor.trim() !== "" ? { continuousFactor: Number(form.continuousFactor) } : {}),
        ...(form.maxRatingA.trim() !== "" ? { maxRatingA: Number(form.maxRatingA) } : {}),
      }),
    );
  };

  const reset = () => {
    setForm({ ...DEFAULTS });
    setApplication("general");
    setErrors({});
    setResult(null);
    setSubmitted(false);
  };

  return (
    <section aria-labelledby="calc-heading" className="min-w-0 scroll-mt-24" id="calculator">
      <h2 id="calc-heading" className="text-xl font-bold text-primary sm:text-2xl">
        Protection current calculation
      </h2>

      <form id="ocpd-form" onSubmit={onSubmit} noValidate className="mt-4 min-w-0 rounded-xl border border-border bg-card p-4 shadow-card sm:p-5">
        <fieldset className="border-0 p-0">
          <legend className={labelCls}>Equipment / application type</legend>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {applications.map((opt) => (
              <button
                key={opt.id}
                type="button"
                aria-pressed={application === opt.id}
                onClick={() => {
                  setApplication(opt.id);
                  setResult(null);
                }}
                className={
                  "flex min-h-11 flex-col items-start justify-center rounded-lg border px-3 py-2 text-left transition-colors " +
                  (application === opt.id
                    ? "border-electric bg-accent text-electric"
                    : "border-border bg-surface text-muted-foreground hover:border-electric/40")
                }
              >
                <span className="text-sm font-semibold">{opt.label}</span>
                <span className="text-[12px] opacity-80">{opt.hint}</span>
              </button>
            ))}
          </div>
          <p className={hintCls}>
            The application type is recorded with the result for your documentation. No code rule is applied
            automatically for any option.
          </p>
        </fieldset>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className={labelCls} htmlFor="ocpd-current">
              Calculated / design current (A)
            </label>
            <input
              id="ocpd-current"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.designCurrentA}
              aria-invalid={Boolean(errors.designCurrentA)}
              onChange={(e) => set("designCurrentA", e.target.value)}
            />
            <p className={hintCls}>Use the load current from your load or cable calculation.</p>
            {submitted && errors.designCurrentA ? <p className={errorCls}>{errors.designCurrentA}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="ocpd-factor">
              Continuous-load factor (optional)
            </label>
            <input
              id="ocpd-factor"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.01"
              min="1"
              max="5"
              placeholder="e.g. 1.25 if your code requires it"
              value={form.continuousFactor}
              aria-invalid={Boolean(errors.continuousFactor)}
              onChange={(e) => set("continuousFactor", e.target.value)}
            />
            <p className={hintCls}>
              Leave blank unless your applicable standard supplies one. OHMICLY never applies a factor
              automatically.
            </p>
            {submitted && errors.continuousFactor ? <p className={errorCls}>{errors.continuousFactor}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="ocpd-max">
              Maximum allowable protection rating (A, optional)
            </label>
            <input
              id="ocpd-max"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              min="0"
              placeholder="e.g. conductor or equipment limit"
              value={form.maxRatingA}
              aria-invalid={Boolean(errors.maxRatingA)}
              onChange={(e) => set("maxRatingA", e.target.value)}
            />
            <p className={hintCls}>Entered by you from conductor ampacity or equipment data.</p>
            {submitted && errors.maxRatingA ? <p className={errorCls}>{errors.maxRatingA}</p> : null}
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button
            id="ocpd-submit"
            type="submit"
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 sm:flex-none sm:px-6"
          >
            Calculate protection current
          </button>
          <button
            type="button"
            onClick={reset}
            className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-lg border border-border bg-surface px-5 text-sm font-semibold text-muted-foreground transition-colors hover:border-electric/40"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            Reset
          </button>
        </div>
        <StickyCalculateBar formId="ocpd-form" anchorId="ocpd-submit" label="Calculate protection current" />
      </form>

      <div aria-live="polite" className="mt-5 min-w-0 space-y-5">
        {result ? <ResultCard result={result} references={references} /> : null}
        {referenceContent}
      </div>
    </section>
  );
}

const APPLICATION_LABEL: Record<OcpdApplication, string> = {
  general: "General circuit",
  continuous: "Continuous load",
  motor: "Motor circuit",
  other: "Other / unspecified",
};

function ResultCard({ result, references }: { result: OcpdResult; references: ReportReference[] }) {
  const fmt = (n: number, d = 2) =>
    n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

  const withinMax = result.maxRatingA !== undefined ? !result.exceedsMaxRating : null;
  const buildSpec = (preparedFor: string): ReportSpec => ({
    title: "Overcurrent Protection (OCPD) Calculation",
    code: "OCPD",
    path: "/calculator/ocpd-calculator",
    ...(preparedFor.trim() ? { preparedFor: preparedFor.trim() } : {}),
    status:
      withinMax === null
        ? { label: "Calculation complete — no maximum rating entered", tone: "info" as const }
        : withinMax
          ? { label: "At or below your entered maximum rating", tone: "pass" as const }
          : { label: "Above your entered maximum rating", tone: "fail" as const },
    headline: `${fmt(result.requiredProtectionCurrentA, 1)} A required protection current`,
    inputs: [
      { label: "Application", value: APPLICATION_LABEL[result.application] },
      { label: "Design current", value: `${fmt(result.designCurrentA)} A` },
      {
        label: "Multiplying factor (user-entered)",
        value: result.continuousFactor !== undefined ? fmt(result.continuousFactor, 2) : "None entered",
      },
      {
        label: "Maximum allowable rating (user-entered)",
        value: result.maxRatingA !== undefined ? `${fmt(result.maxRatingA, 1)} A` : "None entered",
      },
    ],
    results: [
      {
        label: "Required protection current",
        value: `${fmt(result.requiredProtectionCurrentA, 1)} A`,
        tone: "info" as const,
      },
      ...(result.maxRatingA !== undefined
        ? [
            {
              label: "Comparison with your maximum allowable rating",
              value: result.exceedsMaxRating ? "Exceeds your maximum" : "At or below your maximum",
              tone: result.exceedsMaxRating ? ("fail" as const) : ("pass" as const),
            },
          ]
        : []),
      {
        label: "Standard device rating selection",
        value: result.standardRating
          ? `${result.standardRating.ratingA} A`
          : "Unavailable — no verified standard-rating series is loaded",
        tone: "info" as const,
      },
    ],
    steps: [
      {
        label: "Required protection current = design current × your factor",
        expression:
          result.continuousFactor !== undefined
            ? `Iprotection = ${fmt(result.designCurrentA)} × ${fmt(result.continuousFactor, 2)} = ${fmt(result.requiredProtectionCurrentA, 1)} A`
            : `Iprotection = ${fmt(result.designCurrentA)} A (no factor entered)`,
      },
      ...(result.maxRatingA !== undefined
        ? [
            {
              label: "Comparison against your entered maximum rating",
              expression: `${fmt(result.requiredProtectionCurrentA, 1)} A ${result.exceedsMaxRating ? ">" : "≤"} ${fmt(result.maxRatingA, 1)} A`,
            },
          ]
        : []),
    ],
    notes: [
      "No code multiplier, next-standard-size allowance or motor-circuit rule is applied; any factor used is the value you entered.",
      ...(result.standardRatingUnavailableReason ? [result.standardRatingUnavailableReason] : []),
      "Final OCPD selection depends on the applicable code, equipment characteristics, conductor ampacity, short-circuit and interrupting ratings, coordination with upstream devices, and manufacturer requirements.",
    ],
    references,
  });

  return (
    <div className="min-w-0 overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex items-start gap-2 border-b border-electric/25 bg-accent px-5 py-3 text-sm font-semibold text-foreground">
        <Info className="mt-0.5 h-4.5 w-4.5 shrink-0 text-electric" aria-hidden="true" />
        <div className="leading-snug">
          <span className="block">Calculated protection current</span>
          <span className="block font-normal opacity-90">{APPLICATION_LABEL[result.application]}</span>
        </div>
      </div>

      <dl className="grid grid-cols-1 divide-y divide-border sm:grid-cols-2 sm:divide-x sm:divide-y-0">
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Design current
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">
            {fmt(result.designCurrentA)} A
          </dd>
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Required protection current
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-electric">
            {fmt(result.requiredProtectionCurrentA)} A
          </dd>
          {result.continuousFactor !== undefined ? (
            <p className="mt-1 text-[13px] text-muted-foreground">
              {fmt(result.designCurrentA)} A × {fmt(result.continuousFactor, 2)} (your factor)
            </p>
          ) : (
            <p className="mt-1 text-[13px] text-muted-foreground">No factor entered — equals design current.</p>
          )}
        </div>
      </dl>

      <div className="border-t border-border bg-surface px-5 py-4">
        <h3 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
          Standard OCPD rating
        </h3>
        {result.standardRating ? (
          <p className="mt-1 text-lg font-bold text-primary">
            {fmt(result.standardRating.ratingA, 0)} A
            <span className="ml-2 text-[13px] font-normal text-muted-foreground">
              {result.standardRating.series} — {result.standardRating.source}
            </span>
          </p>
        ) : (
          <div className="mt-2 flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-[13px] leading-relaxed text-foreground">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" aria-hidden="true" />
            <p>
              <span className="font-semibold">Automatic standard rating unavailable.</span>{" "}
              {result.standardRatingUnavailableReason} Select the device rating from your applicable code and
              the manufacturer&apos;s data, using the calculated protection current above as the minimum
              requirement.
            </p>
          </div>
        )}
      </div>

      {result.maxRatingA !== undefined ? (
        <div className="border-t border-border px-5 py-4">
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Your maximum allowable rating
          </h3>
          <p className="mt-1 text-sm font-semibold text-foreground">{fmt(result.maxRatingA)} A</p>
          {result.exceedsMaxRating ? (
            <div className="mt-2 flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-[13px] leading-relaxed text-foreground">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden="true" />
              <p>
                The required protection current exceeds the maximum rating you entered. Review the conductor
                size, equipment limits or load assumptions before selecting a device.
              </p>
            </div>
          ) : (
            <p className="mt-1 text-[13px] text-muted-foreground">
              The required protection current is within the maximum you entered. This is a numeric comparison
              only, not a code compliance check.
            </p>
          )}
        </div>
      ) : null}

      <div className="border-t border-border px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">Calculation basis:</span> required protection current ={" "}
        {result.continuousFactor !== undefined
          ? `design current × your factor = ${fmt(result.designCurrentA)} × ${fmt(result.continuousFactor, 2)}`
          : `design current = ${fmt(result.designCurrentA)} A`}
        . No code multiplier, next-standard-size allowance or motor rule is applied.
      </div>

      <div className="border-t border-border px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">Engineering note:</span> final OCPD selection depends on
        the applicable code, equipment characteristics, conductor ampacity, continuous-load requirements,
        short-circuit and interrupting ratings, coordination with upstream devices, and manufacturer
        requirements. This result is a calculation aid and must be reviewed by a qualified engineer.
      </div>
      <PdfReportButton idPrefix="ocpd" buildSpec={buildSpec} />
    </div>
  );
}
