import { useEffect, useState } from "react";

/**
 * Floating "Calculate" button shown on small screens once the form's own submit
 * button has scrolled out of view, so a long form can be submitted without
 * scrolling back up. Purely presentational: it submits the same form element.
 */
export function StickyCalculateBar({
  formId,
  anchorId,
  label,
}: {
  formId: string;
  anchorId: string;
  label: string;
}) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const anchor = document.getElementById(anchorId);
    const form = document.getElementById(formId);
    if (!anchor || !form) return;

    let anchorVisible = true;
    let formVisible = false;
    const update = () => setShow(formVisible && !anchorVisible);

    const anchorObs = new IntersectionObserver(
      ([entry]) => {
        anchorVisible = !!entry?.isIntersecting;
        update();
      },
      { rootMargin: "0px 0px -72px 0px" },
    );
    const formObs = new IntersectionObserver(([entry]) => {
      formVisible = !!entry?.isIntersecting;
      update();
    });
    anchorObs.observe(anchor);
    formObs.observe(form);
    return () => {
      anchorObs.disconnect();
      formObs.disconnect();
    };
  }, [anchorId, formId]);

  if (!show) return null;

  return (
    <div
      className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 px-4 pb-[calc(0.75rem+env(safe-area-inset-bottom))] pt-3 shadow-[0_-6px_20px_-12px_rgba(6,27,43,0.35)] backdrop-blur lg:hidden"
      role="region"
      aria-label="Quick calculate"
    >
      <button
        type="submit"
        form={formId}
        className="inline-flex min-h-[44px] w-full items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
      >
        {label}
      </button>
    </div>
  );
}
