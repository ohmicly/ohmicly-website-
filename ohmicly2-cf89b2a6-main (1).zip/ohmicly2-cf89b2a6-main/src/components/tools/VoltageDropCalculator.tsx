import { useMemo, useState, type ReactNode } from "react";
import { CheckCircle2, AlertTriangle, RotateCcw } from "lucide-react";
import {
  AWG_SIZES,
  METRIC_SIZES,
  calculateVoltageDrop,
  findSize,
  validateVoltageDrop,
  type FieldErrors,
  type Material,
  type PhaseMode,
  type VoltageDropResult,
} from "@/lib/calculators/voltage-drop";
import type { ReportSpec } from "@/lib/pdf/calculator-report";

import { PdfReportButton } from "./PdfReportButton";
import { StickyCalculateBar } from "./StickyCalculateBar";

type ReportReference = ReportSpec["references"][number];


const field =
  "mt-1.5 block w-full rounded-lg border border-border bg-card px-3 py-2.5 text-[15px] text-foreground shadow-sm outline-none transition-colors focus:border-electric focus:ring-2 focus:ring-electric/25 min-h-11";
const labelCls = "block text-sm font-semibold text-foreground";
const errorCls = "mt-1 text-[13px] font-medium text-destructive";

const DEFAULTS = {
  voltage: "400",
  current: "100",
  distanceFt: "150",
  powerFactor: "0.9",
  limitPercent: "3",
  sizeId: "mm2-50",
  conductorsPerPhase: "1",
};

export function VoltageDropCalculator({
  references = [],
  referenceContent,
}: {
  references?: ReportReference[];
  referenceContent?: ReactNode;
}) {
  const [phase, setPhase] = useState<PhaseMode>("three");
  const [material, setMaterial] = useState<Material>("copper");
  const [form, setForm] = useState({ ...DEFAULTS });
  const [errors, setErrors] = useState<FieldErrors>({});
  const [result, setResult] = useState<VoltageDropResult | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const isAc = phase !== "dc";
  const set = (key: keyof typeof DEFAULTS, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setResult(null);
  };

  const limitValue = useMemo(() => Number(form.limitPercent) || 0, [form.limitPercent]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    const found = validateVoltageDrop({ ...form, phase });
    setErrors(found);
    if (Object.keys(found).length > 0) {
      setResult(null);
      return;
    }
    setResult(
      calculateVoltageDrop({
        voltage: Number(form.voltage),
        phase,
        current: Number(form.current),
        distanceFt: Number(form.distanceFt),
        sizeId: form.sizeId,
        material,
        powerFactor: isAc ? Number(form.powerFactor) : 1,
        conductorsPerPhase: Number(form.conductorsPerPhase) || 1,
        limitPercent: Number(form.limitPercent),
      }),
    );
  };

  const reset = () => {
    setForm({ ...DEFAULTS });
    setPhase("three");
    setMaterial("copper");
    setErrors({});
    setResult(null);
    setSubmitted(false);
  };

  return (
    <section aria-labelledby="calc-heading" className="min-w-0 scroll-mt-24" id="calculator">
      <h2 id="calc-heading" className="text-xl font-bold text-primary sm:text-2xl">
        Voltage drop calculation
      </h2>

      <form id="vd-form" onSubmit={onSubmit} noValidate className="mt-4 min-w-0 rounded-xl border border-border bg-card p-4 shadow-card sm:p-5">
        <fieldset className="border-0 p-0">
          <legend className={labelCls}>Current type &amp; phase</legend>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
            {(
              [
                { id: "dc", label: "DC" },
                { id: "single", label: "AC — Single phase" },
                { id: "three", label: "AC — Three phase" },
              ] as { id: PhaseMode; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                aria-pressed={phase === opt.id}
                onClick={() => {
                  setPhase(opt.id);
                  setResult(null);
                }}
                className={
                  "min-h-11 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors " +
                  (phase === opt.id
                    ? "border-electric bg-accent text-electric"
                    : "border-border bg-surface text-muted-foreground hover:border-electric/40")
                }
              >
                {opt.label}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div>
            <label className={labelCls} htmlFor="vd-voltage">
              System voltage (V)
            </label>
            <input
              id="vd-voltage"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.voltage}
              aria-invalid={Boolean(errors.voltage)}
              onChange={(e) => set("voltage", e.target.value)}
            />
            {submitted && errors.voltage ? <p className={errorCls}>{errors.voltage}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="vd-current">
              Load current (A)
            </label>
            <input
              id="vd-current"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.current}
              aria-invalid={Boolean(errors.current)}
              onChange={(e) => set("current", e.target.value)}
            />
            {submitted && errors.current ? <p className={errorCls}>{errors.current}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="vd-distance">
              One-way distance (ft)
            </label>
            <input
              id="vd-distance"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.distanceFt}
              aria-invalid={Boolean(errors.distanceFt)}
              onChange={(e) => set("distanceFt", e.target.value)}
            />
            {submitted && errors.distanceFt ? <p className={errorCls}>{errors.distanceFt}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="vd-size">
              Conductor size
            </label>
            <select
              id="vd-size"
              className={field}
              value={form.sizeId}
              onChange={(e) => set("sizeId", e.target.value)}
            >
              <optgroup label="Metric (mm²)">
                {METRIC_SIZES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </optgroup>
              <optgroup label="AWG / kcmil">
                {AWG_SIZES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </optgroup>
            </select>
            {submitted && errors.sizeId ? <p className={errorCls}>{errors.sizeId}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="vd-material">
              Conductor material
            </label>
            <select
              id="vd-material"
              className={field}
              value={material}
              onChange={(e) => {
                setMaterial(e.target.value as Material);
                setResult(null);
              }}
            >
              <option value="copper">Copper</option>
              <option value="aluminum">Aluminum</option>
            </select>
          </div>

          <div>
            <label className={labelCls} htmlFor="vd-parallel">
              Conductors per phase
            </label>
            <select
              id="vd-parallel"
              className={field}
              value={form.conductorsPerPhase}
              onChange={(e) => set("conductorsPerPhase", e.target.value)}
            >
              {[1, 2, 3, 4].map((n) => (
                <option key={n} value={String(n)}>
                  {n}
                </option>
              ))}
            </select>
          </div>

          {isAc ? (
            <div>
              <label className={labelCls} htmlFor="vd-pf">
                Power factor
              </label>
              <input
                id="vd-pf"
                className={field}
                inputMode="decimal"
                type="number"
                step="0.01"
                min="0.01"
                max="1"
                value={form.powerFactor}
                aria-invalid={Boolean(errors.powerFactor)}
                onChange={(e) => set("powerFactor", e.target.value)}
              />
              {submitted && errors.powerFactor ? <p className={errorCls}>{errors.powerFactor}</p> : null}
            </div>
          ) : null}

          <div>
            <label className={labelCls} htmlFor="vd-limit">
              Design voltage drop limit (%)
            </label>
            <input
              id="vd-limit"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.1"
              value={form.limitPercent}
              aria-invalid={Boolean(errors.limitPercent)}
              onChange={(e) => set("limitPercent", e.target.value)}
            />
            {submitted && errors.limitPercent ? <p className={errorCls}>{errors.limitPercent}</p> : null}
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button
            id="vd-submit"
            type="submit"
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 sm:flex-none sm:px-6"
          >
            Calculate voltage drop
          </button>
          <button
            type="button"
            onClick={reset}
            className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-lg border border-border bg-surface px-5 text-sm font-semibold text-muted-foreground transition-colors hover:border-electric/40"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            Reset
          </button>
        </div>
        <StickyCalculateBar formId="vd-form" anchorId="vd-submit" label="Calculate voltage drop" />
      </form>

      <div aria-live="polite" className="mt-5 min-w-0 space-y-5">
        {result ? (
          <ResultCard
            result={result}
            limit={limitValue}
            inputs={{ ...form, phase, material }}
            references={references}
          />
        ) : null}
        {referenceContent}
      </div>
    </section>
  );
}

const PHASE_LABEL: Record<PhaseMode, string> = {
  dc: "DC",
  single: "AC — Single phase",
  three: "AC — Three phase",
};

function ResultCard({
  result,
  limit,
  inputs,
  references,
}: {
  result: VoltageDropResult;
  limit: number;
  inputs: typeof DEFAULTS & { phase: PhaseMode; material: Material };
  references: ReportReference[];
}) {
  const ok = result.withinLimit;
  const fmt = (n: number, d = 2) =>
    n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

  const sizeLabel = findSize(inputs.sizeId)?.label ?? inputs.sizeId;
  const isAc = inputs.phase !== "dc";
  const pf = isAc ? Number(inputs.powerFactor) : 1;
  const sinPhi = isAc ? Math.sqrt(Math.max(0, 1 - pf * pf)) : 0;
  const multiplier = inputs.phase === "three" ? "√3" : "2";
  const multiplierValue = inputs.phase === "three" ? Math.sqrt(3) : 2;

  const buildSpec = (preparedFor: string): ReportSpec => ({
    title: "Voltage Drop Calculation",
    code: "VD",
    path: "/calculator/voltage-drop-calculator",
    ...(preparedFor.trim() ? { preparedFor: preparedFor.trim() } : {}),
    status: ok
      ? { label: `Within limit — ${fmt(limit, 1)}% design limit`, tone: "pass" as const }
      : { label: `Exceeds limit — ${fmt(limit, 1)}% design limit`, tone: "fail" as const },
    headline: `${fmt(result.dropPercent)} % (${fmt(result.dropVolts)} V) — ${ok ? "within limit" : "exceeds limit"}`,
    inputs: [
      { label: "Current type & phase", value: PHASE_LABEL[inputs.phase] },
      { label: "System voltage", value: `${inputs.voltage} V` },
      { label: "Load current", value: `${inputs.current} A` },
      { label: "One-way distance", value: `${inputs.distanceFt} ft (${fmt(result.lengthM, 1)} m)` },
      { label: "Conductor size", value: sizeLabel },
      { label: "Conductor material", value: inputs.material === "copper" ? "Copper" : "Aluminum" },
      { label: "Conductors per phase", value: inputs.conductorsPerPhase },
      ...(isAc ? [{ label: "Power factor (cos φ)", value: inputs.powerFactor }] : []),
      { label: "Design voltage drop limit", value: `${inputs.limitPercent} %` },
    ],
    results: [
      { label: "Voltage drop", value: `${fmt(result.dropVolts)} V` },
      {
        label: "Voltage drop (% of system voltage)",
        value: `${fmt(result.dropPercent)} %`,
        tone: ok ? ("pass" as const) : ("fail" as const),
      },
      { label: "Receiving-end voltage", value: `${fmt(result.receivingVoltage)} V` },
      { label: "Resistance component (R)", value: `${fmt(result.resistanceOhms, 4)} Ω` },
      { label: "Reactance component (X)", value: `${fmt(result.reactanceOhms, 4)} Ω` },
      { label: "Circuit length (one-way)", value: `${fmt(result.lengthM, 1)} m` },
      {
        label: "Comparison against your design limit",
        value: ok ? "Within limit" : "Exceeds limit",
        tone: ok ? ("pass" as const) : ("fail" as const),
      },
    ],
    steps: [
      {
        label: isAc
          ? inputs.phase === "three"
            ? "AC three phase: Vdrop = √3 × I × (R·cos φ + X·sin φ)"
            : "AC single phase: Vdrop = 2 × I × (R·cos φ + X·sin φ)"
          : "Direct current: Vdrop = 2 × I × R",
        expression: isAc
          ? `Vdrop = ${multiplier} × ${inputs.current} × (${fmt(result.resistanceOhms, 4)} × ${fmt(pf, 2)} + ${fmt(result.reactanceOhms, 4)} × ${fmt(sinPhi, 3)}) = ${fmt(result.dropVolts)} V   [${multiplier} = ${fmt(multiplierValue, 4)}]`
          : `Vdrop = 2 × ${inputs.current} × ${fmt(result.resistanceOhms, 4)} = ${fmt(result.dropVolts)} V`,
      },
      {
        label: "Drop % = Vdrop ÷ Vsystem × 100",
        expression: `Drop % = ${fmt(result.dropVolts)} ÷ ${inputs.voltage} × 100 = ${fmt(result.dropPercent)} %`,
      },
      {
        label: "Receiving-end voltage = Vsystem − Vdrop",
        expression: `Vreceiving = ${inputs.voltage} − ${fmt(result.dropVolts)} = ${fmt(result.receivingVoltage)} V`,
      },
    ],
    notes: [
      `The ${fmt(limit, 1)}% figure is the design limit you entered, not a code requirement.`,
      "Conductor resistance is evaluated at a 75 °C operating temperature; AC reactance uses a typical installed value for conductors in conduit.",
      "Harmonics, bundling and ambient derating, motor starting inrush, skin and proximity effect, and unbalanced neutral loading are not modelled.",
    ],
    references,
  });



  return (
    <div className="min-w-0 overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div
        className={
          "flex items-center gap-2 border-b px-5 py-3 text-sm font-semibold " +
          (ok
            ? "border-free/25 bg-free/8 text-free"
            : "border-amber-accent/30 bg-gold-soft/60 text-amber-accent-foreground")
        }
      >
        {ok ? (
          <CheckCircle2 className="h-4.5 w-4.5" aria-hidden="true" />
        ) : (
          <AlertTriangle className="h-4.5 w-4.5" aria-hidden="true" />
        )}
        {ok
          ? `Within your design limit of ${fmt(limit, 1)}%`
          : `Exceeds your design limit of ${fmt(limit, 1)}%`}
      </div>

      <dl className="grid grid-cols-1 divide-y divide-border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Voltage drop
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">{fmt(result.dropVolts)} V</dd>
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Voltage drop %
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-electric">{fmt(result.dropPercent)} %</dd>
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Receiving-end voltage
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">
            {fmt(result.receivingVoltage)} V
          </dd>
        </div>
      </dl>

      <div className="border-t border-border bg-surface px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        Circuit length {fmt(result.lengthM, 1)} m one-way · Resistance component {fmt(result.resistanceOhms, 4)} Ω
        · Reactance component {fmt(result.reactanceOhms, 4)} Ω. Conductor resistance is evaluated at a 75 °C
        operating temperature; AC reactance uses a typical installed value — see the method notes below.
      </div>
      <div className="border-t border-border px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">About this comparison:</span> the {fmt(limit, 1)}% figure
        is the design limit you entered, not a code requirement. OHMICLY does not substitute any statutory or
        code recommendation for it. Confirm the permissible drop for your project against the standards listed
        on this page and your project specification.
      </div>
      <PdfReportButton idPrefix="vd" buildSpec={buildSpec} />
    </div>
  );
}