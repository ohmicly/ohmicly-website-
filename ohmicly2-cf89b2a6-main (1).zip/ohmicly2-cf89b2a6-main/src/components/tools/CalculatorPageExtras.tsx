import { CalendarCheck, ShieldCheck, ArrowRight, FileText } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { FAQBlock } from "@/components/ui-kit/FAQBlock";
import type { Faq } from "@/lib/content/types";

/**
 * Page-level editorial additions for the four calculators with a live engine:
 * update and methodology notes, a Bangladesh RMG worked example built from the page's own
 * formulas, Bangladesh-specific FAQs and one contextual audit-resource link.
 *
 * Nothing here calls or changes a calculation engine — every worked figure is
 * stated as an example the reader can reproduce in the calculator above.
 */

export type CalculatorSlug =
  | "voltage-drop-calculator"
  | "cable-size-calculator"
  | "load-calculator"
  | "ocpd-calculator";

const LAST_UPDATED = "11 September 2026";

type Extras = {
  exampleTitle: string;
  scenario: string[];
  steps: { label: string; expression: string }[];
  reading: string;
  faqs: Faq[];
  resource: { label: string; description: string };
};

const CONTENT: Record<CalculatorSlug, Extras> = {
  "voltage-drop-calculator": {
    exampleTitle: "Worked example — sewing-floor feeder in an RMG factory",
    scenario: [
      "Three-phase 400 V feeder supplying a sewing floor sub-board",
      "Load current 100 A at a power factor of 0.9",
      "One-way run 150 ft (about 46 m) of 50 mm² copper, one conductor per phase",
      "Design voltage drop limit taken from the project specification: 3 %",
    ],
    steps: [
      {
        label: "Resistance of the run",
        expression: "R = ρ × L ÷ (A × n), with ρ for copper at 75 °C and L the one-way length",
      },
      {
        label: "Three-phase drop",
        expression: "Vdrop = √3 × I × (R·cos φ + X·sin φ)",
      },
      { label: "Drop as a percentage", expression: "Drop % = Vdrop ÷ Vsystem × 100" },
      { label: "Voltage at the sub-board", expression: "Vreceiving = Vsystem − Vdrop" },
    ],
    reading:
      "Run these values in the calculator above and compare the drop percentage against the limit in your own specification. If it exceeds the limit, increase the conductor size, add a conductor per phase, or shorten the run and re-run the calculation.",
    faqs: [
      {
        question: "Does the Bangladesh National Building Code set the voltage drop limit for my feeder?",
        answer:
          "The permissible voltage drop for a project in Bangladesh is set by the standard and specification your design is being assessed against — commonly the Bangladesh National Building Code (BNBC) electrical provisions together with the client or buyer specification. OHMICLY does not substitute a figure for you: the limit in this calculator is the value you enter, so confirm it against the edition of BNBC and the project documents applicable to your work.",
      },
      {
        question: "Why does voltage drop matter so much in RMG factory feeders?",
        answer:
          "Garment factory floors typically combine long horizontal cable routes with many motor loads on one feeder. As terminal voltage falls, motors draw more current and run hotter, contactor coils drop out, and lighting and electronic controls become unreliable. Because drop is proportional to both current and run length, the long, heavily loaded floor feeders are the ones worth checking first.",
      },
    ],
    resource: {
      label: "RSC & Nirapon audit resources",
      description:
        "Electrical audit checklists and templates used on RSC and Nirapon assessments in Bangladesh factories.",
    },
  },
  "cable-size-calculator": {
    exampleTitle: "Worked example — sizing a sewing-floor feeder cable",
    scenario: [
      "Three-phase 400 V feeder, load current 100 A at 0.9 power factor",
      "One-way run 150 ft (about 46 m), copper conductors, one per phase",
      "Three current-carrying conductors, ambient temperature 30 °C",
      "Correction and grouping factors taken from your own standard (1.00 each in this example)",
      "Design voltage drop limit from the project specification: 3 %",
    ],
    steps: [
      {
        label: "Design current after your factors",
        expression: "Idesign = I ÷ (k_temp × k_group)",
      },
      {
        label: "Voltage drop check for each listed size",
        expression: "Vdrop = √3 × I × (R·cos φ + X·sin φ), with R = ρ × L ÷ (A × n)",
      },
      {
        label: "Selection",
        expression: "The smallest listed size whose drop % is at or below your entered limit",
      },
    ],
    reading:
      "The size returned satisfies voltage drop only. Check it against the allowable current from your own ampacity table, then against short-circuit withstand and protective-device coordination before it is issued for construction.",
    faqs: [
      {
        question: "Can I use this size directly for a BNBC-assessed installation in Bangladesh?",
        answer:
          "No. This version selects on voltage drop alone. A conductor for a project assessed against the Bangladesh National Building Code must also satisfy current-carrying capacity after correction and adjustment factors, short-circuit withstand and coordination with the protective device. Use this result as the voltage drop input to that wider check, not as the final size.",
      },
      {
        question: "Which correction and grouping factors should I enter for a Bangladesh factory?",
        answer:
          "Enter the factors published in the standard your project is assessed against, for the actual ambient temperature and installation arrangement on site. Bangladesh factory ceiling voids and cable routes frequently run well above a 30 °C design ambient, and bunched cables on a common tray need a grouping factor, so both values should come from your standard's tables rather than being assumed.",
      },
    ],
    resource: {
      label: "RSC & Nirapon audit resources",
      description:
        "Cable, panel and installation checklists used during RSC and Nirapon electrical assessments.",
    },
  },
  "load-calculator": {
    exampleTitle: "Worked example — connected load on a sewing-line distribution board",
    scenario: [
      "Three-phase 400 V distribution board on a garment production floor",
      "Connected real power 10 kW per unit at a power factor of 0.9",
      "Quantity 1 (increase the quantity to total several identical loads)",
      "Load factor left blank unless your standard gives you one",
    ],
    steps: [
      { label: "Connected load", expression: "P = unit load × quantity" },
      { label: "Apparent power", expression: "S = P ÷ power factor" },
      { label: "Three-phase line current", expression: "I = S × 1000 ÷ (√3 × V)" },
    ],
    reading:
      "The current returned is the running current for the values entered. It becomes a demand load only when you apply a load or diversity factor taken from the standard applicable to your project.",
    faqs: [
      {
        question: "Does this calculator apply Bangladesh demand or diversity factors automatically?",
        answer:
          "No. Demand and diversity factors depend on occupancy and installation type and are published in the code your project is assessed against, such as the Bangladesh National Building Code electrical provisions. OHMICLY applies only the load factor you enter yourself, so the connected-load figure stays traceable to your own source.",
      },
      {
        question: "Is the motor current shown here suitable for sizing a motor feeder?",
        answer:
          "It is the running current only. Motor starting (locked-rotor) current, efficiency and service factor are not modelled, and starting behaviour usually governs both protection settings and voltage drop on garment-factory motor circuits. Carry out the starting-current and protection-coordination checks separately.",
      },
    ],
    resource: {
      label: "RSC & Nirapon audit resources",
      description:
        "Load schedule and distribution board templates aligned with RSC and Nirapon electrical audits.",
    },
  },
  "ocpd-calculator": {
    exampleTitle: "Worked example — protection current for a sewing-floor sub-feeder",
    scenario: [
      "Design current of the feeder: 48 A",
      "Multiplying factor entered from your own standard where the load is continuous",
      "Maximum allowable rating entered from the conductor you have already sized, if known",
    ],
    steps: [
      {
        label: "Required protection current",
        expression: "Iprotection = Idesign × your factor (no factor entered means Iprotection = Idesign)",
      },
      {
        label: "Comparison",
        expression: "Iprotection is compared with the maximum allowable rating you entered",
      },
    ],
    reading:
      "The figure returned is a minimum requirement, not a device selection. OHMICLY holds no verified standard-rating series, so it will not propose a breaker or fuse size.",
    faqs: [
      {
        question: "Why does the tool not suggest a breaker size for a Bangladesh installation?",
        answer:
          "Proposing a rating would require a verified standard-rating series and the code rules that govern it — for example the overcurrent protection provisions of the Bangladesh National Building Code or the equivalent rules in the standard your project follows. None of these is loaded into OHMICLY, and inventing a rating would be unsafe, so the tool reports the required protection current and leaves the device selection to you and the code.",
      },
      {
        question: "What else must be checked before a device is chosen for a factory panel?",
        answer:
          "Conductor ampacity after correction and adjustment factors, continuous-load requirements, motor and transformer rules, the interrupting rating required at the point of installation, coordination with upstream devices, and the manufacturer's trip characteristic. RSC and Nirapon electrical assessments routinely examine panel protection and coordination, so keep the supporting calculation with the panel records.",
      },
    ],
    resource: {
      label: "RSC & Nirapon audit resources",
      description:
        "Panel, protection and electrical safety checklists used in RSC and Nirapon assessments.",
    },
  },
};

export function CalculatorByline() {
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border bg-surface px-4 py-3 text-[13px] text-muted-foreground sm:flex-row sm:items-center sm:gap-6">
      <span className="inline-flex items-center gap-2">
        <CalendarCheck className="h-4 w-4 shrink-0 text-electric" aria-hidden="true" />
        Last updated: <span className="font-semibold text-foreground">{LAST_UPDATED}</span>
      </span>
      <span className="inline-flex items-center gap-2">
        <ShieldCheck className="h-4 w-4 shrink-0 text-electric" aria-hidden="true" />
        Calculation basis: <span className="font-semibold text-foreground">Transparent formulas &amp; worked examples</span>
      </span>
    </div>
  );
}

export function CalculatorExtras({ slug }: { slug: CalculatorSlug }) {
  const data = CONTENT[slug];

  return (
    <>
      <section aria-labelledby="example-heading" className="scroll-mt-24" id="worked-example">
        <h2 id="example-heading" className="text-xl font-bold text-primary sm:text-2xl">
          {data.exampleTitle}
        </h2>
        <div className="mt-4 rounded-xl border border-border bg-card p-5 shadow-card">
          <h3 className="text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
            Scenario
          </h3>
          <ul className="mt-2 space-y-1.5 text-sm leading-relaxed text-muted-foreground">
            {data.scenario.map((line) => (
              <li key={line} className="list-inside list-disc">
                {line}
              </li>
            ))}
          </ul>

          <h3 className="mt-5 text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
            Steps, using the formulas on this page
          </h3>
          <ol className="mt-2 space-y-2 text-sm leading-relaxed text-muted-foreground">
            {data.steps.map((s, i) => (
              <li key={s.label} className="rounded-lg border border-border bg-surface px-3 py-2">
                <span className="font-semibold text-foreground">
                  {i + 1}. {s.label}
                </span>
                <span className="mt-1 block break-words font-mono text-[13px]">{s.expression}</span>
              </li>
            ))}
          </ol>

          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{data.reading}</p>
        </div>
      </section>

      <FAQBlock
        faqs={data.faqs}
        id="bangladesh-faqs"
        title="Bangladesh practice — common questions"
      />

      <section aria-labelledby="rsc-link-heading">
        <h2 id="rsc-link-heading" className="sr-only">
          Related audit resource
        </h2>
        <Link
          to="/resources"
          className="flex items-start gap-3 rounded-xl border border-border bg-card p-5 shadow-card transition-colors hover:border-electric/50"
        >
          <FileText className="mt-0.5 h-5 w-5 shrink-0 text-electric" aria-hidden="true" />
          <span className="min-w-0">
            <span className="block text-[15px] font-semibold text-foreground">{data.resource.label}</span>
            <span className="mt-1 block text-sm leading-relaxed text-muted-foreground">
              {data.resource.description}
            </span>
            <span className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-electric">
              Browse resources
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </span>
          </span>
        </Link>
      </section>
    </>
  );
}
