import { MethodDisclosure } from "./MethodDisclosure";
import { OPERATING_TEMP_C, REACTANCE_PER_M, RESISTIVITY_75C, FT_TO_M } from "@/lib/calculators/voltage-drop";

const rowCls = "border-t border-border py-3 first:border-0 first:pt-0";

/**
 * Documents exactly how this calculator computes its result. Every number shown
 * here is read from the calculation module itself, so the page and the engine
 * can never drift apart.
 */
export function VoltageDropMethod() {
  return (
    <MethodDisclosure id="method" headingId="method-heading" title="Method, formulas and assumptions">

      <div className="rounded-xl border border-border bg-card p-5 shadow-card">
        <h3 className="text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">Formulas used</h3>
        <dl className="mt-2 text-sm leading-relaxed text-muted-foreground">
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Direct current (DC)</dt>
            <dd className="mt-1">
              V<sub>drop</sub> = 2 × I × R. Both the outgoing and returning conductor are counted, and reactance
              is ignored because it has no effect on a DC circuit.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">AC single phase</dt>
            <dd className="mt-1">
              V<sub>drop</sub> = 2 × I × (R·cos φ + X·sin φ). The factor of 2 accounts for the phase and neutral
              conductor of the loop.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">AC three phase</dt>
            <dd className="mt-1">
              V<sub>drop</sub> = √3 × I × (R·cos φ + X·sin φ), expressed as a line-to-line drop against the
              line-to-line system voltage you enter.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Derived outputs</dt>
            <dd className="mt-1">
              Drop % = V<sub>drop</sub> ÷ V<sub>system</sub> × 100. Receiving-end voltage = V<sub>system</sub> −
              V<sub>drop</sub>.
            </dd>
          </div>
        </dl>

        <h3 className="mt-5 text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          Assumptions and data source
        </h3>
        <dl className="mt-2 text-sm leading-relaxed text-muted-foreground">
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Conductor resistance</dt>
            <dd className="mt-1">
              R = ρ × L ÷ (A × n), where A is the nominal cross-sectional area in mm², n the number of
              conductors per phase and L the one-way run length. ρ is taken as{" "}
              {RESISTIVITY_75C.copper} Ω·mm²/m for copper and {RESISTIVITY_75C.aluminum} Ω·mm²/m for aluminium.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Conductor temperature</dt>
            <dd className="mt-1">
              Both resistivity values correspond to a conductor operating temperature of {OPERATING_TEMP_C} °C,
              the usual assumption for insulated building wire at full rated load. A cooler, lightly loaded
              circuit will drop slightly less than this tool reports.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Reactance</dt>
            <dd className="mt-1">
              AC circuits use a single representative reactance of {REACTANCE_PER_M} Ω per metre per conductor
              (≈0.05 Ω per 300 m), typical of conductors installed in conduit. Reactance varies with conductor
              spacing, raceway material and cable construction, so for long or heavily loaded feeders use the
              reactance published by your cable manufacturer instead.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Power factor</dt>
            <dd className="mt-1">
              cos φ is the value you enter and sin φ is derived as √(1 − cos²φ), assuming a lagging
              (inductive) load. DC calculations force cos φ = 1 and sin φ = 0.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Conductor material and size</dt>
            <dd className="mt-1">
              Only uncoated copper and aluminium are modelled. AWG and kcmil sizes are converted to their
              nominal metric area so both size systems use one consistent model; distances entered in feet are
              converted at {FT_TO_M} m per foot.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Not modelled</dt>
            <dd className="mt-1">
              Harmonic distortion, conductor bundling and ambient-temperature derating, motor starting inrush,
              parallel-run circulating currents, skin and proximity effect, and neutral loading on unbalanced
              three-phase circuits are outside the scope of this tool.
            </dd>
          </div>
        </dl>
      </div>
    </MethodDisclosure>
  );
}