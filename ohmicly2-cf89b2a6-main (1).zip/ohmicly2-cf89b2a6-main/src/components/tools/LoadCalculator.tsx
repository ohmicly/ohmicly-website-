import { useState, type ReactNode } from "react";
import { Info, RotateCcw } from "lucide-react";
import { calculateLoad, validateLoad, type LoadResult, type LoadType, type Phase } from "@/lib/calculators/load";
import type { ReportSpec } from "@/lib/pdf/calculator-report";

import { PdfReportButton } from "./PdfReportButton";
import { StickyCalculateBar } from "./StickyCalculateBar";

type ReportReference = ReportSpec["references"][number];

const field =
  "mt-1.5 block w-full rounded-lg border border-border bg-card px-3 py-2.5 text-[15px] text-foreground shadow-sm outline-none transition-colors focus:border-electric focus:ring-2 focus:ring-electric/25 min-h-11";
const labelCls = "block text-sm font-semibold text-foreground";
const hintCls = "mt-1 text-[13px] leading-relaxed text-muted-foreground";
const errorCls = "mt-1 text-[13px] font-medium text-destructive";

const DEFAULTS = {
  powerKw: "10",
  voltage: "400",
  powerFactor: "0.9",
  quantity: "1",
  loadFactor: "",
};

const loadTypeOptions: { id: LoadType; label: string; hint: string }[] = [
  { id: "resistive", label: "Resistive", hint: "Heating, lighting, etc." },
  { id: "motor", label: "Motor", hint: "Starting current not modelled" },
  { id: "general", label: "General", hint: "Mixed load" },
];

export function LoadCalculator({
  references = [],
  referenceContent,
}: {
  references?: ReportReference[];
  referenceContent?: ReactNode;
}) {
  const [loadType, setLoadType] = useState<LoadType>("general");
  const [phase, setPhase] = useState<Phase>("three");
  const [form, setForm] = useState({ ...DEFAULTS });
  const [errors, setErrors] = useState<Partial<Record<keyof typeof DEFAULTS, string>>>({});
  const [result, setResult] = useState<LoadResult | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const set = (key: keyof typeof DEFAULTS, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setResult(null);
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    const found = validateLoad({ ...form, phase });
    setErrors(found);
    if (Object.keys(found).length > 0) {
      setResult(null);
      return;
    }
    setResult(
      calculateLoad({
        loadType,
        powerKw: Number(form.powerKw),
        voltage: Number(form.voltage),
        phase,
        powerFactor: Number(form.powerFactor),
        quantity: Number(form.quantity),
        ...(form.loadFactor.trim() !== "" ? { loadFactor: Number(form.loadFactor) } : {}),
      }),
    );
  };

  const reset = () => {
    setForm({ ...DEFAULTS });
    setLoadType("general");
    setPhase("three");
    setErrors({});
    setResult(null);
    setSubmitted(false);
  };

  return (
    <section aria-labelledby="calc-heading" className="min-w-0 scroll-mt-24" id="calculator">
      <h2 id="calc-heading" className="text-xl font-bold text-primary sm:text-2xl">
        Load current calculation
      </h2>

      <form id="load-form" onSubmit={onSubmit} noValidate className="mt-4 min-w-0 rounded-xl border border-border bg-card p-4 shadow-card sm:p-5">
        <fieldset className="border-0 p-0">
          <legend className={labelCls}>Load type</legend>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
            {loadTypeOptions.map((opt) => (
              <button
                key={opt.id}
                type="button"
                aria-pressed={loadType === opt.id}
                onClick={() => {
                  setLoadType(opt.id);
                  setResult(null);
                }}
                className={
                  "flex min-h-11 flex-col items-start justify-center rounded-lg border px-3 py-2 text-left transition-colors " +
                  (loadType === opt.id
                    ? "border-electric bg-accent text-electric"
                    : "border-border bg-surface text-muted-foreground hover:border-electric/40")
                }
              >
                <span className="text-sm font-semibold">{opt.label}</span>
                <span className="text-[12px] opacity-80">{opt.hint}</span>
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset className="mt-5 border-0 p-0">
          <legend className={labelCls}>Phase arrangement</legend>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {(
              [
                { id: "single", label: "Single phase" },
                { id: "three", label: "Three phase" },
              ] as { id: Phase; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                aria-pressed={phase === opt.id}
                onClick={() => {
                  setPhase(opt.id);
                  setResult(null);
                }}
                className={
                  "min-h-11 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors " +
                  (phase === opt.id
                    ? "border-electric bg-accent text-electric"
                    : "border-border bg-surface text-muted-foreground hover:border-electric/40")
                }
              >
                {opt.label}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div>
            <label className={labelCls} htmlFor="load-power">
              Load power (kW)
            </label>
            <input
              id="load-power"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.powerKw}
              aria-invalid={Boolean(errors.powerKw)}
              onChange={(e) => set("powerKw", e.target.value)}
            />
            {submitted && errors.powerKw ? <p className={errorCls}>{errors.powerKw}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="load-voltage">
              Voltage (V)
            </label>
            <input
              id="load-voltage"
              className={field}
              inputMode="decimal"
              type="number"
              step="any"
              value={form.voltage}
              aria-invalid={Boolean(errors.voltage)}
              onChange={(e) => set("voltage", e.target.value)}
            />
            {submitted && errors.voltage ? <p className={errorCls}>{errors.voltage}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="load-pf">
              Power factor
            </label>
            <input
              id="load-pf"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.01"
              min="0.01"
              max="1"
              value={form.powerFactor}
              aria-invalid={Boolean(errors.powerFactor)}
              onChange={(e) => set("powerFactor", e.target.value)}
            />
            {submitted && errors.powerFactor ? <p className={errorCls}>{errors.powerFactor}</p> : null}
          </div>

          <div>
            <label className={labelCls} htmlFor="load-quantity">
              Quantity
            </label>
            <input
              id="load-quantity"
              className={field}
              inputMode="numeric"
              type="number"
              step="1"
              min="1"
              value={form.quantity}
              aria-invalid={Boolean(errors.quantity)}
              onChange={(e) => set("quantity", e.target.value)}
            />
            <p className={hintCls}>Total connected load = kW × quantity.</p>
            {submitted && errors.quantity ? <p className={errorCls}>{errors.quantity}</p> : null}
          </div>

          <div className="sm:col-span-2">
            <label className={labelCls} htmlFor="load-factor">
              Load factor / diversity factor (optional)
            </label>
            <input
              id="load-factor"
              className={field}
              inputMode="decimal"
              type="number"
              step="0.01"
              min="0"
              max="1"
              placeholder="Only enter if your project supplies one"
              value={form.loadFactor}
              aria-invalid={Boolean(errors.loadFactor)}
              onChange={(e) => set("loadFactor", e.target.value)}
            />
            <p className={hintCls}>
              Leave blank unless you have a verified demand or diversity factor from your applicable standard.
              OHMICLY does not apply one automatically.
            </p>
            {submitted && errors.loadFactor ? <p className={errorCls}>{errors.loadFactor}</p> : null}
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <button
            id="load-submit"
            type="submit"
            className="inline-flex min-h-11 flex-1 items-center justify-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 sm:flex-none sm:px-6"
          >
            Calculate load current
          </button>
          <button
            type="button"
            onClick={reset}
            className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-lg border border-border bg-surface px-5 text-sm font-semibold text-muted-foreground transition-colors hover:border-electric/40"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            Reset
          </button>
        </div>
        <StickyCalculateBar formId="load-form" anchorId="load-submit" label="Calculate load" />
      </form>

      <div aria-live="polite" className="mt-5 min-w-0 space-y-5">
        {result ? <ResultCard result={result} loadType={loadType} references={references} /> : null}
        {referenceContent}
      </div>
    </section>
  );
}

function ResultCard({
  result,
  loadType,
  references,
}: {
  result: LoadResult;
  loadType: LoadType;
  references: ReportReference[];
}) {
  const fmt = (n: number, d = 2) =>
    n.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

  const threePhase = result.phase === "three";
  const buildSpec = (preparedFor: string): ReportSpec => ({
    title: "Load & Current Calculation",
    code: "LOAD",
    path: "/calculator/load-calculator",
    ...(preparedFor.trim() ? { preparedFor: preparedFor.trim() } : {}),
    status: { label: "Calculation complete", tone: "info" as const },
    headline: `${fmt(result.currentA, 1)} A line current · ${fmt(result.apparentPowerKva)} kVA`,
    inputs: [
      { label: "Load type", value: loadType.charAt(0).toUpperCase() + loadType.slice(1) },
      { label: "Phase arrangement", value: threePhase ? "Three phase" : "Single phase" },
      { label: "Load power (per unit)", value: `${fmt(result.unitLoadKw)} kW` },
      { label: "Quantity", value: String(result.quantity) },
      { label: "System voltage", value: `${fmt(result.voltage)} V` },
      { label: "Power factor", value: fmt(result.powerFactor) },
      ...(result.loadFactor !== undefined
        ? [{ label: "Load factor (user-entered)", value: fmt(result.loadFactor) }]
        : []),
    ],
    results: [
      { label: "Connected load", value: `${fmt(result.connectedLoadKw)} kW` },
      { label: "Apparent power", value: `${fmt(result.apparentPowerKva)} kVA` },
      { label: "Line current", value: `${fmt(result.currentA, 1)} A`, tone: "info" as const },
      ...(result.diversifiedLoadKw !== undefined
        ? [{ label: "Load after load factor", value: `${fmt(result.diversifiedLoadKw)} kW` }]
        : []),
      ...(result.diversifiedKva !== undefined
        ? [{ label: "Apparent power after load factor", value: `${fmt(result.diversifiedKva)} kVA` }]
        : []),
    ],
    steps: [
      {
        label: "Connected load = unit load × quantity",
        expression: `P = ${fmt(result.unitLoadKw)} × ${result.quantity} = ${fmt(result.connectedLoadKw)} kW`,
      },
      {
        label: "Apparent power = P ÷ power factor",
        expression: `S = ${fmt(result.connectedLoadKw)} ÷ ${fmt(result.powerFactor)} = ${fmt(result.apparentPowerKva)} kVA`,
      },
      {
        label: threePhase ? "Line current = S × 1000 ÷ (√3 × V)" : "Line current = S × 1000 ÷ V",
        expression: threePhase
          ? `I = ${fmt(result.apparentPowerKva)} × 1000 ÷ (1.7321 × ${fmt(result.voltage)}) = ${fmt(result.currentA, 1)} A`
          : `I = ${fmt(result.apparentPowerKva)} × 1000 ÷ ${fmt(result.voltage)} = ${fmt(result.currentA, 1)} A`,
      },
      ...(result.loadFactor !== undefined && result.diversifiedLoadKw !== undefined
        ? [
            {
              label: "Load after your load factor = P × load factor",
              expression: `Pdiv = ${fmt(result.connectedLoadKw)} × ${fmt(result.loadFactor)} = ${fmt(result.diversifiedLoadKw)} kW`,
            },
          ]
        : []),
    ],
    notes: [
      "This result is a calculation aid only. Final feeder sizing, protection coordination and installation design must be reviewed against the applicable code and project conditions.",
      "Motor starting current, motor efficiency and code demand/diversity factors are not modelled; any load factor shown is the value you entered.",
    ],
    references,
  });

  return (
    <div className="min-w-0 overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex items-start gap-2 border-b border-electric/25 bg-accent px-5 py-3 text-sm font-semibold text-foreground">
        <Info className="mt-0.5 h-4.5 w-4.5 shrink-0 text-electric" aria-hidden="true" />
        <div className="leading-snug">
          <span className="block">Load-current calculation result</span>
          <span className="block font-normal opacity-90">
            {result.phase === "three" ? "Three-phase" : "Single-phase"} · {fmt(result.voltage)} V · PF{" "}
            {fmt(result.powerFactor)}
          </span>
        </div>
      </div>

      <dl className="grid grid-cols-1 divide-y divide-border sm:grid-cols-3 sm:divide-x sm:divide-y-0">
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Connected load
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">
            {fmt(result.connectedLoadKw)} kW
          </dd>
          {result.quantity > 1 ? (
            <p className="mt-1 text-[13px] text-muted-foreground">
              {fmt(result.unitLoadKw, 2)} kW × {result.quantity}
            </p>
          ) : null}
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Apparent power
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-electric">
            {fmt(result.apparentPowerKva)} kVA
          </dd>
        </div>
        <div className="p-5">
          <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            Calculated current
          </dt>
          <dd className="mt-1 text-2xl font-extrabold tracking-tight text-primary">
            {fmt(result.currentA)} A
          </dd>
        </div>
      </dl>

      {result.loadFactor !== undefined && result.diversifiedLoadKw !== undefined ? (
        <div className="border-t border-border bg-surface px-5 py-4">
          <h3 className="text-[11px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
            User-supplied factor applied
          </h3>
          <dl className="mt-2 grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-muted-foreground">Load factor</dt>
              <dd className="font-semibold text-foreground">{fmt(result.loadFactor!, 2)}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Diversified load</dt>
              <dd className="font-semibold text-foreground">
                {fmt(result.diversifiedLoadKw)} kW / {fmt(result.diversifiedKva ?? 0)} kVA
              </dd>
            </div>
          </dl>
        </div>
      ) : null}

      <div className="border-t border-border px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">Calculation basis:</span>{" "}
        {result.phase === "three"
          ? `I = kVA × 1000 / (√3 × V) = ${fmt(result.apparentPowerKva)} × 1000 / (${fmt(Math.sqrt(3), 3)} × ${fmt(result.voltage)})`
          : `I = kVA × 1000 / V = ${fmt(result.apparentPowerKva)} × 1000 / ${fmt(result.voltage)}`}
        . Apparent power = kW / power factor.
      </div>

      <div className="border-t border-border px-5 py-3 text-[13px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">Engineering note:</span> this result is a calculation
        aid only. Final feeder sizing, protection coordination and installation design must be reviewed against
        the applicable code and project conditions. Motor starting current, efficiency and code demand/diversity
        factors are not modelled here.
      </div>
      <PdfReportButton idPrefix="load" buildSpec={buildSpec} />
    </div>
  );
}
