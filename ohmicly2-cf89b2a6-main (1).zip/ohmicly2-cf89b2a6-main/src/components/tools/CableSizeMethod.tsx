import { MethodDisclosure } from "./MethodDisclosure";
import { MISSING_ENGINEERING_DATA, OPERATING_TEMP_C_VALUE, RESISTIVITY_AT_OPERATING_TEMP, REACTANCE_PER_M_VALUE, FT_TO_M } from "@/lib/engineering";

const rowCls = "border-t border-border py-3 first:border-0 first:pt-0";

/**
 * Documents how the cable size selection works and, just as importantly, which
 * engineering data OHMICLY does not yet hold.
 */
export function CableSizeMethod() {
  return (
    <MethodDisclosure id="method" headingId="cs-method-heading" title="Method, data sources and current limitations">

      <div className="rounded-xl border border-border bg-card p-5 shadow-card">
        <h3 className="text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          How a size is selected
        </h3>
        <dl className="mt-2 text-sm leading-relaxed text-muted-foreground">
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Selection criterion</dt>
            <dd className="mt-1">
              Every conductor in the chosen size system is evaluated in ascending area order, and the smallest
              one whose calculated voltage drop is at or below your design limit is recommended. The same
              resistance and reactance model as the OHMICLY Voltage Drop Calculator is used, so both tools
              always agree.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Design current</dt>
            <dd className="mt-1">
              I<sub>design</sub> = I<sub>load</sub> ÷ (k<sub>temp</sub> × k<sub>group</sub>), where both
              factors are the values you enter from your applicable standard. It is reported for your ampacity
              comparison and does not alter the voltage drop calculation, which uses the actual load current.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Conductor data</dt>
            <dd className="mt-1">
              Resistivity is {RESISTIVITY_AT_OPERATING_TEMP.copper.value} Ω·mm²/m for copper and{" "}
              {RESISTIVITY_AT_OPERATING_TEMP.aluminum.value} Ω·mm²/m for aluminium at an assumed{" "}
              {OPERATING_TEMP_C_VALUE.value} °C operating temperature; AC reactance uses{" "}
              {REACTANCE_PER_M_VALUE.value} Ω per metre per conductor. Distances entered in feet are converted
              at {FT_TO_M} m per foot. These are generic engineering assumptions, not clauses from a published
              code.
            </dd>
          </div>
        </dl>

        <h3 className="mt-5 text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          Engineering data OHMICLY does not yet hold
        </h3>
        <ul className="mt-2 space-y-2 text-sm leading-relaxed text-muted-foreground">
          {MISSING_ENGINEERING_DATA.map((d) => (
            <li key={d.id} className="list-inside list-disc">
              <span className="font-semibold text-foreground">{d.label}:</span> {d.notes}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Because of this, version 1 does not perform an automatic thermal (current carrying capacity) check.
          It never guesses a table value: allowable current and correction factors are only used when you
          supply them. A conductor selected here must still be verified against the ampacity, short-circuit
          withstand and protection requirements of the code applicable to your project.
        </p>
      </div>
    </MethodDisclosure>
  );
}