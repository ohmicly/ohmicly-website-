import { MethodDisclosure } from "./MethodDisclosure";
const rowCls = "border-t border-border py-3 first:border-0 first:pt-0";

/**
 * Documents how the Load Calculator computes its result. The formulas are the
 * fundamental single-phase and three-phase relationships; no demand or diversity
 * tables are referenced because OHMICLY does not hold verified ones.
 */
export function LoadMethod() {
  return (
    <MethodDisclosure id="method" headingId="load-method-heading" title="Method, formulas and limitations">

      <div className="rounded-xl border border-border bg-card p-5 shadow-card">
        <h3 className="text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">Formulas used</h3>
        <dl className="mt-2 text-sm leading-relaxed text-muted-foreground">
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Apparent power</dt>
            <dd className="mt-1">
              S (kVA) = P (kW) ÷ power factor. The connected load is the unit load multiplied by the quantity
              you enter.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Single-phase current</dt>
            <dd className="mt-1">
              I = S × 1000 ÷ V, where V is the line-to-neutral (or single-phase) voltage you enter.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Three-phase current</dt>
            <dd className="mt-1">
              I = S × 1000 ÷ (√3 × V), where V is the line-to-line voltage you enter.
            </dd>
          </div>
          <div className={rowCls}>
            <dt className="font-semibold text-foreground">Optional load factor</dt>
            <dd className="mt-1">
              When you explicitly supply a verified load, demand or diversity factor, the diversified load is
              simply connected load × factor. No factor is applied unless you enter one.
            </dd>
          </div>
        </dl>

        <h3 className="mt-5 text-sm font-semibold uppercase tracking-[0.08em] text-muted-foreground">
          What this version does not model
        </h3>
        <ul className="mt-2 space-y-2 text-sm leading-relaxed text-muted-foreground">
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Demand/diversity factors:</span> OHMICLY does not
            apply automatic demand or diversity factors. Enter one only if your applicable standard or project
            data supplies it.
          </li>
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Motor loads:</span> Running current is calculated
            from the kW and power factor you supply. Motor starting (locked-rotor) current, efficiency,
            service factor and power-factor correction are outside the scope of this tool.
          </li>
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Harmonics and non-linear loads:</span> The
            calculator uses a single power factor and does not estimate harmonic currents or K-factor loading.
          </li>
          <li className="list-inside list-disc">
            <span className="font-semibold text-foreground">Code compliance:</span> This tool does not check
            ampacity, voltage drop, protection coordination or any other code requirement. Those checks must be
            performed separately against the standard applicable to your installation.
          </li>
        </ul>
      </div>
    </MethodDisclosure>
  );
}
