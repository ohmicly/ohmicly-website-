import { ArrowRight, ClipboardCheck, FileText, FolderOpen } from "lucide-react";
import { Link } from "@tanstack/react-router";

import heroSubstation from "@/assets/ohmicly-hero-substation.jpg";

const RESOURCES = [
  {
    title: "RSC Guidelines",
    description: "Audit checklists and compliance documents.",
    icon: FileText,
  },
  {
    title: "NIRAPON Templates",
    description: "Ready-to-use reporting templates.",
    icon: FolderOpen,
  },
  {
    title: "Safety Checklists",
    description: "Practical inspection and safety forms.",
    icon: ClipboardCheck,
  },
] as const;

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border bg-background">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_78%_38%,color-mix(in_oklab,var(--electric)_11%,transparent),transparent_30%)]" />

      <div className="container-page relative grid min-h-[580px] items-center gap-9 py-10 lg:h-[610px] lg:min-h-0 lg:grid-cols-[minmax(0,1.02fr)_minmax(0,0.98fr)] lg:gap-8 lg:py-6">
        <div className="relative z-20 min-w-0 lg:max-w-[650px]">
          <p className="text-xs font-bold uppercase text-electric">Bangladesh electrical resource platform</p>

          <h1 className="mt-4 text-[2.3rem] font-extrabold leading-[1.08] tracking-normal text-hero-navy sm:text-[3rem] lg:text-[3.15rem]">
            <span className="block lg:whitespace-nowrap">Trusted Resources for</span>
            <span className="block text-electric lg:whitespace-nowrap">Electrical Compliance</span>
            <span className="block lg:whitespace-nowrap">and Audit Readiness</span>
          </h1>

          <p className="mt-5 max-w-[590px] text-[15px] leading-7 text-muted-foreground sm:text-base">
            Practical guides, templates, checklists and engineering standards to help you stay compliant,
            prepare for audits and build safer electrical systems.
          </p>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/resources"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg bg-electric px-6 py-3 text-sm font-bold text-electric-foreground shadow-card transition-colors hover:bg-electric/90"
            >
              Explore Resources
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
            </Link>
            <Link
              to="/calculator"
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg border border-electric/20 bg-card px-6 py-3 text-sm font-bold text-hero-navy transition-colors hover:bg-surface"
            >
              View Calculators
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
            </Link>
          </div>

          <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-border pt-5 text-xs font-semibold text-muted-foreground">
            <span><strong className="text-hero-navy">RSC</strong> audit guidance</span>
            <span><strong className="text-hero-navy">NIRAPON</strong> templates</span>
            <span><strong className="text-hero-navy">BNBC</strong> references</span>
          </div>
        </div>

        <div className="relative z-10 min-h-[460px] min-w-0 lg:h-[545px]">
          <div className="absolute inset-y-3 right-0 w-[86%] overflow-hidden rounded-[2rem] bg-surface shadow-[0_24px_70px_-36px_color-mix(in_oklab,var(--electric)_48%,transparent)] [clip-path:polygon(14%_0,100%_0,100%_86%,76%_100%,12%_92%,0_68%,0_18%)] sm:w-[82%] lg:w-[78%]">
            <img
              src={heroSubstation}
              alt="Electrical substation with a safety helmet and inspection checklist"
              width={1024}
              height={1024}
              fetchPriority="high"
              className="h-full w-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-[linear-gradient(90deg,color-mix(in_oklab,var(--background)_18%,transparent),transparent_36%)]" />
          </div>

          <div className="absolute right-[3%] top-0 h-12 w-12 rotate-30 rounded-xl border border-electric/25 bg-background/70" aria-hidden="true" />
          <div className="absolute bottom-7 right-0 h-5 w-5 rotate-30 rounded-md bg-amber-accent" aria-hidden="true" />

          <div className="absolute left-0 top-10 z-10 flex w-[64%] max-w-[300px] flex-col gap-4 sm:left-[2%] lg:left-0 lg:top-12">
            {RESOURCES.map(({ title, description, icon: Icon }) => (
              <Link
                key={title}
                to="/resources"
                className="group grid min-h-[92px] grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border border-electric/10 bg-card/95 p-3.5 shadow-card backdrop-blur-sm transition-transform hover:-translate-y-0.5"
              >
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-electric/10 text-electric">
                  <Icon className="h-5 w-5" strokeWidth={2} aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[13px] font-bold text-hero-navy">{title}</span>
                  <span className="mt-1 block text-[11px] leading-relaxed text-muted-foreground">{description}</span>
                </span>
                <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-electric/8 text-electric">
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}