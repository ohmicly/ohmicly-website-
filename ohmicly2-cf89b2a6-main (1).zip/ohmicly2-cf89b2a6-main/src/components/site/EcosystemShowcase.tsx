import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Icon } from "@/components/ui-kit/Icon";
import { cn } from "@/lib/utils";

/**
 * Signature interactive ecosystem showcase for the homepage.
 * Tabs switch both the left product visual and the right resource list.
 * Every link points at an existing route; no new data is invented.
 */

type LinkItem = {
  label: string;
  desc: string;
  href: string;
  badge?: string;
  pro?: boolean;
  icon: "file-text" | "shield-check" | "calculator" | "layers";
};

type Tab = {
  id: string;
  tab: string;
  short: string;
  title: string;
  desc: string;
  links: LinkItem[];
  cta: { label: string; href: string };
  visual: "audit" | "cad" | "templates" | "calculators";
};

const tabs: Tab[] = [
  {
    id: "audit",
    tab: "Audit & Compliance",
    short: "Audit",
    title: "Audit & Compliance",
    desc:
      "Prepare, inspect and document electrical compliance work with practical audit-ready resources.",
    links: [
      {
        label: "RSC Electrical Audit Checklist",
        desc: "Electrical scope checklist for inspection work",
        href: "/resources/rsc-electrical-audit-checklist",
        badge: "PDF · Free",
        icon: "shield-check",
      },
      {
        label: "Nirapon Electrical Assessment Checklist",
        desc: "Assessment points for Nirapon electrical reviews",
        href: "/resources/nirapon-electrical-checklist",
        badge: "PDF · Free",
        icon: "shield-check",
      },
      {
        label: "Electrical Safety Inspection Checklist",
        desc: "Routine safety inspection of installations",
        href: "/resources/electrical-safety-inspection-checklist",
        badge: "PDF · Free",
        icon: "shield-check",
      },
      {
        label: "Audit Reporting Template",
        desc: "Structure findings, CAPA and close-out records",
        href: "/resources/audit-reporting-template",
        badge: "DOCX",
        icon: "file-text",
      },
    ],
    cta: { label: "Explore audit resources", href: "/resources" },
    visual: "audit",
  },
  {
    id: "cad",
    tab: "CAD & AutoLISP",
    short: "CAD",
    title: "CAD & AutoLISP",
    desc:
      "Drafting blocks, drawing templates and AutoLISP utilities that cut repetitive AutoCAD work.",
    links: [
      {
        label: "Electrical Symbols Pack",
        desc: "Standard electrical symbols for drafting",
        href: "/resources/electrical-symbols-pack",
        badge: "DWG",
        icon: "layers",
      },
      {
        label: "AutoLISP Cable Tagging Utility",
        desc: "Automate repetitive cable tagging in AutoCAD",
        href: "/resources/autolisp-cable-tag-utility",
        badge: "LSP",
        icon: "layers",
      },
      {
        label: "MDB Single Line Diagram Template",
        desc: "Editable SLD base for main distribution boards",
        href: "/resources/mdb-sld-template",
        badge: "DWG",
        pro: true,
        icon: "layers",
      },
      {
        label: "Panel Schedule Template",
        desc: "Circuit schedule to pair with distribution drawings",
        href: "/resources/panel-schedule-template",
        badge: "XLSX",
        icon: "file-text",
      },
    ],
    cta: { label: "Explore CAD resources", href: "/autocad" },
    visual: "cad",
  },
  {
    id: "templates",
    tab: "Templates",
    short: "Templates",
    title: "Engineering Templates",
    desc:
      "Ready-to-use schedules, design sheets and documentation formats for everyday electrical work.",
    links: [
      {
        label: "Panel Schedule Template",
        desc: "Circuit-by-circuit schedule for distribution boards",
        href: "/resources/panel-schedule-template",
        badge: "XLSX",
        icon: "file-text",
      },
      {
        label: "Load Schedule Template",
        desc: "Track connected and demand load per board",
        href: "/resources/load-schedule-template",
        badge: "XLSX",
        icon: "file-text",
      },
      {
        label: "Earthing Design Template",
        desc: "Document earthing arrangement and calculations",
        href: "/resources/earthing-design-template",
        badge: "XLSX",
        pro: true,
        icon: "file-text",
      },
      {
        label: "Audit Reporting Template",
        desc: "Report format for inspection findings",
        href: "/resources/audit-reporting-template",
        badge: "DOCX",
        icon: "file-text",
      },
      {
        label: "LPS Design Template",
        desc: "Lightning protection layout starting point",
        href: "/resources/lps-design-template",
        badge: "DWG",
        pro: true,
        icon: "layers",
      },
      {
        label: "Electrical Engineer CV Template",
        desc: "Structured CV format for electrical engineers",
        href: "/resources/electrical-engineer-cv-template",
        badge: "DOCX",
        pro: true,
        icon: "file-text",
      },
    ],
    cta: { label: "Explore templates", href: "/templates" },
    visual: "templates",
  },
  {
    id: "calculators",
    tab: "Calculators",
    short: "Calculators",
    title: "Engineering Calculators",
    desc:
      "Fast, transparent calculators with documented formulas and assumptions for design checks.",
    links: [
      {
        label: "Voltage Drop Calculator",
        desc: "Check drop and receiving-end voltage on a run",
        href: "/calculator/voltage-drop-calculator",
        icon: "calculator",
      },
      {
        label: "Cable Size Calculator",
        desc: "Size conductors against voltage-drop criteria",
        href: "/calculator/cable-size-calculator",
        icon: "calculator",
      },
      {
        label: "Electrical Load Calculator",
        desc: "Connected load, kVA and full-load current",
        href: "/calculator/load-calculator",
        icon: "calculator",
      },
      {
        label: "OCPD Calculator",
        desc: "Required protection current and standard rating",
        href: "/calculator/ocpd-calculator",
        icon: "calculator",
      },
    ],
    cta: { label: "Explore calculators", href: "/calculator" },
    visual: "calculators",
  },
];

function ProBadge() {
  return (
    <span className="shrink-0 rounded-md bg-premium-gradient px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-white">
      Pro
    </span>
  );
}

const panel = "rounded-2xl border border-navy-border bg-navy-panel p-5 sm:p-6";

function VisualShell({ label, meta, children }: { label: string; meta: string; children: React.ReactNode }) {
  return (
    <div className={cn(panel, "relative overflow-hidden")}>
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.10] [background-image:linear-gradient(to_right,white_1px,transparent_1px),linear-gradient(to_bottom,white_1px,transparent_1px)] [background-size:26px_26px]"
      />
      <div className="relative">
        <div className="mb-4 flex items-center justify-between gap-3">
          <p className="text-[13px] font-semibold text-navy-foreground">{label}</p>
          <span className="rounded-md border border-navy-border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-navy-muted">
            {meta}
          </span>
        </div>
        {children}
      </div>
    </div>
  );
}

const workflow = ["Check", "Finding", "CAPA", "Verify", "Close"];

function AuditVisual() {
  const rows = [
    { label: "Panel enclosure & IP integrity", state: "Pass" },
    { label: "Earthing continuity", state: "Pass" },
    { label: "Cable routing & segregation", state: "Observation" },
    { label: "Emergency lighting test record", state: "Finding" },
    { label: "SLD matches installed system", state: "Pass" },
  ];
  const tone: Record<string, string> = {
    Pass: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
    Observation: "border-gold/40 bg-gold/12 text-gold",
    Finding: "border-destructive/40 bg-destructive/12 text-red-300",
  };
  return (
    <VisualShell label="Electrical Inspection Report" meta="Preview">
      <ol className="mb-4 flex flex-wrap items-center gap-x-2 gap-y-2">
        {workflow.map((step, i) => (
          <li key={step} className="flex items-center gap-2">
            <span className="rounded-lg border border-electric/30 bg-electric/12 px-2.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.08em] text-electric">
              {step}
            </span>
            {i < workflow.length - 1 ? (
              <ArrowRight className="h-3.5 w-3.5 text-navy-muted" aria-hidden="true" />
            ) : null}
          </li>
        ))}
      </ol>
      <ul className="flex flex-col gap-2">
        {rows.map((r) => (
          <li
            key={r.label}
            className="flex items-center justify-between gap-3 rounded-lg border border-navy-border bg-white/[0.03] px-3 py-2.5"
          >
            <span className="min-w-0 truncate text-[13px] text-navy-foreground">{r.label}</span>
            <span
              className={cn(
                "shrink-0 rounded-md border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em]",
                tone[r.state],
              )}
            >
              {r.state}
            </span>
          </li>
        ))}
      </ul>
    </VisualShell>
  );
}

function CadVisual() {
  return (
    <VisualShell label="Single Line Diagram — DWG" meta="CAD">
      <svg
        viewBox="0 0 340 210"
        className="h-auto w-full"
        role="img"
        aria-label="Single line diagram preview with transformer, main busbar, breakers and outgoing feeders"
      >
        <g fill="none" stroke="currentColor" strokeWidth="1.6" className="text-navy-muted" strokeLinecap="round">
          <circle cx="60" cy="34" r="13" />
          <circle cx="60" cy="50" r="13" />
          <path d="M60 63v18" />
          <rect x="50" y="81" width="20" height="14" rx="2" />
          <rect x="70" y="120" width="200" height="16" rx="4" />
          <path d="M110 136v20M170 136v20M230 136v20" />
          <rect x="102" y="156" width="16" height="12" rx="2" />
          <rect x="162" y="156" width="16" height="12" rx="2" />
          <rect x="222" y="156" width="16" height="12" rx="2" />
          <path d="M110 168v20M170 168v20M230 168v20" />
        </g>
        <g fill="none" stroke="currentColor" strokeWidth="2.2" className="text-electric">
          <path d="M60 95v25h50" />
        </g>
        <g className="fill-navy-muted" fontSize="9">
          <text x="80" y="30">11kV / 0.4kV</text>
          <text x="70" y="114">MDB BUSBAR</text>
          <text x="92" y="200">DB-01</text>
          <text x="152" y="200">DB-02</text>
          <text x="214" y="200">MOTOR</text>
        </g>
      </svg>
      <div className="mt-4 rounded-xl border border-navy-border bg-black/25 p-3 font-mono text-[11px] leading-relaxed text-navy-muted">
        <p className="text-electric">; cable-tag.lsp</p>
        <p>(defun c:CTAG (/ ss n)</p>
        <p className="pl-3">(setq ss (ssget &apos;((0 . &quot;LINE,LWPOLYLINE&quot;))))</p>
        <p className="pl-3">(tag-cables ss &quot;C-&quot;))</p>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {["DWG", "DXF", "LSP", "Symbols"].map((t) => (
          <span
            key={t}
            className="rounded-md border border-navy-border px-2 py-1 text-[11px] font-semibold text-navy-muted"
          >
            {t}
          </span>
        ))}
      </div>
    </VisualShell>
  );
}

function TemplatesVisual() {
  const rows = [
    ["1", "Lighting — Floor 1", "3.2 kW", "16 A"],
    ["2", "Socket Outlets", "5.8 kW", "32 A"],
    ["3", "AHU-01", "11.0 kW", "40 A"],
    ["4", "Lift Motor", "7.5 kW", "32 A"],
    ["5", "Spare", "—", "—"],
  ];
  return (
    <VisualShell label="Panel Schedule — XLSX" meta="Template">
      <div className="overflow-hidden rounded-xl border border-navy-border">
        <div className="grid grid-cols-[28px_1fr_64px_56px] gap-2 border-b border-navy-border bg-white/[0.05] px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.06em] text-navy-muted">
          <span>#</span>
          <span>Circuit</span>
          <span>Load</span>
          <span>OCPD</span>
        </div>
        {rows.map((r) => (
          <div
            key={r[0]}
            className="grid grid-cols-[28px_1fr_64px_56px] gap-2 border-b border-navy-border px-3 py-2.5 text-[12px] text-navy-foreground last:border-b-0"
          >
            <span className="tabular-nums text-navy-muted">{r[0]}</span>
            <span className="min-w-0 truncate">{r[1]}</span>
            <span className="tabular-nums">{r[2]}</span>
            <span className="tabular-nums text-electric">{r[3]}</span>
          </div>
        ))}
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-navy-border p-3">
          <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-navy-muted">Title block</p>
          <p className="mt-1 text-[13px] font-semibold text-navy-foreground">MDB-01 — Ground Floor</p>
          <p className="mt-0.5 text-[11px] text-navy-muted">Rev. A · Sheet 1 of 3</p>
        </div>
        <div className="rounded-xl border border-navy-border p-3">
          <p className="text-[10px] font-semibold uppercase tracking-[0.1em] text-navy-muted">Report structure</p>
          <p className="mt-1 text-[12px] text-navy-foreground">Scope → Findings → CAPA → Close-out</p>
        </div>
      </div>
    </VisualShell>
  );
}

function CalculatorsVisual() {
  return (
    <VisualShell label="Voltage Drop Calculator" meta="Tool">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {[
          ["System", "400 V, 3-ph"],
          ["Load current", "120 A"],
          ["Run length", "85 m"],
        ].map(([k, v]) => (
          <div key={k} className="rounded-lg border border-navy-border bg-white/[0.03] px-3 py-2.5">
            <p className="text-[11px] font-medium uppercase tracking-[0.06em] text-navy-muted">{k}</p>
            <p className="mt-0.5 text-[13px] font-semibold text-navy-foreground">{v}</p>
          </div>
        ))}
      </div>
      <div className="mt-3 rounded-xl border border-electric/30 bg-electric/10 p-4">
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-electric">Voltage drop</p>
        <p className="mt-1 text-3xl font-bold tabular-nums text-navy-foreground">2.84%</p>
        <p className="mt-1 text-xs text-navy-muted">Within limit — example figures only.</p>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-3">
        {[
          ["Cable size", "70 mm²"],
          ["OCPD", "125 A"],
          ["Load", "83 kVA"],
        ].map(([k, v]) => (
          <div key={k} className="rounded-lg border border-navy-border px-3 py-2.5">
            <p className="text-[11px] font-medium uppercase tracking-[0.06em] text-navy-muted">{k}</p>
            <p className="mt-0.5 text-[13px] font-semibold tabular-nums text-navy-foreground">{v}</p>
          </div>
        ))}
      </div>
    </VisualShell>
  );
}

const visuals = {
  audit: AuditVisual,
  cad: CadVisual,
  templates: TemplatesVisual,
  calculators: CalculatorsVisual,
};

export function EcosystemShowcase() {
  const [activeId, setActiveId] = useState(tabs[0]!.id);
  const active = tabs.find((t) => t.id === activeId) ?? tabs[0]!;
  const Visual = visuals[active.visual];

  return (
    <section aria-labelledby="ecosystem-title" className="bg-navy py-16 sm:py-20 lg:py-24">
      <div className="container-page">
        <div className="max-w-2xl">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.14em] text-electric">
            One engineering workspace
          </p>
          <h2
            id="ecosystem-title"
            className="text-2xl font-bold leading-tight text-navy-foreground sm:text-3xl lg:text-4xl"
          >
            From design work to audit readiness.
          </h2>
          <p className="mt-4 text-[15px] leading-relaxed text-navy-muted sm:text-base">
            Calculators, compliance resources, CAD tools and ready-to-use engineering files — organized in
            one practical workspace.
          </p>
        </div>

        <div
          role="tablist"
          aria-label="OHMICLY ecosystem categories"
          className="-mx-4 mt-8 mb-6 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0"
        >
          {tabs.map((t) => {
            const on = t.id === active.id;
            return (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={on}
                aria-controls={`eco-panel-${t.id}`}
                id={`eco-tab-${t.id}`}
                onClick={() => setActiveId(t.id)}
                className={cn(
                  "min-h-11 shrink-0 rounded-xl border px-4 py-2.5 text-sm font-semibold transition-colors",
                  on
                    ? "border-electric bg-electric text-white"
                    : "border-navy-border text-navy-muted hover:border-electric/45 hover:text-navy-foreground",
                )}
              >
                <span className="sm:hidden">{t.short}</span>
                <span className="hidden sm:inline">{t.tab}</span>
              </button>
            );
          })}
        </div>

        <div
          role="tabpanel"
          id={`eco-panel-${active.id}`}
          aria-labelledby={`eco-tab-${active.id}`}
          key={active.id}
          className="grid animate-in fade-in duration-200 gap-5 lg:grid-cols-[57fr_43fr] lg:items-start lg:gap-8"
        >
          <Visual />

          <div className="min-w-0">
            <h3 className="text-lg font-semibold text-navy-foreground sm:text-xl">{active.title}</h3>
            <p className="mt-2 text-[13px] leading-relaxed text-navy-muted sm:text-sm">{active.desc}</p>
            <ul className="mt-4 flex flex-col gap-2">
              {active.links.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="group flex min-h-11 items-start gap-3 rounded-xl border border-navy-border bg-navy-panel px-4 py-3 transition-colors hover:border-electric/45"
                  >
                    <Icon name={l.icon} className="mt-0.5 h-4 w-4 shrink-0 text-electric" />
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="text-[14px] font-semibold text-navy-foreground">{l.label}</span>
                        {l.pro ? <ProBadge /> : null}
                      </span>
                      <span className="mt-0.5 block text-[12px] leading-relaxed text-navy-muted">{l.desc}</span>
                      {l.badge ? (
                        <span className="mt-1.5 inline-block rounded-md border border-navy-border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em] text-navy-muted">
                          {l.badge}
                        </span>
                      ) : null}
                    </span>
                    <ArrowRight
                      className="mt-0.5 h-4 w-4 shrink-0 text-navy-muted transition-colors group-hover:text-electric"
                      strokeWidth={2.2}
                      aria-hidden="true"
                    />
                  </a>
                </li>
              ))}
            </ul>

            <a
              href={active.cta.href}
              className="mt-5 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-electric transition-colors hover:text-navy-foreground"
            >
              {active.cta.label}
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
