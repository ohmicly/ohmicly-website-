import { createContext, useContext, type ReactNode } from "react";
import { EMPTY_PUBLIC_BRANDING, type PublicBranding } from "@/lib/branding";

const BrandingContext = createContext<PublicBranding>(EMPTY_PUBLIC_BRANDING);

export function BrandingProvider({ value, children }: { value: PublicBranding; children: ReactNode }) {
  return <BrandingContext.Provider value={value}>{children}</BrandingContext.Provider>;
}

export function useBranding() {
  return useContext(BrandingContext);
}