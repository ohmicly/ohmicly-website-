export function CtaSection() {
  return (
    <section className="container-page py-14 sm:py-18">
      <div className="relative overflow-hidden rounded-xl border border-primary/20 bg-primary px-6 py-9 text-primary-foreground sm:px-10 sm:py-11">
        <div aria-hidden="true" className="grid-blueprint absolute inset-0 opacity-20" />
        <div
          aria-hidden="true"
          className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-amber-accent/70 to-transparent"
        />
        <div className="relative max-w-2xl">
          <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
            Build Better Electrical Designs with OHMICLY
          </h2>
          <p className="mt-3 text-[15px] leading-relaxed text-primary-foreground/75">
            Explore practical engineering tools, professional resources and technical knowledge
            built for electrical professionals.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <a
              href="/calculator"
              className="inline-flex items-center justify-center rounded-xl bg-amber-accent px-5 py-3.5 text-base font-semibold text-amber-accent-foreground transition-opacity hover:opacity-90"
            >
              Explore Tools
            </a>
            <a
              href="/resources"
              className="inline-flex items-center justify-center rounded-xl border border-primary-foreground/30 px-5 py-3.5 text-base font-semibold text-primary-foreground transition-colors hover:bg-primary-foreground/10"
            >
              Browse Resources
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}