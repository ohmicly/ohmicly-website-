import { ShieldAlert } from "lucide-react";
import { ENGINEERING_DISCLAIMER } from "@/lib/site";

export function EngineeringDisclaimer({
  className,
  text,
}: {
  className?: string;
  /** Optional custom disclaimer text. Falls back to the global wording. */
  text?: string | null;
}) {
  return (
    <aside
      className={
        "flex gap-3 rounded-xl border border-amber-accent/30 bg-gold-soft/60 p-4 text-sm leading-relaxed text-amber-accent-foreground " +
        (className ?? "")
      }
    >
      <ShieldAlert className="mt-0.5 h-4.5 w-4.5 shrink-0" aria-hidden="true" />
      <p>
        <span className="font-semibold">Engineering disclaimer: </span>
        {text?.trim() ? text : ENGINEERING_DISCLAIMER}
      </p>
    </aside>
  );
}
