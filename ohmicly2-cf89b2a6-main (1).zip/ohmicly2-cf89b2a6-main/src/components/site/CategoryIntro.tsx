/** Short, factual introduction shown at the top of a category landing page. */
export function CategoryIntro({ heading, children }: { heading: string; children: React.ReactNode }) {
  return (
    <section aria-labelledby="category-intro-heading" className="container-page pt-10 sm:pt-14">
      <h2 id="category-intro-heading" className="text-xl font-bold text-primary sm:text-2xl">
        {heading}
      </h2>
      <div className="mt-3 max-w-3xl space-y-3 text-[15px] leading-relaxed text-muted-foreground">
        {children}
      </div>
    </section>
  );
}
