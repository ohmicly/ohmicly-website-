import { useEffect, useState, type MouseEvent } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useRouterState } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Crown, Flame, Loader2, Menu, X } from "lucide-react";
import { Icon } from "@/components/ui-kit/Icon";
import { Button } from "@/components/ui/button";
import { getPublicSidebarData } from "@/lib/content/public.functions";
import { cn } from "@/lib/utils";

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const loadSidebar = useServerFn(getPublicSidebarData);
  const location = useRouterState({ select: (state) => state.location });
  const sidebar = useQuery({
    queryKey: ["public-sidebar"],
    queryFn: () => loadSidebar(),
    staleTime: 5 * 60 * 1000,
  });

  if (sidebar.isLoading) {
    return (
      <div className="flex min-h-32 items-center justify-center text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" aria-label="Loading categories" />
      </div>
    );
  }

  const data = sidebar.data;
  if (!data) return null;

  const onResourcesPage = location.pathname === "/resources" || location.pathname === "/resources/";
  const search = location.search as Record<string, unknown>;
  const activeCategory = typeof search["category"] === "string" ? search["category"] : "";
  const activeSubcategory = typeof search["subcategory"] === "string" ? search["subcategory"] : "";
  const activeTopic = typeof search["q"] === "string" ? search["q"] : "";
  const allActive = onResourcesPage && !activeCategory && !activeSubcategory && !activeTopic;
  const itemClass =
    "flex min-h-11 items-center justify-between gap-2 rounded-lg px-3 text-sm transition-colors";
  const activeClass = "bg-primary text-primary-foreground shadow-sm";

  // Categories are grouped under their admin-defined group label.
  const groups: { label: string; categories: typeof data.categories }[] = [];
  for (const category of data.categories) {
    const existing = groups.find((g) => g.label === category.groupLabel);
    if (existing) existing.categories.push(category);
    else groups.push({ label: category.groupLabel, categories: [category] });
  }

  const handleClick = (event: MouseEvent<HTMLDivElement>) => {
    if (event.target instanceof Element && event.target.closest("a")) onNavigate?.();
  };

  return (
    <div className="space-y-6" onClick={handleClick}>
      <div>
        <p className="text-[11px] font-bold uppercase text-muted-foreground">Browse resources</p>
        <Link
          to="/resources"
          search={{}}
          resetScroll={false}
          activeOptions={{ exact: true }}
          aria-current={allActive ? "page" : undefined}
          className={cn(
            "mt-2 font-semibold",
            itemClass,
            allActive ? activeClass : "text-foreground hover:bg-surface",
          )}
        >
          <span className="flex min-w-0 items-center gap-2">
            <Icon
              name="file-text"
              className={cn("h-4 w-4 shrink-0", allActive ? "text-primary-foreground" : "text-electric")}
            />
            <span className="truncate">All Resources</span>
          </span>
          <span className={cn("text-xs", allActive ? "text-primary-foreground/75" : "text-muted-foreground")}>
            {data.totalResources}
          </span>
        </Link>
      </div>

      {groups.map((group) => (
        <div key={group.label}>
          <p className="text-[11px] font-bold uppercase text-muted-foreground">{group.label}</p>
          <ul className="mt-2 space-y-0.5">
            {group.categories.map((category) => (
              <li key={category.slug}>
                {(() => {
                  const categoryActive =
                    onResourcesPage && activeCategory === category.slug && !activeSubcategory;
                  return (
                    <Link
                      to="/resources"
                      search={{ category: category.slug }}
                      resetScroll={false}
                      activeOptions={{ exact: true }}
                      aria-current={categoryActive ? "page" : undefined}
                      className={cn(
                        itemClass,
                        "font-semibold",
                        categoryActive ? activeClass : "text-foreground hover:bg-surface",
                      )}
                    >
                      <span className="flex min-w-0 items-center gap-2">
                        <Icon
                          name={category.icon}
                          className={cn(
                            "h-4 w-4 shrink-0",
                            categoryActive ? "text-primary-foreground" : "text-muted-foreground",
                          )}
                        />
                        <span className="truncate">{category.name}</span>
                      </span>
                      <span
                        className={cn(
                          "shrink-0 text-xs",
                          categoryActive ? "text-primary-foreground/75" : "text-muted-foreground",
                        )}
                      >
                        {category.count}
                      </span>
                    </Link>
                  );
                })()}
                {category.subcategories.length ? (
                  <ul className="ml-5 border-l border-border pl-2">
                    {category.subcategories.map((sub) => {
                      const subcategoryActive =
                        onResourcesPage &&
                        activeCategory === category.slug &&
                        activeSubcategory === sub.slug;
                      return (
                        <li key={sub.slug}>
                          <Link
                            to="/resources"
                            search={{ category: category.slug, subcategory: sub.slug }}
                            resetScroll={false}
                            activeOptions={{ exact: true }}
                            aria-current={subcategoryActive ? "page" : undefined}
                            className={cn(
                              itemClass,
                              "min-h-10",
                              subcategoryActive
                                ? activeClass
                                : "text-muted-foreground hover:bg-surface hover:text-foreground",
                            )}
                          >
                            <span className="truncate">{sub.name}</span>
                            <span
                              className={cn(
                                "shrink-0 text-xs",
                                subcategoryActive ? "text-primary-foreground/75" : undefined,
                              )}
                            >
                              {sub.count}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                ) : null}
              </li>
            ))}
          </ul>
        </div>
      ))}

      <div className="border-t border-border pt-5">
        <p className="flex items-center gap-2 text-[11px] font-bold uppercase text-muted-foreground">
          <Flame className="h-3.5 w-3.5 text-premium" aria-hidden="true" /> Popular topics
        </p>
        <ul className="mt-2 space-y-0.5">
          {data.topics.map((topic) => (
            <li key={topic.label}>
              {(() => {
                const topicActive = onResourcesPage && activeTopic === topic.label;
                return (
                  <Link
                    to="/resources"
                    search={{ q: topic.label }}
                    resetScroll={false}
                    activeOptions={{ exact: true }}
                    aria-current={topicActive ? "page" : undefined}
                    className={cn(
                      itemClass,
                      topicActive ? activeClass : "text-foreground hover:bg-surface",
                    )}
                  >
                    <span className="truncate">{topic.label}</span>
                    {topic.score > 0 ? (
                      <span
                        className={cn(
                          "shrink-0 text-xs",
                          topicActive ? "text-primary-foreground/75" : "text-muted-foreground",
                        )}
                      >
                        {topic.score}
                      </span>
                    ) : null}
                  </Link>
                );
              })()}
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-lg border border-gold/35 bg-gold-soft p-4">
        <Crown className="h-5 w-5 text-premium" aria-hidden="true" />
        <p className="mt-2 text-sm font-bold text-amber-accent-foreground">Premium resources</p>
        <Link to="/premium" className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-primary">
          Explore premium
        </Link>
      </div>
    </div>
  );
}

export function PublicSidebar() {
  return (
    <aside className="hidden w-62 shrink-0 border-r border-border bg-card lg:block" aria-label="Resource categories and popular topics">
      <div className="sticky top-20 max-h-[calc(100vh-5rem)] overflow-y-auto px-5 py-7">
        <SidebarContent />
      </div>
    </aside>
  );
}

export function MobilePublicSidebar() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [open]);

  return (
    <div className="lg:hidden">
      <Button
        type="button"
        size="icon"
        onClick={() => setOpen(true)}
        aria-label="Open resource menu"
        aria-expanded={open}
        aria-controls="mobile-resource-sidebar"
        className={cn(
          "fixed bottom-[max(1.25rem,env(safe-area-inset-bottom))] right-[max(1.25rem,env(safe-area-inset-right))] z-[60] h-13 w-13 rounded-full border border-primary-foreground/20 shadow-card-hover",
          open && "pointer-events-none opacity-0",
        )}
      >
        <Menu className="h-6 w-6" aria-hidden="true" />
      </Button>

      <div
        className={cn(
          "fixed inset-0 z-[70] transition-visibility duration-300",
          open ? "visible" : "invisible delay-300",
        )}
        aria-hidden={!open}
      >
        <button
          type="button"
          tabIndex={open ? 0 : -1}
          aria-label="Close resource menu"
          onClick={() => setOpen(false)}
          className={cn(
            "absolute inset-0 bg-foreground/40 transition-opacity duration-300 motion-reduce:transition-none",
            open ? "opacity-100" : "opacity-0",
          )}
        />
        <aside
          id="mobile-resource-sidebar"
          role="dialog"
          aria-modal="true"
          aria-label="Resource categories and popular topics"
          className={cn(
            "absolute inset-y-0 left-0 flex h-[100dvh] w-3/4 flex-col border-r border-border bg-card shadow-card-hover transition-transform duration-300 ease-out motion-reduce:transition-none",
            open ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <div className="flex shrink-0 items-center justify-between border-b border-border px-5 py-4">
            <p className="font-display text-base font-bold text-primary">Browse OHMICLY</p>
            <Button
              type="button"
              variant="outline"
              size="icon"
              tabIndex={open ? 0 : -1}
              onClick={() => setOpen(false)}
              aria-label="Close resource menu"
              className="h-10 w-10"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </Button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 py-6 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
            <SidebarContent onNavigate={() => setOpen(false)} />
          </div>
        </aside>
      </div>
    </div>
  );
}