import { useState } from "react";
import {
  ArrowRight,
  BookOpenText,
  Calculator,
  Check,
  ClipboardCheck,
  PenTool,
  type LucideIcon,
} from "lucide-react";

import cadImage from "@/assets/service-cad.jpg";
import calculatorsImage from "@/assets/service-calculators.jpg";
import complianceImage from "@/assets/service-compliance.jpg";
import knowledgeImage from "@/assets/service-knowledge.jpg";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type ServiceItem = {
  id: string;
  label: string;
  icon: LucideIcon;
  title: string;
  description: string;
  benefits: string[];
  href: string;
  linkLabel: string;
  image: string;
  imageAlt: string;
};

const services: [ServiceItem, ...ServiceItem[]] = [
  {
    id: "calculators",
    label: "Engineering Tools",
    icon: Calculator,
    title: "Fast, dependable calculations for everyday design work",
    description:
      "Solve common electrical engineering problems with focused tools built for practical project decisions, from early estimates to final design checks.",
    benefits: [
      "Voltage drop, cable sizing, load and OCPD tools",
      "Clear inputs with traceable engineering results",
      "Free access on desktop and mobile",
    ],
    href: "/calculator",
    linkLabel: "Explore calculators",
    image: calculatorsImage,
    imageAlt: "Electrical engineer using calculation tools beside a distribution panel",
  },
  {
    id: "compliance",
    label: "Audit & Compliance",
    icon: ClipboardCheck,
    title: "Field-ready resources for safer electrical installations",
    description:
      "Prepare inspections and corrective-action work with structured resources aligned to the needs of Bangladesh's industrial electrical teams.",
    benefits: [
      "RSC and Nirapon audit resources",
      "Inspection checklists and reporting templates",
      "Practical electrical safety references",
    ],
    href: "/resources",
    linkLabel: "Browse audit resources",
    image: complianceImage,
    imageAlt: "Electrical safety auditor inspecting an industrial distribution panel",
  },
  {
    id: "cad",
    label: "CAD Resources",
    icon: PenTool,
    title: "Production-ready drafting resources for electrical projects",
    description:
      "Move from design intent to coordinated drawings faster with reusable CAD resources made for professional electrical documentation.",
    benefits: [
      "Single-line diagram and drawing templates",
      "Electrical symbols and AutoLISP utilities",
      "Editable files for real project workflows",
    ],
    href: "/autocad",
    linkLabel: "View CAD resources",
    image: cadImage,
    imageAlt: "Engineer preparing a technical electrical drawing in CAD",
  },
  {
    id: "knowledge",
    label: "Knowledge",
    icon: BookOpenText,
    title: "Technical guidance grounded in engineering practice",
    description:
      "Build confidence in design, safety and compliance decisions through focused articles and reference-led explanations for working engineers.",
    benefits: [
      "Practical electrical design guidance",
      "Standards and compliance perspectives",
      "Bangladesh-focused engineering knowledge",
    ],
    href: "/blog",
    linkLabel: "Read engineering articles",
    image: knowledgeImage,
    imageAlt: "Electrical engineers reviewing drawings and technical references together",
  },
];

export function ResourcePoster() {
  const [activeId, setActiveId] = useState(services[0].id);
  const active = services.find((service) => service.id === activeId) ?? services[0];

  return (
    <section className="border-y border-border bg-card py-14 sm:py-18" aria-labelledby="platform-heading">
      <div className="container-page">
        <div className="max-w-4xl">
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-electric">OHMICLY Platform</p>
          <h2
            id="platform-heading"
            className="mt-3 text-2xl font-bold leading-tight text-foreground sm:text-3xl lg:text-4xl"
          >
            Practical electrical engineering resources for every stage of your work
          </h2>
        </div>

        <div className="mt-7 overflow-x-auto rounded-xl border border-border bg-surface p-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:mt-9">
          <div className="grid min-w-max grid-cols-4 gap-1 lg:min-w-0">
            {services.map((service) => {
              const TabIcon = service.icon;
              const selected = service.id === active.id;
              return (
                <Button
                  key={service.id}
                  type="button"
                  variant="ghost"
                  role="tab"
                  aria-selected={selected}
                  aria-controls="platform-service-panel"
                  onClick={() => setActiveId(service.id)}
                  className={cn(
                    "h-11 min-w-[10.5rem] gap-2 rounded-lg px-4 text-sm font-semibold transition-colors lg:min-w-0",
                    selected
                      ? "border border-border bg-card text-electric shadow-card hover:bg-card hover:text-electric"
                      : "text-muted-foreground hover:bg-surface-strong hover:text-foreground",
                  )}
                >
                  <TabIcon className="h-4 w-4 shrink-0" strokeWidth={2.2} aria-hidden="true" />
                  {service.label}
                </Button>
              );
            })}
          </div>
        </div>

        <div
          id="platform-service-panel"
          role="tabpanel"
          className="mt-8 grid min-w-0 gap-7 md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)] md:items-center md:gap-12 lg:gap-16"
        >
          <div className="aspect-[4/3] min-w-0 overflow-hidden rounded-lg border border-border bg-surface shadow-card">
            <img
              key={active.image}
              src={active.image}
              alt={active.imageAlt}
              width={1200}
              height={912}
              loading="lazy"
              className="h-full w-full object-cover motion-safe:animate-in motion-safe:fade-in motion-safe:duration-300"
            />
          </div>

          <div key={active.id} className="min-w-0 motion-safe:animate-in motion-safe:fade-in motion-safe:duration-300">
            <h3 className="text-xl font-bold leading-tight text-foreground sm:text-2xl">{active.title}</h3>
            <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
              {active.description}
            </p>

            <ul className="mt-5 space-y-3">
              {active.benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3 text-sm font-medium text-foreground">
                  <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-electric">
                    <Check className="h-3 w-3" strokeWidth={3} aria-hidden="true" />
                  </span>
                  <span className="min-w-0 leading-relaxed">{benefit}</span>
                </li>
              ))}
            </ul>

            <a
              href={active.href}
              className="group mt-7 inline-flex items-center gap-2 text-sm font-bold text-electric hover:text-primary"
            >
              {active.linkLabel}
              <ArrowRight
                className="h-4 w-4 transition-transform group-hover:translate-x-1"
                strokeWidth={2.4}
                aria-hidden="true"
              />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}