import { Link } from "@tanstack/react-router";
import { ArrowRight, BookOpen } from "lucide-react";
import { SectionHeader } from "@/components/ui-kit/SectionHeader";
import { cn } from "@/lib/utils";
import type { Article } from "@/lib/content/types";
import { thumbVariant } from "@/lib/images/process";

const linkBtn =
  "inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-semibold text-primary transition-colors hover:border-electric/40";

function HomeBlogCard({ article }: { article: Article }) {
  return (
    <article className="group flex h-full min-w-0 flex-col overflow-hidden rounded-xl border border-border bg-card shadow-card transition-shadow hover:shadow-card-hover">
      <Link
        to="/blog/$slug"
        params={{ slug: article.slug }}
        className="block aspect-[16/9] overflow-hidden bg-surface"
      >
        {article.cover_image_url ? (
          <img
            src={thumbVariant(article.cover_image_url)}
            alt={`${article.title} cover`}
            loading="lazy"
            decoding="async"
            width={400}
            height={225}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
          />
        ) : (
          <div className="grid-blueprint flex h-full items-center justify-center">
            <BookOpen className="h-8 w-8 text-electric/55" aria-hidden="true" />
          </div>
        )}
      </Link>
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.08em] text-electric">
          <span>{article.category}</span>
          <span aria-hidden="true" className="text-border">•</span>
          <span className="normal-case text-muted-foreground">{article.reading_time}</span>
        </div>
        <h3 className="mt-2 line-clamp-2 text-[15px] font-bold leading-snug text-foreground">
          <Link to="/blog/$slug" params={{ slug: article.slug }} className="hover:text-primary">
            {article.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-muted-foreground">
          {article.excerpt}
        </p>
        <Link
          to="/blog/$slug"
          params={{ slug: article.slug }}
          className="mt-4 inline-flex items-center gap-1.5 border-t border-border pt-3.5 text-sm font-semibold text-primary"
        >
          Read Article
          <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
        </Link>
      </div>
    </article>
  );
}

export function HomeBlogSection({ articles }: { articles: Article[] }) {
  if (articles.length === 0) return null;

  return (
    <section className="container-page py-14 sm:py-18">
      <SectionHeader
        eyebrow="OHMICLY Journal"
        title="From the Blog"
        subtitle="Practical guidance on design, safety, compliance and audit practice for electrical engineers."
        action={
          <Link to="/blog" className={cn(linkBtn, "hidden md:inline-flex")}>
            View All Articles
            <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
          </Link>
        }
      />

      {/* Mobile: swipeable horizontal carousel, one card per view */}
      <div
        className={cn(
          "-mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-2",
          "[scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
          "sm:hidden",
        )}
      >
        {articles.map((article) => (
          <div key={article.id} className="w-[85%] shrink-0 snap-start">
            <HomeBlogCard article={article} />
          </div>
        ))}
      </div>

      {/* Desktop / tablet: 4-column grid */}
      <div className="hidden sm:grid sm:grid-cols-2 sm:gap-4 lg:grid-cols-4">
        {articles.slice(0, 8).map((article) => (
          <HomeBlogCard key={article.id} article={article} />
        ))}
      </div>

      <div className="mt-5 sm:hidden">
        <Link
          to="/blog"
          className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-border bg-card px-4 py-3 text-sm font-semibold text-primary"
        >
          View all articles
          <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
        </Link>
      </div>
    </section>
  );
}
