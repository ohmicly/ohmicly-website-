import { useEffect } from "react";
import { X, UserRound } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { navItems } from "@/data/site";
import { SearchBar } from "@/components/ui-kit/SearchBar";
import { Logo } from "./Logo";
import { useAuth } from "@/hooks/useAuth";

export function MobileNav({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user } = useAuth();

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
      <button
        type="button"
        className="absolute inset-0 bg-foreground/40"
        aria-label="Close menu"
        onClick={onClose}
      />
      <div className="absolute inset-x-0 top-0 flex max-h-[100dvh] flex-col rounded-b-2xl border-b border-border bg-card p-5 shadow-card-hover">
        <div className="flex shrink-0 items-center justify-between">
          <Logo />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-border text-foreground"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-4 shrink-0">
          <SearchBar id="mobile-menu-search" placeholder="Search calculators, files, guides..." />
        </div>

        <nav className="mt-4 grid min-h-0 flex-1 gap-1 overflow-y-auto overscroll-contain" aria-label="Mobile">
          {navItems.map((item) => (
            <a
              key={`${item.label}-${item.href}`}
              href={item.href}
              className="shrink-0 rounded-xl px-3 py-3 text-base font-semibold text-foreground transition-colors hover:bg-surface"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <Link
          to={user ? "/account" : "/auth"}
          onClick={onClose}
          className="mt-4 flex w-full shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3.5 text-base font-semibold text-primary-foreground"
        >
          <UserRound className="h-5 w-5" aria-hidden="true" />
          {user ? "My account" : "Login / Sign up"}
        </Link>
      </div>
    </div>
  );
}