import { Facebook, Linkedin, Youtube } from "lucide-react";
import { footerColumns } from "@/data/site";
import { Logo } from "./Logo";

const socials = [
  { label: "LinkedIn", href: "#", icon: Linkedin },
  { label: "Facebook", href: "#", icon: Facebook },
  { label: "YouTube", href: "#", icon: Youtube },
];

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#011A2E] text-primary-foreground">
      <div className="container-page py-12">
        <div className="lg:flex lg:gap-14">
          <div className="max-w-sm lg:w-[30%] lg:shrink-0">
            <Logo tone="light" />
            <p className="mt-3 text-sm leading-relaxed text-primary-foreground/70">
              OHMICLY is an electrical engineering platform for practical calculators, audit
              resources, CAD files and technical knowledge — built for engineers working in
              Bangladesh and beyond.
            </p>
            <div className="mt-5 flex gap-2">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-primary-foreground/20 text-primary-foreground/80 transition-colors hover:bg-primary-foreground/10"
                >
                  <s.icon className="h-4.5 w-4.5" strokeWidth={1.9} aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-8 sm:grid-cols-4 lg:mt-0 lg:flex-1 lg:gap-10">
            {footerColumns.map((col) => (
              <nav key={col.heading} aria-label={col.heading} className="min-w-0">
                <h3 className="text-sm font-semibold uppercase tracking-[0.1em] text-primary-foreground">
                  {col.heading}
                </h3>
                <ul className="mt-3 space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link.href}>
                      <a
                        href={link.href}
                        className="text-sm text-primary-foreground/70 transition-colors hover:text-primary-foreground"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-primary-foreground/15 pt-6 text-xs text-primary-foreground/60 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} OHMICLY. All rights reserved.</p>
          <p>Electrical engineering tools, resources and knowledge.</p>
        </div>
      </div>
    </footer>
  );
}