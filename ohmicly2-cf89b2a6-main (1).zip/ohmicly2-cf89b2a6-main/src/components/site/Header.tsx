import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Search, UserRound } from "lucide-react";
import { navItems } from "@/data/site";
import { Logo } from "./Logo";
import { MobileNav } from "./MobileNav";
import { SearchBar } from "@/components/ui-kit/SearchBar";
import { useAuth } from "@/hooks/useAuth";

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/92 backdrop-blur">
      <div className="container-page">
        <div className="grid h-15 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 lg:flex lg:h-16 lg:justify-between">
          <div className="flex min-w-0 items-center gap-9">
            <Logo />
            <nav className="hidden items-center gap-0.5 lg:flex" aria-label="Main">
              {navItems.map((item) => (
                <a
                  key={`${item.label}-${item.href}`}
                  href={item.href}
                  className="rounded-lg px-3 py-2 text-[14px] font-medium text-foreground/75 transition-colors hover:bg-surface hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                >
                  {item.label}
                </a>
              ))}
            </nav>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={() => setSearchOpen((v) => !v)}
              aria-expanded={searchOpen}
              aria-label="Toggle search"
              className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border text-foreground transition-colors hover:border-electric/40 hover:text-electric lg:h-10 lg:w-10"
            >
              <Search className="h-5 w-5" strokeWidth={1.9} aria-hidden="true" />
            </button>
            <Link
              to={user ? "/account" : "/auth"}
              className="hidden items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 lg:inline-flex"
            >
              <UserRound className="h-4 w-4" aria-hidden="true" />
              {user ? "Account" : "Login"}
            </Link>
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu"
              className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border text-foreground lg:hidden"
            >
              <Menu className="h-5 w-5" strokeWidth={1.9} aria-hidden="true" />
            </button>
          </div>
        </div>

        {searchOpen ? (
          <div className="pb-3">
            <SearchBar id="header-search" />
          </div>
        ) : null}
      </div>

      <MobileNav open={menuOpen} onClose={() => setMenuOpen(false)} />
    </header>
  );
}