import { Header } from "./Header";
import { Footer } from "./Footer";
import { MobilePublicSidebar, PublicSidebar } from "./PublicSidebar";
import { Breadcrumbs, type Crumb } from "@/components/ui-kit/Breadcrumbs";

export function PageLayout({
  children,
  crumbs,
  showSidebar = true,
}: {
  children: React.ReactNode;
  crumbs?: Crumb[];
  showSidebar?: boolean;
}) {
  return (
    <div className="flex min-h-screen flex-col overflow-x-hidden bg-background">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <Header />
      <main id="main" className="flex flex-1 flex-col">
        <div className={showSidebar ? "flex min-w-0 flex-1 flex-col lg:flex-row" : "flex min-w-0 flex-1 flex-col"}>
          {showSidebar ? <PublicSidebar /> : null}
          <div className="min-w-0 flex-1">
            {crumbs ? (
              <div className="border-b border-border bg-surface">
                <div className="container-page py-3">
                  <Breadcrumbs items={crumbs} />
                </div>
              </div>
            ) : null}
            {children}
          </div>
        </div>
      </main>
      <Footer />
      <MobilePublicSidebar />
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-border bg-surface">
      <div aria-hidden="true" className="grid-blueprint absolute inset-0 opacity-45" />
      <div className="container-page relative py-10 sm:py-12">
        <div className="max-w-3xl">
          {eyebrow ? (
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-electric">{eyebrow}</p>
          ) : null}
          <h1 className="mt-2 text-[1.75rem] font-extrabold leading-[1.12] tracking-[-0.03em] text-primary sm:text-4xl">
            {title}
          </h1>
          {description ? (
            <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground sm:text-base">
              {description}
            </p>
          ) : null}
          {actions ? <div className="mt-5 flex flex-col gap-3 sm:flex-row">{actions}</div> : null}
        </div>
      </div>
    </section>
  );
}
