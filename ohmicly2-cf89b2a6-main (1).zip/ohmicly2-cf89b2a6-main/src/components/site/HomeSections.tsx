import { ArrowRight, Download } from "lucide-react";
import { SectionHeader } from "@/components/ui-kit/SectionHeader";
import { Icon } from "@/components/ui-kit/Icon";
import {
  BlogCard,
  CalculatorCard,
  CategoryCard,
  PremiumCard,
  ResourceCard,
} from "@/components/ui-kit/Cards";
import { whyPoints } from "@/data/site";
import type { RscItem } from "@/data/site";
import { cn } from "@/lib/utils";
import type { Article, CalculatorDef, Category, Resource } from "@/lib/content/types";
import { thumbVariant } from "@/lib/images/process";

const linkBtn =
  "inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-semibold text-primary transition-colors hover:border-electric/40";

// On mobile only the first 3 cards of a section are shown; the rest live on the
// dedicated page reachable through the "View all" link below the grid.
const mobileClamp3 = "[&>*:nth-child(n+4)]:hidden sm:[&>*:nth-child(n+4)]:block";

function MobileViewAll({ href, label }: { href: string; label: string }) {
  return (
    <div className="mt-5 sm:hidden">
      <a
        href={href}
        className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-border bg-card px-4 py-3 text-sm font-semibold text-primary"
      >
        {label}
        <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
      </a>
    </div>
  );
}

export function CalculatorsSection({ items }: { items: CalculatorDef[] }) {
  return (
    <section className="container-page py-14 sm:py-18">
      <SectionHeader
        eyebrow="Tools"
        title="Engineering Calculators"
        subtitle="Practical tools for everyday electrical engineering work."
        action={
          <a href="/calculator" className={cn(linkBtn, "hidden md:inline-flex")}>
            View All Calculators
            <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
          </a>
        }
      />
      <div className={cn("grid gap-4 sm:grid-cols-2 lg:grid-cols-3", mobileClamp3)}>
        {items.map((item) => (
          <CalculatorCard key={item.slug} item={item} />
        ))}
      </div>
      <MobileViewAll href="/calculator" label="View all calculators" />
    </section>
  );
}

const fileBadge: Record<string, string> = {
  XLSX: "bg-free text-white",
  PDF: "bg-destructive text-destructive-foreground",
  DOCX: "bg-electric text-white",
};

/** Lightweight CSS/SVG document previews — no imagery required. */
function CardPreview({ kind }: { kind: RscItem["preview"] }) {
  if (kind === "shield") {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="relative">
          <div className="h-16 w-24 rounded-md border border-border bg-card" />
          <span className="absolute -right-3 -top-3 inline-flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-card">
            <Icon name="shield-check" className="h-5 w-5" />
          </span>
        </div>
      </div>
    );
  }
  const rows = kind === "sheet" ? 7 : kind === "doc" ? 5 : 6;
  const cols = kind === "doc" ? 3 : 5;
  return (
    <div className="mx-auto h-full w-[78%] rounded-md border border-border bg-card p-2">
      <div className="mb-1.5 h-1.5 w-1/2 rounded-full bg-primary/25" />
      <div className="space-y-1">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex gap-1">
            {Array.from({ length: cols }).map((__, c) => (
              <span
                key={c}
                className={cn(
                  "h-1.5 flex-1 rounded-sm",
                  r === 0 ? "bg-primary/20" : c === 0 ? "bg-muted-foreground/25" : "bg-muted-foreground/12",
                )}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function previewKind(item: Resource): RscItem["preview"] {
  if (item.file_type === "XLSX") return "sheet";
  if (item.file_type === "DOCX") return "doc";
  if (item.resource_type === "checklist") return "shield";
  return "table";
}

function RscResourceCard({ item }: { item: Resource }) {
  return (
    <a
      href={`/resources/${item.slug}`}
      className="group flex h-full flex-col rounded-xl border border-border bg-card p-3 shadow-card transition-all hover:-translate-y-0.5 hover:border-electric/40 hover:shadow-card-hover"
    >
      <div
        className={cn(
          "relative h-32 overflow-hidden rounded-lg border border-border bg-surface",
          item.thumbnail_url ? "" : "p-3",
        )}
      >
        <span
          className={cn(
            "absolute left-2 top-2 z-10 rounded px-1.5 py-0.5 text-[10px] font-bold tracking-wide",
            fileBadge[item.file_type] ?? "bg-primary text-primary-foreground",
          )}
        >
          {item.file_type}
        </span>
        {item.thumbnail_url ? (
          <img
            src={thumbVariant(item.thumbnail_url)}
            alt={`${item.title} preview`}
            loading="lazy"
            decoding="async"
            width={400}
            height={300}
            className="h-full w-full object-cover"
          />
        ) : (
          <CardPreview kind={previewKind(item)} />
        )}
      </div>
      <h3 className="mt-4 px-1 text-[15px] font-semibold leading-snug text-foreground">{item.title}</h3>
      <p className="mt-1.5 flex-1 px-1 text-sm leading-relaxed text-muted-foreground line-clamp-3">
        {item.description.replace(/<[^>]*>/g, " ").trim()}
      </p>
      <div className="mt-4 flex items-center justify-between gap-3 px-1">
        <span className="text-xs font-medium text-muted-foreground">
          {item.file_type} · {item.download_count} downloads
        </span>
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-surface text-primary transition-colors group-hover:border-electric/40 group-hover:text-electric">
          <Download className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
        </span>
      </div>
    </a>
  );
}

export function RscSection({ items }: { items: Resource[] }) {
  if (!items.length) return null;
  return (
    <section className="border-y border-border bg-background">
      <div className="container-page py-14 sm:py-18">
        <div className="mb-7 flex flex-col gap-3 sm:mb-9 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0 max-w-2xl">
            <h2 className="text-2xl font-bold leading-tight text-primary sm:text-[2rem]">
              Popular RSC &amp; NIRAPON Resources
            </h2>
            <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">
              Most downloaded audit checklists, reporting templates and electrical safety resources.
            </p>
          </div>
          <a
            href="/resources"
            className="hidden shrink-0 items-center gap-1.5 text-sm font-semibold text-electric sm:inline-flex"
          >
            View all resources
            <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
          </a>
        </div>
        <div className={cn("grid gap-4 sm:grid-cols-2 lg:grid-cols-4", mobileClamp3)}>
          {items.map((item) => (
            <RscResourceCard key={item.slug} item={item} />
          ))}
        </div>
        <MobileViewAll href="/resources" label="View all RSC resources" />
      </div>
    </section>
  );
}


export function CadSection({ items }: { items: Resource[] }) {
  return (
    <section className="container-page py-14 sm:py-18">
      <SectionHeader
        eyebrow="Drafting"
        title="AutoCAD & AutoLISP"
        subtitle="DWG resources, electrical symbols, SLD templates and drafting utilities."
        action={
          <div className="flex gap-2">
            <a href="/autocad" className={linkBtn}>
              AutoCAD
            </a>
            <a href="/autolisp" className={linkBtn}>
              AutoLISP
            </a>
          </div>
        }
      />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => (
          <ResourceCard key={item.slug} item={item} />
        ))}
      </div>
    </section>
  );
}

export function TemplatesSection({ items }: { items: Resource[] }) {
  return (
    <section className="border-y border-border bg-surface">
      <div className="container-page py-14 sm:py-18">
        <SectionHeader
          eyebrow="Templates"
          title="Engineering Templates"
          subtitle="Panel schedules, load schedules, earthing sheets, inspection and reporting formats."
          action={
            <a href="/templates" className={linkBtn}>
              Browse templates
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
            </a>
          }
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((item) => (
            <ResourceCard key={item.slug} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
}

export function ResourceLibrarySection({ items }: { items: Category[] }) {
  return (
    <section className="container-page py-14 sm:py-18">
      <SectionHeader
        eyebrow="Library"
        title="Explore Engineering Resources"
        subtitle="Browse by category — drawings, tools, checklists, templates and reference material."
      />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
        {items.map((item) => (
          <CategoryCard key={item.slug} item={item} />
        ))}
      </div>
    </section>
  );
}

export function FreeResourcesSection({ items }: { items: Resource[] }) {
  return (
    <section className="border-y border-border bg-surface">
      <div className="container-page py-14 sm:py-18">
        <SectionHeader
          eyebrow="Downloads"
          title="Free Engineering Resources"
          subtitle="Openly accessible drawings, checklists and templates in working formats."
          action={
            <a href="/resources" className={cn(linkBtn, "hidden md:inline-flex")}>
              Browse all resources
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
            </a>
          }
        />
        <div className={cn("grid gap-4 sm:grid-cols-2 lg:grid-cols-3", mobileClamp3)}>
          {items.map((item) => (
            <ResourceCard key={item.slug} item={item} />
          ))}
        </div>
        <MobileViewAll href="/resources" label="View all free resources" />
      </div>
    </section>
  );
}

export function PremiumSection({ items }: { items: Resource[] }) {
  return (
    <section className="container-page py-14 sm:py-18">
      <SectionHeader
        eyebrow="Premium"
        title="Professional Premium Resources"
        subtitle="Production-ready engineering files prepared for professional project work."
        action={
          <a
            href="/premium"
            className="hidden items-center gap-1.5 rounded-lg bg-premium-gradient px-4 py-2.5 text-sm font-semibold text-white md:inline-flex"
          >
            View premium
            <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
          </a>
        }
      />
      <p className="mb-7 text-sm text-muted-foreground sm:mb-9">Premium access coming soon.</p>
      <div className={cn("grid gap-4 sm:grid-cols-2 lg:grid-cols-4", mobileClamp3)}>
        {items.map((item) => (
          <PremiumCard key={item.slug} item={item} />
        ))}
      </div>
      <MobileViewAll href="/premium" label="View all premium resources" />
    </section>
  );
}

export function KnowledgeSection({ items }: { items: Article[] }) {
  return (
    <section className="border-t border-border bg-surface">
      <div className="container-page py-14 sm:py-18">
        <SectionHeader
          eyebrow="Knowledge"
          title="Electrical Engineering Knowledge"
          subtitle="Technical articles on design, safety, earthing and audit practice."
          action={
            <a href="/blog" className={cn(linkBtn, "hidden md:inline-flex")}>
              Read the blog
              <ArrowRight className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
            </a>
          }
        />
        <div className={cn("grid gap-4 sm:grid-cols-2 lg:grid-cols-4", mobileClamp3)}>
          {items.map((item) => (
            <BlogCard key={item.slug} item={item} />
          ))}
        </div>
        <MobileViewAll href="/blog" label="View all articles" />
      </div>
    </section>
  );
}

export function WhySection() {
  return (
    <section className="border-t border-border bg-card">
      <div className="container-page py-14 sm:py-18">
        <SectionHeader
          eyebrow="Why OHMICLY"
          title="Built for working electrical engineers"
          subtitle="Tools and references that match how engineering work is actually done."
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {whyPoints.map((point) => (
            <div key={point.title} className="flex gap-3.5">
              <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-border bg-surface text-electric">
                <Icon name={point.icon} className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <h3 className="text-[15px] font-semibold text-foreground">{point.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{point.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
