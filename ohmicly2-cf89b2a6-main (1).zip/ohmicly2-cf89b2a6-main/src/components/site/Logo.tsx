import { useState } from "react";
import { useBranding } from "./BrandingProvider";

export function DefaultLogoVisual({ tone = "dark" }: { tone?: "dark" | "light" }) {
  return (
    <>
      <span
        className={
          tone === "light"
            ? "inline-flex h-8 w-8 items-center justify-center rounded-lg bg-primary-foreground/12 text-primary-foreground"
            : "inline-flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground"
        }
      >
        <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" aria-hidden="true">
          <path d="M13 2 4.5 13.5H11L10 22l9-11.8h-6.4L13 2Z" fill="currentColor" />
        </svg>
      </span>
      <span
        className={
          tone === "light"
            ? "font-display text-lg font-extrabold tracking-[0.08em] text-primary-foreground"
            : "font-display text-lg font-extrabold tracking-[0.08em] text-foreground"
        }
      >
        OHMICLY
      </span>
    </>
  );
}

export function Logo({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const { logoUrl } = useBranding();
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const showCustom = Boolean(logoUrl && failedUrl !== logoUrl);

  return (
    <a href="/" className="flex min-w-0 items-center gap-2" aria-label="OHMICLY home">
      {showCustom ? (
        <img
          src={logoUrl ?? undefined}
          alt="OHMICLY"
          className="h-8 w-auto max-w-44 object-contain sm:max-w-52"
          onError={() => setFailedUrl(logoUrl)}
        />
      ) : (
        <DefaultLogoVisual tone={tone} />
      )}
    </a>
  );
}