import { ArrowRight, User, Users } from "lucide-react";

const PRO_ORANGE = "#F97316";

const plans = [
  {
    name: "Free",
    description: "No sign up required",
    price: "0.00৳",
    period: "/month",
    icon: User,
    href: "/premium",
    theme: "light" as const,
  },
  {
    name: "Pro",
    description: "Get all accrss\nOne time Payment",
    price: "999.00৳",
    period: "Year",
    icon: Users,
    href: "/premium",
    theme: "solid" as const,
  },
];

export function PremiumUpgrade() {
  return (
    <section className="container-page py-14 sm:py-18">
      <div className="overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-card sm:p-8 lg:p-10">
        <div className="grid items-center gap-8 lg:grid-cols-[1fr_auto_1fr]">
          {/* Left: pitch */}
          <div className="max-w-md">
            <span
              className="inline-flex rounded-md px-3 py-1 text-[11px] font-bold uppercase tracking-wider"
              style={{ backgroundColor: "#0F172A", color: "#FFFFFF" }}
            >
              Go Premium
            </span>
            <h2 className="mt-4 text-2xl font-bold leading-tight text-foreground sm:text-3xl">
              Upgrade to{" "}
              <span style={{ color: PRO_ORANGE }}>Premium</span>
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-[15px]">
              Unlock unlimited access to premium resources, advanced tools and priority support.
            </p>
          </div>

          {/* Divider */}
          <div className="hidden h-32 w-px bg-border lg:block" aria-hidden="true" />

          {/* Right: plans */}
          <div className="grid gap-4 sm:grid-cols-2">
            {plans.map((plan) => {
              const isSolid = plan.theme === "solid";
              const Icon = plan.icon;
              return (
                <a
                  key={plan.name}
                  href={plan.href}
                  className={`group flex items-center gap-4 rounded-xl border p-4 transition-all hover:-translate-y-0.5 hover:shadow-card-hover sm:p-5 ${
                    isSolid
                      ? "border-transparent bg-[#F97316] text-white"
                      : "border-border bg-[#FFF7ED] text-foreground hover:border-[#F97316]/40"
                  }`}
                >
                  <span
                    className={`inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-full sm:h-14 sm:w-14 ${
                      isSolid ? "bg-white/20 text-white" : "bg-[#F97316]/15 text-[#F97316]"
                    }`}
                  >
                    <Icon className="h-6 w-6 sm:h-7 sm:w-7" strokeWidth={2} aria-hidden="true" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p
                      className={`text-lg font-bold leading-none ${
                        isSolid ? "text-white" : "text-foreground"
                      }`}
                    >
                      {plan.name}
                    </p>
                    <p
                      className={`mt-1 text-xs leading-snug sm:text-[13px] ${
                        isSolid ? "text-white/90" : "text-muted-foreground"
                      }`}
                    >
                      {plan.description}
                    </p>
                    <p className="mt-2 flex items-baseline gap-1">
                      <span
                        className={`text-xl font-bold ${isSolid ? "text-white" : "text-foreground"}`}
                      >
                        {plan.price}
                      </span>
                      <span
                        className={`text-xs ${isSolid ? "text-white/80" : "text-muted-foreground"}`}
                      >
                        {plan.period}
                      </span>
                    </p>
                  </div>
                  <span
                    className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors ${
                      isSolid
                        ? "bg-white/20 text-white group-hover:bg-white/30"
                        : "bg-[#F97316]/10 text-[#F97316] group-hover:bg-[#F97316]/20"
                    }`}
                  >
                    <ArrowRight className="h-4 w-4" strokeWidth={2.4} aria-hidden="true" />
                  </span>
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
