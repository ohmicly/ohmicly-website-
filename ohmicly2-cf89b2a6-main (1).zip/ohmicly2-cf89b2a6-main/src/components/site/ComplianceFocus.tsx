import { ArrowRight, FolderOpen, FileText, Calculator, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import type { PlatformStats } from "@/lib/content/public.functions";

type Ring = {
  key: "rsc" | "nirapon" | "higg";
  title: string;
  heading: string;
  body: string;
  cta: string;
  href: string;
  color: string;
};

const rings: Ring[] = [
  {
    key: "rsc",
    title: "RSC",
    heading: "RSC Compliance",
    body: "Checklists, standards and audit documents.",
    cta: "Explore RSC",
    href: "/resources",
    color: "var(--electric)",
  },
  {
    key: "nirapon",
    title: "NIRAPON",
    heading: "NIRAPON Guidelines",
    body: "Electrical, fire, structural & occupational safety.",
    cta: "Explore NIRAPON",
    href: "/resources",
    color: "var(--free)",
  },
  {
    key: "higg",
    title: "HIGG FEM",
    heading: "HIGG FEM Resources",
    body: "Environmental assessment resources.",
    cta: "Explore HIGG",
    href: "/resources",
    color: "#f97316",
  },
];

function Donut({
  percent,
  color,
  metric,
  metricSub,
}: {
  percent: number;
  color: string;
  metric: string;
  metricSub: string;
}) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-[86px] w-[86px] shrink-0">
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="currentColor" strokeWidth="7" className="text-muted" />
        <circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${(Math.min(percent, 100) / 100) * c} ${c}`}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center leading-tight">
        <span className="text-[13px] font-bold text-foreground">{metric}</span>
        <span className="text-[10px] font-medium" style={{ color }}>
          {metricSub}
        </span>
      </div>
    </div>
  );
}

const compact = (n: number) =>
  n >= 1000 ? `${(n / 1000).toFixed(n >= 10000 ? 0 : 1).replace(/\.0$/, "")}K+` : `${n}`;

export function ComplianceFocus({ stats }: { stats: PlatformStats }) {
  const byKey = new Map(stats.frameworks.map((f) => [f.key, f]));

  const statCards = [
    { icon: FolderOpen, value: compact(stats.resources), label: "Resources", tint: "bg-electric/15 text-electric" },
    { icon: FileText, value: compact(stats.templates), label: "Templates", tint: "bg-destructive/15 text-destructive" },
    { icon: Calculator, value: compact(stats.calculators), label: "Calculators", tint: "bg-free/15 text-free" },
    { icon: Download, value: compact(stats.downloads), label: "Downloads", tint: "bg-primary/20 text-primary-foreground" },
  ];

  return (
    <section className="container-page py-14 sm:py-18">
      <div className="overflow-hidden rounded-2xl bg-navy p-6 shadow-card sm:p-9">
        <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,2.1fr)] lg:items-center">
          <div className="min-w-0">
            <span className="inline-flex rounded-md border border-navy-border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-navy-muted">
              Our compliance focus
            </span>
            <h2 className="mt-4 text-2xl font-bold leading-tight text-navy-foreground sm:text-[1.75rem]">
              Built for compliance.
              <br />
              Focused on what matters.
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-navy-muted">
              Specialized resources for global and local compliance frameworks used in factories and facilities.
            </p>
          </div>

          <div className="grid items-stretch gap-4 sm:grid-cols-3">
            {rings.map((item) => {
              const data = byKey.get(item.key);
              const count = data?.count ?? 0;
              const percent = data?.percent ?? 0;
              return (
                <div
                  key={item.title}
                  className="flex h-full min-w-0 flex-col rounded-xl border border-border bg-card p-4 shadow-card"
                >
                  <h3 className="text-[15px] font-bold text-foreground">{item.title}</h3>
                  <div className="mt-3 flex items-start gap-3">
                    <Donut
                      percent={percent}
                      color={item.color}
                      metric={`${count}`}
                      metricSub={count === 1 ? "File" : "Files"}
                    />
                    <div className="min-w-0">
                      <p className="text-[13px] font-semibold leading-snug text-foreground">{item.heading}</p>
                      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{item.body}</p>
                    </div>
                  </div>
                  <a
                    href={item.href}
                    className="mt-auto inline-flex items-center gap-1.5 pt-3 text-xs font-semibold text-electric"
                  >
                    {item.cta}
                    <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.4} aria-hidden="true" />
                  </a>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-5 border-t border-navy-border pt-6 sm:grid-cols-4">
          {statCards.map((stat) => (
            <div key={stat.label} className="flex min-w-0 items-center gap-3">
              <span className={cn("inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", stat.tint)}>
                <stat.icon className="h-5 w-5" strokeWidth={2.2} aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="text-lg font-bold leading-none text-navy-foreground">{stat.value}</p>
                <p className="mt-1 text-xs text-navy-muted">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
