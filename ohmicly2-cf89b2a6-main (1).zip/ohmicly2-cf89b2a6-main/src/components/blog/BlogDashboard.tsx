import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ArrowUpDown, BookOpen, CalendarDays, Clock3, Search } from "lucide-react";
import type { Article } from "@/lib/content/types";
import { thumbVariant } from "@/lib/images/process";

const PAGE_SIZE = 8;

const formatDate = (value: string | null) =>
  value
    ? new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(value))
    : "Recently published";

function ArticleCard({ article }: { article: Article }) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-lg border border-border bg-card shadow-card transition-shadow hover:shadow-card-hover">
      <Link to="/blog/$slug" params={{ slug: article.slug }} className="block aspect-[16/9] overflow-hidden bg-surface">
        {article.cover_image_url ? (
          <img src={thumbVariant(article.cover_image_url)} alt={`${article.title} cover`} loading="lazy" decoding="async" width={400} height={225} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]" />
        ) : (
          <div className="grid-blueprint flex h-full items-center justify-center">
            <BookOpen className="h-9 w-9 text-electric/55" aria-hidden="true" />
          </div>
        )}
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold uppercase text-electric">
          <span>{article.category}</span><span className="text-border">•</span><span className="normal-case text-muted-foreground">{article.reading_time}</span>
        </div>
        <h2 className="mt-2 text-lg font-bold leading-snug text-foreground">
          <Link to="/blog/$slug" params={{ slug: article.slug }} className="hover:text-primary">{article.title}</Link>
        </h2>
        <p className="mt-2 line-clamp-3 flex-1 text-sm leading-relaxed text-muted-foreground">{article.excerpt}</p>
        <div className="mt-4 flex items-center justify-between border-t border-border pt-4 text-xs text-muted-foreground">
          <span>{formatDate(article.published_at)}</span>
          <Link to="/blog/$slug" params={{ slug: article.slug }} aria-label={`Read ${article.title}`} className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-primary hover:bg-accent">
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </article>
  );
}

export function BlogDashboard({ articles, q, category, page, sort }: { articles: Article[]; q: string; category: string; page: number; sort: string }) {
  const navigate = useNavigate({ from: "/blog/" });
  const [query, setQuery] = useState(q);
  const categories = useMemo(() => {
    const counts = new Map<string, { name: string; count: number }>();
    articles.forEach((article) => {
      const current = counts.get(article.category_slug);
      counts.set(article.category_slug, { name: article.category, count: (current?.count ?? 0) + 1 });
    });
    return [...counts.entries()].sort((a, b) => a[1].name.localeCompare(b[1].name));
  }, [articles]);
  const filtered = articles.filter((article) => {
    const matchesCategory = !category || article.category_slug === category;
    const haystack = `${article.title} ${article.excerpt} ${article.tags.join(" ")}`.toLowerCase();
    return matchesCategory && (!q || haystack.includes(q.toLowerCase()));
  });
  if (sort === "oldest") {
    filtered.sort((a, b) => new Date(a.published_at ?? 0).getTime() - new Date(b.published_at ?? 0).getTime());
  } else if (sort === "title") {
    filtered.sort((a, b) => a.title.localeCompare(b.title));
  } else {
    filtered.sort((a, b) => new Date(b.published_at ?? 0).getTime() - new Date(a.published_at ?? 0).getTime());
  }
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(page, 1), totalPages);
  const featured = filtered[0];
  const visible = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const popular = articles.slice(0, 4);

  const search = (next: Partial<{ q: string; category: string; page: number; sort: string }>) => ({ q, category, page: safePage, sort, ...next });

  return (
    <div className="bg-surface">
      <section className="border-b border-border bg-card">
        <div className="container-page py-9 sm:py-12">
          <p className="text-xs font-semibold uppercase text-electric">OHMICLY Journal</p>
          <div className="mt-2 grid min-w-0 gap-5 lg:grid-cols-[minmax(0,1fr)_28rem] lg:items-end">
            <div className="min-w-0">
              <h1 className="max-w-3xl text-3xl font-extrabold leading-tight text-primary sm:text-4xl">Electrical engineering knowledge, built for the field.</h1>
              <p className="mt-3 max-w-2xl text-base leading-relaxed text-muted-foreground">Practical guidance on design, safety, compliance, audits, and engineering decisions for Bangladesh.</p>
            </div>
            <form
              role="search"
              className="flex h-12 overflow-hidden rounded-lg border border-input bg-background focus-within:border-ring focus-within:ring-2 focus-within:ring-ring/15"
              onSubmit={(event) => { event.preventDefault(); void navigate({ search: search({ q: query.trim(), page: 1 }) }); }}
            >
              <Search className="ml-4 h-5 w-5 self-center text-muted-foreground" aria-hidden="true" />
              <input value={query} onChange={(event) => setQuery(event.target.value)} className="min-w-0 flex-1 bg-transparent px-3 text-sm outline-none" placeholder="Search articles and topics" aria-label="Search articles" />
              <button type="submit" className="m-1 rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground">Search</button>
            </form>
          </div>
        </div>
      </section>

      <div className="container-page py-8">
        <div className="mb-7 flex items-center gap-3">
          <nav className="flex min-w-0 flex-1 gap-2 overflow-x-auto pb-1" aria-label="Article categories">
              <Link to="/blog" search={search({ category: "", page: 1 })} className={`flex h-11 min-w-fit items-center justify-between gap-4 rounded-md px-3 text-sm font-semibold ${!category ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-muted"}`}>
                All articles <span>{articles.length}</span>
              </Link>
              {categories.map(([slug, item]) => (
                <Link key={slug} to="/blog" search={search({ category: slug, page: 1 })} className={`flex h-11 min-w-fit items-center justify-between gap-4 rounded-md px-3 text-sm ${category === slug ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}>
                  {item.name} <span className="text-xs">{item.count}</span>
                </Link>
              ))}
          </nav>
          <label className="flex h-11 min-w-fit shrink-0 items-center gap-2 rounded-md border border-input bg-card px-3 text-sm text-muted-foreground">
            <ArrowUpDown className="h-4 w-4" aria-hidden="true" />
            <span className="sr-only">Sort articles</span>
            <select
              value={sort}
              aria-label="Sort articles"
              className="h-full cursor-pointer bg-transparent font-semibold text-foreground outline-none"
              onChange={(event) => void navigate({ search: search({ sort: event.target.value, page: 1 }) })}
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="title">Title A–Z</option>
            </select>
          </label>
        </div>

        <main className="min-w-0">
          {featured && safePage === 1 ? (
            <article className="mb-7 overflow-hidden rounded-lg border border-border bg-card shadow-card">
              <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] md:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
                <div className="min-w-0 aspect-[16/10] bg-surface md:aspect-auto">
                  {featured.cover_image_url ? <img src={featured.cover_image_url} alt={`${featured.title} cover`} width={1200} height={675} fetchPriority="high" className="h-full w-full object-cover" /> : <div className="grid-blueprint flex h-full min-h-64 items-center justify-center"><BookOpen className="h-12 w-12 text-electric/50" /></div>}
                </div>
                <div className="flex min-w-0 flex-col justify-center p-6 sm:p-8">
                  <span className="text-xs font-bold uppercase text-electric">Featured · {featured.category}</span>
                   <h2 className="mt-3 break-words text-2xl font-extrabold leading-tight text-primary">{featured.title}</h2>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{featured.excerpt}</p>
                  <div className="mt-4 flex flex-wrap gap-4 text-xs text-muted-foreground"><span className="inline-flex items-center gap-1.5"><CalendarDays className="h-4 w-4" />{formatDate(featured.published_at)}</span><span className="inline-flex items-center gap-1.5"><Clock3 className="h-4 w-4" />{featured.reading_time}</span></div>
                  <Link to="/blog/$slug" params={{ slug: featured.slug }} className="mt-6 inline-flex h-11 w-fit items-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground">Read article <ArrowRight className="h-4 w-4" /></Link>
                </div>
              </div>
            </article>
          ) : null}
          <div className="mb-4 flex items-end justify-between gap-3">
            <div><p className="text-xs font-semibold uppercase text-electric">Latest insights</p><h2 className="mt-1 text-2xl font-bold text-foreground">{category ? categories.find(([slug]) => slug === category)?.[1].name ?? "Articles" : q ? "Search results" : "Recent articles"}</h2></div>
            <p className="text-sm text-muted-foreground">{filtered.length} {filtered.length === 1 ? "article" : "articles"}</p>
          </div>
          {visible.length ? <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">{visible.map((article) => <ArticleCard key={article.id} article={article} />)}</div> : <div className="rounded-lg border border-dashed border-border bg-card px-6 py-16 text-center"><BookOpen className="mx-auto h-8 w-8 text-muted-foreground" /><h2 className="mt-3 text-lg font-bold">No matching articles</h2><p className="mt-1 text-sm text-muted-foreground">Try another search or topic.</p></div>}
          {totalPages > 1 ? <nav aria-label="Blog pagination" className="mt-7 flex items-center justify-between border-t border-border pt-5">
            <Link to="/blog" search={search({ page: Math.max(1, safePage - 1) })} aria-disabled={safePage === 1} className={`inline-flex h-11 items-center gap-2 rounded-lg border border-border px-4 text-sm font-semibold ${safePage === 1 ? "pointer-events-none opacity-40" : "hover:border-electric"}`}><ArrowLeft className="h-4 w-4" /> Previous</Link>
            <span className="text-sm text-muted-foreground">Page {safePage} of {totalPages}</span>
            <Link to="/blog" search={search({ page: Math.min(totalPages, safePage + 1) })} aria-disabled={safePage === totalPages} className={`inline-flex h-11 items-center gap-2 rounded-lg border border-border px-4 text-sm font-semibold ${safePage === totalPages ? "pointer-events-none opacity-40" : "hover:border-electric"}`}>Next <ArrowRight className="h-4 w-4" /></Link>
          </nav> : null}
        </main>

        <aside className="mt-8 grid gap-5 md:grid-cols-2">
          <section className="rounded-lg border border-border bg-card p-5"><p className="text-xs font-bold uppercase text-electric">Popular reading</p><h2 className="mt-1 text-lg font-bold">Editor’s picks</h2><ol className="mt-3 divide-y divide-border">{popular.map((article, index) => <li key={article.id} className="flex gap-3 py-3"><span className="text-xl font-extrabold text-electric/35">{String(index + 1).padStart(2, "0")}</span><div><Link to="/blog/$slug" params={{ slug: article.slug }} className="text-sm font-semibold leading-snug hover:text-primary">{article.title}</Link><p className="mt-1 text-xs text-muted-foreground">{article.reading_time}</p></div></li>)}</ol></section>
          <section className="rounded-lg bg-primary p-5 text-primary-foreground"><p className="text-xs font-bold uppercase text-primary-foreground/70">Engineering library</p><h2 className="mt-2 text-lg font-bold">Need field-ready documents?</h2><p className="mt-2 text-sm leading-relaxed text-primary-foreground/75">Browse checklists, templates, CAD files, and audit resources.</p><Link to="/resources" className="mt-4 inline-flex h-11 items-center gap-2 rounded-lg bg-background px-4 text-sm font-semibold text-primary">Explore resources <ArrowRight className="h-4 w-4" /></Link></section>
        </aside>
      </div>
    </div>
  );
}