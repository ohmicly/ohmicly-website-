import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Trash2 } from "lucide-react";
import {
  adminDeleteReference,
  adminListReferences,
  adminReferenceTargets,
  adminSaveReference,
} from "@/lib/admin/admin.functions";
import type { RefEntity } from "@/lib/admin/admin-types";
import { Btn, EmptyState, Field, Loading, Notice, Panel } from "@/components/admin/AdminUI";

type StandardOption = { id: string; code: string; name: string; edition: string | null };

type Draft = {
  id: string | null;
  parentId: string;
  standard_id: string;
  section: string;
  note: string;
  url: string;
  verified: boolean;
};

const EMPTY: Draft = {
  id: null,
  parentId: "",
  standard_id: "",
  section: "",
  note: "",
  url: "",
  verified: false,
};

const ENTITIES: { value: RefEntity; label: string }[] = [
  { value: "calculator", label: "Calculators" },
  { value: "resource", label: "Resources" },
  { value: "article", label: "Articles" },
];

/** Links verified standards (and their clauses) to calculators, resources and articles. */
export function ReferenceManager({ standards }: { standards: StandardOption[] }) {
  const qc = useQueryClient();
  const [entity, setEntity] = useState<RefEntity>("calculator");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const listRefs = useServerFn(adminListReferences);
  const listTargets = useServerFn(adminReferenceTargets);
  const save = useServerFn(adminSaveReference);
  const remove = useServerFn(adminDeleteReference);

  const refs = useQuery({
    queryKey: ["admin", "references", entity],
    queryFn: () => listRefs({ data: { entity } }),
    retry: false,
  });

  const targets = useQuery({
    queryKey: ["admin", "reference-targets", entity],
    queryFn: () => listTargets({ data: { entity } }),
    retry: false,
  });

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      await save({
        data: {
          entity,
          id: draft.id,
          parentId: draft.parentId,
          standard_id: draft.standard_id,
          section: draft.section || null,
          note: draft.note || null,
          url: draft.url || null,
          verified: draft.verified,
        },
      });
      await qc.invalidateQueries({ queryKey: ["admin", "references", entity] });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save this reference.");
    } finally {
      setBusy(false);
    }
  };

  const del = async (id: string) => {
    if (!window.confirm("Delete this reference link?")) return;
    setError(null);
    try {
      await remove({ data: { entity, id } });
      await qc.invalidateQueries({ queryKey: ["admin", "references", entity] });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete this reference.");
    }
  };

  return (
    <Panel title="Reference links">
      <div className="flex flex-wrap items-center gap-2">
        {ENTITIES.map((e) => (
          <Btn
            key={e.value}
            type="button"
            variant={entity === e.value ? "primary" : "outline"}
            onClick={() => {
              setEntity(e.value);
              setDraft(null);
            }}
          >
            {e.label}
          </Btn>
        ))}
        <Btn
          type="button"
          variant="outline"
          className="ml-auto"
          onClick={() => setDraft({ ...EMPTY })}
          disabled={standards.length === 0}
        >
          <Plus className="h-4 w-4" aria-hidden="true" /> New link
        </Btn>
      </div>

      {draft ? (
        <form onSubmit={submit} className="mt-4 space-y-4 rounded-lg border border-border p-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Attach to" required>
              <select
                className="admin-input"
                required
                value={draft.parentId}
                onChange={(e) => setDraft({ ...draft, parentId: e.target.value })}
              >
                <option value="">Select…</option>
                {(targets.data ?? []).map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Standard" required>
              <select
                className="admin-input"
                required
                value={draft.standard_id}
                onChange={(e) => setDraft({ ...draft, standard_id: e.target.value })}
              >
                <option value="">Select…</option>
                {standards.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code}
                    {s.edition ? ` ${s.edition}` : ""} — {s.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Section / clause" hint="Enter only clause numbers you have verified.">
              <input
                className="admin-input"
                value={draft.section}
                onChange={(e) => setDraft({ ...draft, section: e.target.value })}
              />
            </Field>
            <Field label="Source URL">
              <input
                className="admin-input"
                value={draft.url}
                onChange={(e) => setDraft({ ...draft, url: e.target.value })}
              />
            </Field>
          </div>
          <Field label="Section title / engineering summary">
            <textarea
              className="admin-input min-h-24"
              value={draft.note}
              onChange={(e) => setDraft({ ...draft, note: e.target.value })}
            />
          </Field>
          <label className="flex min-h-11 items-center gap-3 text-sm font-semibold text-foreground">
            <input
              type="checkbox"
              className="h-5 w-5"
              checked={draft.verified}
              onChange={(e) => setDraft({ ...draft, verified: e.target.checked })}
            />
            Verified against the published standard
          </label>
          {error ? <Notice kind="error">{error}</Notice> : null}
          <div className="flex flex-wrap gap-2">
            <Btn type="submit" busy={busy}>
              Save reference
            </Btn>
            <Btn type="button" variant="outline" onClick={() => setDraft(null)}>
              Cancel
            </Btn>
          </div>
        </form>
      ) : null}

      {!draft && error ? <Notice kind="error">{error}</Notice> : null}

      <div className="mt-4">
        {refs.isLoading ? (
          <Loading />
        ) : !refs.data?.length ? (
          <EmptyState title="No reference links yet." />
        ) : (
          <ul className="space-y-3">
            {refs.data.map((r) => (
              <li
                key={r.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">
                    {r.parentTitle}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {r.standardCode}
                    {r.standardEdition ? ` ${r.standardEdition}` : ""}
                    {r.section ? ` — ${r.section}` : ""}
                    {r.verified ? " · verified" : " · unverified"}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Btn
                    variant="outline"
                    onClick={() =>
                      setDraft({
                        id: r.id,
                        parentId: r.parentId,
                        standard_id: r.standardId,
                        section: r.section ?? "",
                        note: r.note ?? "",
                        url: r.url ?? "",
                        verified: r.verified,
                      })
                    }
                  >
                    Edit
                  </Btn>
                  <Btn variant="danger" onClick={() => del(r.id)} aria-label="Delete reference">
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                  </Btn>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Panel>
  );
}
