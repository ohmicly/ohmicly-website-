/**
 * Reusable admin thumbnail picker.
 * Uploads a single image to the private `images` bucket and stores a public
 * proxy reference (`/api/public/resource-image?path=…`) on the parent record.
 */
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ImageIcon, Trash2, UploadCloud } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { adminCreateUploadUrl } from "@/lib/admin/admin.functions";
import { Btn } from "@/components/admin/AdminUI";
import { prepareImageUpload } from "@/lib/images/process";

export const thumbnailRef = (path: string) =>
  `/api/public/resource-image?path=${encodeURIComponent(path)}`;

export function ThumbnailField({
  value,
  onChange,
  resourceType = "other",
  hint = "JPG, PNG or WebP, up to 5 MB. Automatically resized and compressed on upload.",
}: {
  value: string;
  onChange: (next: string) => void;
  resourceType?: string;
  hint?: string;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [localUrl, setLocalUrl] = useState<string | null>(null);
  const createUploadUrl = useServerFn(adminCreateUploadUrl);

  const upload = async (file: File) => {
    setBusy(true);
    setError(null);
    try {
      // Resize + compress in the browser, then upload the large and small variants.
      const prepared = await prepareImageUpload(file);
      const baseName = file.name.replace(/\.[^.]+$/, "");
      const signed = await createUploadUrl({
        data: {
          resourceType,
          fileName: `${baseName}.${prepared.full.ext}`,
          size: prepared.full.blob.size,
          originalSize: file.size,
          kind: "image",
        },
      });
      const { error: upErr } = await supabase.storage
        .from(signed.bucket)
        .uploadToSignedUrl(signed.path, signed.token, prepared.full.blob);
      if (upErr) throw new Error(upErr.message);
      if (signed.thumbPath && signed.thumbToken) {
        await supabase.storage
          .from(signed.bucket)
          .uploadToSignedUrl(signed.thumbPath, signed.thumbToken, prepared.thumb.blob);
      }
      setLocalUrl(URL.createObjectURL(prepared.thumb.blob));
      onChange(thumbnailRef(signed.path));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Thumbnail upload failed.");
    } finally {
      setBusy(false);
    }
  };

  const preview = localUrl ?? (value.trim() || null);

  return (
    <div className="space-y-3">
      <div className="flex items-start gap-3">
        <div className="flex h-20 w-28 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-border bg-surface">
          {preview ? (
            <img src={preview} alt="Thumbnail preview" className="h-full w-full object-cover" />
          ) : (
            <ImageIcon className="h-6 w-6 text-muted-foreground" aria-hidden="true" />
          )}
        </div>
        <div className="min-w-0 flex-1 space-y-2">
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-border px-3 py-3 text-center text-sm font-semibold hover:border-electric/50">
            <UploadCloud className="h-4 w-4 text-electric" aria-hidden="true" />
            {busy ? "Uploading…" : value ? "Replace thumbnail" : "Upload thumbnail"}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="sr-only"
              disabled={busy}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void upload(file);
                e.target.value = "";
              }}
            />
          </label>
          <input
            className="admin-input"
            placeholder="…or paste an image link"
            value={value}
            onChange={(e) => {
              setLocalUrl(null);
              onChange(e.target.value);
            }}
          />
        </div>
      </div>
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted-foreground">{hint}</p>
        {value ? (
          <Btn
            type="button"
            variant="danger"
            onClick={() => {
              setLocalUrl(null);
              onChange("");
            }}
          >
            <Trash2 className="h-4 w-4" aria-hidden="true" /> Remove
          </Btn>
        ) : null}
      </div>
      {error ? <p className="text-xs font-semibold text-danger">{error}</p> : null}
    </div>
  );
}
