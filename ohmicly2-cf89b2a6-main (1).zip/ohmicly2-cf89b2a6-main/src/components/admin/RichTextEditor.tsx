import { useEffect, useRef, useState } from "react";
import {
  Bold,
  Heading2,
  Heading3,
  Image as ImageIcon,
  Italic,
  Link2,
  List,
  ListOrdered,
  Minus,
  Quote,
  Redo2,
  Strikethrough,
  Underline as UnderlineIcon,
  Undo2,
  Unlink,
} from "lucide-react";

/**
 * Small WYSIWYG editor for article bodies. Produces simple semantic HTML
 * (headings, bold/italic, quotes, lists, links, images, line breaks).
 */
export function RichTextEditor({
  value,
  onChange,
  onRequestImage,
  busy,
}: {
  value: string;
  onChange: (html: string) => void;
  onRequestImage?: (() => Promise<string | null>) | undefined;
  busy?: boolean;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [ready, setReady] = useState(false);

  // Load the incoming HTML once (and whenever a different article is opened).
  useEffect(() => {
    if (!ref.current) return;
    if (!ready || ref.current.innerHTML.trim() === "") {
      ref.current.innerHTML = value || "";
      setReady(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value === "" ? "empty" : "loaded"]);

  const emit = () => onChange(ref.current?.innerHTML ?? "");

  const run = (command: string, arg?: string) => {
    ref.current?.focus();
    document.execCommand("styleWithCSS", false, "false");
    document.execCommand(command, false, arg);
    emit();
  };

  const insertHtml = (html: string) => {
    ref.current?.focus();
    document.execCommand("insertHTML", false, html);
    emit();
  };

  const addLink = () => {
    const url = window.prompt("Link URL (https://…)");
    if (!url) return;
    if (!/^https?:\/\//i.test(url) && !url.startsWith("/")) {
      window.alert("Please use a full https:// link or an internal path starting with /.");
      return;
    }
    run("createLink", url);
  };

  const tools: { key: string; label: string; icon: React.ReactNode; action: () => void }[] = [
    { key: "bold", label: "Bold", icon: <Bold className="h-4 w-4" />, action: () => run("bold") },
    { key: "italic", label: "Italic", icon: <Italic className="h-4 w-4" />, action: () => run("italic") },
    { key: "underline", label: "Underline", icon: <UnderlineIcon className="h-4 w-4" />, action: () => run("underline") },
    { key: "strike", label: "Strikethrough", icon: <Strikethrough className="h-4 w-4" />, action: () => run("strikeThrough") },
    { key: "h2", label: "Heading", icon: <Heading2 className="h-4 w-4" />, action: () => run("formatBlock", "<h2>") },
    { key: "h3", label: "Subheading", icon: <Heading3 className="h-4 w-4" />, action: () => run("formatBlock", "<h3>") },
    { key: "quote", label: "Quote", icon: <Quote className="h-4 w-4" />, action: () => run("formatBlock", "<blockquote>") },
    { key: "ul", label: "Bullet list", icon: <List className="h-4 w-4" />, action: () => run("insertUnorderedList") },
    { key: "ol", label: "Numbered list", icon: <ListOrdered className="h-4 w-4" />, action: () => run("insertOrderedList") },
    { key: "link", label: "Insert link", icon: <Link2 className="h-4 w-4" />, action: addLink },
    { key: "unlink", label: "Remove link", icon: <Unlink className="h-4 w-4" />, action: () => run("unlink") },
    { key: "hr", label: "Divider", icon: <Minus className="h-4 w-4" />, action: () => insertHtml("<hr />") },
  ];

  if (onRequestImage) {
    tools.push({
      key: "image",
      label: "Insert image",
      icon: <ImageIcon className="h-4 w-4" />,
      action: () => {
        void onRequestImage().then((url) => {
          if (url) insertHtml(`<img src="${url}" alt="" />`);
        });
      },
    });
  }

  tools.push(
    { key: "undo", label: "Undo", icon: <Undo2 className="h-4 w-4" />, action: () => run("undo") },
    { key: "redo", label: "Redo", icon: <Redo2 className="h-4 w-4" />, action: () => run("redo") },
  );

  return (
    <div className="overflow-hidden rounded-lg border border-border bg-card">
      <div className="flex flex-wrap gap-1 border-b border-border bg-surface p-2">
        {tools.map((t) => (
          <button
            key={t.key}
            type="button"
            title={t.label}
            aria-label={t.label}
            disabled={busy}
            onMouseDown={(e) => e.preventDefault()}
            onClick={t.action}
            className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-transparent text-muted-foreground hover:border-border hover:bg-card hover:text-foreground disabled:opacity-50"
          >
            {t.icon}
          </button>
        ))}
      </div>
      <div
        ref={ref}
        contentEditable
        suppressContentEditableWarning
        role="textbox"
        aria-multiline="true"
        aria-label="Article body"
        onInput={emit}
        onBlur={emit}
        className="min-h-72 w-full px-4 py-3 text-[15px] leading-7 text-foreground outline-none [&_a]:text-electric [&_a]:underline [&_blockquote]:my-3 [&_blockquote]:border-l-4 [&_blockquote]:border-electric/40 [&_blockquote]:pl-4 [&_blockquote]:italic [&_h2]:mt-4 [&_h2]:text-2xl [&_h2]:font-bold [&_h3]:mt-3 [&_h3]:text-xl [&_h3]:font-bold [&_hr]:my-4 [&_hr]:border-border [&_img]:my-3 [&_img]:max-w-full [&_img]:rounded-lg [&_li]:ml-5 [&_ol]:my-2 [&_ol]:list-decimal [&_p]:my-2 [&_ul]:my-2 [&_ul]:list-disc"
      />
      <p className="border-t border-border bg-surface px-4 py-2 text-xs text-muted-foreground">
        Shift+Enter adds a line break. Paste keeps basic formatting.
      </p>
    </div>
  );
}
