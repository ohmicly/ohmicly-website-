import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Crown,
  Download,
  Flame,
  FolderOpen,
  Funnel,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui-kit/Icon";
import { cn } from "@/lib/utils";
import { richTextToPlainText } from "@/lib/content/rich-text";
import type { Category, Resource } from "@/lib/content/types";
import { thumbVariant } from "@/lib/images/process";

const PAGE_SIZE = 12;

type QuickFilter = "all" | "rsc" | "nirapon" | "safety" | "autocad";

const quickTabs: Array<{
  id: QuickFilter;
  label: string;
  icon: typeof FolderOpen;
  iconClass: string;
  iconSurfaceClass: string;
}> = [
  {
    id: "all",
    label: "All Resources",
    icon: FolderOpen,
    iconClass: "text-primary",
    iconSurfaceClass: "bg-primary/10",
  },
  {
    id: "rsc",
    label: "RSC Audit Templates",
    icon: ShieldCheck,
    iconClass: "text-electric",
    iconSurfaceClass: "bg-electric/10",
  },
  {
    id: "nirapon",
    label: "Nirapon Checklist",
    icon: Check,
    iconClass: "text-free",
    iconSurfaceClass: "bg-free/10",
  },
  {
    id: "safety",
    label: "Fire & Safety",
    icon: Flame,
    iconClass: "text-destructive",
    iconSurfaceClass: "bg-destructive/10",
  },
  {
    id: "autocad",
    label: "AutoCAD Templates",
    icon: Sparkles,
    iconClass: "text-gold",
    iconSurfaceClass: "bg-gold/10",
  },
];

const fileBadge: Record<string, string> = {
  XLSX: "bg-free text-white",
  PDF: "bg-destructive text-destructive-foreground",
  DOCX: "bg-electric text-white",
  DWG: "bg-primary text-primary-foreground",
  DXF: "bg-primary text-primary-foreground",
  LSP: "bg-foreground text-background",
  ZIP: "bg-gold text-white",
  HTML: "bg-electric text-white",
};

const previewFor = (r: Resource): "sheet" | "shield" | "doc" | "table" | "plan" => {
  if (r.file_type === "DWG" || r.file_type === "DXF") return "plan";
  if (r.resource_type === "checklist") return "shield";
  if (r.file_type === "XLSX") return "sheet";
  if (r.file_type === "DOCX") return "doc";
  return "table";
};

/** Lightweight CSS/SVG document previews — no imagery required. */
function DocPreview({ kind }: { kind: ReturnType<typeof previewFor> }) {
  if (kind === "shield") {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-card">
          <Icon name="shield-check" className="h-7 w-7" />
        </span>
      </div>
    );
  }
  if (kind === "plan") {
    return (
      <div className="mx-auto flex h-full w-[82%] items-center">
        <svg viewBox="0 0 120 60" className="h-full w-full text-primary/45" aria-hidden="true">
          <g fill="none" stroke="currentColor" strokeWidth="1">
            <rect x="4" y="6" width="52" height="34" />
            <rect x="10" y="12" width="18" height="12" />
            <rect x="34" y="18" width="16" height="16" />
            <path d="M60 10h56M60 22h40M60 34h52M68 10v30M92 22v18" />
            <circle cx="104" cy="44" r="6" />
            <path d="M4 48h112" strokeDasharray="4 3" />
          </g>
        </svg>
      </div>
    );
  }
  const rows = kind === "doc" ? 5 : 7;
  const cols = kind === "doc" ? 3 : 5;
  return (
    <div className="mx-auto h-full w-[80%] rounded-md border border-border bg-card p-2">
      <div className="mb-1.5 h-1.5 w-1/2 rounded-full bg-primary/25" />
      <div className="space-y-1">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex gap-1">
            {Array.from({ length: cols }).map((__, c) => (
              <span
                key={c}
                className={cn(
                  "h-1.5 flex-1 rounded-sm",
                  r === 0
                    ? "bg-primary/20"
                    : c === 0
                      ? "bg-muted-foreground/25"
                      : "bg-muted-foreground/12",
                )}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

const selectClass =
  "h-11 w-full min-w-0 rounded-lg border border-border bg-card px-3 text-sm font-medium text-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring";

export function ResourceBrowser({
  categories,
  resources,
  initialCategory,
  initialSubcategory,
  initialAccess,
  initialQuery,
  variant = "all",
}: {
  categories: Category[];
  resources: Resource[];
  initialCategory?: string | undefined;
  initialSubcategory?: string | undefined;
  initialAccess?: "free" | "premium" | undefined;
  initialQuery?: string | undefined;
  variant?: "all" | "premium";
}) {
  const premiumOnly = variant === "premium";
  const [category, setCategory] = useState(initialCategory ?? "");
  const [subcategory, setSubcategory] = useState(initialSubcategory ?? "");
  const [access, setAccess] = useState<string>(premiumOnly ? "premium" : (initialAccess ?? ""));
  const [query, setQuery] = useState(initialQuery ?? "");
  const [sort, setSort] = useState<"newest" | "popular" | "az">("newest");
  const [quickFilter, setQuickFilter] = useState<QuickFilter>("all");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [page, setPage] = useState(1);

  // Sidebar links update this route's search values without remounting the page.
  // Keep the browser filters in sync so category changes feel like tabs.
  useEffect(() => {
    setCategory(initialCategory ?? "");
    setSubcategory(initialSubcategory ?? "");
    setAccess(premiumOnly ? "premium" : (initialAccess ?? ""));
    setQuery(initialQuery ?? "");
    setQuickFilter("all");
    setPage(1);
  }, [initialAccess, initialCategory, initialQuery, initialSubcategory, premiumOnly]);

  const topCategories = useMemo(() => categories.filter((c) => !c.parentId), [categories]);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = resources.filter(
      (r) => {
        const haystack = [
          r.title,
          r.description,
          r.category,
          r.category_name,
          r.subcategory_slug ?? "",
          r.subcategory_name ?? "",
          r.resource_type,
          r.file_type,
          ...r.tags,
        ]
          .join(" ")
          .toLowerCase();
        const matchesQuick =
          quickFilter === "all" ||
          (quickFilter === "rsc" && haystack.includes("rsc")) ||
          (quickFilter === "nirapon" && haystack.includes("nirapon")) ||
          (quickFilter === "safety" && (haystack.includes("fire") || haystack.includes("safety"))) ||
          (quickFilter === "autocad" &&
            (haystack.includes("autocad") || r.file_type === "DWG" || r.file_type === "DXF"));
        return (
          // A subcategory listing includes cross-listed resources from any category.
          (subcategory
            ? r.subcategory_slugs.includes(subcategory)
            : !category || r.category === category) &&
          (!access || (access === "premium" ? r.is_premium : !r.is_premium)) &&
          matchesQuick &&
          (!q || haystack.includes(q))
        );
      },
    );
    const sorted = [...list];
    if (sort === "az") sorted.sort((a, b) => a.title.localeCompare(b.title));
    else if (sort === "popular") sorted.sort((a, b) => b.download_count - a.download_count);
    else sorted.sort((a, b) => b.created_at.localeCompare(a.created_at));
    return sorted;
  }, [resources, category, subcategory, access, query, quickFilter, sort]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const shown = filtered.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);
  const reset = (fn: () => void) => {
    fn();
    setPage(1);
  };

  const activeFilterCount = Number(Boolean(category)) + Number(!premiumOnly && Boolean(access));

  const selectQuickFilter = (next: QuickFilter) => {
    setQuickFilter(next);
    setCategory("");
    setSubcategory("");
    setAccess(premiumOnly ? "premium" : "");
    setQuery("");
    setPage(1);
  };

  return (
    <div className="container-page py-8 sm:py-10">
        <div className="min-w-0">
          <h1 className="text-[1.85rem] font-extrabold leading-[1.1] tracking-[-0.03em] text-primary sm:text-4xl">
            {premiumOnly ? "Premium Resources" : "All Resources"}
          </h1>
          <p className="mt-2 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            {premiumOnly
              ? "Explore production-ready engineering files, templates and professional resources available with Pro access."
              : "Explore our complete collection of tools, templates, guides and resources for electrical engineers."}
          </p>

          <div
            className="mt-6 flex snap-x snap-mandatory gap-2.5 overflow-x-auto overscroll-x-contain pb-2"
            role="tablist"
            aria-label="Featured resource collections"
          >
            {quickTabs.map((tab) => {
              const TabIcon = tab.icon;
              const active = quickFilter === tab.id;
              return (
                <Button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  variant={active ? "default" : "outline"}
                  onClick={() => selectQuickFilter(tab.id)}
                  className={cn(
                     "h-[5.25rem] min-w-[8.5rem] flex-1 shrink-0 snap-start flex-col items-start justify-center gap-2 rounded-xl px-3.5 text-left shadow-card transition-all active:scale-[0.98] sm:min-w-[9rem]",
                    active
                       ? "border-primary bg-primary text-primary-foreground shadow-card-hover"
                       : "border-border bg-card text-foreground hover:-translate-y-0.5 hover:border-electric/40 hover:bg-accent hover:shadow-card-hover",
                  )}
                >
                   <span
                     className={cn(
                       "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                       active ? "bg-primary-foreground/15" : tab.iconSurfaceClass,
                     )}
                   >
                     <TabIcon
                       className={cn(
                         "h-[1.125rem] w-[1.125rem]",
                         active ? "text-primary-foreground" : tab.iconClass,
                       )}
                     />
                   </span>
                   <span className="line-clamp-2 text-xs font-semibold leading-tight">{tab.label}</span>
                </Button>
              );
            })}
          </div>

          {/* Filter bar */}
          <div className="relative mt-5 rounded-xl border border-border bg-card p-2.5 shadow-card">
            <div className="flex min-w-0 items-center gap-2">
              <div className="flex h-11 min-w-0 flex-1 items-center gap-2 rounded-lg border border-border bg-surface px-3">
                <Search className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                <label htmlFor="resource-search" className="sr-only">
                  Search resources
                </label>
                <input
                  id="resource-search"
                  value={query}
                  onChange={(e) => reset(() => setQuery(e.target.value))}
                  placeholder="Search resources..."
                  className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                size="icon"
                aria-label="Open resource filters"
                aria-expanded={filtersOpen}
                onClick={() => setFiltersOpen((open) => !open)}
                className={cn(
                  "relative h-11 w-11 shrink-0 rounded-lg shadow-none",
                  filtersOpen || activeFilterCount
                    ? "border-electric bg-accent text-electric"
                    : "border-border bg-card text-foreground",
                )}
              >
                <Funnel className="h-4 w-4" aria-hidden="true" />
                {activeFilterCount ? (
                  <span className="absolute -right-1 -top-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                    {activeFilterCount}
                  </span>
                ) : null}
              </Button>
              <label htmlFor="resource-sort" className="sr-only">Sort resources</label>
              <select
                id="resource-sort"
                aria-label="Sort by"
                value={sort}
                onChange={(e) => setSort(e.target.value as typeof sort)}
                className={cn(selectClass, "w-28 shrink-0 px-2 text-xs sm:w-44 sm:px-3 sm:text-sm")}
              >
                <option value="newest">Sort: Newest</option>
                <option value="popular">Sort: Popular</option>
                <option value="az">Sort: A–Z</option>
              </select>
            </div>

            {filtersOpen ? (
              <div className="absolute left-2.5 right-2.5 top-[calc(100%+0.5rem)] z-30 rounded-lg border border-border bg-card p-4 shadow-card-hover sm:left-auto sm:w-[30rem]">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-sm font-bold text-foreground">Filter resources</p>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label="Close filters"
                    onClick={() => setFiltersOpen(false)}
                    className="h-8 w-8"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </div>
                <div className="mt-3">
                  <p className="text-xs font-bold uppercase text-muted-foreground">Main category</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant={!category ? "default" : "outline"}
                      onClick={() => reset(() => { setCategory(""); setSubcategory(""); })}
                    >
                      All
                    </Button>
                    {topCategories.map((c) => (
                      <Button
                        key={c.slug}
                        type="button"
                        size="sm"
                        variant={category === c.slug ? "default" : "outline"}
                        onClick={() => reset(() => { setCategory(c.slug); setSubcategory(""); })}
                      >
                        {c.name}
                      </Button>
                    ))}
                  </div>
                </div>
                {!premiumOnly ? (
                  <div className="mt-4 border-t border-border pt-4">
                    <p className="text-xs font-bold uppercase text-muted-foreground">Access</p>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                      {[
                        { value: "", label: "All" },
                        { value: "free", label: "Free" },
                        { value: "premium", label: "Premium" },
                      ].map((option) => (
                        <Button
                          key={option.value || "all"}
                          type="button"
                          size="sm"
                          variant={access === option.value ? "default" : "outline"}
                          onClick={() => reset(() => setAccess(option.value))}
                        >
                          {option.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                ) : null}
              </div>
            ) : null}
          </div>

          {/* Results */}
          <div
            className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"
          >
            {shown.map((r) => (
              <ResourceTile key={r.slug} item={r} layout="grid" showProBadge={premiumOnly} />
            ))}
          </div>

          {shown.length === 0 ? (
            <p className="mt-10 rounded-xl border border-border bg-surface p-8 text-center text-sm text-muted-foreground">
              No resources match these filters.
            </p>
          ) : null}

          {/* Pagination */}
          <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
            <nav aria-label="Pagination" className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                aria-label="Previous page"
                disabled={current === 1}
                onClick={() => setPage(current - 1)}
                className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground disabled:opacity-40"
              >
                <ChevronLeft className="h-4 w-4" aria-hidden="true" />
              </button>
              {Array.from({ length: pageCount }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  type="button"
                  aria-current={p === current ? "page" : undefined}
                  onClick={() => setPage(p)}
                  className={cn(
                    "inline-flex h-11 min-w-11 items-center justify-center rounded-lg border px-3 text-sm font-semibold",
                    p === current
                      ? "border-electric bg-electric text-white"
                      : "border-border bg-card text-muted-foreground",
                  )}
                >
                  {p}
                </button>
              ))}
              <button
                type="button"
                aria-label="Next page"
                disabled={current === pageCount}
                onClick={() => setPage(current + 1)}
                className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground disabled:opacity-40"
              >
                <ChevronRight className="h-4 w-4" aria-hidden="true" />
              </button>
            </nav>
            <p className="text-sm text-muted-foreground">
              Showing {filtered.length === 0 ? 0 : (current - 1) * PAGE_SIZE + 1} to{" "}
              {Math.min(current * PAGE_SIZE, filtered.length)} of {filtered.length} resources
            </p>
          </div>
      </div>
    </div>
  );
}

function ResourceTile({
  item,
  layout,
  showProBadge = false,
}: {
  item: Resource;
  layout: "grid" | "list";
  showProBadge?: boolean;
}) {
  const badge = fileBadge[item.file_type] ?? "bg-primary text-primary-foreground";
  return (
    <article
      className={cn(
        "group relative flex rounded-xl border border-border bg-card p-3 shadow-card transition-all hover:-translate-y-0.5 hover:border-electric/40 hover:shadow-card-hover",
        layout === "grid" ? "h-full flex-col" : "flex-col gap-4 sm:flex-row sm:items-center",
      )}
    >
      <div
        className={cn(
          "relative overflow-hidden rounded-lg border border-border bg-surface",
          item.thumbnail_url ? "" : "p-3",
          layout === "grid" ? "h-32" : "h-28 sm:w-56 sm:shrink-0",
        )}
      >
        <span
          className={cn(
            "absolute left-2 top-2 z-10 rounded px-1.5 py-0.5 text-[10px] font-bold tracking-wide",
            badge,
          )}
        >
          {item.file_type}
        </span>
        {showProBadge ? (
          <span className="absolute right-2 top-2 z-10 inline-flex items-center gap-1 rounded-md bg-premium-gradient px-2.5 py-1 text-xs font-bold uppercase text-primary-foreground shadow-card">
            <Crown className="h-4 w-4" strokeWidth={2.4} aria-hidden="true" />
            PRO
          </span>
        ) : null}
        {item.thumbnail_url ? (
          <img
            src={thumbVariant(item.thumbnail_url)}
            alt={`${item.title} preview`}
            loading="lazy"
            decoding="async"
            width={400}
            height={300}
            className="h-full w-full object-cover"
          />
        ) : (
          <DocPreview kind={previewFor(item)} />
        )}
      </div>
      <div className={cn("flex min-w-0 flex-1 flex-col", layout === "grid" ? "" : "sm:py-1")}>
        <h2 className="mt-3 line-clamp-2 px-1 text-[15px] font-semibold leading-snug text-foreground sm:mt-0">
          <Link to="/resources/$slug" params={{ slug: item.slug }} className="after:absolute after:inset-0">
            {item.title}
          </Link>
        </h2>
        <p className="mt-1.5 line-clamp-2 flex-1 px-1 text-sm leading-relaxed text-muted-foreground">
          {richTextToPlainText(item.description)}
        </p>
        <div className="mt-4 flex items-center justify-between gap-3 px-1">
          <span className="flex min-w-0 items-center gap-2 text-xs font-medium text-muted-foreground">
            <span className="truncate">{item.file_type}</span>
            <span aria-hidden="true">•</span>
            <span className="truncate">{item.is_premium ? "Premium" : "Free"}</span>
          </span>
          <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-border bg-surface text-primary transition-colors group-hover:border-electric/40 group-hover:text-electric">
            <Download className="h-4 w-4" strokeWidth={2.2} aria-hidden="true" />
          </span>
        </div>
      </div>
    </article>
  );
}
