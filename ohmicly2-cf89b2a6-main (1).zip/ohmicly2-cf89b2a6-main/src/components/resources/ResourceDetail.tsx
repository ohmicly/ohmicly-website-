import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Bookmark,
  Check,
  CheckCircle2,
  Facebook,
  Linkedin,
  Link2,
  Mail,
  Maximize2,
  Twitter,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { DownloadButton } from "@/components/ui-kit/DownloadButton";
import { FAQBlock } from "@/components/ui-kit/FAQBlock";
import { ReferenceBlock } from "@/components/ui-kit/ReferenceBlock";
import { EngineeringDisclaimer } from "@/components/site/Disclaimer";
import { cn } from "@/lib/utils";
import type { Faq, Resource } from "@/lib/content/types";
import { isHtmlBody, richTextToPlainText, sanitizeArticleHtml } from "@/lib/content/rich-text";
import { thumbVariant } from "@/lib/images/process";

type Related = { slug: string; title: string; file_type: string; is_premium?: boolean };
type RelatedTool = { slug: string; name: string; category: string };
type RelatedArticle = { slug: string; title: string; reading_time: string };

/** Realistic paper-sheet preview built from DOM text — no imagery required. */
function SheetPreview({ resource, page }: { resource: Resource; page: number }) {
  const rows = 9;
  const offset = page * rows;
  return (
    <div className="mx-auto w-full max-w-[640px] bg-white p-4 shadow-card sm:p-7">
      <p className="text-center text-[11px] font-bold uppercase tracking-[0.14em] text-slate-800 sm:text-sm">
        {resource.title}
      </p>
      <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-1.5 text-[8px] text-slate-500 sm:grid-cols-3 sm:text-[10px]">
        <span>Project Name: ______</span>
        <span>Document No.: ______</span>
        <span>Revision: ______</span>
        <span>Location: ______</span>
        <span>Auditor: ______</span>
        <span>Date: ______</span>
      </div>
      <table className="mt-4 w-full table-fixed border-collapse text-[7px] text-slate-600 sm:text-[9px]">
        <thead>
          <tr className="bg-slate-100 text-slate-700">
            {["No.", "Checkpoint / Description", "Ref.", "Status", "Remarks"].map((h, i) => (
              <th
                key={h}
                className={cn(
                  "border border-slate-300 px-1 py-1 text-left font-semibold sm:px-1.5",
                  i === 1 ? "w-[40%]" : i === 0 ? "w-[8%]" : "w-[17%]",
                )}
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: rows }).map((_, i) => (
            <tr key={i}>
              <td className="border border-slate-200 px-1 py-[5px] sm:px-1.5">{offset + i + 1}</td>
              <td className="break-words border border-slate-200 px-1 py-[5px] sm:px-1.5">
                {resource.whats_included[offset + i] ?? ""}
              </td>
              <td className="border border-slate-200 px-1 py-[5px] sm:px-1.5" />
              <td className="border border-slate-200 px-1 py-[5px] sm:px-1.5" />
              <td className="border border-slate-200 px-1 py-[5px] sm:px-1.5" />
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-4 text-[7px] font-semibold text-slate-700 sm:text-[9px]">Notes:</p>
      <ol className="mt-1 list-inside list-decimal text-[7px] leading-relaxed text-slate-500 sm:text-[9px]">
        <li>Complete every row before sign-off; mark non-applicable items as N/A.</li>
        <li>Attach photographic evidence for each non-conformity recorded.</li>
        <li>This is a template — adapt it to the project scope before use.</li>
      </ol>
      <p className="mt-3 text-right text-[7px] text-slate-400 sm:text-[9px]">Page {page + 1} of 3</p>
    </div>
  );
}

function DetailRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-0.5 py-2 text-sm">
      <dt className="shrink-0 text-muted-foreground">{label}</dt>
      <dd className="min-w-0 break-words text-left font-semibold text-foreground sm:text-right">
        {value}
      </dd>
    </div>
  );
}


const TABS = ["Description", "References", "Details", "FAQs"] as const;
type Tab = (typeof TABS)[number];

function formatFileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function ResourceDetail({
  resource,
  faqs,
  relatedResources,
  relatedTools,
  relatedArticles,
  canDownloadPremium,
}: {
  resource: Resource;
  faqs: Faq[];
  relatedResources: Related[];
  relatedTools: RelatedTool[];
  relatedArticles: RelatedArticle[];
  canDownloadPremium: boolean;
}) {
  const [tab, setTab] = useState<Tab>("Description");
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const [page, setPage] = useState(0);
  const [zoom, setZoom] = useState(100);
  const [fullscreen, setFullscreen] = useState(false);
  const r = resource;
  /** Uploaded preview images take priority over the generated paper-sheet mock. */
  const images = r.preview_images.length
    ? r.preview_images
    : r.thumbnail_url
      ? [r.thumbnail_url]
      : [];
  const pageCount = images.length || 3;
  const activePage = Math.min(page, pageCount - 1);
  const pages = Array.from({ length: pageCount }, (_, i) => i);

  const updated = new Date(r.updated_at).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  function copyLink() {
    if (typeof window === "undefined") return;
    void navigator.clipboard?.writeText(window.location.href).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    });
  }

  const [shareUrl, setShareUrl] = useState(r.canonical_url);
  useEffect(() => setShareUrl(window.location.href), [r.slug]);
  const shares = [
    { label: "Facebook", icon: Facebook, href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}` },
    { label: "X", icon: Twitter, href: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(r.title)}` },
    { label: "LinkedIn", icon: Linkedin, href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}` },
    { label: "Email", icon: Mail, href: `mailto:?subject=${encodeURIComponent(r.title)}&body=${encodeURIComponent(shareUrl)}` },
  ];

  return (
    <div className="container-page py-8 sm:py-10">
        <div className="grid min-w-0 gap-8 xl:grid-cols-[minmax(0,1fr)_20rem]">
          <div className="min-w-0">
            <span className="inline-flex items-center rounded-md bg-gold-soft px-2 py-1 text-[10px] font-bold uppercase tracking-[0.1em] text-amber-accent-foreground">
              {r.resource_type.replace(/-/g, " ")}
            </span>

            <div className="mt-3 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
              <div className="min-w-0">
                <h1 className="text-[1.85rem] font-extrabold leading-[1.1] tracking-[-0.03em] text-primary sm:text-4xl">
                  {r.title}
                </h1>
                <p className="mt-2 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
                  {richTextToPlainText(r.description)}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSaved((v) => !v)}
                  aria-pressed={saved}
                  className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-border bg-card px-4 text-sm font-semibold text-foreground hover:bg-surface"
                >
                  <Bookmark className={cn("h-4 w-4", saved && "fill-current")} aria-hidden="true" />
                  {saved ? "Saved" : "Save"}
                </button>
                <DownloadButton
                  slug={r.slug}
                  fileType={r.file_type}
                  hasFile={r.has_file}
                  premium={r.is_premium}
                  canDownloadPremium={canDownloadPremium}
                />
              </div>
            </div>

            {/* Preview panel */}
            <section
              aria-label="Document preview"
              className="mt-6 overflow-hidden rounded-2xl border border-border bg-surface p-3 sm:p-6"
            >
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs font-semibold text-muted-foreground">
                  Page {activePage + 1} of {pageCount}
                </p>
                <div className="flex items-center gap-1 rounded-lg border border-border bg-card px-1.5 py-1 shadow-card">
                  <button
                    type="button"
                    onClick={() => setZoom((z) => Math.max(50, z - 25))}
                    aria-label="Zoom out"
                    className="inline-flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-surface"
                  >
                    <ZoomOut className="h-4 w-4" aria-hidden="true" />
                  </button>
                  <span className="min-w-11 px-1 text-center text-xs font-semibold text-foreground">
                    {zoom}%
                  </span>
                  <button
                    type="button"
                    onClick={() => setZoom((z) => Math.min(200, z + 25))}
                    aria-label="Zoom in"
                    className="inline-flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-surface"
                  >
                    <ZoomIn className="h-4 w-4" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setFullscreen(true)}
                    aria-label="Open full screen preview"
                    className="inline-flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-surface"
                  >
                    <Maximize2 className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
              <div className="w-full overflow-x-auto">
                <div
                  style={{ width: `${zoom}%`, minWidth: zoom > 100 ? `${zoom * 6}px` : undefined }}
                  className="mx-auto"
                >
                  {images.length ? (
                    <img
                      src={images[activePage]}
                      alt={`${r.title} preview page ${activePage + 1}`}
                      width={1280}
                      height={1706}
                      loading="eager"
                      fetchPriority="high"
                      decoding="async"
                      className="mx-auto h-[min(78vh,900px)] w-full max-w-[640px] rounded-md bg-white object-contain shadow-card"
                    />
                  ) : (
                    <SheetPreview resource={r} page={activePage} />
                  )}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
                {pages.map((i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setPage(i)}
                    aria-label={`Show page ${i + 1}`}
                    aria-current={activePage === i}
                    className={cn(
                      "h-14 w-20 overflow-hidden rounded-md border bg-white p-1.5 text-left transition-shadow",
                      activePage === i ? "border-electric ring-2 ring-electric/30" : "border-border",
                    )}
                  >
                    {images.length ? (
                      <img
                        src={thumbVariant(images[i]!)}
                        alt={`${r.title} preview page ${i + 1}`}
                        loading="lazy"
                        decoding="async"
                        width={80}
                        height={56}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <>
                        <span className="block h-1 w-2/3 rounded-full bg-slate-300" />
                        <span className="mt-1 grid grid-cols-4 gap-[2px]">
                          {Array.from({ length: 16 }).map((_, k) => (
                            <span key={k} className="block h-[3px] rounded-sm bg-slate-200" />
                          ))}
                        </span>
                      </>
                    )}
                  </button>
                ))}
              </div>

            </section>

            {fullscreen ? (
              <div
                role="dialog"
                aria-modal="true"
                aria-label="Document preview full screen"
                className="fixed inset-0 z-50 flex flex-col bg-navy/90 p-3 sm:p-6"
              >
                <div className="mb-3 flex items-center justify-between gap-3">
                  <p className="text-sm font-semibold text-navy-foreground">
                    {r.title} — page {activePage + 1} of {pageCount}
                  </p>
                  <button
                    type="button"
                    onClick={() => setFullscreen(false)}
                    className="inline-flex h-11 items-center gap-2 rounded-lg bg-card px-4 text-sm font-semibold text-foreground"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                    Close
                  </button>
                </div>
                <div className="min-h-0 flex-1 overflow-auto rounded-xl bg-surface p-3 sm:p-6">
                  {images.length ? (
                    <img
                      src={images[activePage]}
                      alt={`${r.title} preview page ${activePage + 1}`}
                      decoding="async"
                      className="mx-auto max-h-full w-auto max-w-full object-contain"
                    />
                  ) : (
                    <SheetPreview resource={r} page={activePage} />
                  )}
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                  {pages.map((i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setPage(i)}
                      className={cn(
                        "min-h-11 min-w-11 rounded-lg px-3 text-sm font-semibold",
                        activePage === i
                          ? "bg-electric text-electric-foreground"
                          : "bg-card text-foreground",
                      )}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>

              </div>
            ) : null}


            {/* Tabs */}
            <div className="mt-8 border-b border-border">
              <div role="tablist" aria-label="Resource information" className="flex gap-6 overflow-x-auto">
                {TABS.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTab(t)}
                    role="tab"
                    id={`resource-tab-${t.toLowerCase()}`}
                    aria-controls="resource-tabpanel"
                    aria-selected={tab === t}
                    className={cn(
                      "-mb-px min-h-11 whitespace-nowrap border-b-2 px-0.5 text-sm font-semibold transition-colors",
                      tab === t
                        ? "border-electric text-electric"
                        : "border-transparent text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {t}
                    {t === "FAQs" && faqs.length ? ` (${faqs.length})` : ""}
                  </button>
                ))}
              </div>
            </div>

            <div
              id="resource-tabpanel"
              role="tabpanel"
              aria-labelledby={`resource-tab-${tab.toLowerCase()}`}
              className="mt-6 space-y-6"
            >
              {tab === "Description" ? (
                <>
                  <section aria-labelledby="resource-overview-heading">
                    <h2 id="resource-overview-heading" className="text-lg font-bold text-foreground">
                      What is this resource?
                    </h2>
                    {isHtmlBody(r.description) ? (
                      <div
                        className="mt-2 text-sm leading-relaxed text-muted-foreground [&_a]:text-electric [&_a]:underline [&_blockquote]:my-3 [&_blockquote]:border-l-4 [&_blockquote]:border-electric/40 [&_blockquote]:pl-4 [&_blockquote]:italic [&_h2]:mt-5 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:text-foreground [&_h3]:mt-4 [&_h3]:text-lg [&_h3]:font-bold [&_h3]:text-foreground [&_hr]:my-5 [&_hr]:border-border [&_li]:ml-5 [&_li]:my-1 [&_ol]:my-3 [&_ol]:list-decimal [&_p]:my-3 [&_strong]:text-foreground [&_ul]:my-3 [&_ul]:list-disc"
                        dangerouslySetInnerHTML={{ __html: sanitizeArticleHtml(r.description) }}
                      />
                    ) : (
                      <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                        {r.description}
                      </p>
                    )}
                  </section>
                  {r.problem_solved ? (
                    <section>
                      <h2 className="text-lg font-bold text-foreground">What problem does it solve?</h2>
                      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{r.problem_solved}</p>
                    </section>
                  ) : null}
                  {r.who_for ? (
                    <section>
                      <h2 className="text-lg font-bold text-foreground">Who is it for?</h2>
                      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{r.who_for}</p>
                    </section>
                  ) : null}
                  {r.whats_included.length ? (
                    <section>
                      <h2 className="text-lg font-bold text-foreground">What&apos;s included?</h2>
                      <ul className="mt-2 space-y-1.5">
                        {r.whats_included.map((i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-free" aria-hidden="true" />
                            <span>{i}</span>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}
                  {r.how_to_use.length ? (
                    <section>
                      <h2 className="text-lg font-bold text-foreground">How to use it</h2>
                      <ol className="mt-2 space-y-1.5">
                        {r.how_to_use.map((item, idx) => (
                          <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-[11px] font-bold text-electric">
                              {idx + 1}
                            </span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ol>
                    </section>
                  ) : null}
                  {relatedResources.length || relatedTools.length || relatedArticles.length ? (
                    <section aria-labelledby="related-content-heading">
                      <h2 id="related-content-heading" className="text-lg font-bold text-foreground">
                        Related content
                      </h2>
                      <div className="mt-3 grid gap-5 md:grid-cols-3">
                        {relatedResources.length ? (
                          <div>
                            <h3 className="text-sm font-bold text-foreground">Related resources</h3>
                            <ul className="mt-2 space-y-2">
                              {relatedResources.map((item) => (
                                <li key={item.slug}>
                                  <Link to="/resources/$slug" params={{ slug: item.slug }} className="text-sm font-semibold text-electric hover:underline">
                                    {item.title}
                                  </Link>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ) : null}
                        {relatedTools.length ? (
                          <div>
                            <h3 className="text-sm font-bold text-foreground">Related calculators</h3>
                            <ul className="mt-2 space-y-2">
                              {relatedTools.map((item) => (
                                <li key={item.slug}>
                                  <Link to="/calculator/$slug" params={{ slug: item.slug }} className="text-sm font-semibold text-electric hover:underline">
                                    {item.name}
                                  </Link>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ) : null}
                        {relatedArticles.length ? (
                          <div>
                            <h3 className="text-sm font-bold text-foreground">Related articles</h3>
                            <ul className="mt-2 space-y-2">
                              {relatedArticles.map((item) => (
                                <li key={item.slug}>
                                  <Link to="/blog/$slug" params={{ slug: item.slug }} className="text-sm font-semibold text-electric hover:underline">
                                    {item.title}
                                  </Link>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ) : null}
                      </div>
                    </section>
                  ) : null}
                  {r.disclaimer?.trim() ? (
                    <EngineeringDisclaimer className="mt-2" text={r.disclaimer} />
                  ) : null}
                </>
              ) : null}

              {tab === "References" ? (
                r.references.length ? (
                  <ReferenceBlock references={r.references} />
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No references have been added for this resource yet.
                  </p>
                )
              ) : null}

              {tab === "Details" ? (
                <dl className="max-w-2xl divide-y divide-border">
                  <DetailRow label="File type" value={r.file_type} />
                  <DetailRow label="Access" value={r.is_premium ? "Premium" : "Free"} />
                  {r.file_name ? <DetailRow label="File name" value={r.file_name} /> : null}
                  {r.file_size ? <DetailRow label="File size" value={formatFileSize(r.file_size)} /> : null}
                  <DetailRow label="Last updated" value={updated} />
                  <DetailRow label="Category" value={r.category_name || r.category} />
                  {r.subcategory_name || r.subcategory ? (
                    <DetailRow label="Subcategory" value={r.subcategory_name || r.subcategory} />
                  ) : null}
                  <DetailRow label="Author" value={r.author} />
                  <DetailRow label="Downloads" value={r.download_count.toLocaleString()} />
                </dl>
              ) : null}

              {tab === "FAQs" ? (
                faqs.length ? (
                  <FAQBlock faqs={faqs} />
                ) : (
                  <p className="text-sm text-muted-foreground">FAQs for this resource have not been added yet.</p>
                )
              ) : null}
            </div>

          </div>

          {/* Right rail */}
          <aside className="min-w-0 space-y-4">
            <section className="rounded-2xl border border-border bg-card p-5">
              <h2 className="text-sm font-bold text-foreground">Share this resource</h2>
              <div className="mt-3 flex items-center justify-between">
                <button
                  type="button"
                  onClick={copyLink}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-muted-foreground hover:bg-surface"
                  aria-label={copied ? "Link copied" : "Copy link"}
                >
                  {copied ? <Check className="h-4 w-4 text-free" /> : <Link2 className="h-4 w-4" />}
                </button>
                {shares.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noreferrer noopener"
                    aria-label={`Share on ${s.label}`}
                    className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-electric hover:bg-surface"
                  >
                    <s.icon className="h-4 w-4" aria-hidden="true" />
                  </a>
                ))}
              </div>
            </section>

          </aside>
      </div>
    </div>
  );
}
