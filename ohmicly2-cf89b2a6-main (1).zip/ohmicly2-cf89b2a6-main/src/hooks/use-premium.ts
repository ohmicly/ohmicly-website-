import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/** Client-side premium/role state used only for UI affordances. Access is
 *  always re-verified server-side before a signed URL is issued. */
export function usePremiumAccess() {
  const [hasPremium, setHasPremium] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const check = async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) {
        if (active) {
          setHasPremium(false);
          setLoading(false);
        }
        return;
      }
      const { data } = await supabase.rpc("has_premium_access", {
        _user_id: session.session.user.id,
      });
      if (active) {
        setHasPremium(Boolean(data));
        setLoading(false);
      }
    };
    void check();
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT") void check();
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  return { hasPremium, loading };
}
