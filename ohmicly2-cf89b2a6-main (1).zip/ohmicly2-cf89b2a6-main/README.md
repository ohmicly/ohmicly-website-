# Ohmily Engineering Hub

Build a completely new website for my brand "OHMICLY".



OHMICLY is a professional Electrical Engineering digital platform focused on Bangladesh, with future global scalability.



IMPORTANT:

This is Phase 1 only.

Focus on creating the visual design system, responsive UI/UX, and complete homepage.

Do NOT build the admin CMS, Supabase database, authentication, payments, or complex backend yet.

However, structure the frontend cleanly so these can be integrated later without redesigning the UI.



BRAND POSITIONING:

OHMICLY should feel like a modern, trustworthy, professional engineering platform — not a generic blog, not a dark hacker website, and not a basic template marketplace.



The platform will eventually provide:

- Electrical calculators

- RSC / Nirapon audit checklists and reporting resources

- AutoCAD SLD templates

- AutoLISP tools

- Electrical CAD resources

- Earthing and LPS resources

- Electrical PDF books and guides

- Engineering templates

- Electrical safety resources

- Technical blogs and knowledge

- Premium engineering resources



DESIGN DIRECTION:

Use a clean, premium, modern LIGHT theme.



Avoid:

- Dark theme

- Neon cyberpunk aesthetics

- Excessive gradients

- Overly colorful backgrounds

- Generic SaaS appearance

- Excessive glassmorphism

- Huge empty spaces

- Excessive animations



The design should communicate:

ENGINEERING + TRUST + TECHNOLOGY + PRECISION + PROFESSIONALISM.



COLOR SYSTEM:

Use a refined light color palette.



Primary:

Deep Engineering Blue



Secondary:

Electric Blue



Accent:

Controlled Amber/Orange for important actions and premium elements



Background:

Warm white / very light neutral



Text:

Dark navy / charcoal



Use color strategically rather than making the whole website colorful.



PREMIUM RESOURCE VISUAL:

Free and Premium resources must be visually distinguishable.



Premium resources should use a sophisticated amber/gold "PREMIUM" badge.

Do not make the badge oversized.



Free resources should have a subtle "FREE" badge.



The interface should feel professional enough for engineers and consultants.



TYPOGRAPHY:

Use a modern highly readable sans-serif font.

Strong hierarchy between:

- H1

- H2

- H3

- body

- metadata

- buttons



Optimize typography for mobile readability.



MOBILE-FIRST REQUIREMENT:

Approximately 70% of users will visit from mobile.



Design mobile FIRST, then tablet and desktop.



The mobile experience must NOT simply be a compressed desktop layout.



Mobile requirements:

- Large touch-friendly buttons

- Easy thumb navigation

- Simple navigation

- Prominent search

- Comfortable spacing

- Readable typography

- Easy calculator access

- Easy file/resource access

- No tiny text

- No horizontal overflow

- Responsive cards

- Fast visual loading



DESKTOP:

Create a professional wide desktop layout with a maximum readable content width.

Use whitespace intelligently.

Do not make the interface unnecessarily huge.



HOMEPAGE STRUCTURE:



1. HEADER / NAVIGATION



Create a professional responsive header.



Desktop navigation should include:



Logo: OHMICLY



Main navigation:

Tools

Resources

RSC & Safety

AutoCAD

Blog

Knowledge



Include:

Search

Login / Account



Use a clean sticky header if appropriate.



On mobile:

Use a compact header with:

Logo

Search

Menu



Do not overcrowd mobile navigation.



--------------------------------------------------



2. HERO SECTION



Create a highly professional hero section.



Primary message should communicate that OHMICLY is a place for electrical engineering tools, resources, calculators and professional knowledge.



Suggested headline direction:



"Electrical Engineering Tools, Resources & Knowledge — All in One Place"



Supporting text should clearly explain:

Find electrical calculators, RSC/Nirapon audit resources, AutoCAD files, templates, technical guides and engineering resources.



Primary CTA:

"Explore Free Resources"



Secondary CTA:

"Explore Calculators"



Add a prominent search box:



"Search calculators, files, checklists, guides..."



The hero should immediately communicate the value of OHMICLY.



Do NOT make the hero excessively tall.



--------------------------------------------------



3. TRUST / VALUE STRIP



Immediately below hero, create a compact visual trust/value strip.



Examples:

- Free Engineering Resources

- Electrical Calculators

- RSC & Nirapon Resources

- AutoCAD & AutoLISP

- Professional Templates



Use simple icons.



--------------------------------------------------



4. FEATURED ENGINEERING TOOLS



Create a section titled:



"Engineering Calculators"



Subtitle:

"Practical tools for everyday electrical engineering work."



Show several calculator cards such as:



Voltage Drop Calculator

Cable Size Calculator

Load Calculator

Transformer Calculator

Fault Current Calculator

Earthing Calculator



Each card should include:

- Icon

- Name

- Short description

- "Open Calculator" CTA



Design the cards so they can later be dynamically populated from Supabase.



--------------------------------------------------



5. RSC / NIRAPON FEATURE SECTION



This is one of OHMICLY's PRIMARY differentiators.



Create a visually stronger section for:



"RSC & Nirapon Audit Resources"



Clearly communicate:



"Free audit checklists, reporting templates and electrical safety resources."



Include cards for:



RSC Audit Checklists

Nirapon Checklists

Audit Reporting Templates

Electrical Safety Checklists



Use a professional engineering visual style.



Include CTA:



"Explore RSC Resources"



This section should have stronger visual emphasis than ordinary blog content.



--------------------------------------------------



6. RESOURCE LIBRARY PREVIEW



Create a section:



"Explore Engineering Resources"



Show resource categories:



AutoCAD

AutoLISP

Electrical CAD

Earthing

LPS

PDF Books

Checklists

Templates

Electrical Safety

Electricians Zone



Use a clean category/card layout.



Some resources should visually show:



FREE



Others:



PREMIUM



Premium badge must use the refined amber/gold accent.



Do not use fake prices or fake download numbers.



--------------------------------------------------



7. FEATURED / PREMIUM RESOURCES



Create a section:



"Professional Resources"



Show a mixture of Free and Premium resources.



Example visual resources:



MDB SLD Template

Electrical Symbols Pack

Earthing Design Template

LPS Design Template

RSC Reporting Template



Clearly distinguish Premium resources with a small amber Premium badge.



Do not imply that these files actually exist yet.

Use realistic placeholder content only for visual demonstration.



--------------------------------------------------



8. KNOWLEDGE / BLOG SECTION



Create:



"Electrical Engineering Knowledge"



Show 3–4 article cards.



Topics can include:



Electrical Safety

Earthing

Substation

Electrical Design

RSC Audit



Each card should contain:

Category

Title

Short excerpt

Read Article



Design for future CMS/database integration.



--------------------------------------------------



9. WHY OHMICLY



Create a concise section communicating the platform's value.



Possible points:



Practical Engineering Tools

Professional Resources

Bangladesh-focused Standards & References

Mobile-friendly Experience

Free Learning Resources

Continuously Growing Library



Use clean icons and short explanations.



--------------------------------------------------



10. FINAL CTA



Create a strong but clean final CTA:



"Build Better Electrical Designs with OHMICLY"



Supporting text:

"Explore practical tools, engineering resources and technical knowledge built for electrical professionals."



Buttons:

Explore Tools

Browse Resources



--------------------------------------------------



11. FOOTER



Create a professional multi-column footer.



Columns:



OHMICLY

Short brand description



Tools

Calculators

Engineering Tools

Report Tools



Resources

RSC & Nirapon

AutoCAD

AutoLISP

Checklists

Templates

PDF Books



Knowledge

Blog

Electrical Guides

FAQs



Company

About

Contact

Privacy

Terms



Include social links placeholders.



Include copyright.



Footer should feel premium and professional, not oversized.



--------------------------------------------------



COMPONENT SYSTEM:



Create reusable components for:



Header

Mobile Navigation

Hero

Search Bar

Section Header

Calculator Card

Resource Card

Category Card

Blog Card

Premium Badge

Free Badge

CTA

Footer



Use consistent spacing, radius, shadows and typography.



Do not create every card as a separate hard-coded visual structure.



--------------------------------------------------



RESPONSIVE DESIGN:



Test and optimize at:



375px mobile

390px mobile

430px mobile

768px tablet

1024px tablet/small desktop

1440px desktop



No horizontal scrolling.



Cards should intelligently stack or transform on smaller screens.



Navigation must remain usable.



--------------------------------------------------



PERFORMANCE:



Keep Phase 1 lightweight.



Avoid unnecessary libraries.



Avoid heavy animations.



Use optimized SVG icons where possible.



Use lazy loading for below-the-fold imagery.



Avoid huge background images.



The eventual goal is a very fast mobile-first website.



--------------------------------------------------



SEO FOUNDATION:



Even though this is Phase 1, structure the page with semantic HTML.



Use:

- One clear H1

- Proper H2/H3 hierarchy

- Descriptive links

- Accessible buttons

- Image alt text

- SEO-friendly URLs for future pages



Do not keyword-stuff.



The architecture must be ready for future:

SEO

AEO

GEO

AIO

SXO



--------------------------------------------------



IMPORTANT FUTURE ARCHITECTURE:



The UI must be designed so that later:



Admin Panel

→ Supabase Database

→ Supabase Storage

→ Website



can dynamically populate:



- Calculators

- Resources

- Files

- Blogs

- Categories

- Topics

- References

- Premium resources



Do NOT hard-code the architecture in a way that makes future Supabase integration difficult.



For now, use realistic mock data only where necessary.



--------------------------------------------------



VISUAL QUALITY:



The final result should feel like a serious professional engineering platform that could eventually scale into a large international product.



Think:

Professional engineering consultancy + modern digital resource platform + engineering tools ecosystem.



It should NOT look like:

- a school project

- a generic WordPress website

- a cheap template marketplace

- a dark developer dashboard

- a crypto/cybersecurity website



Prioritize:

Clarity

Trust

Precision

Professionalism

Visual hierarchy

Mobile usability

Performance

Scalability



Build the complete homepage and responsive design system now.

Do not stop after designing only the hero section.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://ohmicly2.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/eead6c59-4697-4e64-95d1-147d21005be9).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
