# Roadmap

- [x] Simplify resource detail tabs and remove repeated public content
- [x] Surface existing related resources, calculators, and articles in Description
- [x] Verify desktop/mobile, content variants, previews, downloads, links, and SEO

- [x] Fix calculator detail mobile horizontal overflow
- [x] Keep calculator full-width at desktop-site phone widths and move related content below
- [x] Move introductory calculator details below the calculator
- [x] Highlight applicable references directly after each calculator result
- [x] Verify calculator pages at 390px, 980px, and desktop widths
