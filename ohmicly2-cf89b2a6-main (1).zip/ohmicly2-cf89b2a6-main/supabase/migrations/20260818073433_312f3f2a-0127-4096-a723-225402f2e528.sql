create or replace function public.is_admin_internal(_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path to 'public'
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role in ('admin','super_admin')
  )
$$;
revoke all on function public.is_admin_internal(uuid) from public, anon, authenticated;
grant execute on function public.is_admin_internal(uuid) to service_role;

create or replace function public.is_admin(_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path to 'public'
as $$
  select case
    when _user_id is null or auth.uid() is null then false
    when _user_id <> auth.uid() and not public.is_admin_internal(auth.uid()) then false
    else public.is_admin_internal(_user_id)
  end
$$;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security definer
set search_path to 'public'
as $$
  select case
    when _user_id is null or auth.uid() is null then false
    when _user_id <> auth.uid() and not public.is_admin_internal(auth.uid()) then false
    else exists (
      select 1 from public.user_roles where user_id = _user_id and role = _role
    )
  end
$$;

create or replace function public.has_premium_access(_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path to 'public'
as $$
  select case
    when _user_id is null or auth.uid() is null then false
    when _user_id <> auth.uid() and not public.is_admin_internal(auth.uid()) then false
    else exists (
      select 1 from public.premium_entitlements
      where user_id = _user_id and is_active and (expires_at is null or expires_at > now())
    ) or public.is_admin_internal(_user_id)
  end
$$;

revoke all on function public.is_admin(uuid) from public, anon;
revoke all on function public.has_role(uuid, app_role) from public, anon;
revoke all on function public.has_premium_access(uuid) from public, anon;
grant execute on function public.is_admin(uuid) to authenticated, service_role;
grant execute on function public.has_role(uuid, app_role) to authenticated, service_role;
grant execute on function public.has_premium_access(uuid) to authenticated, service_role;

alter table public.rate_limits enable row level security;
revoke all on table public.rate_limits from anon, authenticated;
grant all on table public.rate_limits to service_role;
drop policy if exists rate_limits_no_client_access on public.rate_limits;
create policy rate_limits_no_client_access
  on public.rate_limits
  for all
  to anon, authenticated
  using (false)
  with check (false);