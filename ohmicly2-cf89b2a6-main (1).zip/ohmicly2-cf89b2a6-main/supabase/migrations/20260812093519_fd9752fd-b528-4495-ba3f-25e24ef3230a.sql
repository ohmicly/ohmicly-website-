UPDATE public.calculators
SET faq = '[
  {"question": "What does the Load Calculator compute?", "answer": "It calculates apparent power (kVA), load current (A) and total connected load from the real power (kW), voltage, phase arrangement, power factor and quantity you enter. If you supply a verified load or diversity factor, it also shows the diversified load."},
  {"question": "Does it apply demand or diversity factors automatically?", "answer": "No. OHMICLY does not hold verified demand/diversity tables for every country and installation type, so no factor is applied unless you explicitly enter one from your applicable standard."},
  {"question": "Can I use this for motor feeders?", "answer": "The calculator gives running current only. Motor starting (locked-rotor) current, efficiency, service factor and power-factor correction are not modelled. Size motor feeders and protection separately."}
]'::jsonb,
    updated_at = now()
WHERE slug = 'load-calculator';