ALTER TABLE public.resource_categories ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;
ALTER TABLE public.resources ADD COLUMN IF NOT EXISTS file_size bigint;
ALTER TABLE public.resources ADD COLUMN IF NOT EXISTS file_name text;
ALTER TABLE public.articles ADD COLUMN IF NOT EXISTS cover_image_url text;