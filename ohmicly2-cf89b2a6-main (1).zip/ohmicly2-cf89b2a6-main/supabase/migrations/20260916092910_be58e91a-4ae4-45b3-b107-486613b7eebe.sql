create extension if not exists pg_trgm with schema extensions;

CREATE OR REPLACE FUNCTION public.search_content(q text, scope text DEFAULT 'All'::text)
 RETURNS TABLE(id text, type text, label text, title text, description text, href text, access text, rank real)
 LANGUAGE sql
 STABLE SECURITY INVOKER
 SET search_path TO 'public', 'extensions'
AS $function$
  with params as (
    select
      lower(coalesce(nullif(trim(q), ''), '')) as raw,
      websearch_to_tsquery('english', coalesce(nullif(trim(q), ''), '')) as tsq
  )
  select * from (
    select c.id::text, 'CALCULATOR', 'CALCULATOR', c.name, c.description,
           '/calculator/' || c.slug, 'free',
           greatest(
             ts_rank(c.search_tsv, p.tsq),
             word_similarity(p.raw, hay.txt),
             case when hay.txt like '%' || p.raw || '%' then 0.45 else 0 end
           )::real
    from public.calculators c, params p,
      lateral (select lower(coalesce(c.name,'') || ' ' || coalesce(c.description,'') || ' ' ||
                            coalesce(c.category,'') || ' ' || replace(coalesce(c.slug,''),'-',' ') || ' ' ||
                            array_to_string(coalesce(c.keywords, '{}'), ' ')) as txt) hay
    where c.is_published and scope in ('All','Tools')
      and (c.search_tsv @@ p.tsq or hay.txt like '%' || p.raw || '%' or word_similarity(p.raw, hay.txt) > 0.4)
    union all
    select r.id::text, 'RESOURCE', coalesce(r.file_type,'FILE'), r.title, r.description,
           '/resources/' || r.slug,
           case when r.is_premium then 'premium' else 'free' end,
           greatest(
             ts_rank(r.search_tsv, p.tsq),
             word_similarity(p.raw, hay.txt),
             case when hay.txt like '%' || p.raw || '%' then 0.45 else 0 end
           )::real
    from public.resources r, params p,
      lateral (select lower(coalesce(r.title,'') || ' ' || coalesce(r.description,'') || ' ' ||
                            coalesce(r.subcategory,'') || ' ' || replace(coalesce(r.slug,''),'-',' ') || ' ' ||
                            coalesce(r.file_type,'') || ' ' || coalesce(r.resource_type::text,'') || ' ' ||
                            array_to_string(coalesce(r.tags, '{}'), ' ')) as txt) hay
    where r.status = 'published' and scope in ('All','Resources','Files')
      and (r.search_tsv @@ p.tsq or hay.txt like '%' || p.raw || '%' or word_similarity(p.raw, hay.txt) > 0.4)
    union all
    select a.id::text, 'ARTICLE', 'ARTICLE', a.title, a.excerpt, '/blog/' || a.slug, 'free',
           greatest(
             ts_rank(a.search_tsv, p.tsq),
             word_similarity(p.raw, hay.txt),
             case when hay.txt like '%' || p.raw || '%' then 0.45 else 0 end
           )::real
    from public.articles a, params p,
      lateral (select lower(coalesce(a.title,'') || ' ' || coalesce(a.excerpt,'') || ' ' ||
                            replace(coalesce(a.slug,''),'-',' ') || ' ' ||
                            array_to_string(coalesce(a.tags, '{}'), ' ')) as txt) hay
    where a.status = 'published' and scope in ('All','Articles')
      and (a.search_tsv @@ p.tsq or hay.txt like '%' || p.raw || '%' or word_similarity(p.raw, hay.txt) > 0.4)
    union all
    select f.id::text, 'FAQ', 'FAQ', f.question, f.answer, '/knowledge#faqs', 'free',
           greatest(
             ts_rank(f.search_tsv, p.tsq),
             word_similarity(p.raw, hay.txt),
             case when hay.txt like '%' || p.raw || '%' then 0.45 else 0 end
           )::real
    from public.faqs f, params p,
      lateral (select lower(coalesce(f.question,'') || ' ' || coalesce(f.answer,'')) as txt) hay
    where f.is_published and scope in ('All','FAQs')
      and (f.search_tsv @@ p.tsq or hay.txt like '%' || p.raw || '%' or word_similarity(p.raw, hay.txt) > 0.4)
  ) results(id, type, label, title, description, href, access, rank)
  order by rank desc, title asc
  limit 100
$function$;

GRANT EXECUTE ON FUNCTION public.search_content(text, text) TO anon, authenticated, service_role;