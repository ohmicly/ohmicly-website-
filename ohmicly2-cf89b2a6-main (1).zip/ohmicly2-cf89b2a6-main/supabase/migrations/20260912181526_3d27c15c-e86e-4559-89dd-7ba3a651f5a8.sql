ALTER TABLE public.resource_categories ADD COLUMN IF NOT EXISTS group_label text;

ALTER TABLE public.resources
  ADD COLUMN IF NOT EXISTS primary_subcategory_id uuid REFERENCES public.resource_categories(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS resources_primary_subcategory_idx ON public.resources(primary_subcategory_id);
CREATE INDEX IF NOT EXISTS resource_categories_parent_idx ON public.resource_categories(parent_id);

CREATE TABLE IF NOT EXISTS public.resource_subcategories (
  resource_id uuid NOT NULL REFERENCES public.resources(id) ON DELETE CASCADE,
  subcategory_id uuid NOT NULL REFERENCES public.resource_categories(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (resource_id, subcategory_id)
);

GRANT SELECT ON public.resource_subcategories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.resource_subcategories TO authenticated;
GRANT ALL ON public.resource_subcategories TO service_role;

ALTER TABLE public.resource_subcategories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "resource_subcategories_public_read" ON public.resource_subcategories
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "resource_subcategories_admin_write" ON public.resource_subcategories
  FOR ALL TO authenticated USING (private.is_admin()) WITH CHECK (private.is_admin());

CREATE INDEX IF NOT EXISTS resource_subcategories_sub_idx ON public.resource_subcategories(subcategory_id);