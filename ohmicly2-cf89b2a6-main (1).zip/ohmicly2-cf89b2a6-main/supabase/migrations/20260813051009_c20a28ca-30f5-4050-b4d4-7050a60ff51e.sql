update public.calculators
set faq = '[
 {"question":"What does the OCPD Calculator return?","answer":"It returns the minimum protection current the device must carry, calculated from the design current you enter and, if you supply one, a continuous-load factor from your own standard. With no factor entered, the required protection current equals the design current."},
 {"question":"Does it recommend a breaker or fuse size?","answer":"No. A standard device rating is only returned when a verified standard-rating series exists in OHMICLY engineering data. No such series is loaded in this version, so standard selection is reported as unavailable rather than proposed."},
 {"question":"Does it check the device against conductor ampacity?","answer":"No. No verified ampacity table is loaded, so coordination between the device and the conductor is not checked. Interrupting rating, let-through energy and selectivity with upstream devices are also outside the scope of this version."},
 {"question":"What does the maximum allowable rating comparison mean?","answer":"If you enter a maximum allowable protection rating, the tool reports whether the required protection current is at or below that value. It is a numeric comparison against your own input, not a compliance determination."}
]'::jsonb
where slug = 'ocpd-calculator';

update public.calculators
set faq = faq || '[
 {"question":"Which circuit types does this calculator handle?","answer":"DC, single-phase AC and three-phase AC circuits are each calculated with their own formula, using the system voltage, load current, one-way run length, conductor size and conductor material you enter."},
 {"question":"What results does it give?","answer":"The voltage drop in volts, the drop as a percentage of the system voltage, and the estimated receiving-end voltage at the load."},
 {"question":"How can I reduce an excessive voltage drop?","answer":"Typical options, in rough order of cost, are increasing the conductor size, adding conductors in parallel per phase, shortening the run or relocating the distribution board closer to the load, raising the distribution voltage, or improving the load power factor. You can test each change by re-running the calculation."}
]'::jsonb
where slug = 'voltage-drop-calculator';