create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated, service_role;

alter function public.is_admin(uuid) set schema private;
alter function public.has_role(uuid, public.app_role) set schema private;
alter function public.is_admin_internal(uuid) set schema private;

create or replace function private.is_admin_internal(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role in ('admin','super_admin')
  )
$$;

create or replace function private.is_admin(_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public as $$
  select private.is_admin_internal(_user_id)
$$;

create or replace function private.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.user_roles where user_id = _user_id and role = _role
  )
$$;

revoke all on function private.is_admin(uuid) from public, anon;
revoke all on function private.has_role(uuid, public.app_role) from public, anon;
revoke all on function private.is_admin_internal(uuid) from public, anon;
grant execute on function private.is_admin(uuid) to authenticated, service_role;
grant execute on function private.has_role(uuid, public.app_role) to authenticated, service_role;
grant execute on function private.is_admin_internal(uuid) to service_role;

create or replace function public.has_premium_access(_user_id uuid default auth.uid())
returns boolean language sql stable security invoker set search_path = public as $$
  select case
    when _user_id is null or auth.uid() is null then false
    else exists (
      select 1 from public.premium_entitlements
      where user_id = _user_id and is_active and (expires_at is null or expires_at > now())
    ) or exists (
      select 1 from public.user_roles
      where user_id = _user_id and role in ('admin','super_admin')
    )
  end
$$;
revoke all on function public.has_premium_access(uuid) from public, anon;
grant execute on function public.has_premium_access(uuid) to authenticated, service_role;