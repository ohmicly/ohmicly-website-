
-- Public search no longer bypasses row-level security
CREATE OR REPLACE FUNCTION public.search_content(q text, scope text DEFAULT 'All'::text)
 RETURNS TABLE(id text, type text, label text, title text, description text, href text, access text, rank real)
 LANGUAGE sql
 STABLE SECURITY INVOKER
 SET search_path TO 'public'
AS $function$
  with query as (select websearch_to_tsquery('english', coalesce(nullif(trim(q),''),'')) as tsq)
  select * from (
    select c.id::text, 'CALCULATOR', 'CALCULATOR', c.name, c.description, '/tools/'||c.slug, 'free',
           ts_rank(c.search_tsv, query.tsq)
    from public.calculators c, query
    where c.is_published and (scope in ('All','Tools')) and c.search_tsv @@ query.tsq
    union all
    select r.id::text, 'RESOURCE', coalesce(r.file_type,'FILE'), r.title, r.description, '/resources/'||r.slug,
           case when r.is_premium then 'premium' else 'free' end, ts_rank(r.search_tsv, query.tsq)
    from public.resources r, query
    where r.status = 'published' and (scope in ('All','Resources','Files')) and r.search_tsv @@ query.tsq
    union all
    select a.id::text, 'ARTICLE', 'ARTICLE', a.title, a.excerpt, '/blog/'||a.slug, 'free',
           ts_rank(a.search_tsv, query.tsq)
    from public.articles a, query
    where a.status = 'published' and (scope in ('All','Articles')) and a.search_tsv @@ query.tsq
    union all
    select f.id::text, 'FAQ', 'FAQ', f.question, f.answer, '/knowledge#faqs', 'free',
           ts_rank(f.search_tsv, query.tsq)
    from public.faqs f, query
    where f.is_published and (scope in ('All','FAQs')) and f.search_tsv @@ query.tsq
  ) results(id, type, label, title, description, href, access, rank)
  order by rank desc, title asc
  limit 100
$function$;

-- Premium entitlement checks can only be made about yourself (admins may check anyone)
CREATE OR REPLACE FUNCTION public.has_premium_access(_user_id uuid DEFAULT auth.uid())
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select case
    when _user_id is null or auth.uid() is null then false
    when _user_id <> auth.uid() and not public.is_admin(auth.uid()) then false
    else exists (
      select 1 from public.premium_entitlements
      where user_id = _user_id and is_active and (expires_at is null or expires_at > now())
    ) or public.is_admin(_user_id)
  end
$function$;

REVOKE EXECUTE ON FUNCTION public.has_premium_access(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.search_content(text, text) TO anon, authenticated, service_role;
