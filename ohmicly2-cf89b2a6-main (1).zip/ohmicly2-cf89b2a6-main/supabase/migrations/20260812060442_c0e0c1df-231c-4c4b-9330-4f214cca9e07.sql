alter table public.resources add column if not exists storage_bucket text;

-- Storage policies: admin-only write, no direct client reads (downloads go through signed URLs minted server-side)
do $$
declare b text;
begin
  foreach b in array array['resources','autocad','autolisp','templates','checklists','pdf','images'] loop
    execute format($f$
      create policy %I on storage.objects for insert to authenticated
        with check (bucket_id = %L and public.is_admin());
    $f$, 'admin_insert_' || b, b);
    execute format($f$
      create policy %I on storage.objects for update to authenticated
        using (bucket_id = %L and public.is_admin()) with check (bucket_id = %L and public.is_admin());
    $f$, 'admin_update_' || b, b, b);
    execute format($f$
      create policy %I on storage.objects for delete to authenticated
        using (bucket_id = %L and public.is_admin());
    $f$, 'admin_delete_' || b, b);
    execute format($f$
      create policy %I on storage.objects for select to authenticated
        using (bucket_id = %L and public.is_admin());
    $f$, 'admin_select_' || b, b);
  end loop;
end $$;

create or replace function public.get_published_resource_file(_slug text)
returns table(bucket text, path text, is_premium boolean)
language sql
stable
security definer
set search_path = public
as $$
  select r.storage_bucket, r.file_path, r.is_premium
  from public.resources r
  where r.slug = _slug and r.status = 'published' and r.file_path is not null
$$;

revoke all on function public.get_published_resource_file(text) from public, anon, authenticated;
grant execute on function public.get_published_resource_file(text) to service_role;