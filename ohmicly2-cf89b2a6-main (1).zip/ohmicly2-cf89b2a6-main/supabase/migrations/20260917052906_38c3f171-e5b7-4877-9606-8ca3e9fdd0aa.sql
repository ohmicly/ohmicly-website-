DROP POLICY IF EXISTS site_settings_public_read ON public.site_settings;
CREATE POLICY site_settings_public_branding_read
ON public.site_settings
FOR SELECT
TO anon, authenticated
USING (key IN ('site', 'branding'));

CREATE POLICY admin_site_assets_insert
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'site-assets'
  AND private.is_admin(auth.uid())
  AND (name LIKE 'branding/logo/%' OR name LIKE 'branding/favicon/%')
);

CREATE POLICY admin_site_assets_select
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'site-assets'
  AND private.is_admin(auth.uid())
  AND (name LIKE 'branding/logo/%' OR name LIKE 'branding/favicon/%')
);

CREATE POLICY admin_site_assets_update
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'site-assets'
  AND private.is_admin(auth.uid())
  AND (name LIKE 'branding/logo/%' OR name LIKE 'branding/favicon/%')
)
WITH CHECK (
  bucket_id = 'site-assets'
  AND private.is_admin(auth.uid())
  AND (name LIKE 'branding/logo/%' OR name LIKE 'branding/favicon/%')
);

CREATE POLICY admin_site_assets_delete
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'site-assets'
  AND private.is_admin(auth.uid())
  AND (name LIKE 'branding/logo/%' OR name LIKE 'branding/favicon/%')
);