alter table public.resources
  add column if not exists who_for text,
  add column if not exists problem_solved text,
  add column if not exists whats_included text[] not null default '{}'::text[],
  add column if not exists how_to_use text[] not null default '{}'::text[];