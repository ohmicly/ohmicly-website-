-- Lock down direct API execution of privileged SECURITY DEFINER functions
REVOKE EXECUTE ON FUNCTION public.consume_rate_limit(text, integer, integer) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.get_published_resource_file(text) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.increment_resource_download(uuid) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.tags_text(text[]) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM anon, authenticated, public;

GRANT EXECUTE ON FUNCTION public.consume_rate_limit(text, integer, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.get_published_resource_file(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.increment_resource_download(uuid) TO service_role;

-- Role/entitlement checks are only needed by signed-in users (used by RLS policies and the app)
REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.has_premium_access(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_premium_access(uuid) TO authenticated, service_role;

-- Public site search stays callable by visitors
GRANT EXECUTE ON FUNCTION public.search_content(text, text) TO anon, authenticated, service_role;