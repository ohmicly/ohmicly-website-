UPDATE public.calculators
SET name = 'Electrical Load Calculator',
    updated_at = now()
WHERE slug = 'load-calculator';