CREATE INDEX IF NOT EXISTS articles_status_published_idx ON public.articles (status, published_at DESC);
CREATE INDEX IF NOT EXISTS calculators_is_published_idx ON public.calculators (is_published);
CREATE INDEX IF NOT EXISTS faqs_published_sort_idx ON public.faqs (is_published, sort_order);
CREATE INDEX IF NOT EXISTS downloads_resource_idx ON public.downloads (resource_id);
CREATE INDEX IF NOT EXISTS downloads_user_created_idx ON public.downloads (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS resource_references_standard_idx ON public.resource_references (standard_id);
CREATE INDEX IF NOT EXISTS calculator_references_standard_idx ON public.calculator_references (standard_id);
CREATE INDEX IF NOT EXISTS article_references_standard_idx ON public.article_references (standard_id);

CREATE OR REPLACE FUNCTION public.increment_resource_download(_resource_id uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  UPDATE public.resources
  SET download_count = download_count + 1
  WHERE id = _resource_id
$$;

REVOKE ALL ON FUNCTION public.increment_resource_download(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_resource_download(uuid) TO service_role;