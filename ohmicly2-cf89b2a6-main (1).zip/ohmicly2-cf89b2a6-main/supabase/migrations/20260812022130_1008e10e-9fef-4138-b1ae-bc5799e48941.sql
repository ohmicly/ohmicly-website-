create type public.app_role as enum ('user','admin','super_admin');
create type public.publish_status as enum ('draft','published','archived');
create type public.resource_kind as enum ('autocad','autolisp','electrical-cad','earthing','lps','pdf-books','checklist','template','electrical-safety','electricians-zone','cv-template','guide','blog','other');

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end $$;

create or replace function public.tags_text(_tags text[])
returns text language sql immutable set search_path = public as $$
  select coalesce(array_to_string(_tags, ' '), '')
$$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  headline text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create trigger profiles_updated before update on public.profiles for each row execute function public.set_updated_at();

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_admin(_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role in ('admin','super_admin'))
$$;

create policy "user_roles_select_own" on public.user_roles for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "user_roles_admin_write" on public.user_roles for all to authenticated
  using (public.has_role(auth.uid(),'super_admin')) with check (public.has_role(auth.uid(),'super_admin'));

create table public.resource_categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  icon text,
  description text,
  parent_id uuid references public.resource_categories(id) on delete set null,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.article_categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  description text,
  created_at timestamptz not null default now()
);
create table public.resource_tags (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  created_at timestamptz not null default now()
);
create table public.standards (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  code text not null,
  edition text,
  publisher text,
  summary text not null,
  url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text not null default '',
  resource_type public.resource_kind not null default 'other',
  category_id uuid references public.resource_categories(id) on delete set null,
  subcategory text,
  file_type text,
  file_path text,
  file_url text,
  thumbnail_url text,
  is_free boolean not null default true,
  is_premium boolean not null default false,
  status public.publish_status not null default 'draft',
  featured boolean not null default false,
  tags text[] not null default '{}',
  author text not null default 'OHMICLY',
  download_count int not null default 0,
  view_count int not null default 0,
  seo_title text,
  seo_description text,
  canonical_url text,
  schema_type text not null default 'CreativeWork',
  created_by uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  search_tsv tsvector generated always as (
    setweight(to_tsvector('english'::regconfig, coalesce(title,'')),'A') ||
    setweight(to_tsvector('english'::regconfig, coalesce(description,'')),'B') ||
    setweight(to_tsvector('english'::regconfig, public.tags_text(tags)),'C')
  ) stored
);
create index resources_search_idx on public.resources using gin (search_tsv);
create index resources_status_idx on public.resources (status, featured);
create index resources_category_idx on public.resources (category_id);

create table public.resource_tag_map (
  resource_id uuid not null references public.resources(id) on delete cascade,
  tag_id uuid not null references public.resource_tags(id) on delete cascade,
  primary key (resource_id, tag_id)
);

create table public.calculators (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  category text not null default 'General',
  icon text,
  status text not null default 'coming-soon',
  seo_title text,
  seo_description text,
  keywords text[] not null default '{}',
  formula_notes text[] not null default '{}',
  disclaimer text,
  related_calculators text[] not null default '{}',
  faq jsonb not null default '[]'::jsonb,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  search_tsv tsvector generated always as (
    setweight(to_tsvector('english'::regconfig, coalesce(name,'')),'A') ||
    setweight(to_tsvector('english'::regconfig, coalesce(description,'')),'B') ||
    setweight(to_tsvector('english'::regconfig, public.tags_text(keywords)),'C')
  ) stored
);
create index calculators_search_idx on public.calculators using gin (search_tsv);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  excerpt text not null default '',
  body text,
  category_id uuid references public.article_categories(id) on delete set null,
  author text not null default 'OHMICLY',
  reading_time text,
  status public.publish_status not null default 'draft',
  tags text[] not null default '{}',
  seo_title text,
  seo_description text,
  canonical_url text,
  created_by uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  search_tsv tsvector generated always as (
    setweight(to_tsvector('english'::regconfig, coalesce(title,'')),'A') ||
    setweight(to_tsvector('english'::regconfig, coalesce(excerpt,'')),'B') ||
    setweight(to_tsvector('english'::regconfig, public.tags_text(tags)),'C')
  ) stored
);
create index articles_search_idx on public.articles using gin (search_tsv);

create table public.faqs (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  scope text not null default 'site',
  resource_id uuid references public.resources(id) on delete cascade,
  calculator_id uuid references public.calculators(id) on delete cascade,
  sort_order int not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  search_tsv tsvector generated always as (
    setweight(to_tsvector('english'::regconfig, coalesce(question,'')),'A') ||
    setweight(to_tsvector('english'::regconfig, coalesce(answer,'')),'B')
  ) stored
);
create index faqs_search_idx on public.faqs using gin (search_tsv);

create table public.resource_references (
  id uuid primary key default gen_random_uuid(),
  resource_id uuid not null references public.resources(id) on delete cascade,
  standard_id uuid not null references public.standards(id) on delete cascade,
  section text, note text, url text, verified boolean not null default false,
  created_at timestamptz not null default now(),
  unique (resource_id, standard_id, section)
);
create table public.calculator_references (
  id uuid primary key default gen_random_uuid(),
  calculator_id uuid not null references public.calculators(id) on delete cascade,
  standard_id uuid not null references public.standards(id) on delete cascade,
  section text, note text, url text, verified boolean not null default false,
  created_at timestamptz not null default now(),
  unique (calculator_id, standard_id, section)
);
create table public.article_references (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  standard_id uuid not null references public.standards(id) on delete cascade,
  section text, note text, url text, verified boolean not null default false,
  created_at timestamptz not null default now(),
  unique (article_id, standard_id, section)
);

create table public.downloads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  resource_id uuid not null references public.resources(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  resource_id uuid not null references public.resources(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, resource_id)
);
create table public.premium_entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan text not null default 'pro',
  source text not null default 'manual',
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index premium_entitlements_user_idx on public.premium_entitlements (user_id);

create table public.site_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

do $$ declare t text;
begin
  foreach t in array array['resource_categories','standards','resources','calculators','articles','faqs','premium_entitlements','site_settings']
  loop
    execute format('create trigger %I_updated before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

grant select on public.resource_categories, public.article_categories, public.resource_tags, public.standards,
  public.resources, public.resource_tag_map, public.calculators, public.articles, public.faqs,
  public.resource_references, public.calculator_references, public.article_references, public.site_settings
  to anon, authenticated;
grant insert, update, delete on public.resource_categories, public.article_categories, public.resource_tags, public.standards,
  public.resources, public.resource_tag_map, public.calculators, public.articles, public.faqs,
  public.resource_references, public.calculator_references, public.article_references, public.site_settings
  to authenticated;
grant select, insert on public.downloads to authenticated;
grant insert on public.downloads to anon;
grant select, insert, delete on public.favorites to authenticated;
grant select on public.premium_entitlements to authenticated;
grant all on public.resource_categories, public.article_categories, public.resource_tags, public.standards,
  public.resources, public.resource_tag_map, public.calculators, public.articles, public.faqs,
  public.resource_references, public.calculator_references, public.article_references,
  public.downloads, public.favorites, public.premium_entitlements, public.site_settings to service_role;

alter table public.resource_categories enable row level security;
alter table public.article_categories enable row level security;
alter table public.resource_tags enable row level security;
alter table public.standards enable row level security;
alter table public.resources enable row level security;
alter table public.resource_tag_map enable row level security;
alter table public.calculators enable row level security;
alter table public.articles enable row level security;
alter table public.faqs enable row level security;
alter table public.resource_references enable row level security;
alter table public.calculator_references enable row level security;
alter table public.article_references enable row level security;
alter table public.downloads enable row level security;
alter table public.favorites enable row level security;
alter table public.premium_entitlements enable row level security;
alter table public.site_settings enable row level security;

do $$ declare t text;
begin
  foreach t in array array['resource_categories','article_categories','resource_tags','standards','resource_tag_map',
                           'resource_references','calculator_references','article_references']
  loop
    execute format('create policy "%s_public_read" on public.%I for select to anon, authenticated using (true)', t, t);
    execute format('create policy "%s_admin_write" on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t, t);
  end loop;
end $$;

create policy "resources_public_read" on public.resources for select to anon, authenticated using (status = 'published');
create policy "resources_admin_read" on public.resources for select to authenticated using (public.is_admin());
create policy "resources_admin_write" on public.resources for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "articles_public_read" on public.articles for select to anon, authenticated using (status = 'published');
create policy "articles_admin_read" on public.articles for select to authenticated using (public.is_admin());
create policy "articles_admin_write" on public.articles for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "calculators_public_read" on public.calculators for select to anon, authenticated using (is_published);
create policy "calculators_admin_read" on public.calculators for select to authenticated using (public.is_admin());
create policy "calculators_admin_write" on public.calculators for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "faqs_public_read" on public.faqs for select to anon, authenticated using (is_published);
create policy "faqs_admin_write" on public.faqs for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "site_settings_public_read" on public.site_settings for select to anon, authenticated using (true);
create policy "site_settings_admin_write" on public.site_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "downloads_insert_self" on public.downloads for insert to authenticated with check (user_id = auth.uid() or user_id is null);
create policy "downloads_insert_anon" on public.downloads for insert to anon with check (user_id is null);
create policy "downloads_select_own" on public.downloads for select to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "favorites_own" on public.favorites for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "entitlements_select_own" on public.premium_entitlements for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "entitlements_admin_write" on public.premium_entitlements for all to authenticated using (public.is_admin()) with check (public.is_admin());

create or replace function public.has_premium_access(_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.premium_entitlements
    where user_id = _user_id and is_active and (expires_at is null or expires_at > now())
  ) or public.is_admin(_user_id)
$$;

create or replace function public.search_content(q text, scope text default 'All')
returns table (id text, type text, label text, title text, description text, href text, access text, rank real)
language sql stable security definer set search_path = public as $$
  with query as (select websearch_to_tsquery('english', coalesce(nullif(trim(q),''),'')) as tsq)
  select * from (
    select c.id::text, 'CALCULATOR', 'CALCULATOR', c.name, c.description, '/tools/'||c.slug, 'free',
           ts_rank(c.search_tsv, query.tsq)
    from public.calculators c, query
    where c.is_published and (scope in ('All','Tools')) and c.search_tsv @@ query.tsq
    union all
    select r.id::text, 'RESOURCE', coalesce(r.file_type,'FILE'), r.title, r.description, '/resources/'||r.slug,
           case when r.is_premium then 'premium' else 'free' end, ts_rank(r.search_tsv, query.tsq)
    from public.resources r, query
    where r.status = 'published' and (scope in ('All','Resources','Files')) and r.search_tsv @@ query.tsq
    union all
    select a.id::text, 'ARTICLE', 'ARTICLE', a.title, a.excerpt, '/blog/'||a.slug, 'free',
           ts_rank(a.search_tsv, query.tsq)
    from public.articles a, query
    where a.status = 'published' and (scope in ('All','Articles')) and a.search_tsv @@ query.tsq
    union all
    select f.id::text, 'FAQ', 'FAQ', f.question, f.answer, '/knowledge#faqs', 'free',
           ts_rank(f.search_tsv, query.tsq)
    from public.faqs f, query
    where f.is_published and (scope in ('All','FAQs')) and f.search_tsv @@ query.tsq
  ) results(id, type, label, title, description, href, access, rank)
  order by rank desc, title asc
  limit 100
$$;
grant execute on function public.search_content(text, text) to anon, authenticated;
grant execute on function public.has_premium_access(uuid) to authenticated;
grant execute on function public.has_role(uuid, public.app_role) to authenticated;
grant execute on function public.is_admin(uuid) to anon, authenticated;