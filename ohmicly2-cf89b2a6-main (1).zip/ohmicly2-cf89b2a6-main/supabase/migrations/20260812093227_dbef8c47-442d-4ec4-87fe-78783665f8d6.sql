-- Make Load Calculator available with formula notes
UPDATE public.calculators
SET
  status = 'available',
  formula_notes = ARRAY[
    'Apparent power S (kVA) = P (kW) ÷ power factor.',
    'Single-phase current I = S × 1000 ÷ V.',
    'Three-phase current I = S × 1000 ÷ (√3 × V), using the line-to-line voltage.',
    'Total connected load = unit load power × quantity.',
    'A user-supplied load/diversity factor is applied only when explicitly entered; OHMICLY does not apply automatic demand or diversity factors.',
    'Motor starting current, efficiency, service factor and power-factor correction are not modelled in this version.'
  ],
  updated_at = now()
WHERE slug = 'load-calculator';

-- Attach references to existing verified standards (no invented clause numbers)
INSERT INTO public.calculator_references (calculator_id, standard_id, section, note)
SELECT
  c.id,
  s.id,
  NULL,
  'Referenced as an applicable installation code; no specific clause number is claimed.'
FROM public.calculators c
CROSS JOIN public.standards s
WHERE c.slug = 'load-calculator'
  AND s.code IN ('BNBC', 'NFPA 70 / NEC')
ON CONFLICT (calculator_id, standard_id, section) DO UPDATE SET
  note = EXCLUDED.note;

-- Add FAQs using the existing database structure (idempotent: clear then insert)
DELETE FROM public.faqs
WHERE calculator_id IN (SELECT id FROM public.calculators WHERE slug = 'load-calculator');

INSERT INTO public.faqs (calculator_id, question, answer, scope, sort_order, is_published)
SELECT
  c.id,
  q.question,
  q.answer,
  'calculator',
  q.sort_order,
  true
FROM public.calculators c
CROSS JOIN (
  VALUES
    (1, 'What does the Load Calculator compute?', 'It calculates apparent power (kVA), load current (A) and total connected load from the real power (kW), voltage, phase arrangement, power factor and quantity you enter. If you supply a verified load or diversity factor, it also shows the diversified load.'),
    (2, 'Does it apply demand or diversity factors automatically?', 'No. OHMICLY does not hold verified demand/diversity tables for every country and installation type, so no factor is applied unless you explicitly enter one from your applicable standard.'),
    (3, 'Can I use this for motor feeders?', 'The calculator gives running current only. Motor starting (locked-rotor) current, efficiency, service factor and power-factor correction are not modelled. Size motor feeders and protection separately.')
) AS q(sort_order, question, answer)
WHERE c.slug = 'load-calculator';