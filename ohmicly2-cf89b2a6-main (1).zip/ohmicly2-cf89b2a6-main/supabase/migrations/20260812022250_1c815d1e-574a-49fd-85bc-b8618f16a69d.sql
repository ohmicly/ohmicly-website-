revoke execute on function public.is_admin(uuid) from anon;

insert into public.standards (slug,name,code,edition,publisher,summary,url) values
 ('bnbc-2020','Bangladesh National Building Code','BNBC','2020','Government of Bangladesh','National building code covering electrical installations, safety and building services requirements in Bangladesh.',null),
 ('nfpa-70','National Electrical Code','NFPA 70 / NEC',null,'National Fire Protection Association','Widely adopted code for safe electrical design, installation and inspection practice.','https://www.nfpa.org/codes-and-standards'),
 ('nsc','National Safety Council guidance','NSC',null,null,'Occupational safety guidance frequently referenced in electrical safety programmes.',null),
 ('rsc','RMG Sustainability Council standards','RSC',null,null,'Factory safety inspection and remediation standards applied to electrical installations in Bangladesh RMG facilities.',null),
 ('nirapon','Nirapon safety programme','Nirapon',null,null,'Programme monitoring fire, electrical and structural safety compliance in Bangladesh factories.',null);

insert into public.resource_categories (slug,name,icon,description,sort_order) values
 ('autocad','AutoCAD','pen-tool','DWG drawings, SLD sheets and electrical symbol libraries.',1),
 ('autolisp','AutoLISP','terminal','Drafting utilities and routines that speed up electrical drawing work.',2),
 ('electrical-cad','Electrical CAD','layout-grid','Layout, schematic and detailing resources for electrical CAD work.',3),
 ('earthing','Earthing','shield','Earthing system design references, layouts and calculation sheets.',4),
 ('lps','LPS','zap','Lightning protection design references and drawing templates.',5),
 ('pdf-books','PDF Books','book-open','Reference books and long-form electrical engineering material.',6),
 ('checklists','Checklists','clipboard-check','Inspection, audit and commissioning checklists.',7),
 ('templates','Templates','layers','Schedules, calculation sheets and reporting formats.',8),
 ('electrical-safety','Electrical Safety','hard-hat','Safety documentation, signage and verification resources.',9),
 ('electricians-zone','Electricians Zone','plug','Practical field material for electricians and technicians.',10);

insert into public.article_categories (slug,name) values
 ('earthing','Earthing'),('rsc-audit','RSC Audit'),('substation','Substation'),('electrical-design','Electrical Design');

insert into public.resources (title,slug,description,resource_type,category_id,subcategory,file_type,is_free,is_premium,status,featured,tags,seo_title,seo_description,canonical_url,published_at) values
 ('MDB Single Line Diagram Template','mdb-sld-template','Base DWG sheet for main distribution board single line diagrams.','autocad',(select id from public.resource_categories where slug='autocad'),'sld','DWG',false,true,'published',true,array['sld','mdb','dwg'],'MDB Single Line Diagram Template — OHMICLY','Base DWG sheet for main distribution board single line diagrams.','/resources/mdb-sld-template',now()),
 ('Electrical Symbols Pack','electrical-symbols-pack','Symbol blocks for power, lighting and control drawings.','electrical-cad',(select id from public.resource_categories where slug='electrical-cad'),null,'DWG',true,false,'published',true,array['symbols','blocks','dwg'],'Electrical Symbols Pack — OHMICLY','Symbol blocks for power, lighting and control drawings.','/resources/electrical-symbols-pack',now()),
 ('AutoLISP Cable Tagging Utility','autolisp-cable-tag-utility','Routine for tagging cable references consistently across a drawing set.','autolisp',(select id from public.resource_categories where slug='autolisp'),null,'LSP',true,false,'published',false,array['autolisp','tagging','drafting'],'AutoLISP Cable Tagging Utility — OHMICLY','Routine for tagging cable references consistently across a drawing set.','/resources/autolisp-cable-tag-utility',now()),
 ('AutoLISP Panel Block Inserter','autolisp-panel-block-inserter','Insert and align distribution panel blocks with repeatable spacing.','autolisp',(select id from public.resource_categories where slug='autolisp'),null,'LSP',false,true,'published',false,array['autolisp','blocks','productivity'],'AutoLISP Panel Block Inserter — OHMICLY','Insert and align distribution panel blocks with repeatable spacing.','/resources/autolisp-panel-block-inserter',now()),
 ('Panel Schedule Template','panel-schedule-template','Circuit-by-circuit schedule with load balance summary.','template',(select id from public.resource_categories where slug='templates'),'schedules','XLSX',true,false,'published',true,array['panel schedule','load balance'],'Panel Schedule Template — OHMICLY','Circuit-by-circuit schedule with load balance summary.','/resources/panel-schedule-template',now()),
 ('Load Schedule Template','load-schedule-template','Connected and diversified load summary sheet for distribution boards.','template',(select id from public.resource_categories where slug='templates'),'schedules','XLSX',true,false,'published',false,array['load schedule','diversity'],'Load Schedule Template — OHMICLY','Connected and diversified load summary sheet for distribution boards.','/resources/load-schedule-template',now()),
 ('Earthing Design Template','earthing-design-template','Layout and calculation sheet for earth electrode systems.','earthing',(select id from public.resource_categories where slug='earthing'),null,'XLSX',false,true,'published',false,array['earthing','electrode','calculation'],'Earthing Design Template — OHMICLY','Layout and calculation sheet for earth electrode systems.','/resources/earthing-design-template',now()),
 ('LPS Design Template','lps-design-template','Air termination, down conductor and bonding arrangement sheet.','lps',(select id from public.resource_categories where slug='lps'),null,'DWG',false,true,'published',false,array['lightning protection','bonding'],'LPS Design Template — OHMICLY','Air termination, down conductor and bonding arrangement sheet.','/resources/lps-design-template',now()),
 ('RSC Electrical Audit Checklist','rsc-electrical-audit-checklist','Electrical scope checklist structured around RSC inspection points.','checklist',(select id from public.resource_categories where slug='checklists'),'rsc','PDF',true,false,'published',true,array['rsc','audit','checklist'],'RSC Electrical Audit Checklist — OHMICLY','Electrical scope checklist structured around RSC inspection points.','/resources/rsc-electrical-audit-checklist',now()),
 ('Nirapon Electrical Assessment Checklist','nirapon-electrical-checklist','Structured checklist for Nirapon electrical assessments.','checklist',(select id from public.resource_categories where slug='checklists'),'nirapon','PDF',true,false,'published',false,array['nirapon','assessment'],'Nirapon Electrical Assessment Checklist — OHMICLY','Structured checklist for Nirapon electrical assessments.','/resources/nirapon-electrical-checklist',now()),
 ('Audit Reporting Template','audit-reporting-template','Report format for observations, corrective actions and evidence.','template',(select id from public.resource_categories where slug='templates'),'reporting','DOCX',true,false,'published',false,array['audit report','cap','reporting'],'Audit Reporting Template — OHMICLY','Report format for observations, corrective actions and evidence.','/resources/audit-reporting-template',now()),
 ('Electrical Safety Inspection Checklist','electrical-safety-inspection-checklist','Site verification list for panels, cabling, earthing and signage.','electrical-safety',(select id from public.resource_categories where slug='electrical-safety'),null,'PDF',true,false,'published',false,array['safety','inspection'],'Electrical Safety Inspection Checklist — OHMICLY','Site verification list for panels, cabling, earthing and signage.','/resources/electrical-safety-inspection-checklist',now()),
 ('Electrical Engineer CV Template','electrical-engineer-cv-template','Structured CV format focused on project and compliance experience.','cv-template',(select id from public.resource_categories where slug='templates'),'career','DOCX',false,true,'published',false,array['cv','career'],'Electrical Engineer CV Template — OHMICLY','Structured CV format focused on project and compliance experience.','/resources/electrical-engineer-cv-template',now()),
 ('Electrical Installation Reference Guide','electrical-installation-guide','Reference guide covering distribution, protection and earthing basics.','guide',(select id from public.resource_categories where slug='pdf-books'),null,'PDF',true,false,'published',false,array['guide','reference'],'Electrical Installation Reference Guide — OHMICLY','Reference guide covering distribution, protection and earthing basics.','/resources/electrical-installation-guide',now());

insert into public.resource_references (resource_id,standard_id,verified)
select r.id, s.id, true from (values
 ('mdb-sld-template','bnbc-2020'),
 ('earthing-design-template','bnbc-2020'),
 ('rsc-electrical-audit-checklist','rsc'),
 ('nirapon-electrical-checklist','nirapon'),
 ('audit-reporting-template','rsc'),
 ('electrical-safety-inspection-checklist','nsc'),
 ('electrical-installation-guide','nfpa-70')
) as m(res,std)
join public.resources r on r.slug = m.res
join public.standards s on s.slug = m.std;

insert into public.calculators (name,slug,description,category,icon,status,seo_title,seo_description,keywords,formula_notes,related_calculators,faq) values
 ('Voltage Drop Calculator','voltage-drop-calculator','Check permissible voltage drop across feeders and final circuits.','Cables & Circuits','activity','coming-soon','Voltage Drop Calculator — OHMICLY','Calculate voltage drop across electrical feeders and final circuits using conductor size, length, load current and power factor.',array['voltage drop','feeder','cable run','percentage drop'],array['Voltage drop depends on conductor resistance and reactance, circuit length, load current and power factor.','Permissible limits are defined by the applicable code and project specification, not by this tool.'],array['cable-size-calculator','load-calculator'],'[{"question":"What is voltage drop in an electrical circuit?","answer":"Voltage drop is the reduction in voltage between the source and the load, caused by the resistance and reactance of the conductor carrying the current."},{"question":"Why does voltage drop matter in design?","answer":"Excessive drop reduces equipment performance and can cause nuisance operation. Design limits are set by the applicable code and project specification."}]'::jsonb),
 ('Cable Size Calculator','cable-size-calculator','Size conductors from load current, route length, installation method and derating.','Cables & Circuits','cable','coming-soon','Cable Size Calculator — OHMICLY','Select conductor size from design current, installation method, ambient temperature, grouping and voltage drop limits.',array['cable sizing','conductor size','derating','current carrying capacity'],array['Current carrying capacity is adjusted by derating factors for temperature, grouping and installation method.'],array['voltage-drop-calculator','fault-current-calculator'],'[{"question":"What determines the required cable size?","answer":"Design current, installation method, ambient temperature, grouping, permitted voltage drop and protection against fault current all influence the selected conductor size."}]'::jsonb),
 ('Load Calculator','load-calculator','Build connected and diversified load schedules for boards and feeders.','Distribution','gauge','coming-soon','Electrical Load Calculator — OHMICLY','Prepare connected load, demand factor and diversified load summaries for distribution boards and feeders.',array['load calculation','demand factor','diversity','connected load'],array['Connected load multiplied by applicable demand factors gives the diversified load.'],array['transformer-calculator','cable-size-calculator'],'[{"question":"What is diversified load?","answer":"Diversified load is the connected load adjusted by demand factors that reflect how much equipment operates simultaneously."}]'::jsonb),
 ('Transformer Calculator','transformer-calculator','Full load current, impedance and kVA rating checks for distribution transformers.','Substation','boxes','coming-soon','Transformer Calculator — OHMICLY','Determine transformer full load current, loading percentage and rating suitability for distribution substations.',array['transformer','kVA','full load current','impedance'],array['Rating selection should allow for diversity, future expansion and ambient conditions.'],array['fault-current-calculator','load-calculator'],'[{"question":"How is transformer full load current derived?","answer":"Full load current follows from the transformer kVA rating and rated voltage, adjusted for single-phase or three-phase configuration."}]'::jsonb),
 ('Fault Current Calculator','fault-current-calculator','Estimate prospective short circuit current at distribution boards.','Protection','zap','coming-soon','Fault Current Calculator — OHMICLY','Estimate prospective short circuit current for switchgear and protective device selection.',array['short circuit','fault level','breaking capacity','prospective fault current'],array['Fault level depends on source impedance, transformer impedance and cable impedance to the fault point.'],array['transformer-calculator','cable-size-calculator'],'[{"question":"Why is prospective fault current needed?","answer":"Protective devices must have a breaking capacity at least equal to the prospective fault current at their point of installation."}]'::jsonb),
 ('Earthing Calculator','earthing-calculator','Electrode resistance and conductor sizing checks for earthing systems.','Earthing & LPS','shield','coming-soon','Earthing Calculator — OHMICLY','Estimate earth electrode resistance and check earthing conductor sizing for electrical installations.',array['earthing','earth electrode','soil resistivity','earth resistance'],array['Measured resistance on site takes precedence over any estimated value.'],array['fault-current-calculator'],'[{"question":"What affects earth electrode resistance?","answer":"Soil resistivity, electrode length and diameter, electrode arrangement and moisture conditions all affect the measured resistance."}]'::jsonb);

insert into public.calculator_references (calculator_id,standard_id,verified)
select c.id, s.id, true from (values
 ('voltage-drop-calculator','bnbc-2020'),('voltage-drop-calculator','nfpa-70'),
 ('cable-size-calculator','bnbc-2020'),('cable-size-calculator','nfpa-70'),
 ('load-calculator','bnbc-2020'),
 ('transformer-calculator','bnbc-2020'),
 ('fault-current-calculator','nfpa-70'),
 ('earthing-calculator','bnbc-2020'),('earthing-calculator','nfpa-70')
) as m(calc,std)
join public.calculators c on c.slug = m.calc
join public.standards s on s.slug = m.std;

insert into public.articles (title,slug,excerpt,category_id,reading_time,status,tags,seo_title,seo_description,canonical_url,published_at,created_at) values
 ('Earthing and Bonding: What Actually Differs on Site','earthing-vs-bonding-explained','Protective earthing and equipotential bonding solve two different problems in a building installation — here is how that plays out in practice.',(select id from public.article_categories where slug='earthing'),'6 min read','published',array['earthing','bonding'],'Earthing and Bonding: What Actually Differs on Site — OHMICLY','Protective earthing and equipotential bonding solve two different problems in a building installation.','/blog/earthing-vs-bonding-explained','2026-02-02T00:00:00Z','2026-02-02T00:00:00Z'),
 ('Preparing an Electrical Installation for an RSC Audit','rsc-electrical-audit-preparation','Documentation, panel labelling and earthing evidence commonly decide whether observations are raised during an audit.',(select id from public.article_categories where slug='rsc-audit'),'8 min read','published',array['rsc','audit'],'Preparing an Electrical Installation for an RSC Audit — OHMICLY','Documentation, panel labelling and earthing evidence commonly decide whether observations are raised during an audit.','/blog/rsc-electrical-audit-preparation','2026-02-10T00:00:00Z','2026-02-10T00:00:00Z'),
 ('Selecting Transformer Rating for Industrial Loads','substation-transformer-selection','How diversity, future expansion and ambient conditions shape a defensible kVA selection for industrial substations.',(select id from public.article_categories where slug='substation'),'7 min read','published',array['transformer','substation'],'Selecting Transformer Rating for Industrial Loads — OHMICLY','How diversity, future expansion and ambient conditions shape a defensible kVA selection for industrial substations.','/blog/substation-transformer-selection','2026-02-18T00:00:00Z','2026-02-18T00:00:00Z'),
 ('Five Common Mistakes in Cable Sizing Calculations','cable-sizing-common-mistakes','Derating factors and voltage drop limits that get skipped when cable schedules are prepared under time pressure.',(select id from public.article_categories where slug='electrical-design'),'5 min read','published',array['cable sizing','derating'],'Five Common Mistakes in Cable Sizing Calculations — OHMICLY','Derating factors and voltage drop limits that get skipped when cable schedules are prepared under time pressure.','/blog/cable-sizing-common-mistakes','2026-02-24T00:00:00Z','2026-02-24T00:00:00Z');

insert into public.article_references (article_id,standard_id,verified)
select a.id, s.id, true from (values
 ('earthing-vs-bonding-explained','bnbc-2020'),
 ('rsc-electrical-audit-preparation','rsc'),
 ('cable-sizing-common-mistakes','nfpa-70')
) as m(art,std)
join public.articles a on a.slug = m.art
join public.standards s on s.slug = m.std;

insert into public.faqs (question,answer,scope,sort_order) values
 ('What is OHMICLY?','OHMICLY is an electrical engineering platform that brings calculators, engineering resources, audit material, CAD files, templates and technical knowledge together in one place.','site',1),
 ('Are OHMICLY resources free?','Most resources are free to access. A smaller set of professional resources is marked Premium and requires an account with premium access.','site',2),
 ('Which standards does OHMICLY reference?','Resources can cite BNBC 2020, NFPA 70 (NEC), NSC guidance, RSC and Nirapon requirements. Exact clause references are shown only where they have been verified.','site',3),
 ('Can OHMICLY calculations be used for compliance decisions?','No. Results are reference information and must be reviewed by a qualified electrical professional before use in design, construction or compliance decisions.','site',4);

insert into public.site_settings (key,value) values
 ('site', '{"name":"OHMICLY","tagline":"Electrical Engineering Tools, Resources & Knowledge — All in One Place."}'::jsonb);