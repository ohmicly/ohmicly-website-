
insert into public.calculators (name, slug, description, category, icon, status, seo_title, seo_description, keywords, formula_notes, disclaimer, related_calculators, faq, is_published)
values (
  'OCPD Calculator',
  'ocpd-calculator',
  'Calculate the required overcurrent protection current from your design current, with any continuous-load factor you supply. Standard device ratings are shown only when verified rating data is available.',
  'Protection',
  'shield-check',
  'available',
  'OCPD Calculator — Overcurrent Protection Sizing | OHMICLY',
  'Calculate the required overcurrent protection current from design current and an optional continuous-load factor. Transparent method, no invented breaker ratings.',
  array['ocpd calculator','overcurrent protection device','breaker sizing','fuse rating','protection current','electrical protection'],
  array[
    'Required protection current = design current x continuous-load factor, and the factor is applied only when the user explicitly enters one.',
    'With no factor entered, the required protection current equals the design current supplied by the user.',
    'A standard OCPD rating is returned only when a verified standard-rating series exists in OHMICLY engineering data; none is loaded in v1, so automatic device selection is reported as unavailable.',
    'No code multiplier, motor-circuit rule, next-standard-size allowance or conductor-ampacity coordination check is applied.'
  ],
  'This calculator is a design aid only. Final overcurrent protection device selection depends on the applicable code, equipment characteristics, conductor ampacity, continuous-load requirements, interrupting rating and manufacturer requirements, and must be reviewed by a qualified engineer.',
  array['load-calculator','cable-size-calculator','voltage-drop-calculator'],
  '[]'::jsonb,
  true
)
on conflict (slug) do update set
  status = excluded.status,
  description = excluded.description,
  seo_title = excluded.seo_title,
  seo_description = excluded.seo_description,
  formula_notes = excluded.formula_notes,
  disclaimer = excluded.disclaimer,
  related_calculators = excluded.related_calculators,
  is_published = true;

insert into public.calculator_references (calculator_id, standard_id, section, note, url, verified)
select c.id, s.id, null, 'Overcurrent protection requirements applicable to installations in Bangladesh. Clause numbers are not shown because they have not been verified into OHMICLY.', s.url, true
from public.calculators c, public.standards s
where c.slug = 'ocpd-calculator' and s.slug = 'bnbc-2020'
on conflict (calculator_id, standard_id, section) do nothing;

insert into public.calculator_references (calculator_id, standard_id, section, note, url, verified)
select c.id, s.id, null, 'Overcurrent protection and standard device rating requirements where NEC practice applies. Clause numbers are not shown because they have not been verified into OHMICLY.', s.url, true
from public.calculators c, public.standards s
where c.slug = 'ocpd-calculator' and s.slug = 'nfpa-70'
on conflict (calculator_id, standard_id, section) do nothing;

delete from public.faqs where calculator_id = (select id from public.calculators where slug = 'ocpd-calculator');

insert into public.faqs (question, answer, scope, calculator_id, sort_order, is_published)
select q.question, q.answer, 'calculator', c.id, q.sort_order, true
from public.calculators c,
(values
  ('Why does the calculator not suggest a breaker size?', 'OHMICLY only shows a standard device rating when a verified standard-rating series has been loaded into its engineering data. No such series is loaded yet, so the tool reports the required protection current and leaves device selection to you and your applicable code.', 1),
  ('What is the required protection current?', 'It is the minimum current the protective device must carry continuously without tripping: your design current, multiplied by a continuous-load factor only if you explicitly enter one.', 2),
  ('Should I enter a continuous-load factor?', 'Only if your applicable standard or project specification supplies one. The calculator never applies a multiplier automatically, because continuous-load rules differ between codes.', 3),
  ('Does this check the device against the conductor?', 'No. Conductor ampacity coordination requires verified ampacity tables, which OHMICLY does not hold. You can enter a maximum allowable rating yourself and the tool will compare it numerically with the required protection current.', 4),
  ('Can I use this result for motor circuits?', 'The running-current calculation applies, but motor branch-circuit protection limits, starting current and coordination rules are not modelled. Perform those checks separately against your code.', 5)
) as q(question, answer, sort_order)
where c.slug = 'ocpd-calculator';
