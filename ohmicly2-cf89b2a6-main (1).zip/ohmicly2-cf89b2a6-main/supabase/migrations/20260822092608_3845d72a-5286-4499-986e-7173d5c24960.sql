UPDATE public.resources SET
  problem_solved = 'Audit observations are often recorded in inconsistent, ad-hoc formats, which makes corrective actions hard to track and evidence hard to retrieve later. This template gives every finding a fixed structure so reports stay comparable across sites and review rounds.',
  who_for = 'Electrical auditors, compliance and EHS officers, and site engineers who have to issue written audit reports and follow corrective actions through to closure.',
  whats_included = ARRAY['Editable DOCX report layout with cover and report-identification fields','Observation entries with location, description and severity fields','Corrective action plan fields with responsibility and target date','Evidence section for attaching photographs and supporting notes','Closure and sign-off block for re-verification'],
  how_to_use = ARRAY['Open the DOCX in Word or a compatible editor and fill in the report header for the site and audit date.','Record one observation per entry while on site, keeping descriptions factual and location-specific.','Assign a corrective action, owner and target date to each observation.','Attach photographs or measurement notes in the evidence section for each finding.','Complete the closure block after re-verification, then export to PDF for issue.']
WHERE slug = 'audit-reporting-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Cable references are usually tagged by hand across many sheets, which is slow and leads to mismatched or duplicated tags between drawings. This routine applies tags consistently so the drawing set stays coordinated.',
  who_for = 'AutoCAD drafters and electrical design engineers producing multi-sheet cable and power distribution drawings.',
  whats_included = ARRAY['LSP routine for placing cable reference tags','Consistent tag formatting across a drawing set','Repeatable command usage for batch tagging work'],
  how_to_use = ARRAY['Load the LSP file into AutoCAD with the APPLOAD command.','Run the routine from the command line to start tagging.','Select the cable or line entity to tag and confirm the reference text.','Repeat across each sheet so the whole drawing set uses the same tag convention.','Save the routine to your AutoCAD support path if you want it available in every session.']
WHERE slug = 'autolisp-cable-tag-utility' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Earth electrode layouts and their supporting calculations are frequently kept in separate, unstructured files, so design assumptions get lost and results cannot be reviewed. This sheet keeps the layout and the calculation together in one auditable workbook.',
  who_for = 'Electrical design engineers and consultants preparing earthing system designs and the calculation records that accompany them.',
  whats_included = ARRAY['XLSX workbook combining electrode layout and calculation sheets','Input fields for soil, electrode and arrangement parameters','Calculation area for earth electrode system results','Layout summary suitable for attaching to a design submission'],
  how_to_use = ARRAY['Open the workbook in Excel or a compatible spreadsheet application.','Enter your site and electrode parameters in the input fields.','Review the calculated results and adjust the electrode arrangement as needed.','Record the assumptions you used so the sheet can be checked later.','Keep the completed workbook with the project design records and have results verified by a qualified engineer.']
WHERE slug = 'earthing-design-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'General-purpose CV formats bury the project and compliance experience that electrical hiring managers actually screen for. This structure puts that experience where it is read first.',
  who_for = 'Electrical engineers and technicians applying for design, site, maintenance or compliance roles.',
  whats_included = ARRAY['Editable DOCX CV layout','Profile summary section','Project experience section organised by role and scope','Compliance and safety experience section','Skills, software and qualifications sections'],
  how_to_use = ARRAY['Open the DOCX and replace the placeholder text with your own details.','List projects with your role, scope and measurable outcomes rather than duties alone.','Fill the compliance section with the audit, inspection or safety work you have handled.','Trim sections that do not apply so the CV stays focused on the target role.','Export to PDF before sending to preserve the layout.']
WHERE slug = 'electrical-engineer-cv-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Distribution, protection and earthing fundamentals are scattered across many separate sources, which slows down both study and day-to-day checking. This guide keeps the core reference material in one document.',
  who_for = 'Junior electrical engineers, students and site technicians who need a single refresher on installation fundamentals.',
  whats_included = ARRAY['PDF reference covering electrical distribution basics','Protection fundamentals section','Earthing fundamentals section','Reference material suitable for offline study'],
  how_to_use = ARRAY['Download the PDF and read the section relevant to your current task.','Use it as background reading before design work or site inspections.','Keep it available offline as a quick refresher on site.','Confirm any design decision against the project specification and the applicable local standards before applying it.']
WHERE slug = 'electrical-installation-guide' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Site electrical inspections carried out from memory miss items and produce records that cannot be compared between visits. This list fixes the scope of each inspection so nothing is skipped.',
  who_for = 'Site engineers, maintenance teams, safety officers and inspectors carrying out routine electrical safety walkthroughs.',
  whats_included = ARRAY['Printable PDF verification list','Panel and switchboard verification items','Cabling and containment verification items','Earthing verification items','Signage and labelling verification items'],
  how_to_use = ARRAY['Print the checklist or open it on a tablet before the walkthrough.','Work through each section in order and mark the result for every item.','Note the location and details for any item that fails.','Photograph failed items so the record carries evidence.','File the completed checklist and raise corrective actions for the open items.']
WHERE slug = 'electrical-safety-inspection-checklist' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Redrawing electrical symbols for every project wastes drafting time and produces drawings that look different from sheet to sheet. A shared block library removes both problems.',
  who_for = 'Electrical drafters and design engineers producing power, lighting and control drawings in AutoCAD.',
  whats_included = ARRAY['DWG file of reusable electrical symbol blocks','Power distribution symbols','Lighting symbols','Control and instrumentation symbols'],
  how_to_use = ARRAY['Open the DWG in AutoCAD or a compatible CAD application.','Copy the symbols you need into your project drawing, or insert the file as a block library.','Set the correct layer and scale for each inserted symbol.','Reuse the same blocks across all sheets so the drawing set stays consistent.','Confirm the symbols match the legend agreed for your project.']
WHERE slug = 'electrical-symbols-pack' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Connected and diversified loads are often summed in improvised spreadsheets, so the basis of a distribution board sizing decision cannot be reviewed. This sheet keeps that summary in a consistent, checkable format.',
  who_for = 'Electrical design engineers and estimators preparing load summaries for distribution boards.',
  whats_included = ARRAY['XLSX load schedule workbook','Connected load entry rows per load item','Diversity factor column','Diversified load summary per board'],
  how_to_use = ARRAY['Open the workbook and enter one row per connected load.','Apply the diversity factor agreed for your project — the sheet does not assume one for you.','Review the diversified totals for the board.','Cross-check the resulting current against your cable and protection sizing.','Save a copy per board and keep it with the design records.']
WHERE slug = 'load-schedule-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Air termination, down conductor and bonding arrangements are often drawn from scratch for every building, which is slow and makes review inconsistent. This base sheet provides a ready arrangement layout to adapt.',
  who_for = 'Electrical design engineers and consultants preparing lightning protection system drawings.',
  whats_included = ARRAY['DWG arrangement sheet','Air termination layout','Down conductor routing layout','Bonding arrangement details'],
  how_to_use = ARRAY['Open the DWG in AutoCAD or a compatible CAD application.','Adapt the arrangement to your building geometry and roof plan.','Adjust down conductor routes and bonding points to suit the structure.','Update the title block and drawing references for your project.','Have the completed design reviewed against the standards specified for your project.']
WHERE slug = 'lps-design-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Main distribution board single line diagrams are usually rebuilt sheet by sheet for every project, costing drafting hours and producing inconsistent presentation. This base sheet gives you a starting drawing to adapt.',
  who_for = 'Electrical design engineers and CAD drafters producing MDB single line diagrams.',
  whats_included = ARRAY['Base DWG sheet for an MDB single line diagram','Incomer and outgoing way arrangement','Layout structured for adding protection and cable data','Title block area for project details'],
  how_to_use = ARRAY['Open the DWG in AutoCAD or a compatible CAD application.','Adapt the incomer and outgoing ways to match your board schedule.','Add your protection ratings, cable sizes and circuit references from the project design.','Update the title block and revision details.','Have the completed diagram checked against the approved load and protection schedules.']
WHERE slug = 'mdb-sld-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Teams preparing for a Nirapon electrical assessment often work without a written scope, so preparation is uneven and gaps only surface during the assessment itself. This checklist sets out the electrical points to walk through beforehand.',
  who_for = 'Factory electrical and maintenance teams, compliance officers and consultants preparing for or supporting Nirapon electrical assessments.',
  whats_included = ARRAY['Printable PDF checklist structured for Nirapon electrical assessments','Grouped electrical assessment points','Space to record status per item','Format suitable for repeat pre-assessment rounds'],
  how_to_use = ARRAY['Print the checklist or open it on a tablet before the walkthrough.','Go through each item on site and record the observed status.','Record the location and detail for every item that is not in order.','Assign an owner and a target date to each open item.','Repeat the walkthrough before the assessment to confirm items have been closed.','Treat this as a preparation aid — always work to the current assessment criteria issued by the assessing body.']
WHERE slug = 'nirapon-electrical-checklist' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Circuit records kept as loose notes make it hard to see how load is distributed across phases or to hand a board over cleanly. This schedule keeps every circuit and the load balance summary in one sheet.',
  who_for = 'Electrical design engineers, panel builders and maintenance teams documenting distribution boards.',
  whats_included = ARRAY['XLSX panel schedule workbook','Circuit-by-circuit entry rows','Protection and cable reference columns','Load balance summary across phases'],
  how_to_use = ARRAY['Open the workbook and create a sheet per panel.','Enter one row per circuit with its description, protection and cable reference.','Enter the load for each circuit and review the phase balance summary.','Redistribute circuits between phases if the summary shows an imbalance.','Issue the completed schedule with the panel handover documentation.']
WHERE slug = 'panel-schedule-template' AND status = 'published';

UPDATE public.resources SET
  problem_solved = 'Electrical scope is often the least prepared part of an RSC inspection because teams have no written list to work from in advance. This checklist organises the electrical points into a structure that can be walked before the inspection.',
  who_for = 'Factory electrical and maintenance teams, compliance officers and consultants preparing for RSC electrical inspections.',
  whats_included = ARRAY['Printable PDF checklist structured around RSC electrical inspection points','Grouped electrical scope items','Space to record status and observations','Format suitable for repeat pre-inspection rounds'],
  how_to_use = ARRAY['Print the checklist or open it on a tablet before the walkthrough.','Work through each electrical scope item on site and record the status.','Note the location and detail for every item that is not in order.','Assign an owner and target date to each open item and track it to closure.','Re-walk the checklist before the inspection to confirm outstanding items are closed.','Treat this as a preparation aid — always work to the current inspection criteria issued by the inspecting body.']
WHERE slug = 'rsc-electrical-audit-checklist' AND status = 'published';