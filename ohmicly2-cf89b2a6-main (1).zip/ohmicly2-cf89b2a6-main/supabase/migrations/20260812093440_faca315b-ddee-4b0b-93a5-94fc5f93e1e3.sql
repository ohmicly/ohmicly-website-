UPDATE public.calculators
SET seo_description = 'Calculate electrical load current and apparent power for single-phase and three-phase circuits. Enter kW, voltage, power factor and quantity to get connected load (kW), kVA and line current (A).',
    updated_at = now()
WHERE slug = 'load-calculator';