# Premium page redesign

## Changes
- Replace the current Premium page hero, explanatory section, and basic card grid with the same browsing flow used on the Resources page.
- Keep the Premium page limited to real premium resources already loaded from the database.
- Reuse the Resources page structure: page heading, quick collection tabs, search, category filter, sorting, four-column resource cards, empty state, and pagination.
- Match resource cards exactly, including uploaded thumbnails and fallback previews.
- Add a prominent crown icon with a PRO label at the upper-right of every premium resource card; preserve the file-type badge at the upper-left.
- Keep each card linked to its existing resource detail page and retain the current global sidebar, header, footer, and mobile menu.

## Technical details
- Extract or extend the existing resource browser so the Premium route can use its established layout without duplicating filtering and card logic.
- Lock access to premium items on this page and adapt headings and labels for Premium Resources.
- Use existing semantic premium color tokens and the shared button components.

## Verification
- Check the Premium page at desktop and mobile widths.
- Verify thumbnails, PRO badges, search, filters, sorting, pagination, and resource links.
- Confirm type checks and the preview build complete without errors.
