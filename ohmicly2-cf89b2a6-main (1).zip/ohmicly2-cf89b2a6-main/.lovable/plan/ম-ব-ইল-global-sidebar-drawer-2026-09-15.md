# মোবাইল Global Sidebar Drawer

## কী পরিবর্তন হবে
- সব public page-এ শুধু mobile view-তে নিচের ডান কোণায় সবসময় দৃশ্যমান একটি floating menu icon থাকবে।
- icon চাপলে বাম দিক থেকে smooth animation-এ 75% প্রস্থের sidebar drawer খুলবে; content যত লম্বা হবে drawer-এর ভেতরে scroll করা যাবে।
- drawer-এ বর্তমান resource categories, subcategories, popular topics এবং premium link একই live data ও active state-সহ দেখানো হবে।
- backdrop, close button, বাইরে tap, Escape key এবং কোনো menu link বাছলে drawer বন্ধ হবে; খোলা অবস্থায় পেছনের page scroll বন্ধ থাকবে।
- বর্তমানে page-এর ওপরে থাকা mobile accordion sidebar সরানো হবে, যাতে একই menu দুই জায়গায় না দেখা যায়।
- 960px ও তার বেশি desktop view-এর বর্তমান sidebar এবং layout অপরিবর্তিত থাকবে।

## যাচাই
- mobile blog article ও অন্য public page-এ floating icon স্থির এবং সর্বোচ্চ layer-এ আছে কি না দেখা হবে।
- 320px ও 390px width-এ drawer-এর 75% width, animation, scrolling, close controls এবং active menu state পরীক্ষা করা হবে।
- 980px desktop-site simulation-এ floating icon লুকানো এবং বর্তমান desktop sidebar ঠিক থাকা যাচাই করা হবে।
- type check এবং preview build status যাচাই করা হবে।
