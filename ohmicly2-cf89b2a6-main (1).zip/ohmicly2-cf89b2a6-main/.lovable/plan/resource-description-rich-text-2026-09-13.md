# Resource Description Rich Text

## Goal
Add the existing rich-text formatting experience to the Description field in Add/Edit Resource, without changing uploads, resource fields, or calculators.

## Changes
- Replace the plain Description box with the existing formatting editor for bold, italic, headings, quotes, lists, links, dividers, and line breaks.
- Render formatted descriptions safely on the public resource detail page.
- Keep compact resource cards and search results readable by converting formatted descriptions to plain text there.
- Preserve existing plain-text resource descriptions.

## Verification
- Confirm a formatted description saves and renders correctly.
- Check old plain-text descriptions still display normally.
- Run the project type check and verify the latest app build is healthy.
