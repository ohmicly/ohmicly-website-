# Blog Dashboard Redesign and CMS Completion

## Goal
Redesign only the public blog experience to match the supplied dashboard reference while preserving OHMICLY's global navigation, footer, colors, and typography. Keep every article connected to the existing admin CMS and its deep-linked public page.

## Public blog
- Replace the simple `/blog` grid with a responsive content dashboard: breadcrumb and editorial heading, search, category filters with live counts, featured article, paginated article cards, and a popular-articles rail.
- Use only real published article records. Search, category selection, and pagination will use URL parameters so filtered views are linkable and browser navigation works.
- Keep cards linked to `/blog/{slug}` and upgrade the article page presentation with cover image, publication metadata, readable article content, references, and related articles.
- On mobile, stack the content cleanly and expose filters without a permanent narrow sidebar.
- Do not change the shared navigation or footer.

## Admin blog CMS
- Complete the current article editor with author, SEO title, cover-image URL, canonical URL, status, category, reading time, tags, excerpt, and body controls.
- Preserve working create, edit, publish/archive, and delete actions, with clear success/error states and a direct public preview link for published posts.
- Continue using the existing role-protected dashboard and article/category tables; no new backend tables or permission changes.

## Technical details
- Extend the public article mapping to include cover image and category slug needed by the dashboard UI and article metadata.
- Build focused blog UI components rather than changing shared site components.
- Preserve existing SEO helpers and add the article cover to structured data/page metadata only when a valid absolute image URL exists.
- Verify desktop and mobile layouts, deep links, URL filters, empty states, and the admin article workflow against the running preview.
