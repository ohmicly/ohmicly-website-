# Calculator URL and browser redesign

## What will change
- Move the calculator listing from `/tools` to `/calculator`, and every calculator detail page to `/calculator/{calculator-name}`.
- Update navigation, homepage links, related-calculator links, breadcrumbs, canonical metadata, reports, and sitemap entries to the new calculator URLs.
- Keep old `/tools` and `/tools/{calculator-name}` links working through permanent redirects to their matching new URLs.

## Calculator page design
- Match the Resources page flow: page heading, compact horizontally scrollable highlight cards, compact controls, results grid, and pagination.
- Replace the existing large blue statistics band with four small cards: **7+ Calculators**, **Accurate Result**, **Engineering Focus**, and **Free to Use**.
- Keep all four cards in one horizontal row on mobile with left-right scrolling and no page overflow.
- Keep calculator cards, existing calculator data, and working calculation engines unchanged.

## Search, filter, and sort
- Show only the search field and one combined Filter/Sort icon in a single row.
- Clicking that icon opens one compact panel containing calculator categories and sort choices.
- Clearly highlight selected category and sort options, show an active-filter count on the icon, and update results immediately.
- Remove the separate category and sort dropdowns while preserving search, filtering, sorting, pagination, and URL state.

## Verification
- Verify `/calculator` opens without default query parameters.
- Verify category, sort, search, reset, active states, cards, and pagination on desktop and mobile.
- Verify detail links use `/calculator/...`, old `/tools...` links redirect correctly, and the build is clean.

## Technical details
- Use TanStack file routes for the new URLs and route-level redirects for backward compatibility.
- Strip default search values so the clean listing URL remains `/calculator`.
- Limit visual changes to the calculator browser; calculator detail-page content and calculation logic remain untouched.
