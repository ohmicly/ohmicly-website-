# Calculator detail page layout and references

## What will change
- Fix calculator forms, result cards, tables, formulas, and supporting content so nothing is cut off at 390px mobile width.
- Keep the main calculator in a wide single-column layout at mobile-browser “Desktop site” widths; the related-content sidebar will only sit beside it on genuinely wide screens.
- Move each long “About this … calculation” introduction below its calculator and method content, so users reach the inputs first.
- Replace the narrow sidebar reference card with a stronger, highlighted “Applicable references” block directly below the calculator result area. It will use only the references already stored for that calculator.
- Keep related calculators, resources, and articles available below or beside the main content according to available width.

## Technical details
- Preserve all formulas, validation, PDF export, admin-managed disclaimer, SEO metadata/schema, links, authentication, and backend data.
- Add shared responsive safeguards (`min-width: 0`, wrapping, and contained horizontal scrolling only where tabular data requires it).
- Use the existing semantic color system to make references visually prominent without redesigning the rest of the page.

## Verification
- Check all four live calculators at 390px mobile width, 980px desktop-site simulation, and 1280px desktop.
- Run calculations and confirm results, highlighted references, PDF action, related links, and disclaimer placement.
- Confirm no horizontal page overflow and a clean preview build.
