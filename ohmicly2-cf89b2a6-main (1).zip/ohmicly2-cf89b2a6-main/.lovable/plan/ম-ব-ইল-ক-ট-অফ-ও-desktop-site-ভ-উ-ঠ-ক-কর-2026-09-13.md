# মোবাইল কাট-অফ ও Desktop Site ভিউ ঠিক করা

## কী পরিবর্তন হবে
- ছোট ফোনে Blog-এর featured article এবং অন্য public page-এর content যেন ডানদিকে কেটে না যায়, তার জন্য সংকুচিত হতে না-পারা grid/child width ঠিক করা হবে।
- সাইটের desktop layout চালু হওয়ার সীমা 1024px থেকে 960px করা হবে, যাতে মোবাইল browser-এর “Desktop site” মোডের সাধারণ 980px viewport-এ পূর্ণ desktop header, sidebar ও multi-column layout দেখা যায়।
- viewport-এ safe-area সমর্থন যোগ করা হবে, যাতে notch/edge থাকা ফোনেও content নিরাপদ থাকে।

## যাচাই
- 320px, 390px এবং বর্তমান 649px mobile width-এ public pages পরীক্ষা করা হবে।
- 980px “Desktop site” simulation-এ desktop menu, sidebar ও desktop homepage composition সক্রিয় হচ্ছে কি না দেখা হবে।
- Type check এবং preview build status যাচাই করা হবে।

## সীমা
- কোনো content, backend, calculator formula, auth, upload/download flow বা navigation destination পরিবর্তন হবে না।
