# Redirect RSC resources to Resources

## Changes
- Replace the `/rsc` page with a permanent redirect to `/resources`.
- Update homepage RSC resource cards and “View all” links to open `/resources`.
- Update other visible RSC links and remove `/rsc` from the sitemap.
- Verify the redirect and links on the live preview.
