# মোবাইল Blog Reading Layout ঠিক করা

## পরিবর্তন
- Blog article page থেকে global বাম sidebar সরিয়ে reading area-কে পূর্ণ প্রস্থ দেওয়া হবে। এতে মোবাইলের “Desktop site” মোডেও মাঝখানের লেখা অস্বাভাবিক সরু হবে না।
- References ও related articles-এর ডান sidebar শুধু যথেষ্ট প্রশস্ত desktop screen-এ পাশে থাকবে; ছোট desktop/mobile width-এ এটি লেখার নিচে চলে যাবে।
- Article title, paragraph, link, image, list, quote, table ও code block-এ দীর্ঘ content নিরাপদভাবে wrap বা horizontal scroll করবে, যাতে ডানপাশে লেখা কেটে না যায়।
- Blog listing, navigation, footer, article content এবং অন্য কোনো page পরিবর্তন হবে না।

## যাচাই
- 320px ও 390px mobile width-এ article body ডানদিকে overflow করছে কি না পরীক্ষা করা হবে।
- 980px Desktop Site simulation-এ reading column যথেষ্ট প্রশস্ত এবং side content নিচে আছে কি না পরীক্ষা করা হবে।
- 1280px desktop-এ article ও ডান sidebar-এর ভারসাম্য পরীক্ষা করা হবে।
- Type check এবং preview build status যাচাই করা হবে।
