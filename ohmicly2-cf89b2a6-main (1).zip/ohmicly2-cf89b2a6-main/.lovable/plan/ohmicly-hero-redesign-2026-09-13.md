# OHMICLY Hero Redesign

## লক্ষ্য
শুধু হোমপেজের hero অংশটি দেওয়া রেফারেন্সের মতো পরিষ্কার, প্রিমিয়াম ও electrical-compliance focused ডিজাইনে বদলানো হবে। Header এবং hero-এর নিচের সব অংশ অপরিবর্তিত থাকবে।

## ডিজাইন
- হালকা সাদা/পেল-ব্লু ব্যাকগ্রাউন্ডে বামে বড় navy ও electric-blue headline, ছোট supporting text এবং দুটি button থাকবে।
- ডানে OHMICLY-এর জন্য নতুন, মৌলিক electrical substation ও safety-gear image তৈরি করা হবে; রেফারেন্সের ছবি বা অন্য প্রতিষ্ঠানের logo কপি করা হবে না।
- RSC, NIRAPON এবং safety resource-এর তিনটি compact floating link ছবির পাশে সুশৃঙ্খলভাবে থাকবে।
- ছোট amber accent থাকবে, তবে blue palette-ই প্রধান থাকবে।
- 1280×720 স্ক্রিনে header-সহ hero সম্পূর্ণ দৃশ্যমান থাকবে; mobile-এ content পরিষ্কারভাবে stacked হবে এবং কোনো অংশ কাটা যাবে না।

## বাস্তবায়ন
- বর্তমান `Hero` অংশটিই সীমিতভাবে পুনর্গঠন করা হবে।
- নতুন image project asset হিসেবে সংরক্ষণ ও hero-তে ব্যবহার করা হবে।
- বিদ্যমান `/resources` এবং `/tools` action বজায় থাকবে।
- desktop ও mobile preview, overflow এবং build status যাচাই করা হবে।
