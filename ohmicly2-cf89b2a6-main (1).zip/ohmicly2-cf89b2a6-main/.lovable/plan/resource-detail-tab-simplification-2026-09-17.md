# Resource Detail Tab Simplification

## Goal
Simplify every resource detail page to four distinct tabs while preserving previews, downloads, premium access, routing, structured data, and the existing responsive design.

## Changes
- Keep the preview gallery above the tabs and remove only the redundant **Preview** tab.
- Set the tab order to exactly **Description | References | Details | FAQs**, with mobile horizontal scrolling retained.
- Rework **Description** to show only available resource-specific content: description, problem solved, audience, included items, usage steps, and genuine related resources, calculators, and articles already returned by the current loader.
- Rework **References** to show only stored references and the requested empty message when none exist.
- Rework **Details** into one scannable metadata list using existing values such as file type, access, filename/size when present, updated date, category, subcategory, author, and downloads.
- Rework **FAQs** to show only stored published FAQs and the requested empty message when none exist.
- Remove public SEO/keyword/recommended-for copy, repeated tags/details, and all other duplicate tab content. Keep those database fields and the existing metadata/schema behavior intact.
- Keep one Engineering Disclaimer near the bottom of the page.
- Pass the already-loaded related calculators and articles into the detail view; do not fabricate missing content or add database fields.

## Technical Notes
- Extend the public resource view model only for existing `file_name` and `file_size` values so Details can display them when available.
- Do not change file storage, signed URLs, download tracking, authentication, entitlement checks, database schema, category logic, or admin editing.
- Preserve conditional FAQPage schema, references in CreativeWork schema, canonical/robots/indexability rules, breadcrumbs, and image behavior.

## Verification
- Check desktop and 390px layouts for overflow, tab usability, responsive previews, and accessible download actions.
- Exercise free and premium resources, plus resources with and without FAQs/references.
- Confirm related links, preview controls, and download/sign-in flows still work.
- Confirm page metadata, canonical/robots tags, breadcrumb/CreativeWork schema, and conditional FAQ schema remain unchanged and valid.
- Verify the latest app build and runtime diagnostics are healthy.
