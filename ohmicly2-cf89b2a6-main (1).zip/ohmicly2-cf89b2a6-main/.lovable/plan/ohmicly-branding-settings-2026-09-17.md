# OHMICLY Branding Settings

## Goal
Add an incremental admin-only Branding area for configuring the site logo and favicon, while preserving the current OHMICLY mark and favicon as fallbacks and leaving all unrelated behavior unchanged.

## What will be built

### Admin experience
- Add a **System → Branding** entry in the existing admin navigation and a protected `/admin/branding` page matching the current CMS styles.
- Provide separate Logo and Favicon panels with current preview, filename, upload/replace, remove, confirmation prompts, progress, success/error feedback, and pending/dirty state.
- Logo accepts SVG, PNG, and WebP. Favicon accepts SVG, PNG, and ICO and must be square.
- Keep controls and previews usable at 390px without changing the public site design.

### Storage and settings
- Create a private `site-assets` bucket with a 2 MB bucket limit and admin-only object policies restricted to `branding/logo/` and `branding/favicon/`.
- Reuse `site_settings` with one validated `branding` record holding storage paths and safe metadata; do not add another settings table.
- Tighten public `site_settings` access to the small allowlist needed by the site.
- Use the existing authenticated server-function pattern: every prepare/finalize/remove action re-checks the caller's database role before privileged storage access.
- Upload to unique paths, validate the uploaded bytes and metadata server-side before activating them, atomically replace the setting, and delete superseded or invalid objects to prevent orphans.

### Validation and delivery
- Enforce extension, claimed MIME, detected file signature/content, and size on the server; mirror checks in the browser for fast feedback.
- Enforce square favicon dimensions server-side, including PNG, ICO, and SVG geometry. Reject unsafe/active SVG content and serve accepted SVGs with restrictive security headers.
- Add a narrow public image endpoint that accepts only `logo` or `favicon`, resolves the active path internally, and streams the private object with MIME, ETag, and cache headers. Storage paths and privileged credentials never reach the browser.
- Version public asset URLs from the saved asset revision so replacements invalidate caches immediately without permanent signed URLs.

### Public integration
- Load the safe public branding state once at the root and expose it through a small branding context.
- Update the existing `Logo` component so header and footer use the configured logo with fixed responsive dimensions; retain the current inline OHMICLY logo/wordmark when unset or if the custom image fails.
- Set the configured favicon in the document head, falling back to the existing `/favicon.ico`.
- Add the same single configured logo URL to the existing Organization JSON-LD only when a custom logo exists; do not add schemas or alter any other SEO tags.

## Technical details
- Add focused branding schemas/helpers for setting parsing, safe public DTOs, file sniffing, image dimension checks, SVG safety checks, and asset URL generation.
- Add dedicated branding server functions rather than widening the generic resource upload functions.
- Add `/api/public/site-asset?kind=logo|favicon&v=…` as the only public delivery surface for private branding objects.
- Keep the current CSRF middleware, authenticated route gate, bearer attachment, and server-side role checks intact.

## Verification
- Run focused tests for allowed/rejected formats, size limits, square favicon validation, unsafe SVG rejection, settings parsing, and fallback behavior.
- Verify authenticated upload/replace/remove lifecycle and orphan cleanup using temporary test assets without leaving a custom logo/favicon active.
- Verify unauthenticated mutation calls return unauthorized and public delivery exposes only the two configured asset kinds.
- Check header/footer logo, document favicon, Organization JSON-LD, and fallback rendering in the preview.
- Check `/`, `/resources`, a resource detail page, `/calculator`, and `/blog` for regressions.
- Check the Branding page and public header/footer at 390px for overflow and layout shift.
- Run `bunx tsgo --noEmit`, targeted tests, and confirm the latest preview build is clean.

## Explicitly unchanged
- Resource/download file buckets and signed-download flow.
- Existing routes, visual design, calculators, resources, articles, authentication, SEO titles/descriptions/canonicals/robots/sitemap/breadcrumbs, and unrelated admin features.
- The current OHMICLY logo and favicon remain the defaults until an admin deliberately saves replacements.
