# Resources filter redesign

## What will change
- Replace the five summary counters with clickable quick tabs: **All Resources**, **RSC Audit Templates**, **Nirapon Checklist**, **Fire & Safety**, and **AutoCAD Templates**.
- Make each tab update the resource results instantly and clearly highlight the selected tab.
- Replace the current multi-row filter area with one compact row containing only **Search**, a **Filter** icon button, and **Sort by**.
- Open a compact filter panel from the Filter button containing the live main categories plus Free/Premium access choices.
- Preserve existing sidebar filtering, resource cards, pagination, and page data.

## Responsive behavior
- Keep the three filter controls on one line at desktop widths.
- Use compact widths and horizontally scrollable quick tabs on smaller screens without page overflow.

## Verification
- Check tab, category, access, search, sort, reset, active-state, and pagination behavior.
- Verify the page at desktop and mobile sizes and confirm a clean build.

## Technical details
- Limit changes to the resources browser presentation and its local filtering state.
- Derive quick-tab matches from each resource’s title, category, subcategory, type, and tags so existing published content is used without database changes.
