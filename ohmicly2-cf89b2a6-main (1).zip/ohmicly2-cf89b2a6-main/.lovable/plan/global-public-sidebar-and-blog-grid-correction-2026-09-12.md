# Global Public Sidebar and Blog Grid Correction

## Goal
Replace the blog-only topic rail with one reusable public left sidebar modeled on the Resources page, while keeping the existing global top navigation and footer unchanged. Change the blog listing to a four-column article grid on wide screens.

## Global public sidebar
- Add one shared left sidebar to public content pages through the existing page layout, excluding the homepage, sign-in/reset, account, and admin screens.
- Load active resource categories from the existing dashboard-managed category records, so creating, renaming, ordering, activating, or deactivating a category in Admin automatically updates the sidebar.
- Link category items to the filtered Resources page and show current published-resource counts.
- Add a “Popular topics” group derived automatically from published resource tags, ranked primarily by views and downloads and secondarily by content frequency.
- If engagement data or tags are insufficient, show a small built-in fallback topic set that links to Resources search/filter results.
- Keep the sidebar sticky on desktop and provide a compact expandable browser on smaller screens so it remains usable without reducing the main reading area.
- Remove duplicate page-local category sidebars where the shared sidebar replaces them, especially Resources and resource detail pages.

## Blog page
- Keep URL-driven blog search, categories, pagination, published-record loading, and article deep links.
- Remove the current blog-specific left topic rail because the shared sidebar now occupies that role.
- Keep the editorial heading/search and useful article controls in the content area.
- Render article cards in four columns on sufficiently wide screens, reducing responsively to two and one columns on smaller screens.
- Keep the right-side popular-article panel only where screen width permits without squeezing the four-column article grid.

## Technical details
- Reuse existing `resource_categories`, `view_count`, `download_count`, tags, and public content functions; no new table or permission change is needed for this correction.
- Search popularity is not currently persisted. The initial ranking will use real views/downloads and tag frequency; it can incorporate search volume later if search-event storage is added.
- Preserve route-specific metadata, global navigation, footer, auth protections, and admin workflows.
- Verify public desktop/mobile pages, resource category links, fallback topics, blog filtering/pagination, article deep links, and four-column behavior.
